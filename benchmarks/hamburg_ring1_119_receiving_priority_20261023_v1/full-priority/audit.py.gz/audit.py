"""Reuse the sealed native evidence reader; never launch a simulation."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.junction_split_fanout import _canonical
from astra_sumo.core.local_network_conversion import _index, _owner

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / 'outputs/hamburg-197-through-support-20261023-v1/full'
CANDIDATE = ROOT.parent / 'candidate-priority-v3'
sys.path.insert(0, str(REPO / 'outputs/hamburg-multifield-substitution-20261023-v1/response-audit'))
import audit_response as evidence  # noqa: E402
from audit_scope import digest  # noqa: E402


def check_inputs():
    preflight = json.loads((ROOT / 'preflight.json').read_bytes())
    assert all(digest(Path(p)) == h for p, h in preflight['source_hashes'].items())
    prepared = ROOT / 'prepared'
    assert all(digest(prepared / p) == h for p, h in preflight['prepared_hashes'].items())
    proof = json.loads((CANDIDATE / 'manifest.json').read_bytes())
    assert proof['status'] == 'review_required' and len(proof['checks']) == 10 and all(proof['checks'].values())
    assert proof['checks']['outside_scope_order_and_semantics_identical']
    for name, field in [('network.net.xml', 'candidate_sha256'), ('control.add.xml', 'control_sha256')]:
        assert digest(prepared / name) == digest(CANDIDATE / name) == proof[field]
    fixed = ['demand.rou.xml', 'lane-intentions.json', 'field-loops.add.xml', 'expected-counts.csv', 'initialization-counts.csv']
    assert all((prepared / p).read_bytes() == (SOURCE / 'prepared' / p).read_bytes() for p in fixed)
    assert all((ROOT / 'evaluation' / p).read_bytes() == (SOURCE / 'evaluation' / p).read_bytes() for p in fixed[:2])
    vehicles = ET.parse(prepared / 'demand.rou.xml').getroot().findall('vehicle')
    intentions = json.loads((prepared / 'lane-intentions.json').read_bytes())['vehicles']
    assert len(vehicles) == len(intentions) == 8640
    assert {v.get('id') for v in vehicles} == {r['vehicle_id'] for r in intentions}
    before, after = [ET.parse(p).getroot() for p in [SOURCE / 'prepared/network.net.xml', prepared / 'network.net.xml']]
    def lengths(tree):
        return {lane.get('id'): float(lane.get('length')) for edge in tree.findall('edge') for lane in edge.findall('lane')}
    assert lengths(before) == lengths(after)
    assert lengths(after)['79014037#1_1'] == lengths(after)['79014037#1_0'] == 3.46
    def outside(tree):
        index = _index(tree)
        return [_canonical(c) for c in tree if _owner(c, index) != '266199063' and not(c.tag == 'tlLogic' and c.get('id') == 'GS_266199063')]
    assert outside(before) == outside(after)
    old = next(j for j in before.findall('junction') if j.get('id') == '266199063')
    new = next(j for j in after.findall('junction') if j.get('id') == '266199063')
    assert new.get('type') == 'priority'
    assert [dict(r.attrib) for r in old.findall('request')] == [dict(r.attrib) for r in new.findall('request')]
    assert len(new.findall('request')) == 6
    assert preflight['run_parameters']['junction_body_hold_nodes'] == ['14398547', '205069138', '18653534', 'LSA104_part0']
    return {'status': 'pass', 'native_runs_by_check': 0, 'N': 8640, 'candidate_scope_checks': proof['checks'],
        'outside_scope_order_and_semantics_identical': True, 'all_lane_lengths_exact': True, '790_lane_lengths_m': [3.46, 3.46],
        'six_requests_identical_to_reference': True, 'demand_intentions_and_real_observation_bytes_identical': True,
        'candidate_network_sha256': proof['candidate_sha256'], 'candidate_control_sha256': proof['control_sha256']}


def audit_result():
    scope = check_inputs()
    data = []
    for case in (SOURCE, ROOT):
        data.append(evidence.evidence(case / 'prepared', case / 'evaluation', case / 'evaluation/contributing-passages.json.gz', 8640))
    reference, current = data
    assert reference['periodic'].keys() == current['periodic'].keys()
    intentions = {r['vehicle_id']: r['field_id'] for r in json.loads((ROOT / 'prepared/lane-intentions.json').read_bytes())['vehicles']}
    assert set(current['by_vehicle']) <= intentions.keys()
    repeated = [{'vehicle_id': identity, 'field': f, 'count': n} for identity, events in current['by_vehicle'].items() for f, n in Counter(e['detector_id'] for e in events).items() if n > 1]
    extra = [{'vehicle_id': identity, 'actual_field': e['detector_id'], 'intended_field': intentions[identity]} for identity, events in current['by_vehicle'].items() for e in events if e['detector_id'] != intentions[identity]]
    output = ROOT / 'independent-audit'
    output.mkdir(exist_ok=True)
    for name in ['main', 'initial', 'stations']:
        evidence.table(output / f'{name}-comparison.csv', current[name])
    evidence.table(ROOT / 'evaluation/all182-comparison.csv', current['initial'] + current['main'])
    field_rows = []
    for field in sorted({k[0] for k in current['periodic']}):
        row = {'field': field}
        for label, d in [('reference', reference), ('candidate', current)]:
            row.update({f'{label}_{k}': v for k, v in evidence.metrics([r for r in d['main'] if r['detector_id'] == field]).items()})
        field_rows.append(row)
    evidence.table(output / 'field13-main.csv', field_rows)
    fields535 = {'hh_0535_Z_5_30894', 'hh_0535_Z_6_33855', 'hh_0535_Z_7_29316', 'hh_0535_Z_8_34287'}
    checks535 = {}
    for label, d in [('reference', reference), ('candidate', current)]:
        rows = [r for r in d['initial'] + d['main'] if r['detector_id'] in fields535]
        assert len(rows) == 56
        checks535[label] = evidence.metrics(rows)
        evidence.table(output / f'{label}-535-all56.csv', rows)
    assert checks535['reference']['TAE'] == 0
    valid = current['safe'] and not repeated and not extra
    formal = valid and current['healthy'] and current['metrics130']['TAE'] == 0 and checks535['candidate']['TAE'] == 0
    report = {'status': 'diagnostic_candidate' if valid else 'invalid', 'formal_result': formal,
        'scope': scope, 'before': reference['recorded'], 'after': current['recorded'],
        'reference': {k: reference[k] for k in ['metrics130', 'metrics52', 'metrics182', 'station40_MAE', 'completion', 'safe', 'healthy']},
        'candidate': {k: current[k] for k in ['metrics130', 'metrics52', 'metrics182', 'station40_MAE', 'completion', 'safe', 'healthy', 'event_count']},
        'all182_TAE': current['metrics182']['TAE'], 'native208_rows': len(current['periodic']), '535_all56': checks535,
        '535_zero56_retained': checks535['candidate']['TAE'] == 0, 'repeated_vehicle_fields': repeated,
        'contributions_outside_prior_primary_intention': extra,
        'unfinished': {label: d['completion']['waiting'] + d['completion']['running'] for label, d in [('reference', reference), ('candidate', current)]},
        'source_hashes': {label: d['source_hashes'] for label, d in [('reference', reference), ('candidate', current)]},
        'diagnostic_selection_authority': False,
        'claim_boundary': 'Conditional inferred GS signal to native priority comparison, including uncertain603-major/790-minor ROW. All130/40/52/182 and all53556 rows are retained; no score or unfinished gate is silently dropped. Diagnostic status is not field control validation or promotion. Formal130zero and healthy completion remain separate from unknown field control ownership.'}
    evidence.save(output / 'audit.json', report)
    evidence.save(output / 'manifest.json', {'native_runs': 0, 'files': [{'path': p.name, 'size_bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(output.iterdir()) if p.is_file() and p.name != 'manifest.json']})
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope-only', action='store_true')
    args = parser.parse_args()
    result = check_inputs() if args.scope_only else audit_result()
    evidence.save(ROOT / ('input-proof.json' if args.scope_only else 'independent-audit-result.json'), result)
    print(json.dumps(result, ensure_ascii=False))
