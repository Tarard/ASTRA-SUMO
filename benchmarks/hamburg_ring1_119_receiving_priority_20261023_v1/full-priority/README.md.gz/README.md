# GS266 priority 完整对照（已准备，未启动）

仅检验独立推断GS控制对同一8640需求的影响。候选为 `candidate-priority-v3`；保留197 v5网络其余部分、全部道路长度、六个合法合流movement和权限、119及上游真实信号。原生ROW取603优先、790四项让行；真实让行方向和独立GS灯头仍未知。这不是现场SPaT，也不是撤控结论。

复用197 v5完整运行与既有独立原生计数读入函数。需求、意图、130项真实主窗计数及52项真实初始化计数按原字节保留。40项为派生站点汇总。仿真比较量是原生E1 nVehContrib，不能把真实观测称为SUMO E1。

运行前必须通过10项候选范围检查、范围外元素顺序与语义、全部车道长度、3.46m接收普通边、源/准备/运行代码哈希。参数仍为项目Libsumo1.27.1、0.1s、14400s、seed104和原4处body hold。`--prepare-only`不会启动SUMO。

碰撞、传送、discard、缺测、未完整结束或贡献无法对账，先标invalid并保留原始产物。始终报告130/40/52/182全部行、原生208区间、535已零的全部56项和waiting/running/unfinished。单项改善不能替代其他结果；安全且齐全只给诊断状态，不自动选用。正式130零误差与healthy完成仍未达到。预设条件见 `plan.json`。

项目根目录中，离线核对：

```powershell
.venv/Scripts/python.exe outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/audit.py --scope-only
```

root完成合流smoke审查后，可显式启动一次；此命令当前未执行：

```powershell
.venv/Scripts/python.exe outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/run.py --run
```

该入口拒绝覆盖已有native目录或verdict。结束后自动用既有函数独立重算所有计数、完成情况和完整贡献；不调用OD生成器、不再改候选。
