"""Audit only a sealed14400s priority result, using the established raw readers."""

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
CURRENT = STUDY / "full-priority"
SOURCE = REPO / "outputs/hamburg-197-through-support-20261023-v1/full"
HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPERS))
import audit_response as audit  # noqa: E402
from summarize_response import backlog  # noqa: E402


FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}
FIELD119Z5 = "hh_0119_Z_5_30494"


def scope():
    prepared = CURRENT / "prepared"
    preflight = json.loads((CURRENT / "preflight.json").read_bytes())
    assert all(audit.digest(Path(path)) == value for path, value in preflight["source_hashes"].items())
    assert all(audit.digest(prepared / path) == value for path, value in preflight["prepared_hashes"].items())
    for name in ["demand.rou.xml", "lane-intentions.json", "expected-counts.csv", "initialization-counts.csv", "field-loops.add.xml"]:
        assert (prepared / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    assert all((CURRENT / "evaluation" / name).read_bytes() == (SOURCE / "evaluation" / name).read_bytes()
        for name in ["demand.rou.xml", "lane-intentions.json"])
    scenarios = [json.loads((case / "prepared/scenario.json").read_bytes()) for case in [SOURCE, CURRENT]]
    changed = {key for key in set(scenarios[0]) | set(scenarios[1]) if scenarios[0].get(key) != scenarios[1].get(key)}
    assert changed <= {"network_sha256", "control_sha256", "control_variant", "control_assumptions"}
    manifest = json.loads((STUDY / "candidate-priority-v3/manifest.json").read_bytes())
    assert len(manifest["checks"]) == 10 and all(manifest["checks"].values())
    for name, key in [("network.net.xml", "candidate_sha256"), ("control.add.xml", "control_sha256")]:
        assert audit.digest(prepared / name) == audit.digest(STUDY / "candidate-priority-v3" / name) == manifest[key]
    vehicles = {v.get("id"): v for v in ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")}
    signatures = {r["vehicle_id"]: [r["field_id"]] for r in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
    assert vehicles.keys() == signatures.keys() and len(vehicles) == 8640
    proof = {"status": "pass", "native_reads": False, "N": 8640, "all_demand_intentions_real_targets_bytes_identical": True,
        "scenario_changed_keys": sorted(changed), "candidate_network_sha256": manifest["candidate_sha256"],
        "candidate_control_sha256": manifest["control_sha256"], "scope_checks_as_recorded": manifest["checks"],
        "source_hashes": preflight["source_hashes"], "prepared_hashes": preflight["prepared_hashes"]}
    return proof, vehicles, signatures


def seal():
    audit.save(OUT / "manifest.json", {"native_runs_by_audit": 0, "files": [
        {"path": path.relative_to(OUT).as_posix(), "size_bytes": path.stat().st_size, "sha256": audit.digest(path)}
        for path in sorted(OUT.rglob("*")) if path.is_file() and path != OUT / "manifest.json" and "__pycache__" not in path.parts]})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope-only", action="store_true")
    args = parser.parse_args()
    proof, vehicles, signatures = scope()
    audit.save(OUT / "input-proof.json", proof)
    if args.scope_only:
        print(json.dumps({"status": "pass", "N": 8640, "native_reads": False}))
        return
    runtime_path, verdict_path = CURRENT / "runtime.json", CURRENT / "verdict.json"
    assert verdict_path.exists() and json.loads(runtime_path.read_bytes())["status"] == "terminal", "No sealed verdict: do not read in-progress nativeXML"
    verdict = json.loads(verdict_path.read_bytes())
    assert verdict["status"] != "invalid", "The run was recorded invalid; preserve failure rather than parsing partial output"
    before, after = [audit.evidence(case / "prepared", case / "evaluation", case / "evaluation/contributing-passages.json.gz", 8640) for case in [SOURCE, CURRENT]]
    assert before["periodic"].keys() == after["periodic"].keys()
    assert verdict["before"] == before["recorded"] and verdict["after"] == after["recorded"]
    assert set(after["by_vehicle"]) <= signatures.keys()
    main_keys = {audit.key(row) for row in after["main"]}
    initial_keys = {audit.key(row) for row in after["initial"]}
    target = {audit.key(row): int(row["expected_total"]) for row in after["initial"] + after["main"]}
    rows208 = []
    for key in sorted(after["periodic"], key=lambda k: (k[1], k[0])):
        a, b = [int(data["periodic"][key]["nVehContrib"]) for data in [before, after]]
        expected = target.get(key)
        rows208.append({"field": key[0], "begin_s": key[1], "end_s": key[2],
            "region": "main" if key in main_keys else "initialization" if key in initial_keys else "tail",
            "real_target": expected if expected is not None else "", "before_count": a, "after_count": b,
            "count_change": b - a, "before_residual": a - expected if expected is not None else "",
            "after_residual": b - expected if expected is not None else ""})
    audit.table(OUT / "native208-before-after.csv", rows208)
    all182 = [row for row in rows208 if row["region"] != "tail"]
    audit.table(OUT / "real182-before-after.csv", all182)
    main130 = [row for row in all182 if row["region"] == "main"]
    audit.table(OUT / "main130-before-after.csv", main130)
    audit.table(OUT / "initial52-before-after.csv", [row for row in all182 if row["region"] == "initialization"])
    field_rows = []
    for field in sorted({row["field"] for row in rows208}):
        record = {"field": field}
        for label, data in [("before", before), ("after", after)]:
            record.update({label + "_" + key: value for key, value in audit.metrics([r for r in data["main"] if r["detector_id"] == field]).items()})
            for region in ["main", "initialization", "tail"]:
                record[label + "_" + region + "_events"] = sum(row[label + "_count"] for row in rows208 if row["field"] == field and row["region"] == region)
        record["SSE_change"] = record["after_SSE"] - record["before_SSE"]
        record["TAE_change"] = record["after_TAE"] - record["before_TAE"]
        field_rows.append(record)
    audit.table(OUT / "field13-errors-and-regions.csv", field_rows)
    assert sum(row["SSE_change"] for row in field_rows) == after["metrics130"]["SSE"] - before["metrics130"]["SSE"]
    stations = []
    for a, b in zip(before["stations"], after["stations"]):
        assert all(a[key] == b[key] for key in ["station_stream_id", "begin", "end", "expected_total"])
        stations.append({**{key: a[key] for key in ["station_stream_id", "begin", "end", "expected_total"]},
            "before_count": a["measured_nVehContrib"], "after_count": b["measured_nVehContrib"],
            "before_residual": a["residual"], "after_residual": b["residual"], "independent_evidence": False})
    audit.table(OUT / "station40-before-after.csv", stations)
    rows535 = [row for row in all182 if row["field"] in FIELDS535]
    assert len(rows535) == 56 and all(row["before_residual"] == 0 for row in rows535)
    audit.table(OUT / "535-all56-before-after.csv", rows535)
    audit.table(OUT / "119Z5-main10-before-after.csv", [row for row in main130 if row["field"] == FIELD119Z5])
    audit.table(OUT / "largest20-main-residuals.csv", sorted(main130, key=lambda row: (-abs(row["after_residual"]), row["field"], row["begin_s"]))[:20])
    unwanted = [{"vehicle_id": identity, **audit.event_view([event])[0]} for identity, events in after["by_vehicle"].items()
        for event in events if event["detector_id"] not in signatures[identity]]
    repeats = [{"vehicle_id": identity, "field": field, "count": count} for identity, events in after["by_vehicle"].items()
        for field, count in Counter(event["detector_id"] for event in events).items() if count > 1]
    terminal = {}
    for label, case in [("before", SOURCE), ("after", CURRENT)]:
        terminal[label] = backlog(case / "evaluation", signatures)
        audit.table(OUT / (label + "-terminal-vehicles.csv"), terminal[label][0])
    terminal_rows = []
    for row in terminal["after"][0]:
        identity = row["vehicle_id"]
        terminal_rows.append({**row, "requested_departure_s": vehicles[identity].get("depart"),
            "before_actual_events": audit.event_view(before["by_vehicle"].get(identity, [])),
            "after_actual_events": audit.event_view(after["by_vehicle"].get(identity, [])),
            "before_arrival_s": before["tripinfo"].get(identity, {}).get("arrival"),
            "after_arrival_s": after["tripinfo"].get(identity, {}).get("arrival"), "final_lane_inferred": False})
    audit.table(OUT / "all-unfinished-paired-events.csv", terminal_rows)
    def stats(data):
        return {**{key: data[key] for key in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count"]},
            "station40_max": max(abs(r["residual"]) for r in data["stations"]),
            "unique_complete_vehicles": len(data["by_vehicle"]), "no_complete_event_vehicles": len(vehicles) - len(data["by_vehicle"])}
    valid = after["safe"] and not unwanted and not repeats
    report = {"schema": "astra.hamburg.119-priority-independent/v1", "audit_status": "pass", "native_runs_by_audit": 0,
        "measurement_status": "valid_diagnostic_candidate" if valid else "invalid", "raw_verdict_status": verdict["status"],
        "before": stats(before), "after": stats(after), "native208_rows": len(rows208), "real182_rows": len(all182),
        "main130_exact_rows_before": sum(row["before_residual"] == 0 for row in main130),
        "main130_exact_rows_after": sum(row["after_residual"] == 0 for row in main130),
        "53556_exact_rows_after": sum(row["after_residual"] == 0 for row in rows535),
        "53556_TAE_after": sum(abs(row["after_residual"]) for row in rows535),
        "repeated_same_vehicle_field": repeats, "contributions_outside_primary_intention": unwanted,
        "terminal_groups": {label: groups for label, (_, groups) in terminal.items()},
        "unfinished_IDs_new": sorted({r["vehicle_id"] for r in terminal["after"][0]} - {r["vehicle_id"] for r in terminal["before"][0]}),
        "previously_unfinished_now_arrived": sorted({r["vehicle_id"] for r in terminal["before"][0]} - {r["vehicle_id"] for r in terminal["after"][0]}),
        "worst_119Z5_bin": max([row for row in main130 if row["field"] == FIELD119Z5], key=lambda row: abs(row["after_residual"])),
        "source_hashes": {"before": before["source_hashes"], "after": after["source_hashes"],
            "runtime": audit.digest(runtime_path), "verdict": audit.digest(verdict_path),
            "reader": audit.digest(HELPERS / "audit_response.py"), "backlog_reader": audit.digest(HELPERS / "summarize_response.py")},
        "formal_zero_healthy_condition": valid and after["healthy"] and after["metrics130"]["TAE"] == 0 and all(row["after_residual"] == 0 for row in rows535),
        "field_promotion_authority": False,
        "claim_boundary": "All8640 fixed requests and all real observations remain.130 is independent loss;40 is derived; tail has no real target. Valid safety and lower MAE do not prove GS ownership,603-major priority, field control correctness or promotion. Terminal origin/intention is not a final queue position. Network/control changes are a combined response, not causal decomposition."}
    audit.save(OUT / "summary.json", report)
    seal()
    print(json.dumps({key: report[key] for key in ["measurement_status", "before", "after", "53556_exact_rows_after", "53556_TAE_after", "worst_119Z5_bin", "formal_zero_healthy_condition"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
