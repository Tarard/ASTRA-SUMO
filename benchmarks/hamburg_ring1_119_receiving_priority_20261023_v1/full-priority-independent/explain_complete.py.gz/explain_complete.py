"""Keep the original32-ID cohort and initialization regressions explicit."""

from collections import Counter
import csv
import gzip
import json
from statistics import median
import xml.etree.ElementTree as ET

from audit_complete import OUT, REPO, SOURCE, CURRENT, FIELD119Z5, audit, seal


def events(path):
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    assert data["reconciled"]
    result = {}
    for row in data["passages"]:
        if row["detector_id"] == FIELD119Z5:
            assert row["vehicle_id"] not in result
            result[row["vehicle_id"]] = row
    return result


def read_csv(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    summary = json.loads((OUT / "summary.json").read_bytes())
    assert summary["audit_status"] == "pass"
    cohort_path = SOURCE.parent / "next-observation-cohort/source-bin-all32.csv"
    cohort = {r["vehicle_id"]: r for r in read_csv(cohort_path)}
    assert len(cohort) == 32
    paths = {"original_selected": REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/selected-next-diagnosis/selected-contributing-passages.json.gz",
        "before_v5": SOURCE / "evaluation/contributing-passages.json.gz", "priority": CURRENT / "evaluation/contributing-passages.json.gz"}
    actual = {label: events(path) for label, path in paths.items()}
    rows = []
    for identity, metadata in sorted(cohort.items()):
        row = {"vehicle_id": identity, "source_od_cell": metadata["source_od_cell"], "requested_origin": metadata["requested_origin"],
            "requested_departure_s": metadata["requested_departure_s"]}
        for label, records in actual.items():
            event = records.get(identity)
            row[label + "_notification_s"] = event["notification_time_s"] if event else ""
            row[label + "_bin_begin_s"] = event["interval_begin_s"] if event else ""
        assert row["original_selected_bin_begin_s"] == 6300
        row["priority_minus_v5_s"] = row["priority_notification_s"] - row["before_v5_notification_s"]
        row["priority_minus_original_selected_s"] = row["priority_notification_s"] - row["original_selected_notification_s"]
        rows.append(row)
    audit.table(OUT / "original32-triple-actual-events.csv", rows)
    current_ids = {identity for identity, event in actual["priority"].items() if event["interval_begin_s"] == 6300}
    requests = {v.get("id"): v for v in ET.parse(CURRENT / "prepared/demand.rou.xml").getroot().findall("vehicle")}
    contributors = []
    for identity in sorted(current_ids):
        vehicle = requests[identity]
        row = {"vehicle_id": identity, "in_original32": identity in cohort,
            "requested_origin": vehicle.find("route").get("edges").split()[0], "requested_departure_s": vehicle.get("depart")}
        for label, records in actual.items():
            event = records.get(identity)
            row[label + "_notification_s"] = event["notification_time_s"] if event else ""
            row[label + "_bin_begin_s"] = event["interval_begin_s"] if event else ""
        contributors.append(row)
    audit.table(OUT / "priority-Z5-6300-all39-contributors.csv", contributors)
    bins = {label: {identity for identity, event in data.items() if event["interval_begin_s"] == 6300} for label, data in actual.items()}
    assert len(bins["original_selected"]) == 32 and len(bins["before_v5"]) == 24 and len(bins["priority"]) == 39
    ids = set(cohort)
    transitions = Counter((row["before_v5_bin_begin_s"], row["priority_bin_begin_s"]) for row in rows)
    loss8 = ids - bins["before_v5"]
    assert len(loss8) == 8
    field_rows = read_csv(OUT / "field13-errors-and-regions.csv")
    ranked = sorted(field_rows, key=lambda row: -int(row["after_TAE"]))
    all182 = read_csv(OUT / "real182-before-after.csv")
    initial_fields = []
    for field in sorted({row["field"] for row in all182}):
        selected = [row for row in all182 if row["field"] == field and row["region"] == "initialization"]
        a = sum(abs(int(row["before_residual"])) for row in selected)
        b = sum(abs(int(row["after_residual"])) for row in selected)
        initial_fields.append({"field": field, "before_TAE": a, "after_TAE": b, "TAE_change": b - a,
            "before_SSE": sum(int(row["before_residual"]) ** 2 for row in selected),
            "after_SSE": sum(int(row["after_residual"]) ** 2 for row in selected)})
    assert sum(row["TAE_change"] for row in initial_fields) == 27
    audit.table(OUT / "field13-initialization-errors.csv", initial_fields)
    main = [row for row in all182 if row["region"] == "main"]
    z4 = [row for row in main if row["field"] == "hh_0119_Z_4_29437"]
    result = {"schema": "astra.hamburg.119-priority-remaining-errors/v1", "status": "pass", "native_runs": 0,
        "original32_priority_bin_counts": dict(Counter(str(row["priority_bin_begin_s"]) for row in rows)),
        "original32_priority_minus_v5_notification_min_median_max_s": [min(row["priority_minus_v5_s"] for row in rows), median(row["priority_minus_v5_s"] for row in rows), max(row["priority_minus_v5_s"] for row in rows)],
        "original32_priority_minus_original_notification_min_median_max_s": [min(row["priority_minus_original_selected_s"] for row in rows), median(row["priority_minus_original_selected_s"] for row in rows), max(row["priority_minus_original_selected_s"] for row in rows)],
        "original32_v5_to_priority_bin_transitions": [{"before_bin": key[0], "after_bin": key[1], "vehicles": count} for key, count in sorted(transitions.items())],
        "previous8_crossbin_now_back_in6300": sorted(loss8 & bins["priority"]),
        "priority6300_contributors_original32": len(ids & bins["priority"]),
        "priority6300_contributors_outside_original32": sorted(bins["priority"] - ids),
        "v5_6300_lost_in_priority": sorted(bins["before_v5"] - bins["priority"]),
        "priority6300_new_vs_v5": sorted(bins["priority"] - bins["before_v5"]),
        "source_original_target59_vs_original32_deficit": 27,
        "priority_target59_vs_actual39_deficit": 20,
        "initialization_field_regressions": sorted(initial_fields, key=lambda row: -row["TAE_change"]),
        "main_field_rank_by_TAE": ranked,
        "119Z4_negative_bins": sum(int(row["after_residual"]) < 0 for row in z4),
        "119Z4_target_main": sum(int(row["real_target"]) for row in z4),
        "119Z4_actual_main": sum(int(row["after_count"]) for row in z4),
        "119Z4_and_Z5_TAE": sum(int(row["after_TAE"]) for row in field_rows if row["field"] in {"hh_0119_Z_4_29437", FIELD119Z5}),
        "119Z4_and_Z5_SSE": sum(int(row["after_SSE"]) for row in field_rows if row["field"] in {"hh_0119_Z_4_29437", FIELD119Z5}),
        "source_hashes": {str(path): audit.digest(path) for path in [cohort_path, *paths.values()]},
        "claim_boundary": "The original32 is a fixed cohort of actual original-selected contributors, not a new label on candidate counts. All39 candidate contributors come from new native passages. Transition accounting is paired correspondence, not causal separation of priorities/actuation or trueOD. Main gains are reported with initialization regressions and all remaining errors."}
    audit.save(OUT / "remaining-error-summary.json", result)
    seal()
    print(json.dumps({key: result[key] for key in ["original32_priority_bin_counts", "original32_v5_to_priority_bin_transitions", "previous8_crossbin_now_back_in6300", "priority6300_contributors_original32", "priority6300_contributors_outside_original32", "119Z4_negative_bins", "119Z4_target_main", "119Z4_actual_main", "119Z4_and_Z5_TAE"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
