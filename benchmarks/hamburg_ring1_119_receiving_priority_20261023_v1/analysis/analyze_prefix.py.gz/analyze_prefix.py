"""Decode a sealed getter-only prefix; keep unavailable queries explicit."""

from collections import Counter
import csv
import hashlib
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
TRACE = OUT.parent / "observer/baseline"
FOCAL = ("od_0146_v00068", "od_0146_v00067")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def query(data, key):
    result = data.get(key)
    return result.get("value") if isinstance(result, dict) and result.get("ok") else None


def main():
    result = json.loads((TRACE / "record-result.json").read_bytes())
    assert result["native_prefix_parity"] == "pass" and len(result["checks"]) == 13 and all(result["checks"].values())
    preflight = json.loads((TRACE / "preflight.json").read_bytes())
    assert all(digest(Path(path)) == value for path, value in preflight["plan"]["source_hashes"].items())
    assert digest(TRACE / "executed-observer.py") == preflight["plan"]["observer_script_sha256"]
    frames = [json.loads(line) for line in (TRACE / "read-only-samples.jsonl").open(encoding="utf-8")]
    assert len(frames) == 502 and all("detailed_vehicles" in frame for frame in frames)
    focal_rows, receiver_rows, scenes = [], [], []
    for frame in frames:
        time = frame["native_xml_time_s"]
        all_vehicles = {**frame["neighbor_vehicles"], **frame["detailed_vehicles"]}
        for identity in FOCAL:
            data = frame["detailed_vehicles"][identity]
            links = query(data, "next_links")
            first = links[0] if isinstance(links, list) and links and isinstance(links[0], list) and len(links[0]) == 8 else None
            foes = query(data, "junction_foes100")
            decoded_foes = [foe for foe in foes if isinstance(foe, list) and len(foe) == 9] if isinstance(foes, list) else None
            targets = [target for target in frame["actual_native_target_links"] if any(row["vehicle_id"] == identity for row in target["chosen_by_native_nextTLS"])]
            leader = query(data, "leader200")
            leader_id = leader[0] if isinstance(leader, list) and leader else None
            focal_rows.append({"native_xml_time_s": time, "api_time_s": frame["api_time_s"], "vehicle_id": identity,
                "lane": query(data, "lane"), "pos_m": query(data, "lane_position_m"), "speed_m_s": query(data, "speed_m_s"),
                "leader_id": leader_id, "leader_gap_m": leader[1] if leader_id else None,
                "leader_lane": query(all_vehicles.get(leader_id, {}), "lane"),
                "leader_pos_m": query(all_vehicles.get(leader_id, {}), "lane_position_m"),
                "leader_speed_m_s": query(all_vehicles.get(leader_id, {}), "speed_m_s"),
                "lane_change_mode": query(data, "lane_change_mode"), "stop_state": query(data, "stop_state"),
                "first_next_link_decoded": first is not None, "next_link_to_lane": first[0] if first else None,
                "next_link_via": first[4] if first else None, "next_link_priority": first[1] if first else None,
                "next_link_opened": first[2] if first else None, "next_link_foe": first[3] if first else None,
                "next_link_state": first[5] if first else None,
                "foes100_decoded": decoded_foes is not None, "foes100_count": len(decoded_foes) if decoded_foes is not None else None,
                "ego_yields_to_foes": json.dumps([foe[0] for foe in decoded_foes if foe[7]]) if decoded_foes is not None else "unavailable",
                "best_lanes_query": json.dumps(data["best_lanes"], ensure_ascii=False),
                "lane_change_left_query": json.dumps(data["lane_change_state_pretty_left"], ensure_ascii=False),
                "lane_change_right_query": json.dumps(data["lane_change_state_pretty_right"], ensure_ascii=False),
                "pending_stops_query": json.dumps(data["pending_stops"], ensure_ascii=False),
                "actual_next_tls_queries": json.dumps(targets, ensure_ascii=False)})
            if time in {6735., 6740., 6745., 6748., 6750., 6815., 6825., 6829., 6830., 6831., 6832., 6840., 6845.}:
                scenes.append({"native_xml_time_s": time, "api_time_s": frame["api_time_s"], "vehicle_id": identity,
                    "ego": data, "leader": {"id": leader_id, "data": all_vehicles.get(leader_id)},
                    "foe_snapshots": {foe[0]: all_vehicles.get(foe[0]) for foe in decoded_foes} if decoded_foes is not None else None,
                    "target_tls": targets, "receiving_lanes": frame["receiving_lanes"], "all_neighbor_snapshots": all_vehicles})
        for lane, record in frame["receiving_lanes"].items():
            ids = query(record, "vehicle_ids")
            if not isinstance(ids, list):
                receiver_rows.append({"native_xml_time_s": time, "queried_lane": lane, "vehicle_id": None,
                    "actual_lane": None, "front_pos_m": None, "length_m": None, "front_minus_vehicle_length_m": None,
                    "speed_m_s": None, "query_state": "unavailable"})
                continue
            for identity in ids:
                data = all_vehicles.get(identity, {})
                pos, length = query(data, "lane_position_m"), query(data, "length_m")
                receiver_rows.append({"native_xml_time_s": time, "queried_lane": lane, "vehicle_id": identity,
                    "actual_lane": query(data, "lane"), "front_pos_m": pos, "length_m": length,
                    "front_minus_vehicle_length_m": pos - length if pos is not None and length is not None else None,
                    "speed_m_s": query(data, "speed_m_s"), "query_state": "available" if data.get("present") else "not_present"})
    table(OUT / "focal-state-series.csv", focal_rows)
    if receiver_rows:
        table(OUT / "receiving-vehicle-series.csv", receiver_rows)
    save(OUT / "representative-scenes.json", scenes)
    coverage = result["coverage"]
    summary = {"schema": "astra.hamburg.119-receiving-observer-analysis/v1", "status": "pass" if coverage["status"] == "pass" else "review_required",
        "native_runs_by_analysis": 0, "native_prefix_parity": result["native_prefix_parity"], "coverage_status": coverage["status"],
        "coverage_checks": coverage["checks"], "query_error_types": dict(Counter(row.get("query", "unhandled") for row in coverage["saved_errors"])),
        "frames": len(frames), "focal_series_rows": len(focal_rows), "clock": "native XML time=poststepAPI time-0.1; sealed FCD anchors are reported by coverage gate",
        "nextLinks_actual_tuple_order": ["approachedLane", "priority", "opened", "foe", "approachedInternal", "state", "direction", "length"],
        "leader_gap_semantics": "API getLeader gap excludes ego minGap. FCD leaderGap is physical bumper gap; retain raw values and add ego minGap only for an explicitly labeled comparison.",
        "source_hashes": {str(path): digest(path) for path in [TRACE / "record-result.json", TRACE / "coverage.json", TRACE / "preflight.json",
            TRACE / "read-only-samples.jsonl", TRACE / "executed-observer.py"]},
        "claim_boundary": "Unavailable getters remain unavailable. Native opened/foe/priority flags and response relations are not causal intervention evidence. Receiver front-minus-length is a geometric observation, not native available storage or a collision test. No setters or candidate changes were made."}
    save(OUT / "analysis-proof.json", summary)
    print(json.dumps({k: summary[k] for k in ["status", "coverage_status", "query_error_types", "frames", "focal_series_rows"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
