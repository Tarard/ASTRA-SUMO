# 119接收端：前缀getter诊断

7200秒原样前缀的13项交通一致性检查和5项采集覆盖检查全部通过。104项E1全属性、72000个summary步、69526个instant事件、4341条已到达路线，以及全部51个信号的61355条实际状态前缀记录均一致。两个窗口共502帧，104个整数时刻的车道/位置/速度与既有FCD锚点吻合。所有getter零错误。time==7200的4条源TLS边界记录排除在严格前缀之外；没有源车辆恰在7200秒到达。

6745–6748秒的31帧中，od_0146_v00068在24483344#1_1的94.129米处速度为0。119 link13和GS266 link4均为G；原生nextLink返回priority=true、opened=true、foe=false。100米junctionFoes为空，两个TLS返回的blocking/rival/priority车辆列表也为空。stopState=0，pendingStops为空。其前车v67实际在119内部lane，从18.291米移动到56.503米；当时790_1为空。getBestLanes给当前lane的offset=0、allowsContinuation=true。上述getter没有报告必须先换道或等待ROW foe的条件，但不暴露内部空间回退的DriveProcessItem值。

6825–6829秒，v67实际停在790_1的3.359米处，车长5米，车身后部跨入上游内部lane。它的GS266 link4持续为r；全控制状态yyrrrr中的黄色属于其他索引。6830秒link4转G，v67速度先升至0.26米/秒；v68在6830.1秒以0.26米/秒开始移动，6831秒进入内部lane。v68在停车和起步时的laneChangeMode均为512，不能据相关性删hold。

API getLeader的gap不包括ego minGap。6745秒API gap=11.792米，ego minGap=2.5米，对应FCD的物理前后车间距14.292米。两个量保留原值，不误报为同一距离不一致。

getNextLinks有一个文档顺序陷阱：安装的1.27.1 vehicle docstring把via写在第二位，但实际Libsumo结果和traci._lane._readLinks解析器顺序为lane、priority、opened、foe、via、state、direction、length。本次observer保存的原始元组完全未改，分析解码按解析器和实际类型更正，详见api-semantics.json。

根代理保存的固定1.27.1 MSVehicle.cpp中，checkRewindLinkLanes累积非内部道路空间、扣除内部车辆长度，并在下游关闭或停车条件下传播空间不足，leftSpace<0时可撤销入路请求。因此getNextLinks opened=true仍不保证车辆最终获准移动。这是源码支持的可能机制；本次没有DriveProcessItem.availableSpace、mySetRequest等内部值，不能称为已经证明。

两车局部检验见上一级micro-probe。相同短接收道路、原生keepClear、普通入路、原车辆参数和测得信号颜色边界下，源网没有重现全流中的86秒停车。两车证据不能代替完整下游/交叉交通，也不能证明候选在多流冲突下安全。

原54车观测中，6300–7200秒目标59、旧计数32、新计数24仍分为原有27辆差额和新增8辆跨窗损失。这里不修改真实观测，不把局部两车计数当作全流拟合改进。
