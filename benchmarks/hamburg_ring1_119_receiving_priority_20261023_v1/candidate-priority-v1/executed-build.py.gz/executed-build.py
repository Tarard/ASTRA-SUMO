"""Materialize one conditional GS266 priority-merge hypothesis for small tests."""

import argparse
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.artifact_io import write_json_atomic
from astra_sumo.core.candidate_contracts import file_sha256
from astra_sumo.core.junction_rebuild.restoration import restore_off_scope_netconvert_artifacts
from astra_sumo.core.junction_split_fanout import _canonical, _curve, _internal_path, _key
from astra_sumo.core.local_network_conversion import loaded_turn_permissions, run_scoped_native_conversion
from astra_sumo.core.network_geometry_freeze import compare_frozen_geometry, prepare_geometry_frozen_input

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-197-through-support-20261023-v1/full/evaluation/native"
NODE, TLS = "266199063", "GS_266199063"


def build(out):
    out.mkdir(parents=True, exist_ok=False)
    source, control = SOURCE / "network.net.xml", SOURCE / "signal-programs.add.xml"
    before = ET.parse(source).getroot()
    source_hashes = {str(p): file_sha256(p) for p in (source, control)}
    report = {"status": "blocked", "formal_result": False, "source_hashes": source_hashes,
        "hypothesis": "The inferred GS266 light is a model control boundary at a real merge. Test native priority operation while retaining all roads, turns, geometry and upstream controls. Independent field signal ownership remains unknown.",
        "scope": [NODE], "simulation_started": False}
    try:
        roads = {e.get("id") for e in before.findall("edge") if not e.get("function") and NODE in (e.get("from"), e.get("to"))}
        assert roads == {"603103445#2", "79014037#1", "186713429"}
        permissions = loaded_turn_permissions(before)
        movements = {_key(c): c for c in before.findall("connection") if c.get("tl") == TLS}
        assert len(movements) == 6 and all(key in permissions for key in movements)
        node = before.find(f"junction[@id='{NODE}']")
        assert node is not None and node.get("type") == "traffic_light"
        assert len(before.findall(f"tlLogic[@id='{TLS}']")) == 1
        nodes = ET.Element("nodes")
        ET.SubElement(nodes, "node", {"id": NODE, "type": "priority", "x": node.get("x"), "y": node.get("y"), "shape": node.get("shape")})
        patch = ET.Element("connections")
        for key, row in movements.items():
            lanes = _internal_path(before, row)
            assert len(lanes) == 1
            attrs = {k: row.get(k) for k in ("from", "to", "fromLane", "toLane")}
            attrs.update(shape=lanes[0].get("shape"), length=lanes[0].get("length"), speed=lanes[0].get("speed"),
                allow=" ".join(sorted(permissions[key])))
            ET.SubElement(patch, "connection", attrs)
        node_file, con_file = out / "priority.nod.xml", out / "frozen-turns.con.xml"
        ET.ElementTree(nodes).write(node_file, encoding="utf-8", xml_declaration=True)
        ET.ElementTree(patch).write(con_file, encoding="utf-8", xml_declaration=True)
        frozen = out / "frozen-input.net.xml"
        report["frozen_geometry"] = prepare_geometry_frozen_input(source_file=source, output_file=frozen)
        candidate = out / "converted.net.xml"
        command = [str(REPO / ".venv/Lib/site-packages/sumo/bin/netconvert.exe"), "--sumo-net-file", str(frozen),
            "--node-files", str(node_file), "--connection-files", str(con_file), "--offset.disable-normalization", "true",
            "--precision", "12", "--output-file", str(candidate)]
        result, conversion = run_scoped_native_conversion(command=command, mutable_nodes={NODE}, mutable_edges=roads,
            output_dir=out, prefix="priority", timeout_seconds=120, merge_source_file=source)
        report["execution"] = result if isinstance(result, dict) else {k: getattr(result, k, None) for k in ("command", "returncode", "stdout", "stderr")}
        report["conversion"] = conversion
        assert report["execution"]["returncode"] == 0 and candidate.is_file()
        native = ET.parse(candidate).getroot()
        native_request = _canonical(native.find(f"junction[@id='{NODE}']"))
        report["restoration"] = restore_off_scope_netconvert_artifacts(source_file=source, target_file=candidate,
            mutable_junction_ids={NODE}, mutable_edge_ids=set(), expand_mutable_edge_endpoints=False)
        assert report["restoration"]["status"] == "pass"
        after = ET.parse(candidate).getroot()
        links = {_key(c): c for c in after.findall("connection")}
        checks = {
            "native_priority_node": after.find(f"junction[@id='{NODE}']").get("type") == "priority",
            "inferred_program_removed": not after.findall(f"tlLogic[@id='{TLS}']") and not [c for c in after.findall("connection") if c.get("tl") == TLS],
            "native_request_table_unchanged_after_scope_restore": _canonical(after.find(f"junction[@id='{NODE}']")) == native_request,
            "all_loaded_turn_permissions_identical": loaded_turn_permissions(after) == permissions,
            "all_ordinary_geometry_identical": compare_frozen_geometry(source_file=source, candidate_file=candidate)["status"] == "pass",
        }
        geometry = []
        for key, old in movements.items():
            first, second = _internal_path(before, old), _internal_path(after, links[key])
            same = len(first) == len(second) == 1 and _curve(before, old).hausdorff_distance(_curve(after, links[key])) <= 1e-6
            same = same and all(abs(float(first[0].get(a, default)) - float(second[0].get(a, default))) <= 1e-6
                for a, default in (("length", "0"), ("speed", "0"), ("width", "3.2")))
            geometry.append({"key": key, "same": same, "before": dict(first[0].attrib), "after": [dict(r.attrib) for r in second]})
        checks["all_six_internal_curves_lengths_speeds_widths_retained"] = all(r["same"] for r in geometry)
        report["movement_geometry"] = geometry
        expected_programs = [_canonical(p) for p in before.findall("tlLogic") if p.get("id") != TLS]
        checks["all_other_network_programs_identical"] = expected_programs == [_canonical(p) for p in after.findall("tlLogic")]
        raw = control.read_bytes()
        removed = []
        def remove_program(match):
            if ET.fromstring(match.group()).get("id") == TLS:
                removed.append(match.group())
                return b""
            return match.group()
        new_control = re.sub(rb"<tlLogic\b[^>]*>[\s\S]*?</tlLogic>", remove_program, raw)
        checks["exactly_one_external_program_removed"] = len(removed) == 1
        checks["source_inputs_immutable"] = all(file_sha256(Path(p)) == h for p, h in source_hashes.items())
        report["checks"] = checks
        assert all(checks.values()), checks
        (out / "network.net.xml").write_bytes(candidate.read_bytes())
        (out / "control.add.xml").write_bytes(new_control)
        report.update(status="review_required", candidate_file=str(out / "network.net.xml"),
            candidate_sha256=file_sha256(out / "network.net.xml"), control_sha256=file_sha256(out / "control.add.xml"))
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    write_json_atomic(out / "manifest.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = build(args.output.resolve())
    print(result["status"], result.get("checks"), result.get("error"))
    assert result["status"] == "review_required"
