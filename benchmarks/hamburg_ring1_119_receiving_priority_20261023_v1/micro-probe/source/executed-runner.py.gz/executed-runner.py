"""Two ordinary-entry cars under the measured signal-color boundary; diagnostic only."""

import argparse
from bisect import bisect_right
from copy import deepcopy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import shutil
import time
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
FAMILY = ROOT.parent
REPO = ROOT.parents[2]
SPEC = importlib.util.spec_from_file_location("sealed_receiving_observer", FAMILY / "observer/record_prefix.py")
OBSERVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OBSERVER)
SOURCE = OBSERVER.SOURCE
CANDIDATE = FAMILY / "candidate-priority-v2"
START, END = Decimal("6700"), Decimal("7200")
IDS = ("od_0146_v00067", "od_0146_v00068")
DEPART = ("6710", "6712")
save, digest, libsumo = OBSERVER.save, OBSERVER.digest, OBSERVER.libsumo


def prepare():
    plan = json.loads((FAMILY / "observer/plan.json").read_bytes())
    assert digest(FAMILY / "observer/record_prefix.py") == plan["observer_script_sha256"]
    assert all(digest(Path(path)) == value for path, value in plan["source_hashes"].items())
    tree = ET.parse(SOURCE / "demand.rou.xml")
    original = {v.get("id"): v for v in tree.getroot().findall("vehicle")}
    demand = ET.Element("routes")
    for kind in tree.getroot().findall("vType"):
        demand.append(deepcopy(kind))
    scopes = []
    for identity, depart in zip(IDS, DEPART):
        vehicle = deepcopy(original[identity])
        vehicle.set("depart", depart)
        route = vehicle.find("route")
        edges = route.get("edges").split()
        route.set("edges", " ".join(edges[edges.index("24483344#0"):]))
        demand.append(vehicle)
        assert {k: v for k, v in vehicle.attrib.items() if k != "depart"} == {k: v for k, v in original[identity].attrib.items() if k != "depart"}
        assert ET.tostring(vehicle.find("stop")) == ET.tostring(original[identity].find("stop"))
        scopes.append({"id": identity, "depart_s": depart, "route_edges": route.get("edges"), "stops": [s.attrib for s in vehicle.findall("stop")]})
    ET.ElementTree(demand).write(ROOT / "two-cars.rou.xml", encoding="utf-8", xml_declaration=True)
    intentions = json.loads((SOURCE / "lane-intentions.json").read_bytes())
    intentions["vehicles"] = [r for r in intentions["vehicles"] if r["vehicle_id"] in IDS]
    assert len(intentions["vehicles"]) == 2
    save(ROOT / "lane-intentions.json", intentions)
    recorded = FAMILY / "observer/baseline/tls-recorded-programs.add.xml"
    recorded_root = ET.parse(recorded).getroot()
    assert len(recorded_root.findall("tlLogic")) == 51
    for variant, network, original_control in [("source", SOURCE / "network.net.xml", SOURCE / "signal-programs.add.xml"),
        ("priority", CANDIDATE / "network.net.xml", CANDIDATE / "control.add.xml")]:
        ids = {p.get("id") for p in ET.parse(original_control).getroot().findall("tlLogic")}
        assert len(ids) == (51 if variant == "source" else 50)
        control = deepcopy(recorded_root)
        for program in list(control):
            if program.tag == "tlLogic" and program.get("id") not in ids:
                control.remove(program)
        assert {p.get("id") for p in control.findall("tlLogic")} == ids
        ET.ElementTree(control).write(ROOT / (variant + "-recorded-control.add.xml"), encoding="utf-8", xml_declaration=True)
        assert network.exists()
    files = [SOURCE / "network.net.xml", SOURCE / "demand.rou.xml", SOURCE / "lane-intentions.json", SOURCE / "native-request.json",
        SOURCE / "signal-programs.add.xml", CANDIDATE / "network.net.xml", CANDIDATE / "control.add.xml", recorded,
        FAMILY / "observer/baseline/record-result.json", FAMILY / "observer/record_prefix.py", Path(__file__)]
    save(ROOT / "plan.json", {"schema": "astra.hamburg.119-receiving-two-car-plan/v1", "begin_s": int(START), "end_s": int(END),
        "vehicles": scopes, "source_hashes": {str(path): digest(path) for path in files},
        "scope": "Only two real vehicle templates; same attributes and original moving stops. Departures are6710/6712 and routes start at their existing244#0 suffix. This is ordinary empty-subsystem insertion, not an injected near-collision state or measured speed boundary.",
        "control_boundary": "The measured51-controller color histories are prescribed as static programs; priority case omits onlyGS266. This does not reproduce closed-loop actuated control. All surviving controller colors must match the original measured history at every0.1s step.",
        "safety": "No speed/lane/control setters added; core lane intention and4body hold remain. Native speedMode31 is queried, not set. KeepClear is not disabled. No field-fit objective is used."})


def state_history(path):
    result = {}
    for element in OBSERVER.elements(path, "tlsState"):
        result.setdefault(element.get("id"), []).append((Decimal(element.get("time")), element.get("state")))
    return result


def run(variant):
    plan = json.loads((ROOT / "plan.json").read_bytes())
    assert all(digest(Path(path)) == value for path, value in plan["source_hashes"].items())
    out = ROOT / variant
    out.mkdir(exist_ok=False)
    for name in OBSERVER.COPY_NAMES:
        shutil.copyfile(SOURCE / name, out / name)
    for old, new in [(ROOT / "two-cars.rou.xml", out / "demand.rou.xml"), (ROOT / "lane-intentions.json", out / "lane-intentions.json"),
        (ROOT / (variant + "-recorded-control.add.xml"), out / "signal-programs.add.xml")]:
        shutil.copyfile(old, new)
    if variant == "priority":
        shutil.copyfile(CANDIDATE / "network.net.xml", out / "network.net.xml")
    for name in ("e1.add.xml", "instant.add.xml"):
        tree = ET.parse(out / name)
        for row in tree.getroot():
            row.set("file", str(out / Path(row.get("file")).name))
            if row.tag == "inductionLoop":
                row.set("end", str(END))
        tree.write(out / name, encoding="utf-8", xml_declaration=True)
    additional = ET.Element("additional")
    ET.SubElement(additional, "timedEvent", type="SaveTLSSwitchStates", dest=str(out / "tls-switch-states.xml"))
    ET.ElementTree(additional).write(out / "tls-observer.add.xml", encoding="utf-8", xml_declaration=True)
    request = json.loads((SOURCE / "native-request.json").read_bytes())
    command = [part.replace(str(SOURCE), str(out)) for part in request["command"]]
    command[command.index("--end") + 1] = str(END)
    if "--begin" in command:
        command[command.index("--begin") + 1] = str(START)
    else:
        command.extend(["--begin", str(START)])
    command.extend(["--fcd-output", str(out / "fcd.xml"), "--fcd-output.max-leader-distance", "200",
        "--lanechange-output", str(out / "lanechanges.xml")])
    command[command.index("--additional-files") + 1] += "," + str(out / "tls-observer.add.xml")
    request.update(command=command, end_s=int(END), monitor_file=str(out / "stall-monitor.json"))
    for key in ("route_file", "lane_intentions_file", "e1_file"):
        request[key] = request[key].replace(str(SOURCE), str(out))
    save(out / "native-request.json", request)
    shutil.copyfile(Path(__file__), out / "executed-runner.py")
    save(out / "input-hashes.json", {str(path): digest(path) for path in [out / name for name in OBSERVER.COPY_NAMES]})
    capture = OBSERVER.Capture(out / "samples.jsonl")
    original_basic = capture.basic
    def basic(identity, present):
        row = original_basic(identity, present)
        if identity in present:
            row["speed_mode"] = capture.query("vehicle.speed_mode", libsumo.vehicle.getSpeedMode, identity)
        return row
    capture.basic = basic
    original = libsumo.simulationStep
    libsumo.simulationStep = capture.wrap(original)
    started = time.perf_counter()
    try:
        OBSERVER.monitor_sumo(request)
    finally:
        libsumo.simulationStep = original
        capture.handle.close()
    source_states = state_history(FAMILY / "observer/baseline/tls-switch-states.xml")
    actual_states = state_history(out / "tls-switch-states.xml")
    source_times = {tls: [r[0] for r in rows] for tls, rows in source_states.items()}
    actual_times = {tls: [r[0] for r in rows] for tls, rows in actual_states.items()}
    differences = []
    for tick in range(int(START * 10), int(END * 10)):
        time_value = Decimal(tick) / 10
        for tls, rows in actual_states.items():
            old = source_states[tls][bisect_right(source_times[tls], time_value) - 1][1]
            new = rows[bisect_right(actual_times[tls], time_value) - 1][1]
            if old != new and len(differences) < 10:
                differences.append({"time_s": str(time_value), "tls": tls, "source": old, "micro": new})
    summary = [r.attrib for r in OBSERVER.elements(out / "summary.xml", "step")][-1]
    collisions = ET.parse(out / "collisions.xml").getroot().findall("collision")
    monitor = json.loads((out / "stall-monitor.json").read_bytes())
    modes = []
    for line in (out / "samples.jsonl").open(encoding="utf-8"):
        frame = json.loads(line)
        for row in {**frame.get("neighbor_vehicles", {}), **frame.get("detailed_vehicles", {})}.values():
            if "speed_mode" in row and row["speed_mode"]["ok"]:
                modes.append(row["speed_mode"]["value"])
    checks = {"two_loaded_inserted_arrived": all(int(summary[k]) == 2 for k in ["loaded", "inserted", "ended", "arrived"]),
        "zero_unsafe": not collisions and all(int(summary[k]) == 0 for k in ["collisions", "teleports", "discarded"]),
        "monitor_completed": monitor["status"] == "completed", "all_surviving_actual_colors_match_source_every_step": not differences,
        "51_or50_actual_controllers": len(actual_states) == (51 if variant == "source" else 50),
        "all_observed_speed_modes31": bool(modes) and set(modes) == {31}, "zero_getter_errors": not capture.errors}
    report = {"schema": "astra.hamburg.119-receiving-two-car-run/v1", "variant": variant, "checks": checks,
        "status": "pass" if all(checks.values()) else "review_required", "elapsed_seconds": time.perf_counter() - started,
        "completion": summary, "color_differences": differences, "getter_errors": capture.errors, "captured_frames": len(capture.ticks),
        "observed_speed_modes": sorted(set(modes)), "claim_boundary": plan["control_boundary"], "mechanism_reproduction_not_automatically_claimed": True}
    save(out / "result.json", report)
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=["source", "priority"])
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    if args.prepare_only:
        prepare()
        print("Two-car diagnostic prepared; no native run")
    elif args.variant:
        run(args.variant)
    else:
        parser.error("Choose --prepare-only or --variant")
