# 7200秒被动前缀观测

源为197 v5 full的8640辆同输入请求。脚本只在原生6735–6755与6815–6845秒窗口，在真实simulationStep后调用getter。原核心driver、四个body-hold节点、路网、需求、意向、控制和随机种子保持。没有新增FCD输出，也没有新增驾驶或信号setter。

本次已由根代理执行一次。13项交通一致性检查与5项观测覆盖检查全部通过：104条E1、72000个summary步、69526个instant事件、4341条严格前缀到达路线、61355条全部51TLS实际phase/state记录。502帧均有两个focal，getter零错误；API时间减0.1秒后的104个整数时刻位置锚点与原54车FCD一致。

严格前缀使用time<7200、arrival<7200。完整源中恰在7200秒的4条TLS状态记录属于排除边界，没有车辆恰在7200秒到达。本次前缀没有time≥7200的TLS记录。原始13项检查、边界数据和query coverage均在baseline/record-result.json。

脚本、plan与所有输入在根代理审查后未修改。原始api-contract.json保留同版本TraCI docstrings；其中getNextLinks docstring的元组顺序与实际解析器不同，后续只在旁路analysis修正解码，未改任何采样原值。详见../analysis/api-semantics.json。API getLeader gap不含ego minGap，也与FCD物理间距分别保留。

旁路诊断见../analysis，有限两车配对见../micro-probe。原始原生数据与脚本保留；微型案例不替代全流观测或多流安全检查。
