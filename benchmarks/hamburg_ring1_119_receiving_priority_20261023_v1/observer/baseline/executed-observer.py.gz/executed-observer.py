"""Prepare or run one passive7200s prefix. Default preparation never starts SUMO."""

import argparse
from collections import Counter
from decimal import Decimal
import importlib.util
import itertools
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import libsumo
from libsumo import _libsumo
import traci

from astra_sumo.core.simulation_stall import monitor_sumo, stopped_vehicle_report


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / "outputs/hamburg-197-through-support-20261023-v1/full/evaluation/native"
PREVIOUS = REPO / "outputs/hamburg-197-through-support-20261023-v1/z5-observation"
BASE_SCRIPT = PREVIOUS / "record_z5.py"
END = Decimal("7200")
WINDOWS = ((67350, 67550), (68150, 68450))
FOCAL = ("od_0146_v00068", "od_0146_v00067")
TLS_IDS = {"LSA119_part0", "GS_266199063"}
RECEIVING_LANES = ("24483344#1_0", "24483344#1_1", ":LSA119_part0_12_0", ":LSA119_part0_12_1",
    "79014037#1_0", "79014037#1_1", "186713429_0", "186713429_1", "186713429_2", "186713429_3")
COPY_NAMES = ("network.net.xml", "demand.rou.xml", "signal-programs.add.xml", "lane-intentions.json",
    "source-e1.add.xml", "expected-counts.csv", "e1.add.xml", "instant.add.xml", "native-request.json")
DRIVER_NAMES = ("simulation_stall.py", "lane_section_hold.py")
SPEC = importlib.util.spec_from_file_location("read_only_z5_recorder", BASE_SCRIPT)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
digest, elements = BASE.digest, BASE.elements


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def normalize(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): normalize(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [normalize(item) for item in value]
    attributes = ("lane", "startPos", "endPos", "stoppingPlaceID", "stopFlags", "duration", "until", "intendedArrival",
        "arrival", "depart", "split", "join", "actType", "tripId", "line", "speed", "boarding", "permitted")
    fields = {key: normalize(getattr(value, key)) for key in attributes if hasattr(value, key)}
    return {"type": type(value).__name__, "fields": fields, "repr": repr(value)}


def source_prefix():
    arrivals = [v.get("arrival") for v in elements(SOURCE / "vehicle-routes.xml", "vehicle")]
    boundary = [v.get("id") for v in elements(SOURCE / "vehicle-routes.xml", "vehicle") if Decimal(v.get("arrival")) == END]
    return {"end_s": int(END), "source_arrived_strict_before_end": sum(Decimal(t) < END for t in arrivals),
        "source_arrived_inclusive_end": sum(Decimal(t) <= END for t in arrivals), "source_arrival_exactly_end_ids": boundary,
        "closed_e1_rows": sum(Decimal(r.get("end")) <= END for r in elements(SOURCE / "field-counts.xml", "interval")),
        "summary_steps": sum(Decimal(r.get("time")) < END for r in elements(SOURCE / "summary.xml", "step")),
        "instant_events": sum(Decimal(r.get("time")) < END for r in elements(SOURCE / "instant-e1.xml", "instantOut")),
        "all51_actual_tls_prefix_rows": sum(Decimal(r.get("time")) < END for r in elements(PREVIOUS / "baseline/tls-switch-states.xml", "tlsState")),
        "source_tls_state_rows_exactly_end": sum(Decimal(r.get("time")) == END for r in elements(PREVIOUS / "baseline/tls-switch-states.xml", "tlsState")),
        "boundary_semantics": "Native prefix steps stop at time7199.9; arrivals at7200.0 belong to the unrun future step and are excluded. E1 intervals ending7200 are closed; instant and summary rows require time<7200."}



def planned_request(out):
    original = json.loads((SOURCE / "native-request.json").read_bytes())
    request = dict(original)
    command = [part.replace(str(SOURCE), str(out)) for part in request["command"]]
    command[command.index("--end") + 1] = str(END)
    command[command.index("--additional-files") + 1] += "," + str(out / "tls-observer.add.xml")
    assert not any("fcd-output" in part for part in command)
    request.update(command=command, end_s=int(END), monitor_file=str(out / "stall-monitor.json"))
    for key in ("lane_intentions_file", "route_file", "e1_file"):
        request[key] = request[key].replace(str(SOURCE), str(out))
    assert {key for key in original if original[key] != request[key]} <= {
        "command", "end_s", "monitor_file", "lane_intentions_file", "route_file", "e1_file"}
    restored = [part.replace(str(out), str(SOURCE)) for part in command]
    restored[restored.index("--end") + 1] = original["command"][original["command"].index("--end") + 1]
    restored[restored.index("--additional-files") + 1] = restored[restored.index("--additional-files") + 1].removesuffix("," + str(SOURCE / "tls-observer.add.xml"))
    assert restored == original["command"]
    return request


def prepare_plan():
    assert Path(sys.executable).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    assert libsumo.__version__ == traci.__version__ == "1.27.1"
    original_monitor = json.loads((SOURCE / "stall-monitor.json").read_bytes())
    assert digest(Path(_libsumo.__file__)) == original_monitor["native_library"]["sha256"]
    for name in DRIVER_NAMES:
        assert (SOURCE.parents[1] / "implementation" / name).read_bytes() == (REPO / "plugins/astra-sumo/src/astra_sumo/core" / name).read_bytes()
    requested_ids = {v.get("id") for v in ET.parse(SOURCE / "demand.rou.xml").getroot().findall("vehicle")}
    intention_ids = {v["vehicle_id"] for v in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    assert requested_ids == intention_ids and len(requested_ids) == 8640
    save(ROOT / "planned-native-request.json", planned_request(ROOT / "baseline"))
    original_request = json.loads((SOURCE / "native-request.json").read_bytes())
    assert original_request["backend"] == "libsumo" and original_request["monitor_interval_s"] is None
    assert original_request["junction_body_hold"] is True and len(original_request["junction_body_hold_nodes"]) == 4
    assert original_request["command"][original_request["command"].index("--step-length") + 1] == "0.1"
    source_files = [SOURCE / name for name in COPY_NAMES] + [SOURCE / "stall-monitor.json", SOURCE / "field-counts.xml",
        SOURCE / "summary.xml", SOURCE / "instant-e1.xml", SOURCE / "vehicle-routes.xml", BASE_SCRIPT,
        PREVIOUS / "baseline/record-result.json", PREVIOUS / "baseline/cohort-fcd.xml", PREVIOUS / "baseline/tls-switch-states.xml", ROOT / "api-contract.json", ROOT / "planned-native-request.json", Path(_libsumo.__file__)]
    source_files += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in DRIVER_NAMES]
    prefix = source_prefix()
    assert prefix["closed_e1_rows"] == 104 and prefix["summary_steps"] == 72000
    plan = {"schema": "astra.hamburg.119-receiving-observer-plan/v1", "status": "ready_for_root_review", "simulation_started": False,
        "source_native": str(SOURCE), "output": str(ROOT / "baseline"), "end_s": int(END), "start": "empty", "N": len(requested_ids),
        "focal_vehicles": FOCAL, "native_xml_windows_inclusive_s": [[a / 10, b / 10] for a, b in WINDOWS],
        "expected_capture_frames": sum(b - a + 1 for a, b in WINDOWS), "fcd_added": False, "all51_tls_output": True,
        "native_version": libsumo.__version__, "matching_traci_version": traci.__version__,
        "observer_script_sha256": digest(Path(__file__)), "source_hashes": {str(path): digest(path) for path in source_files},
        "prefix_expectations": prefix, "planned_native_request": "planned-native-request.json",
        "entry": "Default/--plan only prepares this plan. --run is reserved for root after plan review.",
        "hook_position": "The wrapper calls the original simulationStep exactly once, then only getters. It returns unchanged to monitor_sumo before that monitor applies its existing driver.step for the next native step. No subscriptions or driving/control setters are added.",
        "clock": "api_time is getTime after the real step; native_xml_time=api_time-0.1. Integer-time lane/position/speed are independently anchored to the sealed54-ID FCD.",
        "capture": "Both focal vehicles and their dynamic leaders get the detailed getter bundle. Every returned100m foe, TLS blocker/rival/priority vehicle and all vehicles on the declared local receiving lanes get actual basic state. Expansion is one level; no foe or receiver in that level is sampled or silently capped.",
        "unchanged": "8640 requests, demand, intentions, observations, network, external controls, seed, native settings and four body-hold nodes. Only end/output paths and passive timed-event output change.",
        "claim_boundary": "Getter results and returned native link indices are observations. Missing values and exceptions are explicit, never replaced by zeros. Prefix parity and observer coverage are separate gates. No hypothesis is accepted merely because the run loads or parity passes."}
    save(ROOT / "plan.json", plan)
    return plan


class Capture:
    def __init__(self, path):
        self.handle = path.open("w", encoding="utf-8", newline="\n")
        self.success, self.errors = Counter(), []
        self.ticks, self.focal_present, self.target_tls = [], Counter(), set()
        self.anchors = {}

    def query(self, label, function, *args):
        try:
            value = normalize(function(*args))
            self.success[label] += 1
            return {"ok": True, "value": value}
        except Exception as error:
            row = {"query": label, "args": normalize(args), "type": type(error).__name__, "message": str(error)}
            self.errors.append(row)
            return {"ok": False, "error": row}

    def basic(self, identity, present):
        if identity not in present:
            return {"present": False, "reason": "Not in native getIDList at this exact snapshot"}
        result = {"present": True}
        for key, function in [("lane", libsumo.vehicle.getLaneID), ("lane_position_m", libsumo.vehicle.getLanePosition),
            ("position_xy_m", libsumo.vehicle.getPosition), ("speed_m_s", libsumo.vehicle.getSpeed),
            ("acceleration_m_s2", libsumo.vehicle.getAcceleration), ("road", libsumo.vehicle.getRoadID),
            ("route_index", libsumo.vehicle.getRouteIndex), ("length_m", libsumo.vehicle.getLength), ("min_gap_m", libsumo.vehicle.getMinGap)]:
            result[key] = self.query("vehicle." + key, function, identity)
        return result

    def frame(self, api_time, tick):
        ids = self.query("vehicle.getIDList", libsumo.vehicle.getIDList)
        present = set(ids["value"]) if ids["ok"] else set()
        result = {"api_time_s": api_time, "native_xml_time_s": tick / 10, "native_tick": tick,
            "api_minus_native_xml_s": round(api_time - tick / 10, 10), "focal_presence": {v: v in present for v in FOCAL},
            "hook_stage": "after real step and before this iteration's unchanged core driver.step"}
        self.ticks.append(tick)
        self.focal_present.update(v for v in FOCAL if v in present)
        result["shared_stopped_vehicle_report_10m"] = self.query("core.stopped_vehicle_report10", stopped_vehicle_report,
            libsumo, [v for v in FOCAL if v in present])
        detailed, neighbor_ids = {}, set()
        to_detail = {v for v in FOCAL if v in present}
        seed_leaders = {}
        for identity in sorted(to_detail):
            seed_leaders[identity] = self.query("vehicle.getLeader200_seed", libsumo.vehicle.getLeader, identity, 200)
            value = seed_leaders[identity]
            if value["ok"] and value["value"] and value["value"][0] in present:
                to_detail.add(value["value"][0])
        for identity in sorted(to_detail):
            row = self.basic(identity, present)
            for name, function, extra in [
                ("junction_foes100", libsumo.vehicle.getJunctionFoes, (100,)),
                ("best_lanes", libsumo.vehicle.getBestLanes, ()),
                ("lane_change_mode", libsumo.vehicle.getLaneChangeMode, ()),
                ("lane_change_state_pretty_left", libsumo.vehicle.getLaneChangeStatePretty, (1,)),
                ("lane_change_state_pretty_right", libsumo.vehicle.getLaneChangeStatePretty, (-1,)),
                ("stop_state", libsumo.vehicle.getStopState, ()), ("pending_stops", libsumo.vehicle.getStops, ()),
                ("next_links", libsumo.vehicle.getNextLinks, ()), ("next_tls", libsumo.vehicle.getNextTLS, ()),
                ("leader200", libsumo.vehicle.getLeader, (200,))]:
                row[name] = self.query("vehicle." + name, function, identity, *extra)
            if row["junction_foes100"]["ok"]:
                neighbor_ids.update(foe[0] for foe in row["junction_foes100"]["value"])
            if row["leader200"]["ok"] and row["leader200"]["value"]:
                neighbor_ids.add(row["leader200"]["value"][0])
            detailed[identity] = row
        tls_entries = {}
        for identity, row in detailed.items():
            if row["next_tls"]["ok"]:
                for rank, entry in enumerate(row["next_tls"]["value"]):
                    if entry[0] in TLS_IDS:
                        key = (entry[0], int(entry[1]))
                        tls_entries.setdefault(key, []).append({"vehicle_id": identity, "native_next_tls_rank": rank, "raw_entry": entry})
        target_links = []
        for (tls, index), chosen_by in sorted(tls_entries.items()):
            self.target_tls.add(tls)
            row = {"tls_id": tls, "link_index": index, "chosen_by_native_nextTLS": chosen_by}
            for key, function, args in [
                ("controlled_links", libsumo.trafficlight.getControlledLinks, (tls,)),
                ("actual_state", libsumo.trafficlight.getRedYellowGreenState, (tls,)),
                ("actual_phase", libsumo.trafficlight.getPhase, (tls,)),
                ("actual_program", libsumo.trafficlight.getProgram, (tls,)),
                ("blocking_vehicles", libsumo.trafficlight.getBlockingVehicles, (tls, index)),
                ("rival_vehicles", libsumo.trafficlight.getRivalVehicles, (tls, index)),
                ("priority_vehicles", libsumo.trafficlight.getPriorityVehicles, (tls, index))]:
                row[key] = self.query("trafficlight." + key, function, *args)
            if row["controlled_links"]["ok"]:
                groups = row["controlled_links"]["value"]
                row["chosen_binding"] = {"available": 0 <= index < len(groups),
                    "links": groups[index] if 0 <= index < len(groups) else None}
                if not row["chosen_binding"]["available"]:
                    self.errors.append({"query": "controlled_link_binding", "tls": tls, "index": index, "message": "Native chosen index not in native controlled links"})
            for key in ["blocking_vehicles", "rival_vehicles", "priority_vehicles"]:
                if row[key]["ok"]:
                    neighbor_ids.update(row[key]["value"])
            target_links.append(row)
        lanes = {}
        for lane in RECEIVING_LANES:
            row = {"vehicle_ids": self.query("lane.getLastStepVehicleIDs", libsumo.lane.getLastStepVehicleIDs, lane),
                "length_m": self.query("lane.getLength", libsumo.lane.getLength, lane)}
            if row["vehicle_ids"]["ok"]:
                neighbor_ids.update(row["vehicle_ids"]["value"])
            lanes[lane] = row
        result.update(seed_leaders200=seed_leaders, detailed_vehicles=detailed, actual_native_target_links=target_links,
            receiving_lanes=lanes, neighbor_vehicles={v: self.basic(v, present) for v in sorted(neighbor_ids - set(detailed))},
            expansion="one level: all returned foes, TLS relations, receiver vehicles and dynamic leaders; no zero fills")
        if tick % 10 == 0:
            for identity in FOCAL:
                if identity in detailed:
                    self.anchors[tick / 10, identity] = detailed[identity]
        self.handle.write(json.dumps(result, ensure_ascii=False) + "\n")

    def wrap(self, original):
        def observed_step(*args, **kwargs):
            value = original(*args, **kwargs)
            api_time = libsumo.simulation.getTime()
            tick = round(api_time * 10) - 1
            if any(begin <= tick <= end for begin, end in WINDOWS):
                try:
                    self.frame(api_time, tick)
                except Exception as error:
                    row = {"api_time_s": api_time, "native_xml_time_s": tick / 10,
                        "unhandled_observer_error": {"type": type(error).__name__, "message": str(error)}}
                    self.errors.append(row)
                    self.handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            return value
        return observed_step

    def finish(self):
        self.handle.close()
        anchor_rows, time_value = {}, None
        for event, element in ET.iterparse(PREVIOUS / "baseline/cohort-fcd.xml", events=("start", "end")):
            if event == "start" and element.tag == "timestep":
                time_value = float(element.get("time"))
            elif event == "end" and element.tag == "vehicle":
                key = (time_value, element.get("id"))
                if key in self.anchors:
                    anchor_rows[key] = dict(element.attrib)
                element.clear()
            elif event == "end" and element.tag == "timestep":
                element.clear()
        mismatches = []
        for key, actual in self.anchors.items():
            expected = anchor_rows.get(key)
            if expected is None:
                mismatches.append({"time_vehicle": key, "reason": "No matching sealedFCD anchor"})
                continue
            for api_key, fcd_key in [("lane", "lane"), ("lane_position_m", "pos"), ("speed_m_s", "speed")]:
                value = actual[api_key]
                same = value["ok"] and (value["value"] == expected[fcd_key] if api_key == "lane" else abs(value["value"] - float(expected[fcd_key])) <= 1e-9)
                if not same:
                    mismatches.append({"time_vehicle": key, "field": api_key, "api": value, "fcd": expected[fcd_key]})
        expected_ticks = [tick for begin, end in WINDOWS for tick in range(begin, end + 1)]
        checks = {"all502_frames_exactly_once": self.ticks == expected_ticks,
            "both_focals_present_all_frames": all(self.focal_present[v] == len(expected_ticks) for v in FOCAL),
            "zero_saved_query_or_observer_errors": not self.errors,
            "actual_native_nextTLS_119_and_GS_seen": self.target_tls == TLS_IDS,
            "all104_integer_focal_FCD_anchors_match": len(self.anchors) == len(anchor_rows) == 104 and not mismatches}
        return {"status": "pass" if all(checks.values()) else "blocked", "checks": checks,
            "successful_query_counts": dict(self.success), "saved_errors": self.errors, "focal_present_frames": dict(self.focal_present),
            "captured_frames": len(self.ticks), "integer_anchor_count": len(anchor_rows), "anchor_mismatches": mismatches}


def verify_prefix(out, source_hashes, elapsed, coverage):
    checks = {"source_inputs_unchanged": all(digest(Path(path)) == value for path, value in source_hashes.items()),
        "network_demand_control_intentions_identical": all((out / name).read_bytes() == (SOURCE / name).read_bytes()
            for name in ("network.net.xml", "demand.rou.xml", "signal-programs.add.xml", "lane-intentions.json", "source-e1.add.xml"))}
    reference = {(r.get("id"), r.get("begin"), r.get("end")): r.attrib for r in elements(SOURCE / "field-counts.xml", "interval") if Decimal(r.get("end")) <= END}
    actual = {(r.get("id"), r.get("begin"), r.get("end")): r.attrib for r in elements(out / "field-counts.xml", "interval") if Decimal(r.get("begin")) < Decimal(r.get("end"))}
    checks["all_closed_e1_attributes_identical"] = actual == reference
    checks["expected_closed_e1_count"] = len(actual) == 104
    summary_diffs, last, steps = [], None, 0
    original_steps = (r for r in elements(SOURCE / "summary.xml", "step") if Decimal(r.get("time")) < END)
    for before, after in itertools.zip_longest(original_steps, elements(out / "summary.xml", "step")):
        if before is None or after is None:
            summary_diffs.append({"reason": "Native step count differs"})
            break
        steps += 1
        last = dict(after.attrib)
        if {k: v for k, v in before.attrib.items() if k != "duration"} != {k: v for k, v in after.attrib.items() if k != "duration"} and len(summary_diffs) < 10:
            summary_diffs.append({"reference": dict(before.attrib), "observer": dict(after.attrib)})
    checks["all_prefix_summary_attributes_identical"] = not summary_diffs
    checks["expected_native_step_count"] = steps == 72000
    event_diffs, events = [], 0
    before_events = (r for r in elements(SOURCE / "instant-e1.xml", "instantOut") if Decimal(r.get("time")) < END)
    for before, after in itertools.zip_longest(before_events, elements(out / "instant-e1.xml", "instantOut")):
        if before is None or after is None:
            event_diffs.append({"reason": "Instant event count differs"})
            break
        events += 1
        if before.attrib != after.attrib and len(event_diffs) < 10:
            event_diffs.append({"reference": dict(before.attrib), "observer": dict(after.attrib)})
    checks["all_prefix_instant_e1_attributes_identical"] = not event_diffs
    expected_routes = {v.get("id"): ET.canonicalize(ET.tostring(v, encoding="unicode"), strip_text=True)
        for v in elements(SOURCE / "vehicle-routes.xml", "vehicle") if Decimal(v.get("arrival")) < END}
    actual_routes = {v.get("id"): ET.canonicalize(ET.tostring(v, encoding="unicode"), strip_text=True)
        for v in elements(out / "vehicle-routes.xml", "vehicle")}
    checks["all_arrived_strict_prefix_routes_and_exitTimes_identical"] = actual_routes == expected_routes
    checks["zero_collisions"] = not ET.parse(out / "collisions.xml").getroot().findall("collision")
    monitor = json.loads((out / "stall-monitor.json").read_bytes())
    checks["monitor_completed"] = monitor["status"] == "completed" and monitor["simulation_time_s"] == int(END)
    kinds = {p.get("id"): p.get("type") for p in ET.parse(SOURCE / "signal-programs.add.xml").getroot().findall("tlLogic")}
    initial = {r.get("id") for r in elements(out / "tls-switch-states.xml", "tlsState") if Decimal(r.get("time")) == 0}
    checks["all_51_tls_initialized_at_zero"] = initial == kinds.keys() and len(initial) == 51
    exported = ET.parse(out / "tls-recorded-programs.add.xml").getroot().findall("tlLogic")
    checks["native_program_export_complete"] = len(exported) == 51 and {p.get("id") for p in exported} == kinds.keys() and all(
        p.get("type") == "static" and sum(Decimal(r.get("duration")) for r in p.findall("phase")) == END for p in exported)
    tls_differences, tls_rows = [], 0
    reference_states = (r for r in elements(PREVIOUS / "baseline/tls-switch-states.xml", "tlsState") if Decimal(r.get("time")) < END)
    actual_states = (r for r in elements(out / "tls-switch-states.xml", "tlsState") if Decimal(r.get("time")) < END)
    for before, after in itertools.zip_longest(reference_states, actual_states):
        if before is None or after is None:
            tls_differences.append({"reason": "ActualTLS prefix record count differs"})
            break
        tls_rows += 1
        old_semantics = (Decimal(before.get("time")), {k: v for k, v in before.attrib.items() if k != "time"})
        new_semantics = (Decimal(after.get("time")), {k: v for k, v in after.attrib.items() if k != "time"})
        if old_semantics != new_semantics and len(tls_differences) < 10:
            tls_differences.append({"reference": dict(before.attrib), "observer": dict(after.attrib)})
    checks["all51_actual_phase_state_strict_prefix_identical"] = not tls_differences
    assert len(checks) == 13
    result = {"schema": "astra.hamburg.119-receiving-prefix-record/v1", "status": "pass" if all(checks.values()) and coverage["status"] == "pass" else "blocked",
        "native_prefix_parity": "pass" if all(checks.values()) else "blocked", "observer_coverage": coverage["status"],
        "checks": checks, "coverage": coverage, "end_s": int(END), "elapsed_seconds": elapsed, "formal_result": False,
        "closed_e1_rows": len(actual), "summary_steps_checked": steps, "instant_events_checked": events,
        "arrived_routes_checked": len(actual_routes), "completion": last, "summary_differences": summary_diffs,
        "instant_differences": event_diffs, "strict_prefix_boundary_check": source_prefix(), "tls_types": kinds,
        "actual_tls_prefix_rows_checked": tls_rows, "actual_tls_prefix_differences": tls_differences,
        "observer_tls_state_rows_at_or_after_end": [dict(r.attrib) for r in elements(out / "tls-switch-states.xml", "tlsState") if Decimal(r.get("time")) >= END]}
    save(out / "record-result.json", result)
    return result


def run(plan):
    assert plan["observer_script_sha256"] == digest(Path(__file__))
    assert all(digest(Path(path)) == value for path, value in plan["source_hashes"].items())
    out = ROOT / "baseline"
    out.mkdir(exist_ok=False)
    for name in COPY_NAMES:
        shutil.copyfile(SOURCE / name, out / name)
    shutil.copyfile(Path(__file__), out / "executed-observer.py")
    for name in ("e1.add.xml", "instant.add.xml"):
        tree = ET.parse(out / name)
        for row in tree.getroot():
            row.set("file", str(out / Path(row.get("file")).name))
            if row.tag == "inductionLoop":
                row.set("end", str(END))
        tree.write(out / name, encoding="utf-8", xml_declaration=True)
    observer = ET.Element("additional")
    ET.SubElement(observer, "timedEvent", type="SaveTLSSwitchStates", dest=str(out / "tls-switch-states.xml"))
    ET.SubElement(observer, "timedEvent", type="SaveTLSProgram", dest=str(out / "tls-recorded-programs.add.xml"))
    ET.ElementTree(observer).write(out / "tls-observer.add.xml", encoding="utf-8", xml_declaration=True)
    request = planned_request(out)
    assert request == json.loads((ROOT / "planned-native-request.json").read_bytes())
    save(out / "native-request.json", request)
    save(out / "preflight.json", {"plan": plan, "command": request["command"], "observer_sha256": digest(out / "tls-observer.add.xml")})
    capture = Capture(out / "read-only-samples.jsonl")
    original = libsumo.simulationStep
    libsumo.simulationStep = capture.wrap(original)
    started = time.perf_counter()
    try:
        monitor_sumo(request)
    finally:
        libsumo.simulationStep = original
        coverage = capture.finish()
        save(out / "coverage.json", coverage)
    result = verify_prefix(out, plan["source_hashes"], time.perf_counter() - started, coverage)
    print(json.dumps({"status": result["status"], "native_prefix_parity": result["native_prefix_parity"], "observer_coverage": result["observer_coverage"], "checks": result["checks"]}), flush=True)
    assert result["status"] == "pass"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true", help="Run only after root reviewed the frozen plan")
    parser.add_argument("--plan", action="store_true", help="Prepare only; default")
    args = parser.parse_args()
    if args.run and args.plan:
        parser.error("Use either --plan or --run")
    if args.run:
        run(json.loads((ROOT / "plan.json").read_bytes()))
    else:
        prepared = prepare_plan()
        print(json.dumps({"status": prepared["status"], "simulation_started": False, "prefix_expectations": prepared["prefix_expectations"]}), flush=True)
