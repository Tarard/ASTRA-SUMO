"""Check observer mechanics without starting or stepping a simulation."""

import ast
from collections import Counter
from decimal import Decimal
import io
import json
from unittest.mock import patch

import record_prefix as observer


def main():
    results = {}
    before = observer.ROOT / "baseline"
    results["baseline_not_created"] = not before.exists()
    arrival_times = [Decimal("7199.9"), Decimal("7200.0"), Decimal("7200.1")]
    results["strict_arrival_boundary_excludes_7200"] = [t for t in arrival_times if t < observer.END] == [Decimal("7199.9")]
    results["inclusive_arrival_boundary_would_be_wrong"] = len([t for t in arrival_times if t <= observer.END]) == 2
    class Dummy:
        def __init__(self):
            self.samples, self.errors, self.handle = [], [], io.StringIO()

        def frame(self, api, tick):
            self.samples.append((api, tick))

    dummy, step_calls = Dummy(), []
    def fake_step(*args, **kwargs):
        step_calls.append((args, kwargs))
        return "unchanged_native_return"
    wrapped = observer.Capture.wrap(dummy, fake_step)
    tested = [6735.0, 6735.1, 6755.1, 6755.2, 6815.1, 6845.1, 6845.2]
    for time in tested:
        with patch.object(observer.libsumo.simulation, "getTime", return_value=time):
            assert wrapped(0) == "unchanged_native_return"
    results["original_step_called_once_per_invocation"] = len(step_calls) == len(tested) and all(row == ((0,), {}) for row in step_calls)
    results["capture_windows_use_api_minus_point1"] = dummy.samples == [(6735.1, 67350), (6755.1, 67550), (6815.1, 68150), (6845.1, 68450)]
    query = observer.Capture.__new__(observer.Capture)
    query.success, query.errors = Counter(), []
    def fail():
        raise ValueError("intentional offline error")
    error = query.query("offline_intentional", fail)
    results["query_error_saved_without_zero_fill"] = not error["ok"] and "value" not in error and len(query.errors) == 1 and error["error"]["message"] == "intentional offline error"
    empty = query.query("offline_empty", lambda: None)
    results["native_none_preserved"] = empty == {"ok": True, "value": None}
    tree = ast.parse((observer.ROOT / "record_prefix.py").read_text(encoding="utf-8"))
    capture = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Capture")
    native_calls = [ast.unparse(node.func) for node in ast.walk(capture) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and ast.unparse(node.func).startswith("libsumo.")]
    results["direct_hook_native_calls_are_getters_only"] = all(call.split(".")[-1].startswith("get") for call in native_calls)
    results["no_extra_FCD_argument"] = "--fcd-output" not in (observer.ROOT / "record_prefix.py").read_text(encoding="utf-8")
    assert all(results.values()), results
    result = {"schema": "astra.hamburg.119-receiving-observer-offline-check/v1", "status": "pass", "simulation_started": False,
        "checks": results, "direct_native_getter_calls_in_hook": native_calls,
        "boundary": "The mocked wrapper test invokes no real simulation step or live getters. The AST only checks direct native calls, not getter function-pointer arguments; root manually reviewed those. Runtime API support and traffic parity remain untested until root executes the planned run."}
    observer.save(observer.ROOT / "offline-check.json", result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
