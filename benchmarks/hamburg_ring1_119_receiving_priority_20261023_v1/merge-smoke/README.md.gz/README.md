# GS266 priority条件方案的两股合流小试

只完成2次小运行、4辆普通入口请求，均全路线到原199500676出口，0碰撞/传送/丢弃，speedMode31、keepClear及原LaneSectionHold保持。未运行完整8640辆，不以通行更快或E1拟合为目标。

| 目标共享车道 | 603主路实际via | 790支路实际via | 原生入内部时刻 |
|---|---|---|---|
| 186713429_0 | :266199063_0_0，REQ0 | :266199063_2_0，REQ2 | 82.3 / 84.0秒 |
| 186713429_1 | :266199063_0_1，REQ1 | :266199063_2_1，REQ3 | 82.3 / 84.0秒 |

两案原生82.2秒（步后API82.3）均出现实际让行状态：603的native nextLink为M、hasPriority=true、isOpen=true；790为m、hasPriority=false、isOpen=false、hasFoe=true。随后790报告603为leader、正常减速跟随，603先离开合流位置，790再进入。这里报告原生状态与通过次序，不把所有减速都因果归给前车，也不声称测得现场让行方向。

Z4车取原type、24483344#1起步后的原路线和moving-stop，普通depart0秒；603车取原Z15车辆type与603103445#2起步后的原后缀，普通depart82秒。两个入口均为原普通道路，departPos5.1在合法长度内。603车已经跳过实际Z15检测点，只是合流fixture，不称Z15重放或拟合。为选择共享出口，明确增加接收lane0/1上的原生moving waypoint（speed13.888889），不调用setSpeed、changeLane、moveTo、setPhase或关闭碰撞。出发没有延迟；原生实际出发另行记录。

复用已冻结197 driver，只将“一个stop”的断言改为声明stop数量；Z4原stop与新增接收waypoint均保留。其samples中的phase/state是遗留197背景信号字段，不是已移除GS的相位。GS优先/让行以native nextLinks的M/m和实际via为证。原生FCD时间比步后API早0.1秒，audit逐样本核对了FCD、197背景状态、路线、E1及实际到达。

只覆盖六个合法movement中的REQ0/1/2/3，以及它们共享出口0/1的这组到达顺序。790 lane1→186 lane2/3的REQ4/5（Z5）、反向到达次序、连续多车及人行/自行车未测，不追加人口以凑覆盖。现场独立GS灯头未知，上游give_way不能确定本节点让行方向；tiny pass不构成大流量安全或现场控制证明。

原始inputs、普通add及模式命令、FCD/LC/TLS/E1/summary/trips/routes/collisions、日志和全部实际coverage保留。lane1结果位于lane1-fixture/lane0-first，后半目录名只是共享runner原名，plan和实际路径均明确receiver1。没有丢弃失败或未覆盖项。后续完整运行由主任务独立负责，本目录已停止新增native。
