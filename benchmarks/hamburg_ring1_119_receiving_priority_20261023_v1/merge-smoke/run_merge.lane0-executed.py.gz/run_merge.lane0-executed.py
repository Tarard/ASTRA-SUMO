"""One ordinary-entry shared-lane merge; reuse the frozen 197 toy driver."""
import copy
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CANDIDATE = ROOT.parent / 'candidate-priority-v3'
SOURCE = REPO / 'outputs/hamburg-197-through-support-20261023-v1/full/evaluation'


def main():
    frozen = REPO / 'outputs/hamburg-197-through-support-20261023-v1/smoke/run_smoke.executed-v5.py'
    code = frozen.read_text(encoding='utf-8')
    old = "assert len(api.vehicle.getStops(identity)) == int(job['field'] is not None)"
    assert code.count(old) == 1
    adapted = ROOT / 'shared-driver.py'
    assert not adapted.exists()
    adapted.write_text(code.replace(old, "assert len(api.vehicle.getStops(identity)) == job['expected_stop_count']"), encoding='utf-8')
    inputs = ROOT / 'inputs'
    inputs.mkdir(exist_ok=False)
    tree = ET.parse(SOURCE / 'demand.rou.xml').getroot()
    fields = {r['vehicle_id']: r['field_id'] for r in json.loads((SOURCE / 'lane-intentions.json').read_bytes())['vehicles']}
    routes, jobs = ET.Element('routes'), []
    for row in tree:
        if row.tag != 'vehicle':
            routes.append(copy.deepcopy(row))
    for label, z, start, depart, movement in (('minor_Z4', 4, '24483344#1', 0, 203), ('major_603', 15, '603103445#2', 82, 201)):
        vehicle = next(v for v in tree.findall('vehicle') if fields[v.get('id')].startswith(f'hh_0119_Z_{z}_'))
        edges = vehicle.find('route').get('edges').split()
        suffix = edges[edges.index(start):]
        assert suffix[-1] == '199500676'
        route = ET.SubElement(routes, 'route', id='r_'+label, edges=' '.join(suffix))
        if z == 4:
            for stop in vehicle.findall('stop'):
                route.append(copy.deepcopy(stop))
        ET.SubElement(route, 'stop', lane='186713429_0', endPos='5.287260', speed='13.888889')
        attrs = dict(vehicle.attrib)
        jobs.append(dict(id=label, case='gs-merge', field=fields[vehicle.get('id')] if z == 4 else None,
            source_id=vehicle.get('id'), vehicle_attributes=attrs, route_id=route.get('id'), trigger=dict(time_s=depart),
            movement=movement, expected_stop_count=len(route.findall('stop'))))
    ET.ElementTree(routes).write(inputs / 'routes.rou.xml', encoding='utf-8', xml_declaration=True)
    (inputs / 'field-loops.add.xml').write_bytes((SOURCE / 'native/source-e1.add.xml').read_bytes())
    (inputs / 'jobs.json').write_text(json.dumps(dict(end_s=600, jobs=jobs), indent=2)+'\n', encoding='utf-8')
    proof = json.loads((CANDIDATE / 'manifest.json').read_bytes())
    assert len(proof['checks']) == 10 and all(proof['checks'].values())
    spec = spec_from_file_location('shared_197_driver', adapted)
    driver = module_from_spec(spec)
    spec.loader.exec_module(driver)

    def support(network, control):
        net = ET.parse(network).getroot()
        assert next(j for j in net.findall('junction') if j.get('id') == '266199063').get('type') == 'priority'
        assert len(ET.parse(control).getroot().findall('tlLogic')) == 50
        paths = {}
        for key, before, lane, state in ((201, '603103445#2', 0, 'M'), (203, '79014037#1', 0, 'm')):
            match = [r for r in net.findall('connection') if r.get('from') == before and r.get('fromLane') == str(lane)
                and r.get('to') == '186713429' and r.get('toLane') == '0']
            assert len(match) == 1 and match[0].get('state') == state and 'tl' not in match[0].attrib
            paths[key] = [match[0].get('via')]
        for route in routes.findall('route'):
            driver.route_support(net, route.get('edges').split())
        return net, paths

    driver.support = support
    record = dict(native_runs_planned=1, field_fit_claim=False, source_driver_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),
        only_driver_text_edit='Check actual declared stop count; retain native driving loop and all safety settings.',
        fixture='603 vehicle starts after the real Z15 point; normal ordinary-road departure, not a Z15 replay. Both retain original suffix to199500676. Added receiving-lane0 moving waypoint is an explicit toy routing constraint.',
        priority_direction_is_conditional=True, legacy_phase_sample_field='197, not GS266; GS priority M/m and physical via are read from native links and FCD',
        candidate_sha256=hashlib.sha256((CANDIDATE / 'network.net.xml').read_bytes()).hexdigest())
    (ROOT / 'plan.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    driver.run('gs-merge', 'lane0-first', (CANDIDATE / 'network.net.xml').resolve(), (CANDIDATE / 'control.add.xml').resolve())


if __name__ == '__main__':
    main()
