"""Audit two completed cross-stream toy merges using the existing native auditor."""
import json
from pathlib import Path
import runpy


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]


def main():
    tools = runpy.run_path(str(REPO / 'outputs/hamburg-197-through-support-20261023-v1/smoke/audit_smokes.py'))
    reports = {}
    for lane, directory in ((0, ROOT / 'lane0-first'), (1, ROOT / 'lane1-fixture/lane0-first')):
        checked = tools['audit'](directory)
        assert checked['status'] == 'pass' and checked['all_full_routes_arrived']
        result = json.loads((directory / 'result.json').read_bytes())
        assert result['entered_movements']['major_603']['lane'] == f':266199063_0_{lane}'
        assert result['entered_movements']['minor_Z4']['lane'] == f':266199063_2_{lane}'
        data = json.loads((directory / 'samples.json').read_bytes())
        encounters = []
        for row in data:
            cars = row['vehicles']
            if set(cars) != {'major_603', 'minor_Z4'}:
                continue
            links = {}
            for identity, prefix in (('major_603', ':266199063_0_'), ('minor_Z4', ':266199063_2_')):
                links[identity] = next((x for x in cars[identity]['next_links'] if x[4].startswith(prefix)), None)
            a, b = links['major_603'], links['minor_Z4']
            if a and b and a[1] and a[2] and not b[1] and not b[2] and b[3]:
                encounters.append(dict(native_time_s=round(row['time_s']-.1, 1), poststep_API_time_s=row['time_s'],
                    major=dict(lane=cars['major_603']['lane'], pos=cars['major_603']['pos_m'], next_link=a),
                    minor=dict(lane=cars['minor_Z4']['lane'], pos=cars['minor_Z4']['pos_m'], next_link=b)))
        assert encounters
        reports[str(lane)] = dict(native_audit=checked, actual_priority_yield_encounters=encounters,
            actual_via_native_entry_s={i:round(r['time_s']-.1, 1) for i, r in result['entered_movements'].items()})
    report = dict(status='pass', formal_result=False, new_native_runs=2, toy_vehicles=4, cases=reports,
        covered_native_requests=[0, 1, 2, 3], not_covered_native_requests=[4, 5],
        boundary='Only the tested603/790lane0 pairs sharing output lanes0/1. Z5 lane1->2/3, reverse arrival order, saturation, pedestrians/bicycles and field controller/priority ownership are not established. No field-fit or faster-passage claim.')
    (ROOT / 'audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(status='pass', new_native_runs=2, toy_vehicles=4, covered_requests=[0,1,2,3], uncovered=[4,5]),indent=2))


if __name__ == '__main__':
    main()
