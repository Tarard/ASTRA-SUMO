"""Read both sealed stage-two prefixes; never launch or alter native runs."""

from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import read_csv_rows
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-causal-initial-prefix-20261024-v1/advance-first900-120225"
SOURCE_EVALUATION = SOURCE / "full-evaluation"
CANDIDATE = "advance-second900-126232"


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def metrics(rows):
    residuals = [r["residual"] for r in rows]
    return dict(rows=len(rows), TAE=sum(abs(v) for v in residuals), SSE=sum(v*v for v in residuals), MAE=sum(abs(v) for v in residuals)/len(rows), max_abs_error=max(abs(v) for v in residuals))


def event_key(row):
    return row["vehicle_id"], row["detector_id"], row["notification_time_s"], row["time_s"], row["occupancy_s"]


def main():
    assert all((ROOT / name / "record-result.json").is_file() for name in ["reference", CANDIDATE]), "Wait for both terminal results."
    helpers = runpy.run_path(str(ROOT / "reference/executed-run.py"))
    assert sha(ROOT / "reference/executed-run.py") == "ee8c18ad0a0c057a49f4275e1bf3fe9f39f0466a27fc0ba8500394814324021c"
    targets = read_csv_rows(ROOT / "prefix26.csv")
    initial = read_csv_rows(SOURCE / "prepared/initialization-counts.csv")
    assert targets == [r for r in initial if 0 <= float(r["begin"]) < float(r["end"]) <= 1800] and len(targets) == 26
    data = {}
    for name in ["reference", CANDIDATE]:
        case = ROOT / name
        record, core, preflight, scope = [load(case / n) for n in ["record-result.json", "core-result.json", "preflight.json", "scope-proof.json"]]
        assert record["status"] == "pass" and len(record["checks"]) == 19 and all(record["checks"].values())
        assert not core["errors"] and core["inputs_unchanged"] and record["preflight_sha256"] == sha(case / "preflight.json")
        assert preflight["scope_sha256"] == sha(case / "scope-proof.json") and preflight["prefix26_sha256"] == sha(ROOT / "prefix26.csv")
        assert preflight["runner_sha256"] == sha(case / "executed-run.py") == ("ee8c18ad0a0c057a49f4275e1bf3fe9f39f0466a27fc0ba8500394814324021c" if name == "reference" else "f0d7445829729b30a5d02ca67d93d788dd77ff0257bb4e390d546b0bd095bc7e")
        for mapping in [scope["source_hashes"], preflight["source_hashes"], preflight["binaries"], record["native_output_hashes"]]:
            assert all(sha(Path(p)) == h for p, h in mapping.items())
        assert scope["prepared_hashes"] == preflight["prepared_hashes"]
        assert all(sha(case / "prepared" / n) == h for n, h in preflight["prepared_hashes"].items())
        assert all(sha(case / "implementation" / n) == h for n, h in preflight["implementation_sha256"].items())
        assert all(sha(Path(r["path"])) == r["sha256"] for r in core["inputs"] + core["snapshots"])
        native = case / "native"
        raw = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=core["instant_to_periodic_ids"], step_length=.1)
        assert raw["reconciled"] and all(abs(r["notification_time_s"]-1800) < 1e-8 for r in raw["outside_periodic_intervals"])
        with gzip.open(case / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
            assert raw == json.load(handle)
        intents = {r["vehicle_id"]: r for r in load(case / "prepared/lane-intentions.json")["vehicles"]}
        complete = raw["passages"] + raw["outside_periodic_intervals"]
        assert all(r["vehicle_id"] in intents and r["detector_id"] == intents[r["vehicle_id"]]["field_id"] for r in complete)
        assert max(Counter((r["vehicle_id"], r["detector_id"]) for r in complete).values(), default=0) <= 1
        periodic = helpers["interval_rows"](native / "field-counts.xml")
        rows = []
        for target in targets:
            key = target["detector_id"], float(target["begin"]), float(target["end"])
            actual, expected = int(periodic[key]["nVehContrib"]), int(target["expected_total"])
            assert actual == sum((r["detector_id"], r["interval_begin_s"], r["interval_end_s"]) == key for r in raw["passages"])
            rows.append(dict(field_id=key[0], begin_s=key[1], end_s=key[2], expected=expected, actual=actual, residual=actual-expected))
        scores = metrics(rows)
        assert scores == record["prefix26_metrics"] and metrics([r for r in rows if r["end_s"] == 900])["TAE"] == 0
        summary = helpers["summaries"](native / "summary.xml")
        monitor = load(native / "stall-monitor.json")
        command = load(native / "command.json")
        trips = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
        assert len(summary) == 18000 and float(summary[-1]["time"]) == 1799.9
        assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 1800 and monitor["library_completed"] and monitor["native_returncode"] is None
        assert monitor["native_version"] == [22, "SUMO 1.27.1"] and sha(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
        assert command["status"] == "pass" and command["returncode"] == 0
        assert not ET.parse(native / "collisions.xml").getroot().findall("collision") and not any(int(summary[-1][k]) for k in ["collisions", "teleports", "discarded"])
        assert len(trips) == len({r.get("id") for r in trips}) == int(summary[-1]["inserted"])
        assert all(r.get("id") in intents and 0 <= float(r.get("depart")) <= 1800 for r in trips)
        assert all(r.get("vaporized", "") in ({"", "end"} if float(r.get("arrival")) < 0 else {""}) for r in trips)
        coverage = load(case / "all182-coverage.json")
        assert len(coverage) == 182 and sum(r["measured_nVehContrib"] is None for r in coverage) == 156
        assert record["full130_metrics"] is None and record["remaining26_initial_metrics"] is None and record["combined182_metrics"] is None and not record["full130_calibration_acceptance"]
        data[name] = dict(metrics26=scores, h0=metrics([r for r in rows if r["end_s"] == 900]), h1=metrics([r for r in rows if r["begin_s"] == 900]), rows=rows, completion=summary[-1], raw=raw, monitor=monitor, trips=trips, summary=summary, periodic=periodic)
    reference, candidate = data["reference"], data[CANDIDATE]
    full_native = SOURCE_EVALUATION / "native"
    with gzip.open(SOURCE_EVALUATION / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        full_events = json.load(handle)["passages"]
    full_monitor = load(full_native / "stall-monitor.json")
    full_trips = ET.parse(full_native / "tripinfo.xml").getroot().findall("tripinfo")
    parity = dict(intervals26_all_attributes=reference["periodic"] == helpers["interval_rows"](full_native / "field-counts.xml"), summary18000_except_duration=reference["summary"] == helpers["summaries"](full_native / "summary.xml"),
        complete_events=sorted(map(event_key, reference["raw"]["passages"])) == sorted(event_key(r) for r in full_events if r["notification_time_s"] < 1800),
        arrived_routes=helpers["arrived_routes"](ROOT / "reference/native/vehicle-routes.xml") == helpers["arrived_routes"](full_native / "vehicle-routes.xml"),
        arrived_trips={r.get("id"): dict(r.attrib) for r in reference["trips"] if 0 <= float(r.get("arrival")) < 1800} == {r.get("id"): dict(r.attrib) for r in full_trips if 0 <= float(r.get("arrival")) < 1800},
        detector_holds=[r for r in reference["monitor"]["lane_section_hold"]["events"] if r["time_s"] < 1800] == [r for r in full_monitor["lane_section_hold"]["events"] if r["time_s"] < 1800],
        body_holds=[r for r in reference["monitor"]["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"] < 1800] == [r for r in full_monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"] < 1800])
    assert len(parity) == 7 and all(parity.values())
    proposals = load(ROOT / CANDIDATE / "departure-proposals.json")
    selected = {r["vehicle_id"]: r for r in proposals}
    old = {r.get("id"): r for r in ET.parse(ROOT / "reference/prepared/demand.rou.xml").getroot().findall("vehicle")}
    new = {r.get("id"): r for r in ET.parse(ROOT / CANDIDATE / "prepared/demand.rou.xml").getroot().findall("vehicle")}
    assert len(selected) == 467 and old.keys() == new.keys() and len(old) == 8640
    assert set(selected) == {i for i, r in old.items() if 900000 <= helpers["native_ms"](r.get("depart")) < 1800000}
    shifts = Counter()
    for identity in old:
        restored = deepcopy(new[identity])
        restored.set("depart", old[identity].get("depart"))
        assert ET.tostring(restored) == ET.tostring(old[identity])
        delta = helpers["native_ms"](new[identity].get("depart"))-helpers["native_ms"](old[identity].get("depart"))
        if identity in selected:
            shifts[delta] += 1
        else:
            assert delta == 0
    assert shifts == {-126000: 232, -90000: 235}
    by_id = [{r["vehicle_id"]: r for r in d["raw"]["passages"]} for d in [reference, candidate]]
    full_by_id = {r["vehicle_id"]: r for r in full_events}
    selected_events = [dict(vehicle_id=i, field_id=selected[i]["field_id"], source_full_notification_s=full_by_id.get(i, {}).get("notification_time_s"), reference_notification_s=by_id[0].get(i, {}).get("notification_time_s"), candidate_notification_s=by_id[1].get(i, {}).get("notification_time_s")) for i in selected]
    changes = []
    for before, after in zip(reference["rows"], candidate["rows"]):
        key = before["field_id"], before["begin_s"], before["end_s"]
        groups = []
        for d in [reference, candidate]:
            groups.append({r["vehicle_id"] for r in d["raw"]["passages"] if (r["detector_id"], r["interval_begin_s"], r["interval_end_s"]) == key})
        a, b = groups
        changes.append(dict(**after, reference=before["actual"], changed_gained=sorted((b-a) & selected.keys()), changed_lost=sorted((a-b) & selected.keys()), unchanged_gained=sorted((b-a)-selected.keys()), unchanged_lost=sorted((a-b)-selected.keys())))
    report = dict(schema="astra.hamburg.causal-second-prefix-126-independent/v1", audit_status="pass", reference={k: reference[k] for k in ["metrics26", "h0", "h1", "completion"]}, candidate={k: candidate[k] for k in ["metrics26", "h0", "h1", "completion"]}, reference_strict_parity=parity,
        input_scope=dict(requests=8640, changed_h1_departures=467, h0_frozen434=True, future_frozen7739=True, native_shift_counter_ms=dict(shifts), routes_stops_fields_unchanged=True),
        selected_complete_reference=sum(i in by_id[0] for i in selected), selected_complete_candidate=sum(i in by_id[1] for i in selected), field_bin_membership_changes=changes,
        candidate_first900_interval_attributes_equal={k: v for k, v in reference["periodic"].items() if k[2] == 900} == {k: v for k, v in candidate["periodic"].items() if k[2] == 900}, candidate_first900_summary_equal=reference["summary"][:9000] == candidate["summary"][:9000],
        safe=True, repeated_fields=0, outside_primary=0, measured_real_rows=26, unmeasured_real_rows=156, main130_metrics=None, remaining26_initial_metrics=None, full_calibration_acceptance=False,
        claim_boundary="Only0–1800s is measured. Frozen first13 measured rows remain exact. Other26 initialization and130 main rows are unknown, not zero. Measured cohort membership changes are bookkeeping, not a causal decomposition or evidence of full health, true OD, or field control.")
    save(OUT / "summary.json", report)
    save(OUT / "changed467-actual-events.json", selected_events)
    paths = [Path(__file__), ROOT / "prefix26.csv"] + [ROOT / name / p for name in ["reference", CANDIDATE] for p in ["record-result.json", "preflight.json", "executed-run.py", "scope-proof.json"]]
    save(OUT / "source-hashes.json", {str(p): sha(p) for p in paths})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(reference=report["reference"], candidate=report["candidate"], selected_before=report["selected_complete_reference"], selected_after=report["selected_complete_candidate"], manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
