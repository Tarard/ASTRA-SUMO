"""Copy stage-one inputs and retain an exact real 0–1800 s target subset."""

import csv
import hashlib
import io
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-causal-initial-prefix-20261024-v1/advance-first900-120225"
SOURCE_EVALUATION = SOURCE / "full-evaluation"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    case = ROOT / "reference"
    assert not case.exists(), "Preserve any reference evidence."
    with (SOURCE / "prepared/initialization-counts.csv").open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        names, all_rows = reader.fieldnames, list(reader)
    rows = [r for r in all_rows if 0 <= float(r["begin"]) < float(r["end"]) <= 1800]
    assert len(all_rows) == 52 and len(rows) == len({(r["detector_id"], r["begin"], r["end"]) for r in rows}) == 26
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=names, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    prefix = ROOT / "prefix26.csv"
    raw = buffer.getvalue().encode("utf-8")
    if prefix.exists():
        assert prefix.read_bytes() == raw
    else:
        prefix.write_bytes(raw)
    save(ROOT / "prefix26-provenance.json", dict(source=str(SOURCE / "prepared/initialization-counts.csv"), source_sha256=digest(SOURCE / "prepared/initialization-counts.csv"), prefix26_sha256=digest(prefix), filter="0<=begin<end<=1800", rows=26, original_initial_rows=52, original_main_rows=130, observations_changed=False, unmeasured_real_rows=156))
    prepared = case / "prepared"
    prepared.mkdir(parents=True)
    for name in NAMES:
        shutil.copyfile(SOURCE / "prepared" / name, prepared / name)
    save(case / "departure-proposals.json", [])
    request_path = SOURCE_EVALUATION / "native/native-request.json"
    request = json.loads(request_path.read_bytes())
    command = request["command"]
    driver = {k: request[k] for k in ["backend", "end_s", "all_stopped_timeout_s", "junction_body_hold", "junction_body_hold_nodes"]}
    driver.update(step_length_s=command[command.index("--step-length") + 1], seed=command[command.index("--seed") + 1], precision=command[command.index("--precision") + 1])
    source_paths = [*(SOURCE / "prepared" / n for n in NAMES), request_path, SOURCE_EVALUATION / "verdict.json", case / "departure-proposals.json", Path(__file__)]
    save(case / "scope-proof.json", dict(status="pass", N=8640, native_runs=0, formal_result=False, source_hashes={str(p): digest(p) for p in source_paths}, prepared_hashes={n: digest(prepared / n) for n in NAMES}, original_driver_scope=driver, authorized_prefix_end_s=1800, actual_changes=dict(request_departures_changed=0), claim_boundary="Full8640 source requests and full130+52 observations are copied exactly. Only26 real rows at0–1800s are measured. The source full run is safe but unhealthy; valid prefix evidence does not imply full health or a calibrated main window."))
    print(json.dumps(dict(status="prepared", N=8640, prefix26_sha256=digest(prefix), native_runs=0)))


if __name__ == "__main__":
    main()
