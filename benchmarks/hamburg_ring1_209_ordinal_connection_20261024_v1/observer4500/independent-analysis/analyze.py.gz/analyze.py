"""Check the saved episode's observable boundaries; perform no native run."""

import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
NATIVE = ROOT / "native"
SOURCE = ROOT.parent / "hamburg-119-common-offset-20261024-v1/plus15"
EGO, LEAD, PRIMARY = "od_0104_v00042", "od_0102_v00018", "od_0102_v00015"


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def locate(frame, identity):
    rows = [dict(lane=lane, **row) for lane, data in frame["lanes"].items() for row in data["vehicles"] if row["id"] == identity]
    assert len(rows) <= 1
    return rows[0] if rows else None


def main():
    record, coverage = load(NATIVE / "record-result.json"), load(NATIVE / "observer-coverage.json")
    assert record["status"] == "pass" and len(record["checks"]) == 10 and all(record["checks"].values())
    assert coverage["status"] == "pass" and coverage["frames"] == 301 and not coverage["getter_errors"] and coverage["hook_restored"]
    assert sum(row["simulated_count"] is None for row in load(NATIVE / "target182-prefix-measurements.json")) == 117
    with gzip.open(NATIVE / "read-only-samples.jsonl.gz", "rt", encoding="utf-8") as handle:
        frames = [json.loads(line) for line in handle]
    assert len(frames) == 301 and [round(f["native_step_time_s"]*10) for f in frames] == list(range(44050, 44351))
    assert all(abs(f["api_time_s"]-.1-f["native_step_time_s"]) < 1e-8 for f in frames)
    green = [f for f in frames if 4410 <= f["native_step_time_s"] < 4424]
    assert len(green) == 140
    net = ET.parse(SOURCE / "prepared/network.net.xml").getroot()
    lanes = {lane.get("id"): lane for edge in net.findall("edge") for lane in edge.findall("lane")}
    connections = net.findall("connection")
    path = [":LSA119_part0_12_0", "79014037#1_0", ":266199063_2_1", "186713429_1"]
    gap_errors, samples = [], []
    for frame in green:
        ego, lead = locate(frame, EGO), locate(frame, LEAD)
        head = frame["heads"]["24483344#1_0"]
        assert ego["lane"] == "24483344#1_0" and ego["speed_m_s"] == 0 and abs(ego["pos_m"]-94.129) < 1e-8
        assert head["id"] == EGO and head["leader"][0] == LEAD and head["stop_state"] == 0 and not head["stops"] and head["lane_change_mode"] == 512 and head["speed_mode"] == 31
        assert frame["tls"]["LSA119_part0"]["state"][12] == "G" and lead["lane"] == ":343633354_0_1"
        reconstructed = float(lanes[ego["lane"]].get("length"))-ego["pos_m"]+sum(float(lanes[lane].get("length")) for lane in path)+lead["pos_m"]-5.-2.5
        gap_errors.append(abs(reconstructed-head["leader"][1]))
        samples.append(dict(time_s=frame["native_step_time_s"], leader_gap_api_m=head["leader"][1], leader_pos_m=lead["pos_m"], leader_speed_m_s=lead["speed_m_s"]))
    assert max(gap_errors) < 1e-8
    assert next(f for f in frames if f["native_step_time_s"] == 4424)["tls"]["LSA119_part0"]["state"][12] == "y"
    occupancy = {}
    for lane in [*path, "141050975_1", "141050975_2", "141050975_3"]:
        occupancy[lane] = dict(front_vehicle_count_min=min(len(f["lanes"][lane]["vehicles"]) for f in green), front_vehicle_count_max=max(len(f["lanes"][lane]["vehicles"]) for f in green), length_m=float(lanes[lane].get("length")), samples_with_moving_front=sum(any(v["speed_m_s"] > .1 for v in f["lanes"][lane]["vehicles"]) for f in green))
    full_hold = load(SOURCE / "evaluation/native/stall-monitor.json")["lane_section_hold"]
    prefix_hold = load(NATIVE / "stall-monitor.json")["lane_section_hold"]
    holds = {identity: [r for r in full_hold["events"] if r["vehicle_id"] == identity] for identity in [EGO, PRIMARY]}
    bodies = {identity: [r for r in full_hold["junction_body_hold"]["events"] if r["vehicle_id"] == identity] for identity in [EGO, PRIMARY]}
    assert [r for r in holds[PRIMARY] if r["event"] == "released"] == [dict(vehicle_id=PRIMARY, event="released", time_s=4364.6, restored_mode=1621)]
    assert all(r["time_s"] < 4405 for r in bodies[PRIMARY])
    trajectory = []
    for frame in frames:
        row = locate(frame, PRIMARY)
        if row:
            trajectory.append(dict(time_s=frame["native_step_time_s"], **row, signal196_lane1=frame["tls"]["1966837175"]["state"][1]))
    changes = [dict(before=a, after=b) for a, b in zip(trajectory, trajectory[1:]) if a["lane"] != b["lane"]]
    assert len(changes) == 1 and changes[0]["before"]["time_s"] == 4420.6 and changes[0]["after"]["time_s"] == 4420.7
    stopped = next(row for row in trajectory if row["time_s"] == 4415)
    distance_to_end = float(lanes["141050980#0_1"].get("length"))-stopped["pos_m"]
    assert stopped["speed_m_s"] == 0 and abs(distance_to_end-9.571470957263479) < 1e-8
    primary_route = next(v for v in ET.parse(SOURCE / "prepared/demand.rou.xml").getroot().findall("vehicle") if v.get("id") == PRIMARY).find("route").get("edges").split()
    assert "1108564798#0" in primary_route and "27064186#0" not in primary_route
    segment = ["141050980#0", "141050980#1", "603103444", "73474895", "1108564798#0"]
    supports = {}
    for first_lane in [1, 2]:
        states = {first_lane}
        for a, b in zip(segment, segment[1:]):
            states = {int(c.get("toLane")) for c in connections if c.get("from") == a and c.get("to") == b and int(c.get("fromLane")) in states}
        supports[first_lane] = bool(states)
    assert supports == {1: False, 2: True}
    report = dict(schema="astra.hamburg.119-zero-discharge-observable-boundaries/v1", status="pass", native_runs_by_audit=0, parity_checks=record["checks"], getter_errors=0, observed_window_inclusive_s=[4405, 4435], analyzed_green_half_open_s=[4410, 4424], green_samples=140,
        focal=dict(vehicle_id=EGO, position_m=94.129, speed_m_s=0, active_stops=False, observed_lane_change_mode=512, speed_mode=31, field_hold_full_source=holds[EGO], body_hold_full_source=bodies[EGO], source_full_release_4592_is_not_observed_by4500_prefix=True),
        actual_leader=dict(vehicle_id=LEAD, lane=":343633354_0_1", API_gap_range_m=[min(r["leader_gap_api_m"] for r in samples), max(r["leader_gap_api_m"] for r in samples)], speed_range_m_s=[min(r["leader_speed_m_s"] for r in samples), max(r["leader_speed_m_s"] for r in samples)], actual_lane_path=path, route_gap_reconstruction_max_error_m=max(gap_errors), gap_formula="remaining244+119internal+790+GSinternal+186+leader_pos-leader_length5-ego_minGap2.5"),
        front_occupancy=occupancy,
        partial_body_boundary="No front IDs on790/186 does not imply free receiving space. The leader front at2.85m of the next internal can leave part of its5m body on preceding186. Exact private availableSpace is not recorded.",
        downstream_primary=dict(vehicle_id=PRIMARY, stop_lane="141050980#0_1", stop_position_m=stopped["pos_m"], distance_to_lane_end_m=distance_to_end, actual_lane_transition=changes[0], field_hold_full_source=holds[PRIMARY], body_hold_full_source=bodies[PRIMARY], no_lane_change_path_to_primary_from_lane1=False, no_lane_change_path_to_primary_from_lane2=True, current_lane_change_mode_directly_queried=False),
        preserved_source_input_paths=True, prefix_hold_events_checked=len(prefix_hold["events"]), claim_boundary="Observed native positions, colors, stops and two documented hold lifecycles only. The lane transition is observed; its strategic cause is not queried. Queue/selection/red interactions are consistent with spillback, but neither the private keepClear branch nor a unique controller/hold bug is proved. The full chain is not presented as independently queried getLeader pairs.")
    save(OUT / "summary.json", report)
    with (OUT / "v15-trajectory.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(trajectory[0]))
        writer.writeheader()
        writer.writerows(trajectory)
    paths = [Path(__file__), ROOT / "plan.json", NATIVE / "record-result.json", NATIVE / "observer-coverage.json", NATIVE / "read-only-samples.jsonl.gz", NATIVE / "stall-monitor.json", SOURCE / "evaluation/native/stall-monitor.json", SOURCE / "prepared/network.net.xml", SOURCE / "prepared/demand.rou.xml"]
    save(OUT / "source-hashes.json", {str(path): sha(path) for path in paths})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(status="pass", green_samples=140, gap_error=max(gap_errors), lane_change_time_s=4420.7, v15_hold_released_s=4364.6, manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
