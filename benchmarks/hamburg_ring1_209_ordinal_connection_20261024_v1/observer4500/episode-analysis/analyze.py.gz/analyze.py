"""Locate the recorded lane1 queue and route split; no native execution."""

from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
FAMILY = ROOT.parent
REPO = ROOT.parents[2]
SOURCE = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15"
IDS = ("od_0104_v00042", "od_0102_v00018", "od_0102_v00016", "od_0102_v00014", "od_0091_v00047",
    "od_0091_v00049", "od_0091_v00046", "od_0102_v00015", "od_0091_v00050")


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    frames = [json.loads(line) for line in gzip.open(FAMILY / "native/read-only-samples.jsonl.gz", "rt", encoding="utf-8")]
    assert len(frames) == 301
    records, transitions, tls_changes = [], [], []
    previous, prior_tls = {}, {}
    scenes = []
    for frame in frames:
        tick = frame["native_step_time_s"]
        scene = {"native_step_time_s": tick, "api_time_s": frame["api_time_s"], "vehicles": {}, "tls": frame["tls"], "heads": frame["heads"]}
        for lane, data in frame["lanes"].items():
            assert data["getter_ok"]
            for vehicle in data["vehicles"]:
                identity = vehicle["id"]
                if identity not in IDS:
                    continue
                row = {"native_step_time_s": tick, "api_time_s": frame["api_time_s"], "vehicle_id": identity,
                    "lane": lane, "position_m": vehicle["pos_m"], "speed_m_s": vehicle["speed_m_s"]}
                records.append(row)
                scene["vehicles"][identity] = row
                if identity in previous and lane != previous[identity]["lane"]:
                    transitions.append({"vehicle_id": identity, "before": previous[identity], "after": row,
                        "same_ordinary_edge_lane_change": lane.rsplit("_", 1)[0] == previous[identity]["lane"].rsplit("_", 1)[0]})
                previous[identity] = row
        if tick in (4410, 4415, 4420, 4424, 4435):
            scenes.append(scene)
        for identity, state in frame["tls"].items():
            if prior_tls.get(identity) != state:
                tls_changes.append({"native_step_time_s": tick, "tls_id": identity, **state})
                prior_tls[identity] = state
    monitor = json.loads((SOURCE / "evaluation/native/stall-monitor.json").read_bytes())["lane_section_hold"]
    held = [row for row in monitor["events"] if row["vehicle_id"] in IDS]
    net = ET.parse(SOURCE / "prepared/network.net.xml").getroot()
    edges = {edge.get("id"): edge for edge in net.findall("edge") if edge.get("function") != "internal"}
    all_lanes = {lane.get("id"): lane.attrib for edge in net.findall("edge") for lane in edge.findall("lane")}
    source_routes = {v.get("id"): v for v in ET.parse(SOURCE / "evaluation/native/vehicle-routes.xml").getroot().findall("vehicle")}
    loops = ET.parse(SOURCE / "prepared/field-loops.add.xml").getroot()
    loop_edges = {loop.get("id"): loop.get("lane").rsplit("_", 1)[0] for loop in loops}
    compact = json.loads(gzip.decompress((SOURCE / "evaluation/contributing-passages.json.gz").read_bytes()))
    route_evidence = []
    for identity in IDS:
        vehicle = source_routes[identity]
        route = vehicle.find("route")
        ordinary = route.get("edges").split()
        nodes = [edges[edge].get("from") for edge in ordinary] + [edges[ordinary[-1]].get("to")]
        route_evidence.append({"vehicle_id": identity, "arrival_s": vehicle.get("arrival"),
            "edges": ordinary, "ordinary_exit_times_s": route.get("exitTimes").split(),
            "repeated_ordinary_edges": [edge for edge, count in Counter(ordinary).items() if count > 1],
            "repeated_model_junctions": [node for node, count in Counter(nodes).items() if count > 1],
            "potential_loop_edges_on_route": {field: edge for field, edge in loop_edges.items() if edge in ordinary},
            "actual_complete_e1": [row for row in compact["passages"] if row["vehicle_id"] == identity]})
    relevant = {"141050975", "141050980#0", "141050980#1", "603103444", "73474895", "1108564798#0", "1108564798#1"}
    connections = [c.attrib for c in net.findall("connection") if c.get("from") in relevant]
    for connection in connections:
        if connection.get("fromLane"):
            for key in ("from", "to"):
                lane = all_lanes[connection[key] + "_" + connection[key + "Lane"]]
                assert "passenger" not in lane.get("disallow", "").split()
                assert not lane.get("allow") or "passenger" in lane["allow"].split()
    evidence = {"status": "pass", "formal_result": False, "native_runs": 0,
        "native_parity": json.loads((FAMILY / "native/record-result.json").read_bytes())["status"],
        "directly_queried_leader": "4410–4424: Z4 headod_0104_v00042 reportsod_0102_v00018 ahead82.349–84.395m. Head stays94.129m with119link12G, no stop/stop-state, speedMode31 and assigned-lane mode512.",
        "spatial_route_compatible_queue_sequence": ["244#1_0:od_0104_v00042", ":343633354_0_1:od_0102_v00018",
            "141050975_1:od_0102_v00016", "141050975_1:od_0102_v00014", "141050975_1:od_0091_v00047",
            "141050980#0_1:od_0091_v00049", "141050980#0_1:od_0091_v00046", "141050980#0_1:od_0102_v00015"],
        "lane_split": "The same-index path141#0_1→141#1_1→603103444_1→73474895_0 only continues to27064186#0. A primary110856 route needs a lane change to an approach feeding734lane1/2. This describes the current model, not field correctness.",
        "v15": {"prior_hold_release_api_s": 4364.6, "restored_mode": 1621, "stopped_position_m": 17.742492042736522,
            "distance_to_edge_end_m": 27.313963 - 17.742492042736522,
            "observed_lane_change_native_s": 4420.7, "from_lane": "141050980#0_1", "to_lane": "141050980#0_2"},
        "explicit_red_queue_head": "Residentialod_0091_v00050 stops at:244203534_0_1 pos0.294059. Internal length1.136838 plus603_1 length0.158221 minus native1.001m stop offset equals0.294059. Its next movement266197536/link1 isr until4416, thenG; it exits603 at4416.8. It then stops734_0 pos2.216263 at266197525/link5r until4426 and exits734 at4426.8.",
        "after_v15_moves": "v46 residential follows lane1 through196 at4424.3 and enters244 internal4425.6. Next primaryv49 remains near the entry of141#0_1. The queue through141lane1 and:343633354 remains; v42 still stopped at4435. Full recorded v42 front entry is4590.8.",
        "claim_boundary": "Only v42→v18 is a queried leader relation. Further links are observed route-compatible lane ordering, not separately queried leader or private availableSpace. Required lane changing is a support fact; its strategic motive and all stopping causes were not queried. Actual red/green states and movements are recorded. No claim that mode512, long empty internal space, duplicate signals, or one specific keepClear branch caused the stop."}
    assert any(row["vehicle_id"] == "od_0102_v00015" and row["same_ordinary_edge_lane_change"]
        and row["after"]["native_step_time_s"] == 4420.7 and row["after"]["lane"] == "141050980#0_2" for row in transitions)
    assert all(not row["repeated_ordinary_edges"] and not row["repeated_model_junctions"] for row in route_evidence)
    assert all(len(row["actual_complete_e1"]) == 1 for row in route_evidence)
    assert any(row["vehicle_id"] == "od_0102_v00015" and row["event"] == "released"
        and row["time_s"] == 4364.6 and row["restored_mode"] == 1621 for row in held)
    save(ROOT / "evidence.json", evidence)
    save(ROOT / "scenes.json", scenes)
    save(ROOT / "lane-transitions.json", transitions)
    save(ROOT / "routes-and-holds.json", {"routes": route_evidence, "lane_hold_events": held,
        "body_hold_events": [row for row in monitor["junction_body_hold"]["events"] if row["vehicle_id"] in IDS],
        "connections": connections, "lane_attributes": {key: value for key, value in all_lanes.items() if key.startswith(("141050", ":244203534_0_1", "603103444", "73474895"))}})
    write_csv(ROOT / "vehicle-window.csv", records)
    write_csv(ROOT / "tls-changes.csv", tls_changes)
    paths = [FAMILY / "native/read-only-samples.jsonl.gz", FAMILY / "native/record-result.json", SOURCE / "prepared/network.net.xml",
        SOURCE / "prepared/control.add.xml", SOURCE / "prepared/field-loops.add.xml", SOURCE / "evaluation/native/vehicle-routes.xml",
        SOURCE / "evaluation/native/stall-monitor.json", SOURCE / "evaluation/contributing-passages.json.gz", Path(__file__)]
    save(ROOT / "source-hashes.json", {str(path): {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in paths})
    print(json.dumps({"status": "pass", "native_runs": 0, "records": len(records), "scene_count": len(scenes),
        "v15_actual_lane_change_s": 4420.7, "all_full_routes_arrived": all(float(row["arrival_s"]) > 0 for row in route_evidence),
        "repeated_edges_or_junctions": sum(bool(row["repeated_ordinary_edges"] or row["repeated_model_junctions"]) for row in route_evidence)}))


if __name__ == "__main__":
    main()
