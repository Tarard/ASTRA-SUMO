The passive prefix matches the +15 full source on65 closed E1 rows,45000 summary steps,34993 instant events,2390 arrived routes/trips, and driver hold events. The local record contains301 frames. This analysis starts no native run.

At4415, Z4 headod_0104_v00042 is stationary at244#1_0 position94.129m with119link12G, no remaining stop, and speedMode31. Its queried leader isod_0102_v00018,84.302m ahead in:343633354_0_1. The observed lane1 queue continues through141050975 and into141050980#0. Further pairs are route-compatible spatial ordering, not additional queried leader relations.

Primary-tailod_0102_v00015 is stationary on141050980#0_1 at17.742m. Its original field hold ended4364.6 with mode1621 restored. It changes to#0_2 at4420.7. Keeping lane1 would feed603103444_1→73474895_0, whose only current continuation is the residential27064186 branch. The primary110856 tail therefore requires a lane change in the current model. Its actual reason for stopping was not queried.

Afterv15 leaves lane1, residentialv46 advances, but the next primaryv49 still occupies the entrance to141#0_1. The upstream lane1 queue remains. Z4 headv42 stays stopped through4435. Its original full-run front entry into119 is4590.8.

There is also a directly located red-signal queue head. Residentialod_0091_v00050 is stopped at:244203534_0_1 position0.294059m. The next ordinary edge603103444_1 is only0.158221m long. The next signal266197536/link1 is red until4416. The car starts at4416 and enters the following internal lane at4416.8. It then stops on734_0 at2.216263m while266197525/link5 remains red until4426. It starts at4426 and enters that junction at4426.8. These actual transitions locate two receiving restrictions rather than naming six possible lights.

Both complete route types are legal in the current model. All nine listed vehicles arrive at199500676, have no repeated ordinary edge or model junction, and contribute once at their own field. This does not verify field topology or a true route share. The original lane1 continuation restriction remains a source-review question.

The record does not expose private availableSpace or every link request. It does not prove that the long internal lane, lane mode512, any specific keepClear branch, or one signal alone causes the stopped119 head. The route split, actual lane change, queue ordering, and signal waits are separate observations.
