"""Check prefix parsing against a temporary slice of existing outputs; no native run."""

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import runpy
import tempfile
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
module = runpy.run_path(str(ROOT / "record_prefix.py"))
checked = module["check"]()
elements = runpy.run_path(str(module["OLD_PARSER"]))["elements"]
source = module["SOURCE"] / "evaluation/native"
audit_globals = module["audit"].__globals__
with tempfile.TemporaryDirectory() as temporary:
    destination = Path(temporary)
    for name, tag, attribute, inclusive in [("field-counts.xml", "interval", "end", True),
        ("summary.xml", "step", "time", False), ("instant-e1.xml", "instantOut", "time", False),
        ("tripinfo.xml", "tripinfo", "arrival", False), ("vehicle-routes.xml", "vehicle", "arrival", False)]:
        root = ET.Element(ET.parse(source / name).getroot().tag)
        for row in elements(source / name, tag):
            value = Decimal(row.get(attribute))
            if 0 <= value <= 4500 if inclusive else 0 <= value < 4500:
                root.append(deepcopy(row))
        ET.ElementTree(root).write(destination / name, encoding="utf-8", xml_declaration=True)
    monitor = json.loads((source / "stall-monitor.json").read_bytes())
    hold = monitor["lane_section_hold"]
    hold["events"] = [r for r in hold["events"] if r["time_s"] <= 4500]
    hold["junction_body_hold"]["events"] = [r for r in hold["junction_body_hold"]["events"] if r["time_s"] <= 4500]
    monitor.update(status="completed", simulation_time_s=4500)
    module["save"](destination / "stall-monitor.json", monitor)
    module["save"](destination / "observer-coverage.json", {"status": "pass", "frames": 301, "getter_errors": []})
    ET.ElementTree(ET.Element("collisions")).write(destination / "collisions.xml", encoding="utf-8")
    audit_globals["NATIVE"] = destination
    module["audit"]()
    result = json.loads((destination / "record-result.json").read_bytes())
    assert result["status"] == "pass"
    targets = json.loads((destination / "target182-prefix-measurements.json").read_bytes())
    assert sum(r["simulated_count"] is not None for r in targets) == 65
    assert sum(r["simulated_count"] is None for r in targets) == 117
    tree = ET.parse(destination / "field-counts.xml")
    tree.getroot().find("interval").set("nVehContrib", "99999")
    tree.write(destination / "field-counts.xml", encoding="utf-8")
    rejected = False
    try:
        module["audit"]()
    except AssertionError:
        rejected = True
    assert rejected
module["save"](ROOT / "audit-selfchecks.json", {"status": "pass", "native_runs": 0,
    "same_source_prefix65_and45000_pass": True, "unmeasured117_rows_null": True, "changed_e1_rejected": True,
    "scope_check": {k: v for k, v in checked.items() if k != "runtime"}})
