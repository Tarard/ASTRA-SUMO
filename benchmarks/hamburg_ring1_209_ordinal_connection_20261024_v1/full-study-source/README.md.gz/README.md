This prepares one full evaluation of the209 ordinal connection candidate. Preparation has not run traffic. Native launch now binds the actual reviewed smoke report, schema`astra.hamburg.209-ordinal-smoke/v1`, and SHA256`0a080b83fb656e6000669a8a2c862bb651d4190df9384f6d87dc8f7a3c5db9c4`.

The source is the completed +15 case. All8640 requests, intentions,13 loops,130 main targets, and52 initialization targets keep their original bytes. Only network/control change to candidatev3. Scenario metadata records the new hashes. No OD model or demand is generated.

Use`run_full.py --check-only` and`selfcheck.py` for offline checks. The source +15 actual208 E1 data is audited again through the existing response helper. Runtime checks require the same project Python, SUMO/Libsumo binaries, and project module paths as the parent.

After smoke binding, the explicit`--run` entry uses the shared point-detector runner and measurement summary. Settings remain14400s,0.1s,seed104,Libsumo, and the original four body-hold nodes. The code saves130/52/182/40/208 tables, protected53556, complete event correspondence, safety, and completion/backlog. All original fields remain.

The result compares both the +15 parent and original offset0 reference. Initialization and all182 changes are reported without treating non-worseningall182 as a user requirement. Exact130 fit, safety, healthy completion, and physical applicability are separate fields. Better counts would not certify the source geometry. Worse counts alone would not refute it. This remains a source-supported hypothesis requiring physical review, not field-certified zero.
