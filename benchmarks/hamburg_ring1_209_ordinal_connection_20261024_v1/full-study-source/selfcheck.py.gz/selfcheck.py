"""Offline source/scope audit and actual smoke/hash binding; never run native."""

import json
from pathlib import Path
import runpy


ROOT = Path(__file__).resolve().parent
module = runpy.run_path(str(ROOT / "run_full.py"))
result = module["check"]()
assert result["status"] == "pass"
smoke = module["require_smoke"]()
assert smoke["status"] == "pass" and smoke["actual_unique_movements"] == 6
before = json.loads((ROOT / "unbound-history/scope-proof.json").read_bytes())
after = json.loads((ROOT / "full/scope-proof.json").read_bytes())
assert before["prepared_hashes"] == after["prepared_hashes"]
globals_ = module["check"].__globals__
original = globals_["sha"]
try:
    globals_["sha"] = lambda _: "tampered"
    try:
        module["check"]()
    except AssertionError:
        pass
    else:
        raise AssertionError("Tampered input hashes were accepted.")
finally:
    globals_["sha"] = original
assert not (ROOT / "full/evaluation").exists()
report = {"status": "pass", "native_runs": 0, "unchanged8640_scope": True,
    "actual_source_plus15_182_offline_audit": True, "same_project_binary_hashes_and_modules": True,
    "bound_actual_smoke_pass": True, "all8_prepared_hashes_unchanged": True,
    "tampered_hash_rejected": True}
(ROOT / "offline-selfchecks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))
