"""Read one sealed 209 response and two references; never launch or poll SUMO."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import runpy
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
CASE = ROOT / "full"
SOURCE = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15"
OFFSET0 = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
CANDIDATE = REPO / "outputs/hamburg-209-ordinal-connection-20261024-v1/candidate-v3"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"
FILES = ("demand.rou.xml", "lane-intentions.json", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv")
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def static_checks():
    proof, preflight = load(CASE / "scope-proof.json"), load(CASE / "preflight.json")
    prepared = CASE / "prepared"
    assert proof["N"] == 8640 and all((prepared / n).read_bytes() == (SOURCE / "prepared" / n).read_bytes() for n in FILES)
    assert all((prepared / n).read_bytes() == (CANDIDATE / n).read_bytes() for n in ("network.net.xml", "control.add.xml"))
    assert sha(prepared / "network.net.xml") == "4cd5d1b95cce0f43b0626e82c7066cce3b1807db35840c115bcf66252437ae80"
    assert sha(prepared / "control.add.xml") == "27220b430aa68c24f0ad360c57ee3bd0f4b8dcdc88aead5344bcff00e4f43e3b"
    assert all(sha(p) == value for p, value in proof["source_hashes"].items())
    assert all(sha(prepared / n) == value for n, value in proof["prepared_hashes"].items())
    assert preflight["scope_sha256"] == sha(CASE / "scope-proof.json")
    assert all(sha(CASE / "implementation" / n) == value for n, value in preflight["implementation_sha256"].items())
    assert sha(CASE / "executed-driver.py") == preflight["implementation_sha256"]["run_full.py"]
    runtime = preflight["runtime"]
    assert all(sha(p) == value for p, value in runtime["binaries"].items())
    for module in runtime["modules"].values():
        assert module["version"] == "1.27.1" and Path(module["path"]).resolve().is_relative_to(REPO / ".venv")
        assert sha(module["path"]) == module["sha256"]
    assert sha(runtime["native_library"]["path"]) == runtime["native_library"]["sha256"]
    assert runtime["native_library"]["sha256"] == "b7fec284bf60e07fd6b10d2b58547530f13a83e34ff39aa0facb20a4bad6036e"
    assert preflight["smoke"]["sha256"] == sha(Path(preflight["smoke"]["path"])) == "0a080b83fb656e6000669a8a2c862bb651d4190df9384f6d87dc8f7a3c5db9c4"
    assert (preflight["end_s"], preflight["step_length_s"], preflight["seed"]) == (14400, .1, 104)
    return proof, preflight


def stats(data):
    return {k: data[k] for k in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true", help="Read immutable inputs/runtime records only; never read active native XML.")
    args = parser.parse_args()
    proof, preflight = static_checks()
    if args.check_only:
        print(json.dumps({"status": "pass", "native_runs": 0, "five_source_inputs_byte_equal": True, "candidate_hashes_match": True, "runtime_hashes_match": True}))
        return
    assert (CASE / "verdict.json").is_file(), "Terminal verdict required; active native XML is not read."
    assert not (OUT / "summary.json").exists(), "Preserve the sealed independent result."
    verdict = load(CASE / "verdict.json")
    assert verdict["status"] == "diagnostic_measurement_complete", "Preserve invalid raw result; do not reinterpret partial native output."
    sys.path.insert(0, str(HELPER.parent))
    tools = runpy.run_path(str(HELPER))
    data = {}
    for label, case in (("plus15", SOURCE), ("offset0", OFFSET0), ("candidate", CASE)):
        evaluation = case / "evaluation"
        data[label] = tools["evidence"](case / "prepared", evaluation, evaluation / "contributing-passages.json.gz", 8640)
    after = data["candidate"]
    assert verdict["after"] == stats(after)
    monitor = load(CASE / "evaluation/native/stall-monitor.json")
    run = load(CASE / "evaluation/native/run.json")
    assert run["errors"] == [] and run["native_status"] == "pass" and run["inputs_unchanged"]
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400
    assert monitor["library_completed"] is True and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"]
    assert monitor["native_library"] == preflight["runtime"]["native_library"]
    assert Path(monitor["api_module"]).resolve().is_relative_to(REPO / ".venv")
    assert Path(monitor["traci_module"]).resolve().is_relative_to(REPO / ".venv")
    vehicles = {v.get("id"): v for v in ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle")}
    fields = {r["vehicle_id"]: r["field_id"] for r in load(CASE / "prepared/lane-intentions.json")["vehicles"]}
    assert len(vehicles) == len(fields) == 8640 and vehicles.keys() == fields.keys()
    repeats = [{"vehicle_id": identity, "field": field, "count": n} for identity, events in after["by_vehicle"].items() for field, n in Counter(e["detector_id"] for e in events).items() if n > 1]
    outside = [{"vehicle_id": identity, "actual_field": e["detector_id"], "intended_field": fields.get(identity)} for identity, events in after["by_vehicle"].items() for e in events if e["detector_id"] != fields.get(identity)]
    unknown = sorted(after["by_vehicle"].keys() - vehicles.keys())
    unique_once = all(len(after["by_vehicle"].get(identity, [])) == 1 and after["by_vehicle"][identity][0]["detector_id"] == field for identity, field in fields.items())
    assert verdict["repeated_vehicle_fields"] == repeats and verdict["contributions_outside_prior_primary_intention"] == outside
    assert verdict["unique_intended_fields"] == (unique_once and not repeats and not outside)
    protected = [r for r in after["initial"] + after["main"] if r["detector_id"] in FIELDS535]
    assert len(protected) == 56 and verdict["all53556"] == tools["metrics"](protected)
    field_rows = []
    for field in sorted(set(fields.values())):
        row = {"field": field}
        for label, measured in data.items():
            for region, rows in (("main", measured["main"]), ("initial", measured["initial"]), ("all182", measured["initial"] + measured["main"])):
                subset = [r for r in rows if r["detector_id"] == field]
                row.update({f"{label}_{region}_" + k: value for k, value in tools["metrics"](subset).items() if k in {"TAE", "SSE"}})
                row[f"{label}_{region}_signed"] = sum(int(r["diff_nVehContrib_minus_expected"]) for r in subset)
        field_rows.append(row)
    terminals = []
    for identity, vehicle in vehicles.items():
        trip = after["tripinfo"].get(identity)
        if trip is None or float(trip["arrival"]) < 0:
            route = vehicle.find("route").get("edges").split()
            terminals.append({"vehicle_id": identity, "origin": route[0], "destination": route[-1], "intended_field": fields[identity], "requested_depart_s": vehicle.get("depart"), "terminal_status": "waiting_not_inserted" if trip is None else "running", "completed_fields": [e["detector_id"] for e in after["by_vehicle"].get(identity, [])]})
    assert sum(r["terminal_status"] == "waiting_not_inserted" for r in terminals) == after["completion"]["waiting"]
    assert sum(r["terminal_status"] == "running" for r in terminals) == after["completion"]["running"]
    tools["table"](OUT / "field13.csv", field_rows)
    tools["table"](OUT / "terminal-vehicles.csv", terminals)
    for name, rows in (("main130", after["main"]), ("initialization52", after["initial"]), ("all182", after["initial"] + after["main"]), ("station40", after["stations"]), ("native208", list(after["periodic"].values()))):
        tools["table"](OUT / (name + ".csv"), rows)
    group = defaultdict(Counter)
    for row in terminals:
        group["origins"][row["origin"]] += 1
        group["fields"][row["intended_field"]] += 1
    source_hashes = {str(p): sha(p) for p in [Path(__file__), HELPER, HELPER.parent / "audit_scope.py", CASE / "verdict.json", CASE / "scope-proof.json", CASE / "preflight.json", CASE / "executed-driver.py"]}
    source_hashes.update({str(CASE / "prepared" / n): value for n, value in proof["prepared_hashes"].items()})
    for measured in data.values():
        source_hashes.update(measured["source_hashes"])
    tools["save"](OUT / "source-hashes.json", source_hashes)
    result = {"schema": "astra.hamburg.209-ordinal-full-independent/v1", "audit_status": "pass", "raw_verdict": verdict["status"], "native_runs_by_audit": 0,
        "after": stats(after), "references": {label: stats(data[label]) for label in ("plus15", "offset0")},
        "comparison": {label: {"main130_TAE_delta": after["metrics130"]["TAE"] - data[label]["metrics130"]["TAE"], "main130_SSE_delta": after["metrics130"]["SSE"] - data[label]["metrics130"]["SSE"], "initial52_TAE_delta": after["metrics52"]["TAE"] - data[label]["metrics52"]["TAE"], "all182_TAE_delta": after["metrics182"]["TAE"] - data[label]["metrics182"]["TAE"]} for label in ("plus15", "offset0")},
        "native_rows": len(after["periodic"]), "all53556": tools["metrics"](protected), "unique_contributing_vehicles": len(after["by_vehicle"]), "one_expected_event_per_request": unique_once,
        "repeated_vehicle_fields": repeats, "outside_primary": outside, "unknown_vehicle_ids": unknown,
        "terminal_groups": dict(group), "terminal_count": len(terminals), "exact_count_fit_main130": after["metrics130"]["TAE"] == 0,
        "top_main_residuals": sorted(after["main"], key=lambda r: abs(int(r["diff_nVehContrib_minus_expected"])), reverse=True)[:15],
        "scope": {"five_source_files_byte_identical": True, "candidate_network_control_exact": True, "N": 8640, "runtime": preflight["runtime"], "implementation_sha256": preflight["implementation_sha256"]},
        "claim_boundary": "A complete raw-data audit, not field certification or a new SSE/all182 promotion gate. Source-plus15 and offset0 are distinct references; main130, initial52, derived40 and all182 remain explicit. Single-seed small-car support does not imply full-flow safety. Unfinished tripinfo gives completion, not last position. No causal separation of network effects is claimed."}
    tools["save"](OUT / "summary.json", result)
    tools["save"](OUT / "manifest.json", {"files": [{"path": p.relative_to(OUT).as_posix(), "size_bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "manifest.json"], "native_runs": 0})
    print(json.dumps({"audit_status": "pass", "after": stats(after), "comparison": result["comparison"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
