"""Compare209 MAP14-to5 with two explicit existing source-road candidates only."""
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import xml.etree.ElementTree as ET

from shapely.geometry import LineString
import sumolib
from astra_sumo.core.digital_twin import parse_mapem
from astra_sumo.core.hamburg_map_kml import bind_hamburg_map_kml_to_mapem, parse_hamburg_map_kml

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
ASSETS = OUT.parent / 'official-209-retry'
ORIGINAL = REPO / 'benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml'
CURRENT = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/prepared/network.net.xml'
OSM = REPO / 'benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not (OUT / 'summary.json').exists(), 'Preserve the prior source audit.'
    with tempfile.TemporaryDirectory() as temporary:
        p = Path(temporary)
        (p / '209.xml').write_bytes(gzip.decompress((ASSETS / 'map_xml.xml.gz').read_bytes()))
        (p / '209.kml').write_bytes(gzip.decompress((ASSETS / 'map_kml.xml.gz').read_bytes()))
        lanes, connections = parse_mapem(p / '209.xml')
        bound = bind_hamburg_map_kml_to_mapem(parse_hamburg_map_kml(p / '209.kml'), lanes, connections, expected_node_id='209')
    official = next(c for c in bound['connections'] if c['ingress_lane_id'] == '14' and c['egress_lane_id'] == '5')
    lane5 = next(row for row in bound['lanes'] if row['lane_id'] == '5')
    source, current = [sumolib.net.readNet(str(p), withInternal=True) for p in (ORIGINAL, CURRENT)]
    reference = LineString([source.convertLonLat2XY(*p[:2]) for p in lane5['coordinates']])
    drive = LineString([source.convertLonLat2XY(*p[:2]) for p in official['drive_line_coordinates']])
    rows = []
    for label, net, identity in [('existing_residential_tail', current, '27064186#0_0'), ('unpruned_source_candidate', source, '790292963_0')]:
        lane = net.getLane(identity)
        shape = LineString(lane.getShape())
        rows.append(dict(role=label, source_lane=identity, passenger=lane.allows('passenger'),
                         egress5_reference_distance_m=shape.distance(reference), full14_to5_drive_line_distance_m=shape.distance(drive)))
    osm = ET.fromstring(gzip.decompress(OSM.read_bytes()))
    tags = {identity: {t.get('k'): t.get('v') for t in osm.find(f"way[@id='{identity}']").findall('tag')}
            for identity in ('790292963', '1108564795', '27064186')}
    current_ids = {e.getID() for e in current.getEdges()}
    report = dict(status='review_required', native_runs=0, official_connection=dict(ingress='14', egress='5', signal_group=official['signal_group']),
        distance_comparison=rows, source_OSM_tags=tags, source790292963_in_current_corridor='790292963' in current_ids,
        conclusion='MAP14-to5 follows the northeast Alsterufer exit; it is not the existing Warburgstrasse270 residential tail and is not the381 bridge exit. The nearest explicit source candidate790292963 is outside the retained corridor. This source connection must not be used to assignSG6 to734-to270.',
        claim_boundary='Current legal270 access may be retained on its own OSM/native legal-turn evidence. No OCIT209 timing or dated operation is known. This source distinction does not revoke authorization for a reversible explore candidate, generate a candidate, or imply promotion. No network/control/demand/source changed.',
        source_hashes={str(p): sha(p) for p in (ASSETS / 'manifest.json', ORIGINAL, CURRENT, OSM, Path(__file__))})
    (OUT / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (OUT / 'manifest.json').write_text(json.dumps(dict(status='review_required', native_runs=0, files=[dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'manifest.json']), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
