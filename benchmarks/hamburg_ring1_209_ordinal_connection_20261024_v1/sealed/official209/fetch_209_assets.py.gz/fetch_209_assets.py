"""Read only the listed209 MAP/KML and one explicitly labelled OCIT URL candidate."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
URLS = {'map_xml': 'https://www.daten-hamburg.de/tlf_public/MAP_ITS_02_209_15.1_Quelle_ETRS89.xml',
        'map_kml': 'https://www.daten-hamburg.de/tlf_public/MAP_ITS_02_209_15.1_Quelle_ETRS89.kml',
        'ocit_candidate': 'https://www.daten-hamburg.de/tlf_public/OCIT-C/MAP_ITS_02_209_15.1.xml'}


def fetch(item):
    kind, url = item
    row = dict(kind=kind, url=url, access_started_utc=datetime.now(timezone.utc).isoformat(), listed_in_current_directory=kind != 'ocit_candidate')
    try:
        with urlopen(Request(url, headers={'User-Agent': 'ASTRA source provenance audit'}), timeout=30) as response:
            data = response.read()
            row.update(http_status=response.status, final_url=response.geturl(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                       headers={k: response.headers.get(k) for k in ('Content-Type', 'Last-Modified', 'Date', 'ETag')})
        root = ET.fromstring(data)
        row.update(xml_root=root.tag, xml_root_attributes=root.attrib)
        target = OUT / (kind + '.xml.gz')
        assert not target.exists()
        target.write_bytes(gzip.compress(data, mtime=0))
        row.update(snapshot=target.name, snapshot_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
    except HTTPError as error:
        row.update(status='HTTP_error', http_status=error.code, error=str(error))
    except Exception as error:
        row.update(status='access_failed', error=f'{type(error).__name__}: {error}')
    row['access_completed_utc'] = datetime.now(timezone.utc).isoformat()
    return row


if __name__ == '__main__':
    assert not (OUT / 'assets.json').exists(), 'Preserve the prior retrieval.'
    with ThreadPoolExecutor(max_workers=3) as pool:
        records = list(pool.map(fetch, URLS.items()))
    report = dict(status='review_required', native_runs=0, files=records, filename_configuration_revision='209/15.1',
        current_directory_provenance='access.json', dated_implementation_2026_10_19_established=False,
        claim_boundary='The OCIT URL is a single conventional-name check, not a listed asset. XML validity and current publication do not establish historical implementation, movement binding, timing or field SPaT. No current model changed.')
    (OUT / 'assets.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))
