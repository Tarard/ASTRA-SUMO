"""One bounded read of the two frozen-catalog official directories; no simulation."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

OUT = Path(__file__).resolve().parent
URLS = {'map': 'https://daten-hamburg.de/tlf_public/', 'ocit': 'https://daten-hamburg.de/tlf_public/OCIT-C/'}


def fetch(item):
    kind, url = item
    started = datetime.now(timezone.utc).isoformat()
    row = dict(kind=kind, requested_url=url, access_started_utc=started)
    try:
        with urlopen(Request(url, headers={'User-Agent': 'ASTRA source provenance audit'}), timeout=30) as response:
            data = response.read()
            final = response.geturl()
            assert urlparse(final).hostname in {'daten-hamburg.de', 'www.daten-hamburg.de'}
            row.update(http_status=response.status, final_url=final, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                       headers={k: response.headers.get(k) for k in ('Content-Type', 'Last-Modified', 'Date', 'ETag')})
        target = OUT / (kind + '-directory.html.gz')
        assert not target.exists()
        target.write_bytes(gzip.compress(data, mtime=0))
        hrefs = re.findall(r'href="([^"]+)"', data.decode('utf-8', errors='replace'), flags=re.I)
        row.update(snapshot=target.name, snapshot_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                   listed_hrefs=len(hrefs), exact_209_asset_urls=[urljoin(final, h) for h in hrefs if re.search(r'(?:^|_)209(?:_|\.)', h)])
    except Exception as error:
        row.update(status='access_failed', error=f'{type(error).__name__}: {error}')
    row['access_completed_utc'] = datetime.now(timezone.utc).isoformat()
    return row


if __name__ == '__main__':
    assert not (OUT / 'access.json').exists(), 'Preserve the prior access record.'
    with ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(fetch, URLS.items()))
    result = dict(status='review_required', native_runs=0, access_records=records,
        urls_from='benchmarks/hamburg_ring1_official_sources_20261020_v1/catalog.json',
        catalog_sha256='42fd5c0e9798ea6554e3657b0cf33e22fb852ebe80a295e68cd9531a771e7d1d',
        configuration_version_209=None, configuration_publication_date_209=None,
        dated_implementation_2026_10_19_established=False,
        claim_boundary='Only these two current official directory listings were read once. No listed209 asset is not proof that no209 configuration exists elsewhere. Current publication would not prove implementation on the count date. No controller, network or demand changed.')
    (OUT / 'access.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))
