"""Read the completed60-car fixture; do not start or alter a simulation."""

from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
NATIVE, PREPARED = ROOT / "native", ROOT / "prepared"
APPROACH = ("24483344#1_0", "24483344#1_1")
INTERNAL = (":LSA119_part0_12_0", ":LSA119_part0_12_1")
FIELDS = ("hh_0119_Z_4_29437", "hh_0119_Z_5_30494")
WINDOWS = [(90, 104), (180, 194), (270, 284)]


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    result, plan = load(NATIVE / "result.json"), load(ROOT / "plan.json")
    assert result["status"] == "pass" and all(result["checks"].values())
    assert sha(ROOT / "run_fixture.py") == sha(NATIVE / "executed-runner.py") == "11efae283e663fa9d5961a7107eabd5a8e36dbb78bd6aee295695195fa7b9482"
    assert all(sha(Path(p)) == h for p, h in plan["source_hashes"].items())
    assert all(sha(Path(p)) == h for p, h in plan["prepared_hashes"].items())
    monitor = load(NATIVE / "stall-monitor.json")
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 1200 and monitor["library_completed"] and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"] and sha(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    summary_rows = ET.parse(NATIVE / "summary.xml").getroot().findall("step")
    assert len(summary_rows) == 12000 and float(summary_rows[-1].get("time")) == 1199.9
    assert all(int(summary_rows[-1].get(k)) == 60 for k in ["loaded", "inserted", "arrived", "ended"])
    assert all(int(summary_rows[-1].get(k)) == 0 for k in ["running", "waiting", "collisions", "teleports", "discarded"])
    demand = {v.get("id"): v for v in ET.parse(PREPARED / "demand.rou.xml").getroot().findall("vehicle")}
    intents = {r["vehicle_id"]: r["field_id"] for r in load(PREPARED / "lane-intentions.json")["vehicles"]}
    periodic = ET.parse(PREPARED / "e1.add.xml").getroot().findall("inductionLoop")
    lookup = {(r.get("lane"), float(r.get("pos"))): r.get("id") for r in periodic}
    instant = ET.parse(PREPARED / "instant.add.xml").getroot().findall("instantInductionLoop")
    mapping = {r.get("id"): lookup[r.get("lane"), float(r.get("pos"))] for r in instant}
    events = read_contributing_e1_passages(instant_file=NATIVE / "instant-e1.xml", periodic_file=NATIVE / "field-counts.xml", detector_ids=mapping, step_length=.1)
    assert events["reconciled"] and not events["outside_periodic_intervals"] and len(events["passages"]) == 60
    assert Counter((r["vehicle_id"], r["detector_id"]) for r in events["passages"]) == Counter(intents.items())
    routes = ET.parse(NATIVE / "vehicle-routes.xml").getroot().findall("vehicle")
    trips = ET.parse(NATIVE / "tripinfo.xml").getroot().findall("tripinfo")
    assert len(routes) == len(trips) == 60 and {r.get("id") for r in routes} == {r.get("id") for r in trips} == demand.keys()
    assert all(r.find("route").get("edges") == demand[r.get("id")].find("route").get("edges") for r in routes)
    assert all(float(r.get("arrival")) >= 0 and not r.get("vaporized", "") and r.get("arrivalLane").startswith("199500676_") for r in trips)
    assert not ET.parse(NATIVE / "collisions.xml").getroot().findall("collision")
    lc = ET.parse(NATIVE / "lanechanges.xml").getroot()
    internal_changes = [dict(r.attrib) for r in lc if r.get("from", "").startswith(":LSA119_part0_") or r.get("to", "").startswith(":LSA119_part0_")]
    front, previous, fcd_windows, internal_lanes = [], {}, {}, defaultdict(set)
    stage_stats = defaultdict(lambda: dict(samples=0, stopped_samples=0, min_speed=None, max_concurrent=0))
    fcd_steps = 0
    for _, frame in ET.iterparse(NATIVE / "fcd.xml", events=("end",)):
        if frame.tag != "timestep":
            continue
        tick = float(frame.get("time"))
        rows = {r.get("id"): dict(r.attrib) for r in frame.findall("vehicle")}
        fcd_steps += 1
        counts = Counter()
        for identity, row in rows.items():
            lane, speed = row["lane"], float(row["speed"])
            if previous.get(identity) in APPROACH and lane in INTERNAL:
                front.append(dict(vehicle_id=identity, from_lane=previous[identity], to_lane=lane, native_step_time_s=tick))
            if lane.startswith(":LSA119_part0_12_"):
                stage = lane
                internal_lanes[identity].add(lane)
            elif lane.startswith("79014037#1_"):
                stage = "790"
            elif lane.startswith(":266199063_"):
                stage = "GS_internal"
            elif lane.startswith("186713429_"):
                stage = "186713429"
            else:
                stage = None
            if stage:
                stat = stage_stats[stage]
                stat["samples"] += 1
                stat["stopped_samples"] += speed < .1
                stat["min_speed"] = speed if stat["min_speed"] is None else min(stat["min_speed"], speed)
                counts[stage] += 1
        for stage, count in counts.items():
            stage_stats[stage]["max_concurrent"] = max(stage_stats[stage]["max_concurrent"], count)
        if any(begin <= tick < end for begin, end in WINDOWS):
            fcd_windows[round(tick*10)] = rows
        previous = {identity: r["lane"] for identity, r in rows.items()}
        frame.clear()
    assert fcd_steps == 12000 and len(front) == 60 and set(internal_lanes) == demand.keys()
    assert all(lanes == {INTERNAL[FIELDS.index(intents[i])]} for i, lanes in internal_lanes.items())
    recorded_front = load(NATIVE / "front-entries.json")
    assert sorted(front, key=lambda r: r["vehicle_id"]) == sorted([{k: r[k] for k in ["vehicle_id", "from_lane", "to_lane", "native_step_time_s"]} for r in recorded_front], key=lambda r: r["vehicle_id"])
    windows = {(begin, end, lane): dict(begin_s=begin, end_s=end, lane=lane, samples=0, min_approach_vehicles=60, start_vehicles=None, start_stopped=None, start_head_pos=None, empty_samples=0, near_line_samples=0, stopped_samples=0) for begin, end in WINDOWS for lane in APPROACH}
    sample_count, position_mismatches = 0, []
    with gzip.open(NATIVE / "samples.jsonl.gz", "rt", encoding="utf-8") as handle:
        for line in handle:
            frame = json.loads(line)
            sample_count += 1
            tick = frame["native_step_time_s"]
            assert abs(frame["api_time_s"]-.1-tick) < 1e-8
            for begin, end in WINDOWS:
                if not begin <= tick < end:
                    continue
                fcd = fcd_windows[round(tick*10)]
                for lane_index, lane in enumerate(APPROACH):
                    assert frame["tls"]["LSA119_part0"]["state"][12+lane_index] == "G"
                    row = windows[begin, end, lane]
                    members = frame["lanes"][lane]["vehicles"]
                    for member in members:
                        physical = fcd[member["id"]]
                        if physical["lane"] != lane or abs(float(physical["pos"])-member["pos_m"]) > 1e-8:
                            position_mismatches.append(dict(time_s=tick, sampled_lane=lane, id=member["id"], fcd_lane=physical["lane"]))
                    if row["samples"] == 0:
                        row.update(start_vehicles=len(members), start_stopped=frame["lanes"][lane]["stopped"], start_head_pos=members[0]["pos_m"] if members else None)
                    row["samples"] += 1
                    row["min_approach_vehicles"] = min(row["min_approach_vehicles"], len(members))
                    row["empty_samples"] += not members
                    row["near_line_samples"] += bool(members) and members[0]["pos_m"] >= 80.13
                    row["stopped_samples"] += frame["lanes"][lane]["stopped"] > 0
    assert sample_count == 12000 and not position_mismatches
    for (begin, end, lane), row in windows.items():
        field = FIELDS[APPROACH.index(lane)]
        row["front_entries"] = sum(r["from_lane"] == lane and begin <= r["native_step_time_s"] < end for r in front)
        row["E1_rear_complete"] = sum(r["detector_id"] == field and begin <= r["notification_time_s"] < end for r in events["passages"])
        row["supply_evidence"] = "approach_depleted" if row["empty_samples"] else "continuous_supply_supported" if row["start_stopped"] and row["start_head_pos"] >= 80.13 else "uncertain"
    for begin, end in WINDOWS[:2]:
        for lane in APPROACH:
            row = windows[begin, end, lane]
            assert row["front_entries"] == row["E1_rear_complete"] == 8 and row["start_vehicles"] == 12 and row["start_stopped"] == 11 and row["min_approach_vehicles"] == 7
    assert not internal_changes
    report = dict(schema="astra.hamburg.119-saturated-fixture-independent/v1", status="pass", native_runs_by_audit=0, population=60, all60_arrived_real_destination=True, complete_E1_events=60, unsafe=0,
        sample_and_FCD_steps=12000, API_native_FCD_positions_match_in_reviewed_windows=True, reviewed_green_windows=list(windows.values()), internal_lane_changes=internal_changes,
        stage_observations={stage: dict(**value, stopped_vehicle_seconds=value["stopped_samples"]*.1) for stage, value in stage_stats.items()},
        conclusion="In this no603 fixture, both reviewed queued14s greens admit8 fronts and8 complete E1 events per lane. Multiple cars coexist on each119 internal; the recorded receiving/GS states decide whether stopping occurs. This does not locate a full-traffic bottleneck, measure field capacity, or prove universal maximum service.", E1_boundary="Loop95.03 on95.13m lane;5m vehicles normally clear it with front about4.9m into internal. The original moving waypoint87.63 is a different location.")
    save(OUT / "native-review.json", report)
    with (OUT / "reviewed-greens.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(next(iter(windows.values()))))
        writer.writeheader()
        writer.writerows(windows.values())
    save(OUT / "native-source-hashes.json", {str(p.relative_to(ROOT)): sha(p) for p in [ROOT / "plan.json", ROOT / "run_fixture.py", NATIVE / "runtime.json", NATIVE / "result.json", NATIVE / "fcd.xml", NATIVE / "lanechanges.xml", NATIVE / "front-entries.json", NATIVE / "samples.jsonl.gz", NATIVE / "field-counts.xml", NATIVE / "instant-e1.xml", NATIVE / "vehicle-routes.xml", NATIVE / "tripinfo.xml"]})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(status="pass", greens=list(windows.values()), stages=report["stage_observations"], manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
