"""Compare six existing tail-route lane ends with explicit209 MAP ingress stoplines."""
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path
import tempfile
import xml.etree.ElementTree as ET

import sumolib
from astra_sumo.core.digital_twin import parse_mapem
from astra_sumo.core.hamburg_map_kml import bind_hamburg_map_kml_to_mapem, parse_hamburg_map_kml

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
ASSETS = OUT.parent / 'official-209-retry'
PREPARED = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/prepared'
CHAIN = [('1966837175', '141050980#0', '141050980#1'), ('244203534', '141050980#1', '603103444'),
         ('266197536', '603103444', '73474895'), ('266197525', '73474895', '1108564798#0'),
         ('6390683113', '1108564798#0', '1108564798#1'), ('1562406613', '1108564798#1', '24483197')]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def vector(first, second):
    x, y = second[0] - first[0], second[1] - first[1]
    norm = math.hypot(x, y)
    assert norm > 1e-5
    return x / norm, y / norm


def main():
    assert not (OUT / 'summary.json').exists(), 'Preserve the earlier analysis.'
    raw_xml, raw_kml = [gzip.decompress((ASSETS / n).read_bytes()) for n in ('map_xml.xml.gz', 'map_kml.xml.gz')]
    with tempfile.TemporaryDirectory() as temporary:
        p = Path(temporary)
        (p / '209.xml').write_bytes(raw_xml)
        (p / '209.kml').write_bytes(raw_kml)
        lanes, connections = parse_mapem(p / '209.xml')
        bound = bind_hamburg_map_kml_to_mapem(parse_hamburg_map_kml(p / '209.kml'), lanes, connections, expected_node_id='209')
    net = sumolib.net.readNet(str(PREPARED / 'network.net.xml'), withInternal=True)
    root = ET.parse(PREPARED / 'network.net.xml').getroot()
    xml_lanes = {r.findtext('laneID'): r for r in ET.fromstring(raw_xml).findall('.//GenericLane')}
    semantic = {r.lane_id: r for r in lanes}
    official = []
    for lane in bound['lanes']:
        meaning = semantic[lane['lane_id']]
        if not meaning.is_vehicle or not meaning.is_ingress:
            continue
        nodes = xml_lanes[lane['lane_id']].findall('nodeList/nodes/NodeXY')
        stop = [i for i, r in enumerate(nodes) if r.find('.//stopLine') is not None]
        assert stop == [0] and lane['kml_direction_role'] == 'ingress'
        points = [net.convertLonLat2XY(*xy[:2]) for xy in lane['coordinates']]
        direction = vector(next(xy for xy in points[1:] if math.dist(xy, points[0]) > .1), points[0])
        official.append(dict(lane=lane['lane_id'], approach=meaning.ingress_approach, stop=points[0], direction=direction,
            permission=meaning.permission_metadata, connections=[dict(egress=r.egress_lane_id, signal_group=r.signal_group) for r in connections if r.ingress_lane_id == lane['lane_id']]))
    rows, summaries = [], []
    for tls, before, after in CHAIN:
        controls = [r for r in root.findall('connection') if r.get('tl') == tls and r.get('from') == before and r.get('to') == after]
        selected = []
        for connection in controls:
            lane = net.getLane(before + '_' + connection.get('fromLane'))
            if not lane.allows('passenger'):
                continue
            shape = lane.getShape()
            end = shape[-1]
            heading = vector(next(xy for xy in reversed(shape[:-1]) if math.dist(xy, end) > .01), end)
            candidates = []
            for target in official:
                allowed = target['permission'].get('allowed_classes')
                if allowed is not None and 'passenger' not in allowed:
                    continue
                delta = target['stop'][0] - end[0], target['stop'][1] - end[1]
                angle = math.degrees(math.acos(max(-1, min(1, sum(a*b for a, b in zip(heading, target['direction']))))))
                candidates.append(dict(official_lane=target['lane'], official_ingress_approach=target['approach'],
                    stopline_distance_m=math.hypot(*delta), heading_difference_deg=angle,
                    signed_ahead_m=sum(a*b for a, b in zip(delta, heading)), lateral_m=abs(delta[0]*heading[1]-delta[1]*heading[0]),
                    official_connections=json.dumps(target['connections']), official_permission=json.dumps(target['permission'])))
            matching = sorted((r for r in candidates if r['heading_difference_deg'] <= 20), key=lambda r: r['stopline_distance_m'])
            # Preserve a failed direction match; a turn is not a licence to widen the filter.
            best = matching[0] if matching else min(candidates, key=lambda r: r['stopline_distance_m'])
            row = dict(tls=tls, native_lane=lane.getID(), outgoing_edge=after, TLS_index=connection.get('linkIndex'),
                       native_lane_end_x=end[0], native_lane_end_y=end[1], native_stop_proxy='ordinary lane shape end; no observed front/painted-line claim',
                       **best, direction_compatible=bool(matching), candidate_within_10m=bool(matching) and best['stopline_distance_m'] <= 10,
                       status='review_required')
            rows.append(row)
            selected.append(row)
        summaries.append(dict(tls=tls, native_main_path_lanes=len(selected), official_approaches=sorted({r['official_ingress_approach'] for r in selected}),
            min_distance_m=min(r['stopline_distance_m'] for r in selected), max_distance_m=max(r['stopline_distance_m'] for r in selected),
            min_signed_ahead_m=min(r['signed_ahead_m'] for r in selected), max_signed_ahead_m=max(r['signed_ahead_m'] for r in selected),
            official_lane_ids=sorted({r['official_lane'] for r in selected}), near_direction_candidate_count=sum(r['candidate_within_10m'] for r in selected)))
    with (OUT / 'lane-stopline-candidates.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    paths = [PREPARED / 'network.net.xml', PREPARED / 'control.add.xml', ASSETS / 'manifest.json', ASSETS / 'map_xml.xml.gz', ASSETS / 'map_kml.xml.gz', Path(__file__)]
    report = dict(status='review_required', native_runs=0, analyzed_at_utc=datetime.now(timezone.utc).isoformat(), native_path=CHAIN,
        official_vehicle_ingress_stoplines=len(official), source_209_identity=bound['node_id'], source_reader_gates=bound['gates'], nodes=summaries,
        method='Only six tail-route controlled incoming passenger-lane ends. MAP explicit stopLine node0 is the first exact-ID KML ingress point; incoming direction is toward that point. Candidate direction differs by at most20degrees. Where none matches, the closest undirected line is retained with direction_compatible=false, not a valid binding. 10m is a reporting filter, not a field binding rule. Positive signed_ahead means the official line is ahead of the native lane end.',
        claim_boundary='Official MAP reference lines, native lane-end proxies and aerial/field geometry remain different sources. This table does not identify signal-head ownership, prove a SUMO point redundant, choose an OCIT program, or establish dated operation. No geometry/control/source changed; no native run.',
        source_hashes={str(p): sha(p) for p in paths})
    (OUT / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (OUT / 'manifest.json').write_text(json.dumps(dict(native_runs=0, files=[dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'manifest.json']), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summaries))


if __name__ == '__main__':
    main()
