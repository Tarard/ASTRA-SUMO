"""Read only the two local turn allocations across saved build stages."""

import csv
import gzip
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
PRIMARY = REPO / "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1"
END_TO_END = REPO / "benchmarks/hamburg_ring1_end_to_end_20261021_v1"
FILES = [
    ("legacy_V1", "benchmarks/hamburg_ring1_readme_v1_zero_20261023_v1/inputs/network.net.xml.gz"),
    ("first_saved_OSM_full_import", "benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml"),
    ("first_main_road_pruning", "benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/pruned.net.xml"),
    ("M1_input", "benchmarks/hamburg_ring1_m1_demand_pool_20261021_v1/inputs/network.net.xml"),
    ("M2_input", "benchmarks/hamburg_ring1_m2_control_20261021_v1/inputs/network.xml"),
    ("primary_repair_full_donor", "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/network.net.xml.gz"),
    ("corridor236_before_primary_restore", "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/parent-prepared/network.net.xml.gz"),
    ("primary_source_projection238", "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source-projection/selected.net.xml.gz"),
    ("primary_restored_candidate238", "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/prepared/network.net.xml.gz"),
    ("current_plus15", "outputs/hamburg-119-common-offset-20261024-v1/plus15/prepared/network.net.xml"),
]
WAYS = {"73474895", "1108564798", "27064186", "603103444", "141050980", "381750336"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def raw(path):
    content = path.read_bytes()
    return gzip.decompress(content) if path.suffix == ".gz" else content


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def keys(root, origin):
    return sorted((int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))) for c in root.findall("connection") if c.get("from") == origin)


def main():
    stages, source_hashes = [], {}
    expected734 = [(0, "27064186#0", 0), (1, "1108564798#0", 1), (2, "1108564798#0", 2)]
    expected603 = [(0, "381750336", 0), (1, "73474895", 0), (2, "73474895", 1), (3, "73474895", 2)]
    for label, relative in FILES:
        path = REPO / relative
        content = raw(path)
        root = ET.fromstring(content)
        connections = [{k: v for k, v in c.attrib.items() if k in {"from", "fromLane", "to", "toLane", "via", "tl", "linkIndex", "dir"}} for c in root.findall("connection") if c.get("from") in {"73474895", "603103444", "141050980#1"}]
        lane_rows = [{"edge": edge.get("id"), **{k: v for k, v in lane.attrib.items() if k in {"id", "index", "allow", "disallow", "length"}}} for edge in root.findall("edge") if edge.get("id") in {"73474895", "1108564798#0", "603103444", "381750336"} for lane in edge.findall("lane")]
        for row in lane_rows:
            assert ("allow" not in row or "passenger" in row["allow"].split()) and "passenger" not in row.get("disallow", "").split()
        assert keys(root, "603103444") == expected603
        if label == "legacy_V1":
            assert keys(root, "73474895") == [(i, "1108564798#0", i) for i in range(3)]
            assert root.find("edge[@id='27064186#0']") is None
        elif label == "corridor236_before_primary_restore":
            assert keys(root, "73474895") == [(0, "27064186#0", 0)]
            assert root.find("edge[@id='1108564798#0']") is None
        else:
            assert keys(root, "73474895") == expected734
        stages.append(dict(stage=label, file=relative, stored_sha256=sha(path.read_bytes()), raw_sha256=sha(content), connections=connections, lane_permissions=lane_rows, mapping734=keys(root, "73474895"), mapping603=keys(root, "603103444")))
        source_hashes[relative] = dict(stored=sha(path.read_bytes()), raw=sha(content))
    osm_rows = []
    for relative in ["benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz", "benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/ring1-full_filtered.osm.xml.gz"]:
        path = REPO / relative
        root = ET.fromstring(raw(path))
        ways = [{"id": way.get("id"), "nodes": [n.get("ref") for n in way.findall("nd")], "tags": {t.get("k"): t.get("v") for t in way.findall("tag")}} for way in root.findall("way") if way.get("id") in WAYS]
        tags = {w["id"]: w["tags"] for w in ways}
        assert not any(k.startswith("turn:lanes") for k in tags["73474895"])
        assert tags["1108564798"]["cycleway:right"] == "separate" and tags["1108564798"]["lanes"] == "3"
        assert tags["603103444"]["turn:lanes"] == "left|left|none|right|right"
        restrictions = [ET.tostring(r, encoding="unicode") for r in root.findall("relation") if any(m.get("ref") in {"73474895", "603103444", "1108564798", "27064186"} for m in r.findall("member"))]
        osm_rows.append(dict(file=relative, ways=ways, related_restrictions=restrictions))
        source_hashes[relative] = dict(stored=sha(path.read_bytes()), raw=sha(raw(path)))
    assert osm_rows[0]["ways"] == osm_rows[1]["ways"]
    original_path = END_TO_END / "source-stages/original-osm.net.xml"
    header = re.search(rb"<!--(.*?)-->", original_path.read_bytes(), re.S).group(1).decode("utf-8")
    configuration = ET.fromstring(header[header.index("<netconvertConfiguration"):header.index("</netconvertConfiguration>")+len("</netconvertConfiguration>")])
    options = {node.tag: node.get("value") for node in configuration.iter() if node.get("value") is not None}
    assert "connection-files" not in options and options["osm.turn-lanes"] == "true"
    manifest = json.loads((END_TO_END / "manifest.json").read_bytes())
    original_binding = next(row for row in manifest["copied_sources"] if row["path"] == "source-stages/original-osm.net.xml")
    assert original_binding["sha256"] == sha(original_path.read_bytes())
    projection = json.loads(raw(PRIMARY / "source-projection/report.json.gz"))
    command = projection["command"]["command"]
    assert "--sumo-net-file" in command and "--keep-edges.input-file" in command
    report = dict(schema="astra.hamburg.734-603-turn-allocation-lineage/v1", status="evidence_complete", native_runs=0, candidates_created=0,
        direct_evidence=dict(earliest_current734_mapping="first saved original OSM full import, before road pruning or official junction/geometry work", current734_matches_first_full_semantic_keys=True, source110_three_lanes_all_passenger=True, source603_five_lanes_and381_two_lanes_all_passenger=True, original603_mapping_already_same_in_V1=True, original603_fifth_lane_has_no_outgoing_connection=True, primary_repair_restored_existing_source1_2_links_and_kept0_to270=True),
        stages=stages, OSM_snapshots=osm_rows, original_import_embedded_configuration=options, original_import_header_generated_line=header.splitlines()[0].strip(), original_file_frozen_binding=original_binding,
        primary_source_projection_saved_command=command,
        inference=dict(strength="plausible, not counterfactual proof", explanation="For734, the saved first full OSM import contains the270 branch, lacks turn:lanes on734 and has no external connection file in its embedded configuration. Native output assigns rightmost lane0 to native direction s toward270 and lanes1/2 to partial-left L toward110. Automatic connection allocation in this fuller branch environment is the likely origin, rather than a later manual removal. The saved V1 input is a different, already processed network and is not a controlled no270 counterfactual.", limits="No native rebuild with270 removed was run. Other original network/profile/geometry differences are not held fixed.603 has explicit turn:lanes and the same problematic mapping inV1, so that issue cannot be attributed to newly included270."),
        field_boundary="The209 MAP interpretation is supplied by a separate physical-source audit. This lineage does not validateV1, add a connection, change bicycle/passenger permission, or prove the field turn ordinal. A734-only addition could preserve the upstream603 ordinal error; the two locations need joint source review.")
    save(OUT / "lineage.json", report)
    table_rows = [dict(stage=r["stage"], file=r["file"], mapping734=json.dumps(r["mapping734"]), mapping603=json.dumps(r["mapping603"]), raw_sha256=r["raw_sha256"]) for r in stages]
    with (OUT / "stages.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(table_rows[0]))
        writer.writeheader()
        writer.writerows(table_rows)
    paths = [END_TO_END / "manifest.json", PRIMARY / "source-projection/report.json.gz", PRIMARY / "code-source/hamburg_primary_branch_repair.py.gz", REPO / "plugins/astra-sumo/src/astra_sumo/core/osm_network.py", Path(__file__)]
    source_hashes.update({str(p.relative_to(REPO)): dict(stored=sha(p.read_bytes()), raw=sha(raw(p))) for p in paths})
    save(OUT / "source-hashes.json", source_hashes)
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p.read_bytes()), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(status="evidence_complete", stages=len(stages), earliest734="original OSM full", mapping603_already_in_V1=True, native_runs=0, manifest_sha256=sha((OUT / "manifest.json").read_bytes()))))


if __name__ == "__main__":
    main()
