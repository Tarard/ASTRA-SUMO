"""Verify that all analysis crops preserve pixels from the frozen aerial image."""

import hashlib
import json
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parent
meta = json.loads((ROOT / "crop-source.json").read_bytes())
source = Path(meta["source_path"])
assert hashlib.sha256(source.read_bytes()).hexdigest() == meta["source_sha256"]
image = Image.open(source)
for native_name, larger_name, box in [
    ("native-pixel-crop.png", "nearest4-view.png", meta["crop_pixel_box_left_top_right_bottom"]),
    ("south-approach-native.png", "south-approach-nearest4.png", meta["south_approach_pixel_box"]),
]:
    expected = image.crop(box)
    actual = Image.open(ROOT / native_name)
    assert expected.size == actual.size and expected.tobytes() == actual.tobytes()
    enlarged = expected.resize((expected.width * 4, expected.height * 4), Image.Resampling.NEAREST)
    assert enlarged.tobytes() == Image.open(ROOT / larger_name).tobytes()
print("Frozen aerial hash and both exact pixel crops/nearest4 copies match. Native runs:0.")
