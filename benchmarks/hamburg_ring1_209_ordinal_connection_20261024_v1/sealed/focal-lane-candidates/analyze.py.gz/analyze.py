"""Read source candidates for the603 five-lane ordinal and734 primary continuation."""
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import tempfile
import xml.etree.ElementTree as ET

import sumolib
from astra_sumo.core.digital_twin import parse_mapem
from astra_sumo.core.hamburg_map_kml import bind_hamburg_map_kml_to_mapem, parse_hamburg_map_kml
from astra_sumo.core.local_network_conversion import loaded_turn_permissions

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
ASSETS = OUT.parent / 'official-209-retry'
CURRENT = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/prepared/network.net.xml'
LEGACY = REPO / 'benchmarks/hamburg_ring1_readme_v1_zero_20261023_v1/inputs/network.net.xml.gz'
OSM = REPO / 'benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz'
AERIAL = REPO / 'outputs/hamburg-209-existing-aerial-read-20261024-v1/manifest.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not (OUT / 'summary.json').exists(), 'Preserve the earlier analysis.'
    xml, kml = [gzip.decompress((ASSETS / n).read_bytes()) for n in ('map_xml.xml.gz', 'map_kml.xml.gz')]
    with tempfile.TemporaryDirectory() as temporary:
        p = Path(temporary)
        (p / '209.xml').write_bytes(xml)
        (p / '209.kml').write_bytes(kml)
        lanes, connections = parse_mapem(p / '209.xml')
        bound = bind_hamburg_map_kml_to_mapem(parse_hamburg_map_kml(p / '209.kml'), lanes, connections, expected_node_id='209')
    geometry = {r['lane_id']: r for r in bound['lanes']}
    native = sumolib.net.readNet(str(CURRENT), withInternal=True)
    current, legacy = ET.parse(CURRENT).getroot(), ET.fromstring(gzip.decompress(LEGACY.read_bytes()))
    compiled = [loaded_turn_permissions(r) for r in (current, legacy)]

    def xy(lane):
        return [native.convertLonLat2XY(*pair[:2]) for pair in geometry[lane]['coordinates']]

    ordinal = []
    for i in range(5):
        before = native.getLane(f'141050980#0_{i}')
        stop = before.getShape()[-1]
        distances = sorted((math.dist(stop, xy(lane)[0]), lane) for lane in ('12', '13', '14', '15', '16'))
        distance, official = distances[0]
        outgoing = [dict(target_edge=k[2], target_lane=k[3]) for k, modes in compiled[0].items() if k[0] == '603103444' and int(k[1]) == i and 'passenger' in modes]
        source_moves = [dict(egress=c.egress_lane_id, signal_group=c.signal_group, maneuver_bits=c.maneuver_bits) for c in connections if c.ingress_lane_id == official]
        ordinal.append(dict(native603_lane=i, official209_ingress=official, native141_end_to_official_stopline_m=distance,
                            current_passenger_outgoing=json.dumps(outgoing), official_connections=json.dumps(source_moves)))
    assert [r['official209_ingress'] for r in ordinal] == ['16', '15', '14', '13', '12']
    with (OUT / '603-ordinal.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(ordinal[0]))
        writer.writeheader()
        writer.writerows(ordinal)
    continuity = []
    for egress, incoming, native_lane in [('52', '46', 0), ('51', '45', 1), ('50', '44', 2)]:
        continuity.append(dict(official_egress=egress, next_official_ingress=incoming,
            reference_endpoint_gap_m=math.dist(xy(egress)[-1], xy(incoming)[-1]),
            native734_lane_ordinal_candidate=native_lane, native110_lane_ordinal_candidate=native_lane,
            next_official_connections=[dict(egress=c.egress_lane_id, signal_group=c.signal_group) for c in connections if c.ingress_lane_id == incoming],
            basis='Geometric reference continuity and monotonic lane order; not an explicit MAP egress-to-ingress connection or installed native binding.'))
    ways = {}
    for way in ET.fromstring(gzip.decompress(OSM.read_bytes())).findall('way'):
        if way.get('id') in {'73474895', '1108564798', '141050980', '603103444'}:
            ways[way.get('id')] = {t.get('k'): t.get('v') for t in way.findall('tag')}
    permissions = []
    for edge in ('73474895', '1108564798#0', '1108564798#1'):
        for lane in native.getEdge(edge).getLanes():
            permissions.append(dict(lane=lane.getID(), passenger=lane.allows('passenger'), bicycle=lane.allows('bicycle')))
    assert all(r['passenger'] and not r['bicycle'] for r in permissions)
    stages = {}
    for name, table in zip(('current', 'legacy_V1'), compiled):
        stages[name] = {edge: [list(k) for k, modes in table.items() if k[0] == edge and 'passenger' in modes]
                        for edge in ('603103444', '73474895')}
    sources = [CURRENT, LEGACY, OSM, ASSETS / 'manifest.json', ASSETS / 'map_xml.xml.gz', ASSETS / 'map_kml.xml.gz', AERIAL, Path(__file__)]
    report = dict(status='review_required', native_runs=0, official_reader_gates=bound['gates'], native_compiled_permissions=permissions,
        exact_OSM_tags=ways, native_stage_connections=stages, primary_reference_continuity=continuity,
        candidate_interpretation='The source-compatible full ordinal candidate is6030/1 toward the two right-turn lanes and6032/3/4 toward the three734 forward lanes. MAP14 also has a separateSG6 exit5, which is not silently merged with the retained right-turn exit. Primary continuation references52/51/50 approach46/45/44 have three close endpoint pairs. This is evidence for a bounded complete-movement review, not a generated or approved edit.',
        unresolved=['2022MAP applicability on the count date and exact field arrow/lane binding',
                    '2026aerial native0.407m/pixel has tree/vehicle occlusion; independent ordinal/arrow/stopline confirmation unavailable',
                    'OCIT209/SP1/intergreens unavailable after one404; signal timing not inferred from MAP',
                    'Preserve legal residential access, bicycle exclusions and real observations in any later candidate'],
        source_hashes={str(p): sha(p) for p in sources},
        claim_boundary='Read-only geometry/permission/connection candidates. Native lanes are not renamed or widened. No current network/control/demand/source changed; no traffic run. Geometric reference continuity does not itself prove a legal lane-to-lane connection or vehicle service gain.')
    (OUT / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (OUT / 'manifest.json').write_text(json.dumps(dict(status='review_required', native_runs=0, files=[dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'manifest.json']), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(ordinal=ordinal, continuity=continuity), ensure_ascii=False))


if __name__ == '__main__':
    main()
