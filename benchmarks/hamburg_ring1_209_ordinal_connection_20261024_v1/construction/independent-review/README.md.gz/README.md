# 209局部ordinal候选独立静态复核

candidate-v3的20项独立检查均通过。网络SHA256为`4cd5d1b95cce0f43b0626e82c7066cce3b1807db35840c115bcf66252437ae80`，外部控制为`27220b430aa68c24f0ad360c57ee3bd0f4b8dcdc88aead5344bcff00e4f43e3b`。本次复核没有构建网络或运行交通仿真。

普通道路集合、道路XML、权限、节点外的全部元素及顺序与源相同。局部保留movement的内部曲线和长度也保持。三个旧forward连接被删除，改由下一条incoming lane承担；这不是“所有旧turn保留”。新增连接共五条，没有扩大edge对的可达关系。603 lane1现在只直接通向381 lane1，没有直接进入734的primary捷径。静态lane连接不限制车辆在允许的位置正常换道。

536新增right的TL6继承原TL0；forward TL1/2/3分别绑定603 lanes2/3/4到734 lanes0/1/2。525新增primary TL8继承原TL6，住宅连接保留。内嵌与外部控制分别从各自源程序投影；所有旧字符、phase属性、时长、min/max、type和offset保持。525 unused TL2–4的内嵌G与外部r差异未被统一。外部控制文件除声明的state追加外，全部原字节相同。

按完整movement及末级internal lane确定REQ，而不是把TL序号当REQ。536 TL0/6/1/2/3对应REQ0/1/2/3/4；525 TL8对应REQ3。最终请求表与保存的最终netconvert输出逐行相同，没有手填。两节点的内嵌与外部各phase均没有同时G且native foes为1的pair。新增曲线长度由native生成，未调长度。

该结果只证明声明范围和模型内信号/ROW映射一致。它不证明现场控制归属、实际车道适用性、车辆运行安全或计数改善。原始netconvert的unused state警告仍保留；v1/v2失败产物也保留。后续若运行少车试验，应核实际路径、实际灯色、正常入口与驾驶安全，而不把静态通过当作完整安全验收。

`source-hashes.json`绑定源、候选、最终native输出、builder及两个来源审查；`movement-request-bindings.json`给出逐movement绑定；`program-projection.json`保留两套程序逐phase值。

构建v3的materializer完整SHA为`d0dc8ac39fbceeafa845804ec6421bb4185c0ded50c88c4f5e4a4f7e68f89f40`，由candidate-v3/implementation中的原字节绑定。之后live verifier增加严格programme keyset检查，未重新netconvert或运行交通。本次独立检查自身已核完整keysets相等；不把后来的验证修复当作候选构建来源，也不改原始manifest。映射见`builder-snapshot-mapping.json`。
