"""Read the existing v3 ordinal candidate; never build or simulate it."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.junction_split_fanout import _canonical, _curve, _internal_path, _key
from astra_sumo.core.local_network_conversion import loaded_turn_permissions
from astra_sumo.core.osm_access import _permission_set


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
SOURCE = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15/prepared"
CANDIDATE = OUT.parent / "candidate-v3"
NODES = {"266197536", "266197525"}
REMOVED = {("603103444", lane, "73474895", lane - 1) for lane in (1, 2, 3)}
ADDED = {
    ("603103444", 1, "381750336", 1): ("266197536", 6, ("603103444", 0, "381750336", 0)),
    ("603103444", 2, "73474895", 0): ("266197536", 1, ("603103444", 1, "73474895", 0)),
    ("603103444", 3, "73474895", 1): ("266197536", 2, ("603103444", 2, "73474895", 1)),
    ("603103444", 4, "73474895", 2): ("266197536", 3, ("603103444", 3, "73474895", 2)),
    ("73474895", 0, "1108564798#0", 0): ("266197525", 8, ("73474895", 1, "1108564798#0", 1)),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def programs(root):
    return {(p.get("id"), p.get("programID")): p for p in root.findall("tlLogic")}


def exterior(root, ordinary):
    def local(row):
        identity = row.get("id", "")
        def internal(value):
            return any(value.startswith(":" + node + "_") for node in NODES)
        return (
            row.tag in {"edge", "junction"} and (identity in NODES or internal(identity))
            or row.tag == "tlLogic" and identity in NODES
            or row.tag == "connection" and (
                internal(row.get("from", ""))
                or row.get("from") in ordinary and ordinary[row.get("from")].get("to") in NODES
            )
        )
    return [_canonical(row) for row in root if not local(row)]


def main():
    source = ET.parse(SOURCE / "network.net.xml").getroot()
    candidate = ET.parse(CANDIDATE / "network.net.xml").getroot()
    native = ET.parse(CANDIDATE / "ordinal.native-local-output.net.xml").getroot()
    old = {_key(c): c for c in source.findall("connection")}
    new = {_key(c): c for c in candidate.findall("connection")}
    old_access, new_access = loaded_turn_permissions(source), loaded_turn_permissions(candidate)
    roads = {e.get("id"): e for e in source.findall("edge") if not e.get("function")}
    new_roads = {e.get("id"): e for e in candidate.findall("edge") if not e.get("function")}
    lanes = {(e.get("id"), int(lane.get("index"))): lane for e in source.findall("edge") for lane in e.findall("lane")}
    checks = {
        "ordinary_edge_set_and_xml_identical": roads.keys() == new_roads.keys() and all(_canonical(e) == _canonical(new_roads[k]) for k, e in roads.items()),
        "exterior_semantics_and_order_identical": exterior(source, roads) == exterior(candidate, roads),
        "exact_ordinary_turn_key_delta": new_access.keys() == (old_access.keys() - REMOVED) | ADDED.keys(),
        "old_retained_turn_permissions_identical": all(new_access.get(k) == v for k, v in old_access.items() if k not in REMOVED),
        "target_boundary_attributes_identical": all({k: v for k, v in source.find(f"junction[@id='{n}']").attrib.items() if k != "intLanes"} == {k: v for k, v in candidate.find(f"junction[@id='{n}']").attrib.items() if k != "intLanes"} for n in NODES),
        "requests_exactly_final_native_output": all([_canonical(x) for x in candidate.find(f"junction[@id='{n}']").findall("request")] == [_canonical(x) for x in native.find(f"junction[@id='{n}']").findall("request")] for n in NODES),
        "no_direct_lane1_forward_shortcut": ("603103444", 1, "73474895", 0) not in new_access and {k[2:] for k in new_access if k[:2] == ("603103444", 1)} == {("381750336", 1)},
        "edge_pair_reachability_not_expanded": {(k[0], k[2]) for k in old_access} == {(k[0], k[2]) for k in new_access},
    }
    geometry = []
    for k, c in old.items():
        if k not in old_access or k in REMOVED or roads[k[0]].get("to") not in NODES:
            continue
        a, b = _internal_path(source, c), _internal_path(candidate, new[k])
        geometry.append({"movement": k, "curve_hausdorff_m": _curve(source, c).hausdorff_distance(_curve(candidate, new[k])), "length_delta_m": sum(float(lane.get("length")) for lane in b) - sum(float(lane.get("length")) for lane in a)})
    checks["retained_local_internal_curves_and_lengths"] = all(x["curve_hausdorff_m"] <= 1e-6 and abs(x["length_delta_m"]) <= 1e-6 for x in geometry)
    checks["new_permissions_intersect_donor_and_endpoints"] = all(new_access[k] == old_access[donor] & _permission_set(lanes[k[:2]].attrib, network_version=source.get("version")) & _permission_set(lanes[k[2:]].attrib, network_version=source.get("version")) for k, (_, _, donor) in ADDED.items())
    checks["all_added_connections_have_passenger"] = all("passenger" in new_access[k] for k in ADDED)
    checks["added_signal_bindings_exact"] = all((new[k].get("tl"), int(new[k].get("linkIndex"))) == (node, index) for k, (node, index, _) in ADDED.items())
    movement_rows, conflict_pairs, program_rows = [], [], []
    for node in sorted(NODES):
        junction = candidate.find(f"junction[@id='{node}']")
        internal = junction.get("intLanes").split()
        requests = {int(r.get("index")): r.attrib for r in junction.findall("request")}
        local = []
        for key, conn in new.items():
            if conn.get("tl") == node:
                path = _internal_path(candidate, conn)
                req = internal.index(path[-1].get("id"))
                row = {"node": node, "movement": key, "tls_index": int(conn.get("linkIndex")), "request_index": req, "internal_lanes": [lane.get("id") for lane in path], "internal_length_m": sum(float(lane.get("length")) for lane in path), "direction": conn.get("dir")}
                local.append(row)
                movement_rows.append(row)
        checks[f"request_mapping_complete_{node}"] = {x["request_index"] for x in local} == set(requests) == set(range(len(internal)))
        for filename in ("network.net.xml", "control.add.xml"):
            old_pg, new_pg = programs(ET.parse(SOURCE / filename).getroot()), programs(ET.parse(CANDIDATE / filename).getroot())
            expected = deepcopy(old_pg)
            for (identity, _), pg in expected.items():
                if identity in NODES:
                    donor = 0 if identity == "266197536" else 6
                    for phase in pg.findall("phase"):
                        phase.set("state", phase.get("state") + phase.get("state")[donor])
            checks[f"all_programs_exact_declared_projection_{filename}"] = old_pg.keys() == new_pg.keys() and all(_canonical(expected[k]) == _canonical(v) for k, v in new_pg.items())
            for (identity, program), pg in new_pg.items():
                if identity != node:
                    continue
                for i, phase in enumerate(pg.findall("phase")):
                    state = phase.get("state")
                    program_rows.append({"file": filename, "node": node, "program": program, "phase": i, **phase.attrib})
                    for a in local:
                        for b in local:
                            if a["request_index"] < b["request_index"] and state[a["tls_index"]] == state[b["tls_index"]] == "G" and requests[a["request_index"]]["foes"][::-1][b["request_index"]] == "1":
                                conflict_pairs.append({"file": filename, "node": node, "phase": i, "tls_pair": [a["tls_index"], b["tls_index"]]})
    checks["no_simultaneous_G_native_foe_pairs"] = not conflict_pairs
    raw = (SOURCE / "control.add.xml").read_bytes()
    for block in re.findall(rb"<tlLogic\b[^>]*>[\s\S]*?</tlLogic>", raw):
        identity = ET.fromstring(block).get("id")
        if identity in NODES:
            donor = 0 if identity == "266197536" else 6
            expected = block
            for state in reversed(list(re.finditer(rb'\bstate="([^"]*)"', block))):
                expected = expected[:state.end(1)] + state[1][donor:donor + 1] + expected[state.end(1):]
            raw = raw.replace(block, expected, 1)
    checks["external_control_only_declared_state_bytes_changed"] = raw == (CANDIDATE / "control.add.xml").read_bytes()
    manifest = json.loads((CANDIDATE / "manifest.json").read_text(encoding="utf-8"))
    checks["candidate_hashes_match_builder_record"] = sha(CANDIDATE / "network.net.xml") == manifest["candidate_sha256"] and sha(CANDIDATE / "control.add.xml") == manifest["control_sha256"]
    snapshot_mapping = []
    for path, value in manifest["source_hashes"].items():
        original = Path(path)
        actual = CANDIDATE / "implementation" / original.name if original.name == "hamburg_209_connection_support.py" else original
        snapshot_mapping.append({"recorded_path": path, "evidence_path": str(actual.relative_to(REPO)), "recorded_sha256": value, "actual_sha256": sha(actual)})
    checks["all_builder_source_hashes_match_exact_source_or_declared_snapshot"] = all(row["recorded_sha256"] == row["actual_sha256"] for row in snapshot_mapping)
    write("builder-snapshot-mapping.json", {"bindings": snapshot_mapping, "boundary": "The d0dc materializer produced v3. Its exact implementation snapshot supplies the source binding after the live verifier guard changed; no source hash is skipped or rewritten. The newer 524 verifier only strengthens offline checks and does not rebuild the candidate."})
    source_paths = [SOURCE / n for n in ("network.net.xml", "control.add.xml")]
    source_paths += [CANDIDATE / n for n in ("network.net.xml", "control.add.xml", "manifest.json", "ordinal.native-local-output.net.xml", "connections.con.xml", "projected-programs.tll.xml")]
    source_paths += [CANDIDATE / "implementation/hamburg_209_connection_support.py", CANDIDATE / "implementation-mapping.json", CANDIDATE / "post-build-verification.json", REPO / "outputs/hamburg-734-turn-allocation-lineage-20261024-v1/manifest.json", REPO / "outputs/hamburg-119-downstream-control-source-20261024-v1/focal-lane-candidates/manifest.json"]
    write("source-hashes.json", {str(p.relative_to(REPO)): sha(p) for p in source_paths})
    write("movement-request-bindings.json", movement_rows)
    write("program-projection.json", program_rows)
    write("summary.json", {
        "schema": "astra.hamburg.209-ordinal-independent-review/v1", "audit_status": "pass" if all(checks.values()) else "blocked", "candidate_status": "review_required", "checks": checks,
        "removed_movements": sorted(REMOVED), "added_movements": list(ADDED), "protected_internal_geometry": geometry, "simultaneous_G_foe_pairs": conflict_pairs,
        "native_traffic_runs_by_this_review": 0,
        "semantics": "Three original forward movements are removed and reassigned to the next incoming lane. This is not an all-old-turn preservation claim. The right/forward ordinal proposal follows the separate source geometry review; applicability to the present field remains uncertain.",
        "claim_boundary": "Static scope and modeled signal/ROW compatibility only. Native request tables are retained from the final native conversion, not field right-of-way evidence or a multi-vehicle safety proof. New internal lengths are native, untuned. Root may choose bounded driving smokes; no full traffic or count-fit claim.",
    })
    print(json.dumps({"audit_status": "pass" if all(checks.values()) else "blocked", "checks": checks}, ensure_ascii=False))


if __name__ == "__main__":
    main()
