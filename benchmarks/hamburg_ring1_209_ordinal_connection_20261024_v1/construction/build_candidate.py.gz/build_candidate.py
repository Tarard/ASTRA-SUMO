"""Compile only the reviewed209 connection hypothesis; never run traffic."""

import argparse
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))


if __name__ == "__main__":
    from astra_sumo.core.hamburg_209_connection_support import materialize_hamburg_209_connection_support

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    source = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15/prepared"
    result = materialize_hamburg_209_connection_support(source_file=source / "network.net.xml", control_file=source / "control.add.xml",
        output_dir=ROOT / args.name, netconvert_binary=REPO / ".venv/Lib/site-packages/sumo/bin/netconvert.exe")
    print(json.dumps(result, ensure_ascii=False))
