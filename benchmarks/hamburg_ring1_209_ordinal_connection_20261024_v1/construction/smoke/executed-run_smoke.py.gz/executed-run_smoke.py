"""Prepare or explicitly run five ordinary-entry movement witnesses; never calibrate."""
import argparse
from collections import defaultdict, deque
import copy
import hashlib
import importlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.local_network_conversion import loaded_turn_permissions

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CANDIDATE = ROOT.parent / 'candidate-v3'
SOURCE = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority'
OLD_DRIVER = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/merge-smoke/shared-driver.py'
MOVES = {531: ('603103444', 1, '381750336', 1), 532: ('603103444', 2, '73474895', 0),
         533: ('603103444', 3, '73474895', 1), 534: ('603103444', 4, '73474895', 2),
         625: ('73474895', 0, '1108564798#0', 0), 626: ('73474895', 0, '27064186#0', 0)}
CASES = ('coverage',)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def load_driver():
    spec = spec_from_file_location('existing_native_smoke_driver', ROOT / 'shared-driver.py')
    driver = module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.REPO = REPO
    return driver


def support(network, control):
    plan = json.loads((ROOT / 'plan.json').read_bytes())
    assert sha(network) == plan['candidate_network_sha256'] and sha(control) == plan['candidate_control_sha256']
    net = ET.parse(network).getroot()
    permissions = loaded_turn_permissions(net)
    paths = {}
    for movement, key in MOVES.items():
        assert 'passenger' in permissions[key]
        match = [c for c in net.findall('connection') if (c.get('from'), int(c.get('fromLane')), c.get('to'), int(c.get('toLane'))) == key]
        assert len(match) == 1
        via, sequence = match[0].get('via'), []
        assert sum(c.get('via') == via for c in net.findall('connection') if not c.get('from').startswith(':')) == 1
        while via:
            assert via not in sequence
            sequence.append(via)
            edge, lane = via.rsplit('_', 1)
            links = [c for c in net.findall('connection') if c.get('from') == edge and c.get('fromLane') == lane]
            assert len(links) == 1
            via = links[0].get('via')
        paths[movement] = sequence
    for route in ET.parse(ROOT / 'inputs/routes.rou.xml').getroot().findall('route'):
        load_driver().route_support(net, route.get('edges').split())
    return net, paths


def prepare():
    assert not (ROOT / 'inputs').exists() and not (ROOT / 'shared-driver.py').exists()
    manifest = json.loads((CANDIDATE / 'manifest.json').read_bytes())
    assert all(manifest['checks'].values()) and manifest['source_unchanged'] and not manifest['traffic_simulation_run']
    code = OLD_DRIVER.read_text(encoding='utf-8')
    assert "'1975693623'" in code
    # All new jobs use time triggers. Only diagnostic TLS reads change; native driving stays unchanged.
    code = code.replace("'1975693623'", "'266197536'")
    anchor = '            api.simulationStep()\n'
    assert code.count(anchor) == 1
    code = code.replace(anchor, anchor + "            if api.simulation.getCollidingVehiclesNumber() or api.simulation.getStartingTeleportNumber():\n                raise RuntimeError('Unsafe native collision/teleport: stop this fixture and preserve outputs.')\n")
    (ROOT / 'shared-driver.py').write_text(code, encoding='utf-8')
    (ROOT / 'inputs').mkdir()
    driver = load_driver()
    source = ET.parse(SOURCE / 'evaluation/demand.rou.xml').getroot()
    net = ET.parse(CANDIDATE / 'network.net.xml').getroot()
    graph = defaultdict(set)
    for key, modes in loaded_turn_permissions(net).items():
        if 'passenger' in modes:
            graph[key[0]].add(key[2])
    boundaries = {v.find('route').get('edges').split()[-1] for v in source.findall('vehicle')}
    loops = ET.parse(SOURCE / 'prepared/field-loops.add.xml').getroot()
    field_roads = {r.get('lane').rsplit('_', 1)[0] for r in loops}
    queue, seen, right = deque([['381750336']]), {'381750336'}, None
    while queue:
        path = queue.popleft()
        if path[-1] in boundaries:
            right = path
            break
        for road in sorted(graph[path[-1]]):
            if road not in seen and road not in field_roads | {'141050980#0', '141050980#1', '603103444', '73474895'}:
                seen.add(road)
                queue.append(path + [road])
    assert right is not None
    prefix = ['141050980#0', '141050980#1', '603103444']
    primary = ['73474895', '1108564798#0', '1108564798#1', '24483197', '199500676']
    residential = ['73474895', '27064186#0', '1073054122#1', '1345098540', '24483197', '199500676']
    specs = [('right1', 'coverage', 1, right, 0, 531, [531]),
             ('forward2_primary0', 'coverage', 2, primary, 90, 532, [532, 625]),
             ('forward3', 'coverage', 3, primary, 180, 533, [533]),
             ('forward4', 'coverage', 4, primary, 270, 534, [534]),
             ('residential0', 'coverage', 2, residential, 360, 626, [532, 626])]
    routes, jobs = ET.Element('routes'), []
    for element in source:
        if element.tag != 'vehicle':
            routes.append(copy.deepcopy(element))
    lengths = {lane.get('id'): float(lane.get('length')) for lane in net.iter('lane')}
    original = source.find('vehicle')
    for identity, case, lane, tail, depart, movement, targets in specs:
        edges = prefix + tail
        assert len(edges) == len(set(edges)) and edges[-1] in boundaries and not field_roads.intersection(edges)
        driver.route_support(net, edges)
        route = ET.SubElement(routes, 'route', id='r_' + identity, edges=' '.join(edges))
        waypoints = [(f'141050980#0_{lane}', 7.5), (f'141050980#1_{lane}', .1)]
        if tail is right:
            waypoints.append(('381750336_1', .1))
        else:
            receiver = lane - 2
            waypoints.append((f'73474895_{receiver}', .1))
            if tail is primary:
                waypoints.append((f'1108564798#0_{receiver}', .1))
        for lane_id, margin in waypoints:
            end = lengths[lane_id] - margin
            assert 0 < end < lengths[lane_id]
            ET.SubElement(route, 'stop', lane=lane_id, endPos=f'{end:.9f}', speed='13.888889')
        attrs = dict(original.attrib)
        attrs['departLane'] = str(lane)
        jobs.append(dict(id=identity, case=case, field=None, source_id=original.get('id'), vehicle_attributes=attrs,
            route_id=route.get('id'), trigger=dict(time_s=depart), movement=movement, coverage_movements=targets,
            expected_stop_count=len(waypoints), boundary_exit=edges[-1], explicit_route=edges))
    ET.ElementTree(routes).write(ROOT / 'inputs/routes.rou.xml', encoding='utf-8', xml_declaration=True)
    (ROOT / 'inputs/field-loops.add.xml').write_bytes((SOURCE / 'prepared/field-loops.add.xml').read_bytes())
    save(ROOT / 'inputs/jobs.json', dict(end_s=900, jobs=jobs))
    save(ROOT / 'plan.json', dict(status='prepared', native_runs=0, planned_cases={'coverage': 5},
        step_s=.1, seed=104, speed_mode=31, end_s=900, actual_native_coverage_required=True, MAE=None,
        candidate_network_sha256=sha(CANDIDATE / 'network.net.xml'), candidate_control_sha256=sha(CANDIDATE / 'control.add.xml'),
        candidate_manifest_sha256=sha(CANDIDATE / 'manifest.json'), source_driver_sha256=sha(OLD_DRIVER),
        adapted_driver_sha256=sha(ROOT / 'shared-driver.py'), old_driver_path=str(OLD_DRIVER),
        text_edit="Diagnostic197 literal replaced by536; support predicate supplied for six exact movement keys. Time triggers only; unchanged driving loop/LaneSectionHold/safety. Legacy near_197 labels now mean the monitored536 proximity.",
        inputs={p.name: sha(p) for p in (ROOT / 'inputs').iterdir()}, source_hashes={str(p): sha(p) for p in
            (SOURCE / 'evaluation/demand.rou.xml', SOURCE / 'prepared/field-loops.add.xml', Path(__file__))},
        movement_keys={k: list(v) for k, v in MOVES.items()}, jobs=jobs,
        claim_boundary='Toy ordinary-entry movement support only. Five normal entries are90s apart; primary/residential lane0 requests are270s apart. Native moving waypoints constrain test lanes; no setSpeed/changeLane/moveTo/setPhase/collision override. Original vType and default speedMode31. Thirteen E1 loops are instrumentation only; no real targets or MAE. Coverage requires actual unique internal via and receiving-lane transition plus completed boundary route. LC away is not tested coverage; no congestion or field-validity proof.'))
    check()


def check():
    plan = json.loads((ROOT / 'plan.json').read_bytes())
    assert sha(ROOT / 'shared-driver.py') == plan['adapted_driver_sha256']
    assert all(sha(ROOT / 'inputs' / n) == h for n, h in plan['inputs'].items())
    assert all(sha(Path(p)) == h for p, h in plan['source_hashes'].items())
    support(CANDIDATE / 'network.net.xml', CANDIDATE / 'control.add.xml')
    return plan


def execute(case):
    plan = check()
    assert Path(sys.executable).resolve() == (REPO / '.venv/Scripts/python.exe').resolve()
    modules = {n: str(Path(importlib.import_module(n).__file__).resolve()) for n in ('libsumo', 'traci', 'sumolib', 'sumo')}
    assert all(Path(p).is_relative_to((REPO / '.venv').resolve()) for p in modules.values()), 'Set project PYTHONPATH/SUMO_HOME before Python.'
    assert (Path(modules['sumo']).parent / 'bin/sumo.exe').resolve() == (REPO / '.venv/Lib/site-packages/sumo/bin/sumo.exe').resolve()
    driver = load_driver()
    driver.support = support
    driver.run(case, 'native-' + case, (CANDIDATE / 'network.net.xml').resolve(), (CANDIDATE / 'control.add.xml').resolve())
    out = ROOT / ('native-' + case)
    result = json.loads((out / 'result.json').read_bytes())
    samples = json.loads((out / 'samples.json').read_bytes())
    _, paths = support(CANDIDATE / 'network.net.xml', CANDIDATE / 'control.add.xml')
    arrivals = {v.get('id'): v.find('route') for v in ET.parse(out / 'vehicle-routes.xml').getroot().findall('vehicle')}
    evidence = []
    for job in (r for r in plan['jobs'] if r['case'] == case):
        history = [r['vehicles'][job['id']]['lane'] for r in samples if job['id'] in r['vehicles']]
        route = arrivals.get(job['id'])
        route_complete = route is not None and route.get('edges').split() == job['explicit_route'] and len(route.get('exitTimes', '').split()) == len(job['explicit_route']) and all(float(t) >= 0 for t in route.get('exitTimes').split())
        for movement in job['coverage_movements']:
            target = MOVES[movement]
            via_indices = [i for i, lane in enumerate(history) if lane in paths[movement]]
            after = next((lane for lane in history[max(via_indices) + 1:] if not lane.startswith(':')), None) if via_indices else None
            covered = bool(via_indices) and after == f'{target[2]}_{target[3]}' and route_complete
            evidence.append(dict(vehicle_id=job['id'], movement=movement, key=list(target), actual_via_lanes=sorted(set(history).intersection(paths[movement])),
                                 first_ordinary_lane_after_via=after, route_complete=route_complete, covered=covered))
    checks = dict(all_required_actual_transitions=all(r['covered'] for r in evidence), original_driver_pass=result['status'] == 'pass', source_inputs_unchanged=result['source_inputs_unchanged'])
    check()
    save(out / 'movement-coverage.json', dict(status='pass' if all(checks.values()) else 'review_required', native_runs=1,
        checks=checks, movements=evidence, module_paths=modules, MAE=None, toy_only=True,
        claim_boundary='Actual native via-to-ordinary transitions and arrived boundary routes only. The0.158m603 road can fall between steps, so its unique compiled via identifies the actual connection. No nominal lane assignment is accepted as coverage.'))
    print(json.dumps(checks))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--prepare-only', action='store_true')
    action.add_argument('--check-only', action='store_true')
    action.add_argument('--run', choices=CASES)
    args = parser.parse_args()
    prepare() if args.prepare_only else print(json.dumps(check())) if args.check_only else execute(args.run)
