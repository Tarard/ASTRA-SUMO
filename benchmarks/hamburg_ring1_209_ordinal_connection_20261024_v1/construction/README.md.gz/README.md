Candidatev3 is an exploratory209 connection hypothesis. It is not adopted and has no traffic simulation result. Source geometry and lane ordinals still require field review.

The source is the completed +15 prepared network/control. At266197536, the candidate keeps603lane0→381lane0, addslane1→381lane1, and replaces the three misaligned forwards with603lanes2/3/4→734lanes0/1/2. At266197525, it keeps the residential734lane0→270 branch and the two existing primary turns. It adds734lane0→110lane0. Ordinary roads and lanes keep their geometry, permissions, and lengths. Demand and driver stay fixed.

The retained residential270 branch is inherited from the current model. It is not the MAP14→egress5/SG6 movement. That movement is the separate northeast Alsterufer branch omitted from this corridor, about55m away. This candidate does not add that road.

The new right turn uses signal6 and inherits old536signal0. The three reordered forwards retain signals1–3. The new primary turn uses525signal8 and inherits old6, whose colors match old7. All original states and phase attributes remain. Embedded and external programs are projected separately. Their existing unused525states2–4 difference remains unchanged.

The shared core calls geometry freeze, scoped native netconvert, exterior restoration, and local merge. Netconvert computes the final ROW with the projected programs. Its request tables remain unchanged afterward. Candidatev3 passes13 construction scope checks and the independent20-check review. These checks establish construction scope, not driving safety or field correctness.

Candidatev1 remains blocked because native coordinate formatting changed target boundary text. Candidatev2 remains blocked because exterior element order differed. Candidatev3 restores only numerically equal boundary text and uses the existing local merge to retain source order. Both failed prototypes remain saved.

The original v3 materializer is thed0dc8ac3 snapshot in`candidate-v3/implementation/`. Later guard-only fixes add exact program inventory and all junction-attribute checks, except recomputedintLanes. They do not alter v3, its native output, or its original manifest. The strengthened offline proof is`candidate-v3/post-build-verification-v2.json`; its verifier snapshot is separate. The current core hash isb544ffcd. Source/candidate hashes and exact mappings remain in the manifests and snapshot mapping files.

Testing: the original materializer passed one scoped netconvert test and six unit tests. The current guard version passed eight offline unit tests here. Root then ran all nine current tests, including scoped netconvert, and reported all passed. Ruff and diff-check pass. No SUMO traffic simulation ran.
