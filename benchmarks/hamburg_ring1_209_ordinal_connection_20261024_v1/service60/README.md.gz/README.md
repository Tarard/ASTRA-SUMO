This fixture tests service at LSA119 with no603103445#2 inflow. It does not fit the real counts or establish field capacity.

The fixed source is the completed +15 common-offset case. Network, control, vehicle type, moving stops, and the four body-hold nodes remain unchanged. Thirty vehicles per lane enter24483344#1 at requested times0–29s. The ordinary entry lane is explicitly0 or1. Each vehicle follows the source legal tail to199500676. Native insertion may delay departures.

Use the project virtual environment. Run `run_fixture.py --check-only` to check inputs. Run `selfcheck.py` for offline checks. Only `run_fixture.py --run` starts SUMO. It writes a new `native/` directory and refuses to overwrite one.

The diagnostic keeps all13loops and runs1200s at0.1s with seed104. It records native E1, FCD, lane changes, TLS switches, routes, trips, queues, safety outputs, and local lane states. The real130+52 observations remain referenced background files. No fixture MAE is computed.

The first declared green is0–14s and may have late approach supply. The next green is90–104s. Actual TLS states determine the reported windows. Each green includes starting queue/head position, minimum approach occupancy, front entries into the internal lane, and complete E1 rear-clear contributions. They are separate measurements. Moving queues need not have a halted vehicle at every step. Empty or uncertain supply cannot establish saturated service. The trace must also be checked for receiving and downstream queues.

No runtime speed, position, route, phase, or signal setters are added. The existing lane-intention driver remains active. KeepClear and the GS266 priority rules remain unchanged. This is a toy service diagnostic, not a demand candidate or evidence for the cause of the full-run delays.
