The +15 full run contains1205 native603103445#2→GS266 passages. All belong to Z15. Their later tail splits into603 residential and602 primary routes. Both groups pass GS before that split.

The100 main-window greens use the current static119 program: [90k,90k+14). Only51 of the1205 major-flow front entries fall within these greens across the full run. The vehicle table preserves every native603#2 exit and186 exit. Their interval covers the GS internal path plus the short receiving edge. It is a wide occupancy bound, not an exact conflict occupancy record.

Fourteen main cycles have a244 lane listed with at least20m of native queue length at all14 one-second samples, but fewer than8 complete E1 contributions. Four have no major-flow occupancy-bound overlap. At4410–4424, Z4 has14 queue samples of96.013m, zero front entries, and zero E1 contributions. Z5 has3 front entries and3 E1 contributions. No603 entry-to186-exit interval overlaps this window.

This identifies an episode worth observing. It does not establish continuous0.1s stopline demand or identify the cause. Queue rows contain no vehicle identity. An unlisted lane is not an empty lane. E1 rear clearance and front entry into the internal lane remain separate measures.

The full network can also restrict receiving space beyond GS. The retained route passes six further TLS and several short edges before24483197. No603 overlap therefore does not isolate keepClear, lane behavior, or any one downstream signal. No demand, geometry, control, or driver changed. This audit started no native run.
