"""Read existing +15 native evidence; do not start SUMO or change inputs."""

from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15"
NATIVE = SOURCE / "evaluation/native"
FIELDS = ("hh_0119_Z_4_29437", "hh_0119_Z_5_30494")
Z15 = "hh_0119_Z_15_29375"
LANES = ("24483344#1_0", "24483344#1_1")
RECEIVING = ("79014037#1_0", "79014037#1_1") + tuple(f"186713429_{i}" for i in range(4))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze():
    metadata = json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())
    intentions = {r["vehicle_id"]: r["field_id"] for r in metadata["vehicles"]}
    control = ET.parse(SOURCE / "prepared/control.add.xml").getroot()
    program = next(r for r in control.findall("tlLogic") if r.get("id") == "LSA119_part0")
    assert program.get("offset") == "15" and program.get("type") == "static"
    duration = 0
    green_phase_bounds = []
    for phase in program.findall("phase"):
        end = duration + float(phase.get("duration"))
        if phase.get("state")[12] in "gG" or phase.get("state")[13] in "gG":
            assert phase.get("state")[12] in "gG" and phase.get("state")[13] in "gG"
            green_phase_bounds.append([duration, end])
        duration = end
    assert duration == 90 and green_phase_bounds == [[75, 89]]
    passages = json.loads(gzip.decompress((SOURCE / "evaluation/contributing-passages.json.gz").read_bytes()))
    assert passages["reconciled"] and not passages["outside_periodic_intervals"]
    e1 = defaultdict(list)
    for row in passages["passages"]:
        if row["detector_id"] in FIELDS:
            e1[row["detector_id"]].append(round(row["notification_time_s"] * 10))
    gs_rows, all_major_fields, branches = [], Counter(), Counter()
    left_entries = defaultdict(list)
    for vehicle in ET.parse(NATIVE / "vehicle-routes.xml").getroot().findall("vehicle"):
        route = vehicle.find("route")
        edges = route.get("edges").split()
        field = intentions[vehicle.get("id")]
        if field in FIELDS:
            times = [float(t) for t in route.get("exitTimes").split()]
            left_entries[field].append(times[edges.index("24483344#1")])
        if "603103445#2" not in edges:
            continue
        index = edges.index("603103445#2")
        assert edges[index + 1] == "186713429"
        times = [float(t) for t in route.get("exitTimes").split()]
        assert len(times) == len(edges)
        all_major_fields[field] += 1
        branch = "primary1108564798" if "1108564798#0" in edges else "residential27064186" if "27064186#0" in edges else "other"
        branches[branch] += 1
        gs_rows.append({"vehicle_id": vehicle.get("id"), "field_id": field, "native_depart_s": float(vehicle.get("depart")),
            "upstream_603_1_front_exit_s": times[index - 1], "gs_front_entry_s": times[index],
            "receiver_186_front_exit_s": times[index + 1], "gs_plus_receiver_elapsed_s": round(times[index + 1] - times[index], 10),
            "later_tail_branch": branch, "entry_during_119_green": round(times[index] * 10) % 900 < 140})
    queues = {}
    observed_times = set()
    for _, element in ET.iterparse(NATIVE / "queues.xml", events=("end",)):
        if element.tag != "data":
            continue
        tick = round(float(element.get("timestep")))
        if 3600 <= tick < 12600 and tick % 90 < 14:
            observed_times.add(tick)
            queues[tick] = {r.get("id"): r.attrib.copy() for r in element.iter("lane") if r.get("id") in LANES + RECEIVING}
        element.clear()
    assert len(observed_times) == 1400
    periods, bins = [], []
    for begin in range(3600, 12600, 90):
        end = begin + 14
        row = {"green_begin_s": begin, "green_end_s": end}
        for index, (lane, field) in enumerate(zip(LANES, FIELDS)):
            present = [queues[t][lane] for t in range(begin, end) if lane in queues[t]]
            lengths = [float(r["queueing_length"]) for r in present]
            experimental = [float(r["queueing_length_experimental"]) for r in present]
            prefix = f"z{4 + index}_"
            row.update({prefix + "e1_rear_contributions": sum(begin * 10 <= t < end * 10 for t in e1[field]),
                prefix + "front_internal_entries": sum(begin <= t < end for t in left_entries[field]),
                prefix + "queue_listed_samples": len(present), prefix + "queue_unlisted_samples": 14 - len(present),
                prefix + "min_listed_queue_length_m": min(lengths) if lengths else None,
                prefix + "max_listed_queue_length_m": max(lengths) if lengths else None,
                prefix + "min_listed_experimental_length_m": min(experimental) if experimental else None,
                prefix + "all14_queue_at_least20m": len(lengths) == 14 and min(lengths) >= 20})
        for lane in RECEIVING:
            listed = [queues[t][lane] for t in range(begin, end) if lane in queues[t]]
            row[lane + "_queue_listed_samples"] = len(listed)
            row[lane + "_max_listed_queue_m"] = max((float(r["queueing_length"]) for r in listed), default=None)
        starts = [r for r in gs_rows if begin <= r["gs_front_entry_s"] < end]
        overlap = [r for r in gs_rows if r["gs_front_entry_s"] < end and r["receiver_186_front_exit_s"] > begin]
        row.update(major_603_front_entries=len(starts), major_603_z15_front_entries=sum(r["field_id"] == Z15 for r in starts),
            major_603_to186_interval_overlaps=len(overlap),
            major_603_entry_times_s=";".join(str(r["gs_front_entry_s"]) for r in starts))
        periods.append(row)
    for begin in range(0, 14400, 900):
        rows = [r for r in gs_rows if begin <= r["gs_front_entry_s"] < begin + 900]
        bins.append({"begin_s": begin, "end_s": begin + 900, "major603_front_entries": len(rows),
            "z15_major603_front_entries": sum(r["field_id"] == Z15 for r in rows),
            "during_left_green": sum(r["entry_during_119_green"] for r in rows)})
    selected = [r for r in periods if any(r[f"z{z}_all14_queue_at_least20m"] and r[f"z{z}_e1_rear_contributions"] < 8 for z in (4, 5))]
    no_major = [r for r in selected if r["major_603_to186_interval_overlaps"] == 0]
    write_csv(ROOT / "major603-vehicles.csv", gs_rows)
    write_csv(ROOT / "major603-by900.csv", bins)
    write_csv(ROOT / "main100-greens.csv", periods)
    write_csv(ROOT / "selected-queued-low-service-greens.csv", selected)
    summary = {"status": "pass", "formal_result": False, "native_runs": 0, "all603_major_field_counts": dict(all_major_fields),
        "z15_planned_requests": sum(v == Z15 for v in intentions.values()), "all603_major_vehicles": len(gs_rows),
        "later_tail_branch_counts_separate_from_gs_flow": dict(branches),
        "all_day_major_entry_during_left_green": sum(r["entry_during_119_green"] for r in gs_rows),
        "main100_green_count": len(periods), "all14_listed_20m_queue_but_less_than8_e1_cycles": len(selected),
        "such_cycles_without_major_interval_overlap": len(no_major), "first_examples": selected[:4],
        "first_examples_without_major_interval_overlap": no_major[:4],
        "per_lane_summary": {str(z): {"queued_low_service_cycles": sum(r[f"z{z}_all14_queue_at_least20m"] and r[f"z{z}_e1_rear_contributions"] < 8 for r in periods),
            "all14_queue_listed_cycles": sum(r[f"z{z}_queue_listed_samples"] == 14 for r in periods)} for z in (4, 5)},
        "scope": "Static119 input yields declared green[90k,90k+14); no new TLS observation was run. Exact native front exits603#2 locate GS entry. Entry-to186exit intervals include internal path and receiver, not exact conflict occupancy. Queue rows have no vehicle identity; absence is not an empty lane.14 listed positive queue samples do not prove uninterrupted queue at0.1s or stopline front demand. RearE1 is not front entry.",
        "remaining_restrictions": "Even without603 overlap, full traffic can block186/141050975/141050980/603103444/73474895/1108564798/24483197. Six downstreamTLS and short storage remain; no claim of duplicate controls or a specific keepClear cause.",
        "claim_boundary": "The60-car no603 diagnostic demonstrates8 per green under its actual supply. It does not set full-network or field capacity. Existing full native flow, not arbitrary major traffic, would define any later paired fixture."}
    save(ROOT / "summary.json", summary)
    paths = [SOURCE / "prepared/control.add.xml", SOURCE / "prepared/lane-intentions.json", NATIVE / "vehicle-routes.xml", NATIVE / "queues.xml",
        SOURCE / "evaluation/contributing-passages.json.gz", NATIVE / "field-counts.xml", Path(__file__)]
    save(ROOT / "source-hashes.json", {str(path): {"bytes": path.stat().st_size, "sha256": digest(path)} for path in paths})
    print(json.dumps({k: v for k, v in summary.items() if k not in {"first_examples", "first_examples_without_major_interval_overlap", "scope", "remaining_restrictions", "claim_boundary"}}, ensure_ascii=False))


if __name__ == "__main__":
    analyze()
