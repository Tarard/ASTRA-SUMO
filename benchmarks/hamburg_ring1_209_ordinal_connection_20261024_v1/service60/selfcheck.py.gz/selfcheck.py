"""Offline assertions only. This file never starts SUMO."""

import gzip
import json
from pathlib import Path
import runpy
import tempfile


ROOT = Path(__file__).resolve().parent
module = runpy.run_path(str(ROOT / "run_fixture.py"))
assert module["check"]()["status"] == "pass"
runtime, _ = module["check_runtime"]()
scope_globals = module["check"].__globals__
original_digest = scope_globals["digest"]
try:
    scope_globals["digest"] = lambda _: "invalid"
    try:
        module["check"]()
    except AssertionError:
        pass
    else:
        raise AssertionError("A changed input hash was accepted.")
finally:
    scope_globals["digest"] = original_digest

service = module["green_service"]
with tempfile.TemporaryDirectory() as temporary:
    destination = Path(temporary)
    service.__globals__["NATIVE"] = destination
    (destination / "front-entries.json").write_text(json.dumps([{
        "vehicle_id": "toy", "from_lane": module["APPROACH"][0], "native_step_time_s": 90.5}]), encoding="utf-8")
    with gzip.open(destination / "samples.jsonl.gz", "wt", encoding="utf-8") as handle:
        for tick in range(15):
            state = "r" * 12 + ("GG" if tick < 14 else "rr")
            lanes = {module["APPROACH"][0]: {"vehicles": [{"pos_m": 90, "speed_m_s": 1}], "stopped": int(tick == 0)},
                     module["APPROACH"][1]: {"vehicles": [], "stopped": 0}}
            handle.write(json.dumps({"native_step_time_s": 90 + tick / 10, "lanes": lanes,
                "tls": {module["TLS"][0]: {"state": state}}}) + "\n")
    result = service([{"detector_id": module["FIELDS"][0], "notification_time_s": 90.6}])
    assert len(result["rows"]) == 2
    assert result["rows"][0]["front_entries"] == result["rows"][0]["e1_rear_contributions"] == 1
    assert result["rows"][0]["supply_classification"] == "continuous_supply_supported"
    assert result["rows"][1]["supply_classification"] == "late_supply_at_start"

report = {"status": "pass", "native_runs": 0, "scope_and_hash_checks": True,
    "tampered_hash_rejected": True, "front_and_rear_separate": True,
    "moving_queue_not_rejected_for_zero_halted_steps": True, "late_supply_marked": True, "runtime": runtime}
(ROOT / "selfchecks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in report.items() if k != "runtime"}))
