"""Prepare/check one fixed-input209 evaluation. Native awaits a bound smoke schema."""

import argparse
from collections import Counter
import gzip
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import time
import traceback
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15"
OFFSET0 = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
CANDIDATE = REPO / "outputs/hamburg-209-ordinal-connection-20261024-v1/candidate-v3"
RUNTIME_HELPER = REPO / "outputs/hamburg-119-saturated-service-20261024-v1/run_fixture.py"
AUDIT_HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"
CASE = ROOT / "full"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "lane-intentions.json", "field-loops.add.xml",
    "expected-counts.csv", "initialization-counts.csv", "scenario.json")
REUSED = runpy.run_path(str(RUNTIME_HELPER))
sha, save = REUSED["digest"], REUSED["save"]


def audit_tools():
    sys.path.insert(0, str(AUDIT_HELPER.parent))
    return runpy.run_path(str(AUDIT_HELPER))


def prepare():
    prepared = CASE / "prepared"
    prepared.mkdir(parents=True, exist_ok=False)
    for name in NAMES:
        origin = CANDIDATE if name in ("network.net.xml", "control.add.xml") else SOURCE / "prepared"
        shutil.copyfile(origin / name, prepared / name)
    scenario = json.loads((prepared / "scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False,
        network_sha256=sha(prepared / "network.net.xml"), control_sha256=sha(prepared / "control.add.xml"),
        demand_sha256=sha(prepared / "demand.rou.xml"), geometry_validated_as_field_truth=False,
        connection_candidate="209 ordinal hypothesis at266197536/266197525 only. Original +15 demand/driver/observations retained. Warburg270 remains inherited; it is not the separate MAP Alsterufer SG6 movement.")
    save(prepared / "scenario.json", scenario)
    request = json.loads((SOURCE / "evaluation/native/native-request.json").read_bytes())
    paths = [SOURCE / "prepared" / name for name in NAMES] + [CANDIDATE / name for name in ("network.net.xml", "control.add.xml", "manifest.json")]
    paths += [SOURCE / "verdict.json", SOURCE / "preflight.json", OFFSET0 / "verdict.json", SOURCE / "evaluation/native/native-request.json",
        RUNTIME_HELPER, AUDIT_HELPER, AUDIT_HELPER.parent / "audit_scope.py", Path(__file__)]
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core"
    paths += [core / name for name in ("detector_demand_replay.py", "hamburg_od_spsa.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    save(CASE / "scope-proof.json", {"status": "pass", "N": 8640, "formal_result": False,
        "source_hashes": {str(path): sha(path) for path in paths},
        "prepared_hashes": {name: sha(prepared / name) for name in NAMES},
        "unchanged_input_names": [name for name in NAMES if name not in ("network.net.xml", "control.add.xml", "scenario.json")],
        "original_driver_scope": {key: request[key] for key in ("backend", "junction_body_hold", "junction_body_hold_nodes", "all_stopped_timeout_s", "monitor_interval_s")},
        "end_s": 14400, "step_length_s": .1, "seed": 104,
        "demand_changes": {"IDs": 0, "departures": 0, "routes": 0, "stops": 0, "field_intentions": 0},
        "smoke_binding_status": "pending_actual_schema_and_report", "claim_boundary": "This scope permits preparation only. Native execution requires the later reviewed smoke report/hash. Count response does not establish or refute physical applicability."})


def check():
    runtime, _ = REUSED["check_runtime"]()
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes

    proof = json.loads((CASE / "scope-proof.json").read_bytes())
    prior_runtime = json.loads((SOURCE / "preflight.json").read_bytes())
    assert all(sha(path) == value for path, value in prior_runtime["binaries"].items())
    assert all(runtime["modules"][name]["path"] == path for name, path in prior_runtime["module_paths"].items())
    assert runtime["native_library"]["sha256"] == prior_runtime["binaries"][runtime["native_library"]["path"]]
    runtime["binaries"] = prior_runtime["binaries"]
    prepared = CASE / "prepared"
    assert all(sha(path) == value for path, value in proof["source_hashes"].items())
    assert all(sha(prepared / name) == value for name, value in proof["prepared_hashes"].items())
    assert all((prepared / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes() for name in proof["unchanged_input_names"])
    assert all((prepared / name).read_bytes() == (CANDIDATE / name).read_bytes() for name in ("network.net.xml", "control.add.xml"))
    assert len(ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")) == 8640
    assert tuple(proof["original_driver_scope"]["junction_body_hold_nodes"]) == _body_hold_nodes(prepared)
    assert proof["original_driver_scope"]["backend"] == "libsumo" and proof["original_driver_scope"]["junction_body_hold"]
    assert proof["end_s"] == 14400 and proof["step_length_s"] == .1 and proof["seed"] == 104
    assert len(ET.parse(prepared / "field-loops.add.xml").getroot().findall("inductionLoop")) == 13
    tools = audit_tools()
    baseline = tools["evidence"](SOURCE / "prepared", SOURCE / "evaluation", SOURCE / "evaluation/contributing-passages.json.gz", 8640)
    assert baseline["healthy"] and baseline["safe"] and baseline["metrics130"]["TAE"] == 460
    return {"status": "pass", "native_runs": 0, "N": 8640, "runtime": runtime,
        "source_plus15_offline182_audit": {key: baseline[key] for key in ("metrics130", "metrics52", "metrics182", "healthy", "safe")},
        "smoke": require_smoke(), "native_launch": "ready_for_explicit_run"}


def require_smoke():
    path = CANDIDATE.parent / "smoke/smoke-verdict.json"
    expected_hash = "0a080b83fb656e6000669a8a2c862bb651d4190df9384f6d87dc8f7a3c5db9c4"
    assert sha(path) == expected_hash
    report = json.loads(path.read_bytes())
    assert report["schema"] == "astra.hamburg.209-ordinal-smoke/v1" and report["status"] == "pass"
    assert report["formal_result"] is False and report["native_runs"] == 1 and report["vehicles"] == 5
    assert report["end_s"] == 900 and report["step_s"] == .1 and report["seed"] == 104
    assert report["candidate_network_sha256"] == sha(CASE / "prepared/network.net.xml") == sha(CANDIDATE / "network.net.xml")
    assert report["candidate_control_sha256"] == sha(CASE / "prepared/control.add.xml") == sha(CANDIDATE / "control.add.xml")
    assert report["candidate_manifest_sha256"] == sha(CANDIDATE / "manifest.json")
    required_checks = {"source_scope_and_input_hashes_unchanged", "all5arrived", "zero_unsafe",
        "all5new_and_preserved_residential_movements_observed", "no_field_targets_or_MAE", "only5normal_vehicle_add_commands"}
    assert report["checks"].keys() == required_checks and all(report["checks"][key] is True for key in required_checks)
    assert all(report["completion"][key] == 5 for key in ("loaded", "inserted", "arrived"))
    assert all(report["completion"][key] == 0 for key in ("waiting", "running", "collisions", "teleports", "discarded"))
    required_movements = {("603103444", 1, "381750336", 1), ("603103444", 2, "73474895", 0),
        ("603103444", 3, "73474895", 1), ("603103444", 4, "73474895", 2),
        ("73474895", 0, "1108564798#0", 0), ("73474895", 0, "27064186#0", 0)}
    coverage = report["movement_coverage"]
    assert {tuple(row["key"]) for row in coverage} == required_movements
    assert len(coverage) == 7 and len({row["vehicle_id"] for row in coverage}) == 5
    assert all(row["covered"] is True and row["route_complete"] is True and row["actual_via_lanes"]
        and row["first_ordinary_lane_after_via"] == f"{row['key'][2]}_{row['key'][3]}" for row in coverage)
    assert report["source_hashes"] and all(sha(REPO / name) == value for name, value in report["source_hashes"].items())
    return {"path": str(path), "schema": report["schema"], "sha256": expected_hash,
        "status": report["status"], "vehicles": 5, "actual_unique_movements": 6,
        "candidate_network_sha256": report["candidate_network_sha256"], "candidate_control_sha256": report["candidate_control_sha256"]}


def run():
    checked = check()
    smoke = require_smoke()
    from astra_sumo.core.detector_demand_replay import run_point_detector_demand
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

    prepared, evaluation = CASE / "prepared", CASE / "evaluation"
    assert not evaluation.exists() and not (CASE / "verdict.json").exists()
    evaluation.mkdir()
    for name in ("demand.rou.xml", "lane-intentions.json"):
        shutil.copyfile(prepared / name, evaluation / name)
    shutil.copyfile(__file__, CASE / "executed-driver.py")
    implementation = CASE / "implementation"
    implementation.mkdir()
    for path in json.loads((CASE / "scope-proof.json").read_bytes())["source_hashes"]:
        source_path = Path(path)
        if source_path.suffix == ".py":
            shutil.copyfile(source_path, implementation / source_path.name)
    save(CASE / "preflight.json", {"runtime": checked["runtime"], "scope_sha256": sha(CASE / "scope-proof.json"),
        "smoke": smoke, "end_s": 14400, "step_length_s": .1, "seed": 104,
        "implementation_sha256": {path.name: sha(path) for path in implementation.iterdir()}})
    started = time.perf_counter()
    try:
        native = run_point_detector_demand(net_file=prepared / "network.net.xml", route_file=prepared / "demand.rou.xml",
            e1_additional_file=prepared / "field-loops.add.xml", expected_counts_csv=prepared / "expected-counts.csv",
            output_dir=evaluation / "native", end_s=14400, timeout_seconds=4800, step_length=.1, seed=104,
            backend="libsumo", sumo_binary=str(REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe"), signal_program_file=prepared / "control.add.xml",
            lane_intentions_file=prepared / "lane-intentions.json", junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared))
        assert Path(native["stall_monitor"]["traci_module"]).resolve().is_relative_to((REPO / ".venv").resolve())
        assert native["stall_monitor"]["native_library"]["sha256"] == checked["runtime"]["native_library"]["sha256"]
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        events = read_contributing_e1_passages(instant_file=evaluation / "native/instant-e1.xml", periodic_file=evaluation / "native/field-counts.xml",
            detector_ids=native["instant_to_periodic_ids"], step_length=.1)
        assert events["reconciled"]
        compact = evaluation / "contributing-passages.json.gz"
        compact.write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        tools = audit_tools()
        measured = tools["evidence"](prepared, evaluation, compact, 8640)
        fields = {row["vehicle_id"]: row["field_id"] for row in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
        repeated = [dict(vehicle_id=i, field=f, count=n) for i, passages in measured["by_vehicle"].items()
            for f, n in Counter(row["detector_id"] for row in passages).items() if n > 1]
        outside = [dict(vehicle_id=i, actual_field=row["detector_id"], intended_field=fields[i]) for i, passages in measured["by_vehicle"].items()
            for row in passages if row["detector_id"] != fields[i]]
        complete_once = all(len(measured["by_vehicle"].get(identity, [])) == 1
            and measured["by_vehicle"][identity][0]["detector_id"] == field for identity, field in fields.items())
        for name, rows in (("main130", measured["main"]), ("initialization52", measured["initial"]),
            ("all182", measured["initial"] + measured["main"]), ("native208", list(measured["periodic"].values())), ("station40", measured["stations"])):
            tools["table"](evaluation / (name + "-comparison.csv"), rows)
        protected = [row for row in measured["initial"] + measured["main"] if row["detector_id"] in {
            "hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}]
        assert len(protected) == 56
        tools["table"](evaluation / "535-all56.csv", protected)
        stats = {key: measured[key] for key in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}
        parent = json.loads((SOURCE / "verdict.json").read_bytes())["after"]
        offset0 = json.loads((OFFSET0 / "verdict.json").read_bytes())["candidate"]
        verdict = {"status": "diagnostic_measurement_complete", "formal_result": False, "physical_applicability": "review_required",
            "source_plus15": parent, "offset0_reference": offset0, "after": stats,
            "exact_count_fit_main130": stats["metrics130"]["TAE"] == 0, "healthy": measured["healthy"], "safe": measured["safe"],
            "main130_zero_and_healthy": stats["metrics130"]["TAE"] == 0 and measured["healthy"] and measured["safe"],
            "all53556": tools["metrics"](protected), "repeated_vehicle_fields": repeated, "contributions_outside_prior_primary_intention": outside,
            "unique_intended_fields": complete_once and not repeated and not outside,
            "one_intended_complete_event_per_request": complete_once,
            "comparison": {label: {"main130_TAE_delta": stats["metrics130"]["TAE"] - reference["metrics130"]["TAE"],
                "main130_SSE_delta": stats["metrics130"]["SSE"] - reference["metrics130"]["SSE"],
                "initial52_TAE_delta": stats["metrics52"]["TAE"] - reference["metrics52"]["TAE"],
                "all182_TAE_delta": stats["metrics182"]["TAE"] - reference["metrics182"]["TAE"]} for label, reference in (("plus15_parent", parent), ("offset0_reference", offset0))},
            "claim_boundary": "All182/40/53556 and backlog are reported. No all182 non-worsening gate is a user requirement. Count improvement is separate from source applicability; worse MAE alone does not refute topology. This remains a diagnostic measurement, not field-certified zero."}
    except Exception as error:
        verdict = {"status": "invalid", "formal_result": False, "error": f"{type(error).__name__}: {error}", "partial_outputs_preserved": True}
        (CASE / "failure.log").write_text(traceback.format_exc(), encoding="utf-8")
    verdict["elapsed_s"] = time.perf_counter() - started
    save(CASE / "verdict.json", verdict)
    print(json.dumps(verdict, ensure_ascii=False))
    if verdict["status"] == "invalid":
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare-only", action="store_true")
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.prepare_only:
        prepare()
    if args.prepare_only or args.check_only:
        checked = check()
        save(ROOT / "selfchecks.json", checked)
        print(json.dumps({key: value for key, value in checked.items() if key != "runtime"}))
    else:
        run()
