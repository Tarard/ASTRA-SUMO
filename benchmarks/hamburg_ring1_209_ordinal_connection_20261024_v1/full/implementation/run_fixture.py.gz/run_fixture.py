"""Prepare a 60-car service diagnostic; native execution requires --run."""

import argparse
from collections import Counter
from copy import deepcopy
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-common-offset-20261024-v1/plus15/prepared"
SOURCE_NATIVE = SOURCE.parent / "evaluation/native"
PREPARED, NATIVE = ROOT / "prepared", ROOT / "native"
TLS = ("LSA119_part0", "6390683126")
APPROACH = ("24483344#1_0", "24483344#1_1")
INTERNAL = (":LSA119_part0_12_0", ":LSA119_part0_12_1")
FIELDS = ("hh_0119_Z_4_29437", "hh_0119_Z_5_30494")
TEMPLATES = ("od_0020_v00000", "od_0020_v00001")
END = 1200


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prepare():
    PREPARED.mkdir(parents=True, exist_ok=False)
    source = ET.parse(SOURCE / "demand.rou.xml").getroot()
    original = {v.get("id"): v for v in source.findall("vehicle")}
    demand = ET.Element("routes")
    for item in source.findall("vType"):
        demand.append(deepcopy(item))
    intentions, provenance = [], []
    for index in range(30):
        for lane, (template, field) in enumerate(zip(TEMPLATES, FIELDS)):
            vehicle = deepcopy(original[template])
            identity = f"sat_z{lane + 4}_{index:02d}"
            vehicle.set("id", identity)
            vehicle.set("depart", str(index))
            vehicle.set("departLane", str(lane))
            route = vehicle.find("route")
            edges = route.get("edges").split()
            route.set("edges", " ".join(edges[edges.index("24483344#1"):]))
            demand.append(vehicle)
            intentions.append({"vehicle_id": identity, "field_id": field})
            provenance.append({"vehicle_id": identity, "template_vehicle_id": template,
                "field_id": field, "depart_s": index, "ordinary_depart_lane": lane})
    ET.ElementTree(demand).write(PREPARED / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    save(PREPARED / "lane-intentions.json", {"mechanism": "Two cloned legal tail templates; ordinary lane-specific entry, not measured demand.", "vehicles": intentions})
    for name, tag, output in [("e1.add.xml", "inductionLoop", "field-counts.xml"),
                              ("instant.add.xml", "instantInductionLoop", "instant-e1.xml")]:
        tree = ET.parse(SOURCE_NATIVE / name)
        for element in tree.getroot().findall(tag):
            element.set("file", str(NATIVE / output))
            if tag == "inductionLoop":
                element.set("end", str(END))
        tree.write(PREPARED / name, encoding="utf-8", xml_declaration=True)
    addition = ET.Element("additional")
    ET.SubElement(addition, "timedEvent", type="SaveTLSSwitchStates", dest=str(NATIVE / "tls-switch-states.xml"))
    ET.ElementTree(addition).write(PREPARED / "tls-observer.add.xml", encoding="utf-8", xml_declaration=True)
    request = json.loads((SOURCE_NATIVE / "native-request.json").read_bytes())
    command = [value.replace(str(SOURCE_NATIVE), str(NATIVE)) for value in request["command"]]
    for flag, value in {"--net-file": SOURCE / "network.net.xml", "--route-files": PREPARED / "demand.rou.xml",
        "--additional-files": ",".join(map(str, [SOURCE / "control.add.xml", PREPARED / "e1.add.xml", PREPARED / "instant.add.xml", PREPARED / "tls-observer.add.xml"])),
        "--end": END}.items():
        command[command.index(flag) + 1] = str(value)
    command.extend(["--fcd-output", str(NATIVE / "fcd.xml"), "--lanechange-output", str(NATIVE / "lanechanges.xml")])
    request.update(command=command, end_s=END, monitor_file=str(NATIVE / "stall-monitor.json"),
        route_file=str(PREPARED / "demand.rou.xml"), lane_intentions_file=str(PREPARED / "lane-intentions.json"),
        e1_file=str(SOURCE / "field-loops.add.xml"))
    save(PREPARED / "native-request.json", request)
    paths = [SOURCE / name for name in ["network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
        "lane-intentions.json", "expected-counts.csv", "initialization-counts.csv", "scenario.json"]]
    paths += [SOURCE_NATIVE / name for name in ["native-request.json", "e1.add.xml", "instant.add.xml"]]
    paths += [Path(__file__), REPO / "plugins/astra-sumo/src/astra_sumo/core/simulation_stall.py",
        REPO / "plugins/astra-sumo/src/astra_sumo/core/lane_section_hold.py"]
    save(ROOT / "plan.json", {"schema": "astra.hamburg.119-saturated-service-plan/v1", "formal_result": False,
        "source_hashes": {str(path): digest(path) for path in paths},
        "prepared_hashes": {str(path): digest(path) for path in PREPARED.iterdir()}, "vehicles": provenance,
        "end_s": END, "step_s": 0.1, "seed": 104, "zero_major_603_flow": True,
        "measurement": "E1 at95.03m reports rear clearance. Approach length95.13m. Record front entry into internal separately; they can fall in different green windows.",
        "supply": "Each lane requests30 vehicles at0..29s, ordinary departLane0/1 and source departPos5.1. Insertion delays remain native. No runtime speed/position/phase setters are added.",
        "declared_first_target_green_s": [0, 14], "first_full_waiting_queue_green_s": [90, 104],
        "green_claim": "Observe actual states. The first green has entry travel lag. A requested population or queue at green start does not establish continuous saturation.",
        "background_only": [str(SOURCE / "expected-counts.csv"), str(SOURCE / "initialization-counts.csv")],
        "claim_boundary": "Service diagnostic with no603 major inflow, not field capacity, calibrated demand, or a fit to the real130/52 counts. Other downstream restrictions remain."})


def check():
    plan = json.loads((ROOT / "plan.json").read_bytes())
    assert all(digest(path) == value for path, value in plan["source_hashes"].items())
    assert all(digest(path) == value for path, value in plan["prepared_hashes"].items())
    vehicles = ET.parse(PREPARED / "demand.rou.xml").getroot().findall("vehicle")
    original = {v.get("id"): v for v in ET.parse(SOURCE / "demand.rou.xml").getroot().findall("vehicle")}
    assert len(vehicles) == len({v.get("id") for v in vehicles}) == 60
    assert Counter(v.find("stop").get("lane") for v in vehicles) == Counter(dict.fromkeys(APPROACH, 30))
    net = ET.parse(SOURCE / "network.net.xml").getroot()
    connections = net.findall("connection")
    for vehicle, row in zip(vehicles, plan["vehicles"]):
        template = original[row["template_vehicle_id"]]
        assert {k: v for k, v in vehicle.attrib.items() if k not in {"id", "depart", "departLane"}} == {k: v for k, v in template.attrib.items() if k not in {"id", "depart", "departLane"}}
        assert [ET.tostring(stop) for stop in vehicle.findall("stop")] == [ET.tostring(stop) for stop in template.findall("stop")]
        edges = vehicle.find("route").get("edges").split()
        assert edges[0] == "24483344#1" and edges[-1] == "199500676" and "603103445#2" not in edges
        assert len(edges) == len(set(edges))
        assert all(any(c.get("from") == a and c.get("to") == b for c in connections) for a, b in zip(edges, edges[1:]))
    request = json.loads((PREPARED / "native-request.json").read_bytes())
    assert request["backend"] == "libsumo" and request["end_s"] == END
    assert request["junction_body_hold_nodes"] == ["14398547", "205069138", "18653534", "LSA104_part0"]
    assert request["command"][request["command"].index("--step-length") + 1] == "0.1"
    assert len(ET.parse(PREPARED / "e1.add.xml").getroot().findall("inductionLoop")) == 13
    programs = {p.get("id"): p for p in ET.parse(SOURCE / "control.add.xml").getroot().findall("tlLogic")}
    assert all(programs[tls].get("offset") == "15" and programs[tls].get("type") == "static" for tls in TLS)
    return {"status": "pass", "native_runs": 0, "vehicles": 60, "source_hashes_match": True, "scope_assertions_pass": True}


def run():
    check()
    runtime, libsumo = check_runtime()
    from astra_sumo.core.simulation_stall import monitor_sumo

    NATIVE.mkdir(exist_ok=False)
    shutil.copyfile(__file__, NATIVE / "executed-runner.py")
    save(NATIVE / "runtime.json", runtime)
    request = json.loads((PREPARED / "native-request.json").read_bytes())
    samples = gzip.open(NATIVE / "samples.jsonl.gz", "wt", encoding="utf-8")
    front_entries, previous, modes = [], {}, set()
    observed_lanes = APPROACH + INTERNAL + ("79014037#1_0", "79014037#1_1") + tuple(f"186713429_{i}" for i in range(4))
    original_step = libsumo.simulationStep

    def observed_step(*args, **kwargs):
        value = original_step(*args, **kwargs)
        api_time = libsumo.simulation.getTime()
        current, lanes = {}, {}
        for identity in libsumo.vehicle.getIDList():
            lane = libsumo.vehicle.getLaneID(identity)
            current[identity] = lane
            modes.add(libsumo.vehicle.getSpeedMode(identity))
            if previous.get(identity) in APPROACH and lane in INTERNAL:
                front_entries.append({"vehicle_id": identity, "from_lane": previous[identity], "to_lane": lane,
                    "api_time_s": api_time, "native_step_time_s": round(api_time - 0.1, 10)})
        for lane in observed_lanes:
            members = [{"id": identity, "pos_m": libsumo.vehicle.getLanePosition(identity),
                "speed_m_s": libsumo.vehicle.getSpeed(identity)} for identity in libsumo.lane.getLastStepVehicleIDs(lane)]
            members.sort(key=lambda r: r["pos_m"], reverse=True)
            lanes[lane] = {"vehicles": members, "stopped": sum(r["speed_m_s"] < 0.1 for r in members)}
        row = {"api_time_s": api_time, "native_step_time_s": round(api_time - 0.1, 10), "lanes": lanes,
            "tls": {tls: {"state": libsumo.trafficlight.getRedYellowGreenState(tls),
                "phase": libsumo.trafficlight.getPhase(tls), "program": libsumo.trafficlight.getProgram(tls)} for tls in TLS}}
        samples.write(json.dumps(row, separators=(",", ":")) + "\n")
        previous.clear()
        previous.update(current)
        return value

    libsumo.simulationStep = observed_step
    started = time.perf_counter()
    try:
        monitor_sumo(request)
    finally:
        libsumo.simulationStep = original_step
        samples.close()
        save(NATIVE / "front-entries.json", front_entries)
    summarize(modes, time.perf_counter() - started)


def check_runtime():
    environment = REPO / ".venv"
    assert Path(sys.executable).resolve() == (environment / "Scripts/python.exe").resolve()
    sys.path.insert(0, str(environment / "Lib/site-packages"))
    sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
    os.environ["SUMO_HOME"] = str(environment / "Lib/site-packages/sumo")
    import libsumo
    from libsumo import _libsumo
    import sumolib
    import traci

    modules = (traci, sumolib, libsumo)
    assert all(Path(module.__file__).resolve().is_relative_to(environment.resolve()) for module in modules)
    assert all(module.__version__ == "1.27.1" for module in modules)
    assert Path(_libsumo.__file__).resolve().is_relative_to(environment.resolve())
    return {"python": sys.executable, "sumo_home": os.environ["SUMO_HOME"],
        "modules": {module.__name__: {"path": module.__file__, "version": module.__version__,
            "sha256": digest(module.__file__)} for module in modules},
        "native_library": {"path": _libsumo.__file__, "sha256": digest(_libsumo.__file__)}}, libsumo


def summarize(modes, elapsed):
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

    periodic = ET.parse(NATIVE / "field-counts.xml").getroot().findall("interval")
    mapping = {i.get("id"): p.get("id") for i, p in zip(ET.parse(PREPARED / "instant.add.xml").getroot(), ET.parse(PREPARED / "e1.add.xml").getroot())}
    passages = read_contributing_e1_passages(instant_file=NATIVE / "instant-e1.xml", detector_ids=mapping,
        periodic_file=NATIVE / "field-counts.xml", step_length=0.1)
    save(NATIVE / "contributing-passages.json", passages)
    greens = green_service(passages["passages"])
    summary = ET.parse(NATIVE / "summary.xml").getroot().findall("step")[-1].attrib
    collisions = ET.parse(NATIVE / "collisions.xml").getroot().findall("collision")
    monitor = json.loads((NATIVE / "stall-monitor.json").read_bytes())
    checks = {"all60_arrived": all(int(summary[key]) == 60 for key in ["loaded", "inserted", "arrived", "ended"]),
        "zero_unsafe": not collisions and all(int(summary[key]) == 0 for key in ["collisions", "teleports", "discarded"]),
        "monitor_completed": monitor["status"] == "completed", "speed_mode31": modes == {31},
        "periodic60_total_contributions": sum(int(row.get("nVehContrib")) for row in periodic) == 60,
        "instant_periodic_reconciled": passages["reconciled"],
        "each_vehicle_once_only_intended_field": Counter((r["vehicle_id"], r["detector_id"]) for r in passages["passages"]) == Counter(
            (r["vehicle_id"], r["field_id"]) for r in json.loads((PREPARED / "lane-intentions.json").read_bytes())["vehicles"])}
    save(NATIVE / "result.json", {"formal_result": False, "status": "pass" if all(checks.values()) else "review_required",
        "checks": checks, "summary": summary, "elapsed_seconds": elapsed, "green_service": greens,
        "claim_boundary": "No fixture MAE is computed. Per-green service requires the separate continuously queued coverage audit. Front-entry ticks and E1 rear-clear times are different measurements."})


def green_service(passages):
    entries = json.loads((NATIVE / "front-entries.json").read_bytes())
    rows, active = [], {}
    with gzip.open(NATIVE / "samples.jsonl.gz", "rt", encoding="utf-8") as handle:
        for line in handle:
            frame = json.loads(line)
            for lane_index, lane in enumerate(APPROACH):
                color = frame["tls"][TLS[0]]["state"][12 + lane_index]
                tick = frame["native_step_time_s"]
                if color in "gG":
                    lane_data = frame["lanes"][lane]
                    row = active.setdefault(lane, {"lane": lane, "begin_s": tick, "end_s": tick,
                        "samples": 0, "samples_with_stopped_queue": 0, "samples_with_near_line_head": 0,
                        "min_lane_vehicles": 60, "start_lane_vehicles": len(lane_data["vehicles"]),
                        "start_stopped": lane_data["stopped"],
                        "start_head_pos_m": lane_data["vehicles"][0]["pos_m"] if lane_data["vehicles"] else None})
                    members = frame["lanes"][lane]["vehicles"]
                    row["end_s"] = round(tick + 0.1, 10)
                    row["samples"] += 1
                    row["samples_with_stopped_queue"] += frame["lanes"][lane]["stopped"] > 0
                    row["samples_with_near_line_head"] += bool(members) and members[0]["pos_m"] >= 80.13
                    row["min_lane_vehicles"] = min(row["min_lane_vehicles"], len(members))
                elif lane in active:
                    rows.append(active.pop(lane))
    rows.extend(active.values())
    for row in rows:
        begin, end, lane = row["begin_s"], row["end_s"], row["lane"]
        field = FIELDS[APPROACH.index(lane)]
        row["front_entries"] = sum(r["from_lane"] == lane and begin <= r["native_step_time_s"] < end for r in entries)
        row["e1_rear_contributions"] = sum(r["detector_id"] == field and begin <= r["notification_time_s"] < end for r in passages)
        row["supply_classification"] = ("late_supply_at_start" if not row["start_lane_vehicles"] else
            "approach_depleted" if row["min_lane_vehicles"] == 0 else
            "continuous_supply_supported" if row["start_stopped"] > 0 and row["start_head_pos_m"] >= 80.13 else "uncertain")
    with (NATIVE / "green-service.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["lane"])
        writer.writeheader()
        writer.writerows(rows)
    return {"rows": rows, "continuous_supply_green_count": sum(r["supply_classification"] == "continuous_supply_supported" for r in rows),
        "criterion": "Start with a stopped approach queue and head within15m of lane end; approach must stay occupied throughout green. Moving queues need not contain a halted car at every step. Review head and receiving traces before claiming saturation.",
        "time_boundary": "Native step labels equal API time minus0.1s. A detected lane transition brackets front entry within one0.1s step. E1 notification is rounded to its native notification step. These are distinct measures."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare-only", action="store_true")
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.prepare_only:
        prepare()
    if args.prepare_only or args.check_only:
        print(json.dumps(check()))
    else:
        run()
