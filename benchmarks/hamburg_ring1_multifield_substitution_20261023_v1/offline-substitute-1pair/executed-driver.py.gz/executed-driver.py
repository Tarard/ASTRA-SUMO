"""Measure a bounded explicit two-trip to one-trip substitution."""
import argparse
from collections import Counter, defaultdict
import gzip
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.lane_section_hold import read_lane_intentions
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pairs', type=int, choices=(1, 20), required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    source = root.parent / 'hamburg-classical-od-calibration-20261023-v1'
    original, base = source / 'probe-minus1/evaluation', source / 'prepared'
    plan_file = root / 'proposal/plan.json'
    witness_file = root.parent / 'hamburg-joint-od-spsa-20261023-v1/support-audit/multi-field-witnesses.json'
    plan = json.loads(plan_file.read_bytes())
    pairs = plan['pairs'][:args.pairs]
    assert len(pairs) == args.pairs
    assert Path(sys.executable).resolve() == (repo / '.venv/Scripts/python.exe').resolve()
    assert {version(name) for name in ('eclipse-sumo', 'traci', 'sumolib', 'libsumo')} == {'1.27.1'}
    witnesses = {row['id']: row for row in json.loads(witness_file.read_bytes())}
    source_files = [base / name for name in ('network.net.xml', 'control.add.xml', 'field-loops.add.xml', 'expected-counts.csv', 'initialization-counts.csv', 'scenario.json')]
    source_files += [original / name for name in ('demand.rou.xml', 'lane-intentions.json', 'od-vector.json', 'evaluation.json')]
    source_files += [plan_file, witness_file, Path(__file__).resolve()]
    hashes = {str(path): sha(path) for path in source_files}
    tree = ET.parse(original / 'demand.rou.xml')
    vehicles = {v.get('id'): v for v in tree.getroot().findall('vehicle')}
    old_xml = {key: ET.tostring(v) for key, v in vehicles.items()}
    intentions = json.loads((original / 'lane-intentions.json').read_bytes())
    assignments = {r['vehicle_id']: r['field_id'] for r in intentions['vehicles']}
    assert len(vehicles) == len(assignments) == 8640 and vehicles.keys() == assignments.keys()
    loops = {r.get('id'): r for r in ET.parse(base / 'field-loops.add.xml').getroot()}
    lanes = {r.get('id'): r for r in ET.parse(base / 'network.net.xml').getroot().iter('lane')}
    retained, removed = set(), set()
    signatures = {key: [field] for key, field in assignments.items()}
    for pair in pairs:
        keep, drop = pair['retained_vehicle_id'], pair['removed_vehicle_id']
        assert keep != drop and not {keep, drop} & (retained | removed)
        witness = witnesses[pair['witness_id']]
        fields = witness['fields']
        assert [assignments[keep], assignments[drop]] == fields == pair['expected_fields']
        route = vehicles[keep].find('route')
        old_edges, new_edges = route.get('edges').split(), witness['edges']
        approach = '186821034#0'
        assert old_edges[:old_edges.index(approach) + 1] == new_edges[:new_edges.index(approach) + 1]
        assert len(new_edges) == len(set(new_edges)) and witness['junction_audit']['allowed'] and not witness['uturn_connections']
        assert len(vehicles[keep].findall('stop')) == 1
        assert vehicles[keep].find('stop').get('lane') == loops[fields[0]].get('lane')
        route.set('edges', ' '.join(new_edges))
        lane = loops[fields[1]].get('lane')
        ET.SubElement(vehicles[keep], 'stop', lane=lane, endPos=f"{float(lanes[lane].get('length')) - 7.5:.6f}", speed='13.888889')
        tree.getroot().remove(vehicles[drop])
        signatures[keep] = fields
        del signatures[drop]
        retained.add(keep)
        removed.add(drop)
    for key, vehicle in vehicles.items():
        if key not in retained | removed:
            assert ET.tostring(vehicle) == old_xml[key]
        elif key in retained:
            restored = ET.fromstring(ET.tostring(vehicle))
            restored.remove(restored.findall('stop')[-1])
            restored.find('route').set('edges', ET.fromstring(old_xml[key]).find('route').get('edges'))
            assert ET.tostring(restored) == old_xml[key]
    assert Counter(field for fields in signatures.values() for field in fields) == Counter(assignments.values())
    intentions['vehicles'] = [r for r in intentions['vehicles'] if r['vehicle_id'] not in removed]
    out = root / f'{"offline-" if args.prepare_only else ""}substitute-{args.pairs}pair'
    out.mkdir(exist_ok=False)
    prepared, evaluation = out / 'prepared', out / 'evaluation'
    prepared.mkdir()
    evaluation.mkdir()
    for path in source_files[:6]:
        shutil.copyfile(path, prepared / path.name)
    tree.write(prepared / 'demand.rou.xml', encoding='utf-8', xml_declaration=True)
    save(prepared / 'lane-intentions.json', intentions)
    read_lane_intentions(prepared / 'lane-intentions.json', prepared / 'field-loops.add.xml', signatures)
    scenario = json.loads((prepared / 'scenario.json').read_bytes())
    scenario.update(vehicles=8640 - args.pairs, demand_sha256=sha(prepared / 'demand.rou.xml'),
        demand_prior='Explicit paired trip substitution: extend a 119 Z12 trip to a legal boundary via 535 Z4 and remove one separate 535 Z4 request. Departure times of retained vehicles are unchanged. No observed OD share is asserted.',
        lane_waypoints='Retained trips keep their original first waypoint and first-field rear-clear hold; substituted trips add a native moving waypoint on the second detector lane.')
    save(prepared / 'scenario.json', scenario)
    for name in ('demand.rou.xml', 'lane-intentions.json'):
        shutil.copyfile(prepared / name, evaluation / name)
    shutil.copyfile(__file__, out / 'executed-driver.py')
    implementation = out / 'implementation'
    implementation.mkdir()
    for name in ('detector_demand_replay.py', 'simulation_stall.py', 'lane_section_hold.py', 'hamburg_od_spsa.py', 'route_sensor_matrix.py', 'detector_demand.py', 'candidate_contracts.py', 'artifact_io.py', 'command_runner.py'):
        shutil.copyfile(repo / 'plugins/astra-sumo/src/astra_sumo/core' / name, implementation / name)
    save(out / 'preflight.json', {'pairs': pairs, 'source_hashes': hashes, 'input_hashes': {p.name: sha(p) for p in prepared.iterdir()},
        'signatures': signatures, 'source_vehicle_count': 8640, 'candidate_vehicle_count': len(signatures),
        'python': sys.executable, 'versions': {name: version(name) for name in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')},
        'allowed_changes_only': True, 'all_field_signature_totals_preserved': True, 'departure_bin_field_totals_preserved': all(p['retained_departure_bin'] == p['removed_departure_bin'] for p in pairs),
        'selection_gate': 'Both MAE and SSE lower than selected reference; waiting<=7 and waiting+running<=21; no unsafe/repeated/unplanned contributions; all substituted trips complete both fields. Otherwise retain source.',
        'formal_result': False})
    if args.prepare_only:
        print(json.dumps({'preflight': 'pass', 'pairs': args.pairs, 'vehicles': len(signatures)}), flush=True)
        return
    started = time.perf_counter()
    native = run_point_detector_demand(net_file=prepared / 'network.net.xml', route_file=prepared / 'demand.rou.xml',
        e1_additional_file=prepared / 'field-loops.add.xml', expected_counts_csv=prepared / 'expected-counts.csv',
        output_dir=evaluation / 'native', end_s=14400, timeout_seconds=4800, seed=104, backend='libsumo',
        sumo_binary=str(repo / '.venv/Lib/site-packages/sumo/bin/sumo.exe'), signal_program_file=prepared / 'control.add.xml',
        lane_intentions_file=prepared / 'lane-intentions.json', junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared))
    measured = summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
    all182 = audit_expected_to_e1_strict(read_csv_rows(prepared / 'initialization-counts.csv') + read_csv_rows(prepared / 'expected-counts.csv'), evaluation / 'native/field-counts.xml')
    assert len(all182) == 182 and all(r['measured_nVehContrib'] is not None for r in all182)
    write_csv(evaluation / 'all182-comparison.csv', all182, list(all182[0]))
    baseline182 = audit_expected_to_e1_strict(read_csv_rows(prepared / 'initialization-counts.csv') + read_csv_rows(prepared / 'expected-counts.csv'), original / 'native/field-counts.xml')
    first_change = min(float(vehicles[key].get('depart')) for key in retained | removed)
    prefix = [(a, b) for a, b in zip(all182, baseline182, strict=True) if float(a['end']) <= first_change]
    assert prefix and all(a == b for a, b in prefix)
    passages = read_contributing_e1_passages(instant_file=evaluation / 'native/instant-e1.xml', periodic_file=evaluation / 'native/field-counts.xml', detector_ids=native['instant_to_periodic_ids'], step_length=.1)
    assert passages['reconciled']
    (evaluation / 'contributing-passages.json.gz').write_bytes(gzip.compress(json.dumps(passages).encode('utf-8'), mtime=0))
    actual = defaultdict(list)
    for row in sorted(passages['passages'], key=lambda r: r['time_s']):
        actual[row['vehicle_id']].append(row['detector_id'])
    unexpected = [r for r in passages['passages'] if r['detector_id'] not in signatures[r['vehicle_id']]]
    repeated = [key for key, n in Counter((r['vehicle_id'], r['detector_id']) for r in passages['passages']).items() if n > 1]
    retained_actual = {key: actual[key] for key in sorted(retained)}
    dual_complete = all(actual[key] == signatures[key] for key in retained)
    baseline = json.loads((original / 'evaluation.json').read_bytes())
    completion = measured['completion']
    accepted = (not any(completion[k] for k in ('collisions', 'teleports', 'discarded')) and not unexpected and not repeated and dual_complete
        and measured['MAE'] < baseline['MAE'] and measured['loss'] < baseline['loss'] and completion['waiting'] <= 7 and completion['waiting'] + completion['running'] <= 21)
    assert all(sha(Path(path)) == digest for path, digest in hashes.items())
    verdict = {'status': 'diagnostic_candidate' if accepted else 'rejected', 'formal_result': False, 'before': baseline, 'after': measured,
        'all182_TAE': sum(abs(r['diff_nVehContrib_minus_expected']) for r in all182), 'substituted_actual_signatures': retained_actual,
        'dual_contributions_complete': dual_complete, 'unexpected_contributions': unexpected, 'repeated_vehicle_fields': repeated,
        'source_inputs_unchanged': True, 'unchanged_prefix_rows': len(prefix), 'elapsed_s': time.perf_counter() - started}
    save(out / 'verdict.json', verdict)
    print(json.dumps(verdict), flush=True)


if __name__ == '__main__':
    main()
