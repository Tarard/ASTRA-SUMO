"""Summarize sealed native cohort responses and terminal origin/field inventory."""

from collections import Counter, defaultdict
import csv
import gzip
import json
from statistics import median
import xml.etree.ElementTree as ET

from audit_scope import OUT, SOURCE, STUDY, digest


def read_csv(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                         for k, v in row.items()} for row in rows)


def backlog(evaluation, signatures):
    vehicles = {v.get("id"): v for v in ET.parse(evaluation / "demand.rou.xml").getroot().findall("vehicle")}
    trips = {t.get("id"): t.attrib for t in ET.parse(evaluation / "native/tripinfo.xml").getroot().findall("tripinfo")}
    compact_file = evaluation / "contributing-passages.json.gz"
    if evaluation == SOURCE:
        compact_file = SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz"
    with gzip.open(compact_file, "rt", encoding="utf-8") as handle:
        compact = json.load(handle)
    events = defaultdict(list)
    for e in compact["passages"]:
        events[e["vehicle_id"]].append(e["detector_id"])
    rows, groups = [], Counter()
    for identity, vehicle in vehicles.items():
        if identity not in trips:
            state = "not_inserted"
        elif float(trips[identity]["arrival"]) < 0:
            state = "running"
        else:
            continue
        path = vehicle.find("route").get("edges").split()
        row = {"vehicle_id": identity, "state": state, "requested_origin": path[0], "requested_destination": path[-1],
               "departure_bin": int(float(vehicle.get("depart")) // 900), "intended_fields": signatures[identity],
               "actual_complete_fields": events[identity], "has_any_complete_event": bool(events[identity])}
        rows.append(row)
        groups[state, path[0], tuple(signatures[identity]), bool(events[identity])] += 1
    completion = json.loads((evaluation / "evaluation.json").read_bytes())["completion"]
    assert sum(r["state"] == "not_inserted" for r in rows) == completion["waiting"]
    assert sum(r["state"] == "running" for r in rows) == completion["running"]
    return rows, [{"state": k[0], "requested_origin": k[1], "intended_fields": list(k[2]),
                   "has_any_complete_event": k[3], "vehicles": n} for k, n in sorted(groups.items())]


def main():
    output = OUT / "complete"
    scan = json.loads((output / "scan.json").read_bytes())
    assert len(scan["complete_cases"]) == 2 and not scan["skipped_without_verdict"]
    source_signatures = {r["vehicle_id"]: [r["field_id"]] for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    source_rows, source_groups = backlog(SOURCE, source_signatures)
    table(output / "reference-terminal-vehicles.csv", source_rows)
    all_summary = {"reference_terminal_groups": source_groups, "cases": []}
    pair_timing_rows, region_rows = [], []
    for count in [1, 20]:
        case = STUDY / f"substitute-{count}pair"
        target = output / case.name
        signatures = json.loads((case / "preflight.json").read_bytes())["signatures"]
        rows, groups = backlog(case / "evaluation", signatures)
        table(target / "terminal-vehicles.csv", rows)
        dual = read_csv(target / "modified-trips.csv")
        for row in dual:
            old119 = json.loads(row["source_retained_events"])[0]
            old535 = json.loads(row["source_removed_events"])[0]
            new119, new535 = json.loads(row["candidate_retained_events"])
            pair_timing_rows.append({"case": case.name, "retained_vehicle_id": row["retained_vehicle_id"], "removed_vehicle_id": row["removed_vehicle_id"],
                "source119_s": old119["notification_s"], "candidate119_s": new119["notification_s"],
                "shift119_s": new119["notification_s"] - old119["notification_s"],
                "source535_removed_s": old535["notification_s"], "source535_exit_proxy_s": row["original_exit535_proxy_s"],
                "candidate535_s": new535["notification_s"], "shift535_vs_removed_s": new535["notification_s"] - old535["notification_s"],
                "source119_bin": old119["begin"], "candidate119_bin": new119["begin"],
                "source535_bin": old535["begin"], "candidate535_bin": new535["begin"]})
        cohort = read_csv(target / "cohort-delta208.csv")
        for region in ["initialization", "main", "tail"]:
            selected = [r for r in cohort if r["region"] == region]
            region_rows.append({"case": case.name, "region": region,
                **{name: sum(int(r[name]) for r in selected) for name in ["baseline_count", "candidate_count", "delta", "retained_delta", "removed_delta", "unchanged_delta"]}})
        field_region = []
        for field in sorted({r["field"] for r in cohort}):
            for region in ["main", "tail"]:
                selected = [r for r in cohort if r["field"] == field and r["region"] == region]
                field_region.append({"field": field, "region": region,
                    **{name: sum(int(r[name]) for r in selected) for name in ["baseline_count", "candidate_count", "delta", "retained_delta", "removed_delta", "unchanged_delta"]}})
        table(target / "field13-region-contributions.csv", field_region)
        fields = read_csv(target / "field13-main.csv")
        source_fields = {"hh_0119_Z_12_31546", "hh_0535_Z_4_33055"}
        terminal535 = {f"hh_0535_Z_{z}_{suffix}" for z, suffix in [(5, 30894), (6, 33855), (7, 29316), (8, 34287)]}
        ranked = sorted([{k: v if k == "field" else int(v) for k, v in r.items()} for r in fields], key=lambda r: r["SSE_change"], reverse=True)
        timings = [r for r in pair_timing_rows if r["case"] == case.name]
        unchanged_rows = read_csv(target / "unchanged-trip-responses.csv")
        gained = sum(int(r["candidate_complete_events"]) > int(r["source_complete_events"]) for r in unchanged_rows)
        lost = sum(int(r["candidate_complete_events"]) < int(r["source_complete_events"]) for r in unchanged_rows)
        shifted = sum(int(r["candidate_complete_events"]) == int(r["source_complete_events"]) == 1
                      and r["field_bin_signature_changed"] == "True" for r in unchanged_rows)
        summary = {"case": case.name, "terminal_groups": groups,
            "terminal_total": len(rows), "terminal_minus142": sum(r["requested_origin"] == "-142944318" for r in rows),
            "terminal_963_Z5": sum(r["requested_origin"] == "963776077#0" and r["intended_fields"] == ["hh_0119_Z_5_30494"] for r in rows),
            "terminal_963_Z5_without_complete_event": sum(r["requested_origin"] == "963776077#0" and not r["has_any_complete_event"] for r in rows),
            "paired_field_SSE_change": sum(int(r["SSE_change"]) for r in fields if r["field"] in source_fields),
            "other_field_SSE_change": sum(int(r["SSE_change"]) for r in fields if r["field"] not in source_fields),
            "terminal535_Z5to8_SSE_change": sum(int(r["SSE_change"]) for r in fields if r["field"] in terminal535),
            "field_SSE_ranked": ranked,
            "new535_vs_removed_shift_min_median_max_s": [min(r["shift535_vs_removed_s"] for r in timings), median(r["shift535_vs_removed_s"] for r in timings), max(r["shift535_vs_removed_s"] for r in timings)],
            "new119_shift_min_median_max_s": [min(r["shift119_s"] for r in timings), median(r["shift119_s"] for r in timings), max(r["shift119_s"] for r in timings)],
            "unchanged_vehicles_gain_complete_event": gained, "unchanged_vehicles_lose_complete_event": lost,
            "unchanged_vehicles_both_complete_but_shift_bin": shifted,
            "claim_boundary": "Terminal grouping is by requested origin and intended field, not observed final queue location. No final lane is inferred from departed/arrival lanes or the arrived-only vehroute file. Field/cohort changes describe this coupled full-run response, not causal isolation or real OD identification."}
        all_summary["cases"].append(summary)
    table(output / "pair-timing-response.csv", pair_timing_rows)
    table(output / "cohort-region-summary.csv", region_rows)
    save(output / "response-mechanism-summary.json", all_summary)
    for directory in [output, OUT]:
        save(directory / "manifest.json", {"files": [{"path": p.relative_to(directory).as_posix(), "size_bytes": p.stat().st_size, "sha256": digest(p)}
            for p in sorted(directory.rglob("*")) if p.is_file() and p != directory / "manifest.json" and "__pycache__" not in p.parts], "native_runs": 0})
    print(json.dumps([{k: v for k, v in row.items() if k not in ["terminal_groups", "field_SSE_ranked", "claim_boundary"]} for row in all_summary["cases"]], indent=2))


if __name__ == "__main__":
    main()
