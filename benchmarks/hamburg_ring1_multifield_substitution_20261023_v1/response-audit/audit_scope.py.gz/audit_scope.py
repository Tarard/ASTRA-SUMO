"""Independently inspect immutable explicit inputs, without reading active native output."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
ROOT = STUDY.parents[1]
SOURCE = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation"
BASE = SOURCE.parents[1] / "prepared"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def inspect_scope(count):
    case = STUDY / f"substitute-{count}pair"
    prepared = case / "prepared"
    preflight = json.loads((case / "preflight.json").read_bytes())
    source_tree = ET.parse(SOURCE / "demand.rou.xml").getroot()
    candidate_tree = ET.parse(prepared / "demand.rou.xml").getroot()
    old = {v.get("id"): v for v in source_tree.findall("vehicle")}
    new = {v.get("id"): v for v in candidate_tree.findall("vehicle")}
    original_fields = {r["vehicle_id"]: r["field_id"] for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    intentions = json.loads((prepared / "lane-intentions.json").read_bytes())
    candidate_fields = {r["vehicle_id"]: r["field_id"] for r in intentions["vehicles"]}
    plan = json.loads((STUDY / "proposal/plan.json").read_bytes())
    witnesses = {w["id"]: w for w in json.loads(Path(plan["source"]["witness_file"]).read_bytes())}
    pairs = plan["pairs"][:count]
    retained = {p["retained_vehicle_id"] for p in pairs}
    removed = {p["removed_vehicle_id"] for p in pairs}
    assert len(retained) == len(removed) == count and not retained & removed
    assert old.keys() == original_fields.keys() and len(old) == 8640
    assert new.keys() == old.keys() - removed == candidate_fields.keys() and len(new) == 8640 - count
    assert [ET.tostring(e) for e in source_tree if e.tag != "vehicle"] == [ET.tostring(e) for e in candidate_tree if e.tag != "vehicle"]
    assert [v.get("id") for v in candidate_tree.findall("vehicle")] == [v.get("id") for v in source_tree.findall("vehicle") if v.get("id") not in removed]
    assert {k: v for k, v in intentions.items() if k != "vehicles"} == {
        k: v for k, v in json.loads((SOURCE / "lane-intentions.json").read_bytes()).items() if k != "vehicles"}
    assert intentions["vehicles"] == [r for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"] if r["vehicle_id"] not in removed]
    signatures = {identity: [field] for identity, field in candidate_fields.items()}
    pair_checks = []
    for pair in pairs:
        keep, drop = pair["retained_vehicle_id"], pair["removed_vehicle_id"]
        actual_keep_h, actual_drop_h = [int(float(old[v].get("depart")) // 900) for v in (keep, drop)]
        assert actual_keep_h == pair["retained_departure_bin"] == actual_drop_h == pair["removed_departure_bin"]
        assert old[keep].attrib == new[keep].attrib
        witness = witnesses[pair["witness_id"]]
        assert new[keep].find("route").get("edges").split() == witness["edges"] == pair["replacement_route_edges"]
        old_route = old[keep].find("route").get("edges").split()
        prefix = pair["common_prefix_edge_count"]
        assert old_route[:prefix] == witness["edges"][:prefix] and old_route[prefix] != witness["edges"][prefix]
        assert old_route[prefix - 1] == "186821034#0"
        assert len(old[keep].findall("stop")) == 1 and len(new[keep].findall("stop")) == 2
        restored = ET.fromstring(ET.tostring(new[keep]))
        extra = restored.findall("stop")[-1]
        assert extra.attrib == {"lane": "186821034#0_5", "endPos": "15.120000", "speed": "13.888889"}
        restored.remove(extra)
        restored.find("route").set("edges", old[keep].find("route").get("edges"))
        assert ET.tostring(restored) == ET.tostring(old[keep])
        assert [original_fields[keep], original_fields[drop]] == pair["expected_fields"] == witness["fields"]
        signatures[keep] = pair["expected_fields"]
        pair_checks.append({"retained_vehicle_id": keep, "removed_vehicle_id": drop,
            "actual_retained_departure_bin": actual_keep_h, "actual_removed_departure_bin": actual_drop_h,
            "attributes_identical": True, "old_prefix_preserved": True, "new_tail_exact_witness": True,
            "only_route_and_second_stop_changed": True})
    unchanged = new.keys() - retained
    assert all(ET.tostring(new[v]) == ET.tostring(old[v]) for v in unchanged)
    before = Counter((int(float(old[v].get("depart")) // 900), f) for v, f in original_fields.items())
    after = Counter((int(float(new[v].get("depart")) // 900), f) for v, fields in signatures.items() for f in fields)
    assert before == after and sum(after.values()) == 8640
    assert signatures == preflight["signatures"]
    fixed = ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]
    assert all((prepared / name).read_bytes() == (BASE / name).read_bytes() for name in fixed)
    assert all(digest(prepared / name) == value for name, value in preflight["input_hashes"].items())
    assert all(digest(Path(path)) == value for path, value in preflight["source_hashes"].items())
    assert (case / "executed-driver.py").read_bytes() == (STUDY / "measure.py").read_bytes()
    scenario, old_scenario = [json.loads(p.read_bytes()) for p in (prepared / "scenario.json", BASE / "scenario.json")]
    metadata_changes = {k: {"before": old_scenario.get(k), "after": scenario.get(k)} for k in set(scenario) | set(old_scenario) if scenario.get(k) != old_scenario.get(k)}
    assert set(metadata_changes) <= {"vehicles", "demand_sha256", "demand_prior", "lane_waypoints"}
    assert scenario["vehicles"] == len(new)
    first_change = min(float(old[v].get("depart")) for v in retained | removed)
    return {"status": "pass", "case": case.name, "pairs": count, "source_N": len(old), "candidate_N": len(new),
        "actual14bin_signature_inventory_equal": True, "planned_event_intentions": sum(after.values()),
        "unchanged_vehicle_XML_count": len(unchanged), "all_surviving_vehicle_attributes_identical": True,
        "nonvehicle_children_and_order_preserved": True, "only_expected_first_field_hold_mapping_preserved": True,
        "second_field_driver_treatment": "Native moving stop only; lane-intention/rear-clear hold remains assigned to the original first field.",
        "pair_checks": pair_checks, "scenario_metadata_changes": metadata_changes, "first_changed_requested_departure_s": first_change,
        "inventory": [{"departure_bin": h, "field": f, "before": n, "after": after[h, f]} for (h, f), n in sorted(before.items())],
        "source_hashes": preflight["source_hashes"], "candidate_input_hashes": preflight["input_hashes"],
        "claim_boundary": "Explicit input scope and intended field inventory only; no reading or validation of active native outputs or predicted counts."}


if __name__ == "__main__":
    reports = [inspect_scope(count) for count in (1, 20)]
    (OUT / "input-scope-review.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps([{k: row[k] for k in ["status", "case", "candidate_N", "unchanged_vehicle_XML_count", "actual14bin_signature_inventory_equal", "first_changed_requested_departure_s"]} for row in reports], indent=2))
