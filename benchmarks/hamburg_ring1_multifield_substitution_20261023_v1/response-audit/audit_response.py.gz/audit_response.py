"""Audit sealed substitution responses once; never launch or poll a native run."""

import argparse
from collections import Counter, defaultdict
import csv
import gzip
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from audit_scope import BASE, OUT, SOURCE, STUDY, digest, inspect_scope
from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows
from astra_sumo.core.hamburg_readme_results import STATIONS


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                         for k, v in row.items()} for row in rows)


def key(row):
    return row["detector_id"], float(row["begin"]), float(row["end"])


def metrics(rows):
    errors = [int(r["diff_nVehContrib_minus_expected"]) for r in rows]
    return {"rows": len(rows), "SSE": sum(v * v for v in errors), "TAE": sum(map(abs, errors)),
            "MAE": sum(map(abs, errors)) / len(rows), "max_abs_error": max(map(abs, errors))}


def evidence(prepared, evaluation, compact_file, expected_n):
    native = evaluation / "native"
    paths = [evaluation / "evaluation.json", evaluation / "station-comparison.csv", compact_file]
    paths += [native / name for name in ["field-counts.xml", "instant-e1.xml", "run.json", "native-request.json",
                                       "summary.xml", "tripinfo.xml", "collisions.xml", "stall-monitor.json"]]
    before = {str(p): digest(p) for p in paths}
    recorded = json.loads((evaluation / "evaluation.json").read_bytes())
    run = json.loads((native / "run.json").read_bytes())
    request = json.loads((native / "native-request.json").read_bytes())
    periodic = {}
    for row in ET.parse(native / "field-counts.xml").getroot().findall("interval"):
        identity = row.get("id"), float(row.get("begin")), float(row.get("end"))
        assert identity not in periodic
        periodic[identity] = dict(row.attrib)
    assert len(periodic) == 208
    main = audit_expected_to_e1_strict(read_csv_rows(prepared / "expected-counts.csv"), native / "field-counts.xml")
    initial = audit_expected_to_e1_strict(read_csv_rows(prepared / "initialization-counts.csv"), native / "field-counts.xml")
    assert len(main) == 130 and len(initial) == 52
    main_metrics, initial_metrics, all_metrics = [metrics(rows) for rows in [main, initial, initial + main]]
    metadata = {key(row): row for row in read_csv_rows(prepared / "expected-counts.csv")}
    groups = defaultdict(list)
    for row in main:
        meta = metadata[key(row)]
        for station, (node, assets) in STATIONS.items():
            if meta["node_id"] == node and meta["asset_id"] in assets:
                groups[station, float(row["begin"]), float(row["end"])].append(row)
    stations = [{"station_stream_id": s, "begin": begin, "end": end,
        "expected_total": sum(int(r["expected_total"]) for r in rows),
        "measured_nVehContrib": sum(int(r["measured_nVehContrib"]) for r in rows),
        "residual": sum(int(r["diff_nVehContrib_minus_expected"]) for r in rows), "independent_evidence": False}
        for (s, begin, end), rows in sorted(groups.items())]
    assert len(stations) == 40
    stored = {(r["station_stream_id"], float(r["begin"]), float(r["end"])): r
              for r in read_csv_rows(evaluation / "station-comparison.csv")}
    for row in stations:
        assert all(int(stored[row["station_stream_id"], row["begin"], row["end"]][name]) == row[name]
                   for name in ["expected_total", "measured_nVehContrib", "residual"])
    assert main_metrics["SSE"] == recorded["loss"] and main_metrics["MAE"] == recorded["MAE"]
    assert main_metrics["max_abs_error"] == recorded["max_abs_error"]
    station_mae = sum(abs(r["residual"]) for r in stations) / 40
    assert station_mae == recorded["station_MAE"]
    final, steps = None, 0
    for _, element in ET.iterparse(native / "summary.xml"):
        if element.tag == "step":
            final, steps = dict(element.attrib), steps + 1
        element.clear()
    completion = {name: int(final.get(name, 0)) for name in ["loaded", "inserted", "arrived", "running", "waiting", "teleports", "collisions", "discarded"]}
    assert steps == 144000 and run["end_s"] == 14400 and run["step_length_s"] == .1
    assert completion == recorded["completion"] == run["completion"] and completion["loaded"] == expected_n
    tripinfo = {r.get("id"): dict(r.attrib) for r in ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")}
    healthy = (all(completion[k] == expected_n for k in ["loaded", "inserted", "arrived"])
        and not any(completion[k] for k in ["running", "waiting", "teleports", "collisions", "discarded"])
        and len(tripinfo) == expected_n and all(not r.get("vaporized", "") for r in tripinfo.values()))
    assert healthy == recorded["healthy"] == run["healthy"]
    collisions = [r.attrib for r in ET.parse(native / "collisions.xml").getroot().findall("collision")]
    safe = not collisions and not any(completion[k] for k in ["collisions", "teleports", "discarded"])
    command = request["command"]
    assert int(command[command.index("--seed") + 1]) == run["seed"] == 104
    assert float(command[command.index("--step-length") + 1]) == .1 and float(command[command.index("--end") + 1]) == 14400
    assert request["backend"] == run["backend"] == "libsumo"
    assert request["junction_body_hold_nodes"] == run["junction_body_hold_nodes"] == ["14398547", "205069138", "18653534", "LSA104_part0"]
    for prepared_name, native_name in [("network.net.xml", "network.net.xml"), ("control.add.xml", "signal-programs.add.xml"),
            ("field-loops.add.xml", "source-e1.add.xml"), ("expected-counts.csv", "expected-counts.csv"),
            ("demand.rou.xml", "demand.rou.xml"), ("lane-intentions.json", "lane-intentions.json")]:
        source = evaluation / prepared_name if prepared_name in {"demand.rou.xml", "lane-intentions.json"} else prepared / prepared_name
        assert digest(source) == digest(native / native_name)
    with gzip.open(compact_file, "rt", encoding="utf-8") as handle:
        compact = json.load(handle)
    assert compact["reconciled"] and compact["measurement_attribute"] == "nVehContrib" and not compact["outside_periodic_intervals"]
    for source in compact["inputs"]:
        assert digest(Path(source["path"])) == source["sha256"]
    by_vehicle = defaultdict(list)
    event_counts = Counter()
    for event in compact["passages"]:
        by_vehicle[event["vehicle_id"]].append(event)
        event_counts[event["detector_id"], event["interval_begin_s"], event["interval_end_s"]] += 1
    assert all(event_counts[k] == int(row["nVehContrib"]) for k, row in periodic.items())
    assert event_counts.keys() <= periodic.keys()
    for events in by_vehicle.values():
        events.sort(key=lambda e: e["notification_time_s"])
    assert before == {str(p): digest(p) for p in paths}
    return {"main": main, "initial": initial, "stations": stations, "periodic": periodic, "by_vehicle": by_vehicle,
        "metrics130": main_metrics, "metrics52": initial_metrics, "metrics182": all_metrics,
        "station40_MAE": station_mae, "completion": completion, "safe": safe, "healthy": healthy,
        "source_hashes": before, "recorded": recorded, "event_count": len(compact["passages"]), "tripinfo": tripinfo}


def counts(by_vehicle, ids):
    return Counter((e["detector_id"], e["interval_begin_s"], e["interval_end_s"])
                   for identity in ids for e in by_vehicle.get(identity, []))


def event_view(events):
    return [{"field": e["detector_id"], "begin": e["interval_begin_s"], "end": e["interval_end_s"],
             "notification_s": e["notification_time_s"]} for e in events]


def compare_case(count, baseline, output):
    scope = inspect_scope(count)
    case, prepared = STUDY / f"substitute-{count}pair", STUDY / f"substitute-{count}pair/prepared"
    evaluation = case / "evaluation"
    verdict = json.loads((case / "verdict.json").read_bytes())
    assert digest(case / "executed-driver.py") == scope["source_hashes"][str(STUDY / "measure.py")]
    after = evidence(prepared, evaluation, evaluation / "contributing-passages.json.gz", 8640 - count)
    plan = json.loads((STUDY / "proposal/plan.json").read_bytes())["pairs"][:count]
    signatures = json.loads((case / "preflight.json").read_bytes())["signatures"]
    retained, removed = {p["retained_vehicle_id"] for p in plan}, {p["removed_vehicle_id"] for p in plan}
    source_ids = {r.get("id") for r in ET.parse(SOURCE / "demand.rou.xml").getroot().findall("vehicle")}
    unchanged = source_ids - retained - removed
    assert set(after["by_vehicle"]) <= set(signatures) and not removed & after["by_vehicle"].keys()
    before_kept, before_removed, before_unchanged = [counts(baseline["by_vehicle"], ids) for ids in [retained, removed, unchanged]]
    after_kept, after_unchanged = [counts(after["by_vehicle"], ids) for ids in [retained, unchanged]]
    assert baseline["periodic"].keys() == after["periodic"].keys()
    main_keys = {key(r) for r in after["main"]}
    initial_keys = {key(r) for r in after["initial"]}
    decomp = []
    for k in sorted(after["periodic"], key=lambda k: (k[1], k[0])):
        a, b = int(after["periodic"][k]["nVehContrib"]), int(baseline["periodic"][k]["nVehContrib"])
        modified_delta, removed_delta, unchanged_delta = after_kept[k] - before_kept[k], -before_removed[k], after_unchanged[k] - before_unchanged[k]
        assert a - b == modified_delta + removed_delta + unchanged_delta
        decomp.append({"field": k[0], "begin": k[1], "end": k[2], "region": "main" if k in main_keys else "initialization" if k in initial_keys else "tail",
            "baseline_count": b, "candidate_count": a, "delta": a - b,
            "retained_baseline": before_kept[k], "retained_candidate": after_kept[k], "retained_delta": modified_delta,
            "removed_baseline": before_removed[k], "removed_delta": removed_delta,
            "unchanged_baseline": before_unchanged[k], "unchanged_candidate": after_unchanged[k], "unchanged_delta": unchanged_delta})
    unexpected = [{"vehicle_id": identity, **event_view([e])[0]} for identity, events in after["by_vehicle"].items()
                  for e in events if e["detector_id"] not in signatures[identity]]
    repeats = [{"vehicle_id": identity, "field": field, "count": n} for identity, events in after["by_vehicle"].items()
               for field, n in Counter(e["detector_id"] for e in events).items() if n > 1]
    dual = []
    for p in plan:
        identity = p["retained_vehicle_id"]
        events = after["by_vehicle"].get(identity, [])
        dual.append({"retained_vehicle_id": identity, "removed_vehicle_id": p["removed_vehicle_id"],
            "expected_fields": p["expected_fields"], "actual_fields": [e["detector_id"] for e in events],
            "complete_exact_two_in_order": [e["detector_id"] for e in events] == p["expected_fields"],
            "source_retained_events": event_view(baseline["by_vehicle"].get(identity, [])),
            "source_removed_events": event_view(baseline["by_vehicle"].get(p["removed_vehicle_id"], [])),
            "candidate_retained_events": event_view(events), "original_exit535_proxy_s": p["original_exit535_s"],
            "candidate_terminal_state": "not_inserted" if identity not in after["tripinfo"] else "arrived" if float(after["tripinfo"][identity]["arrival"]) >= 0 else "running",
            "selected_pair_bin": p["selected_event_bin"],
            "new535_same_selected_pair_bin": any(e["detector_id"] == p["expected_fields"][1] and e["interval_begin_s"] == p["selected_event_bin"] for e in events)})
    changed_unchanged = []
    for identity in sorted(unchanged):
        a, b = event_view(after["by_vehicle"].get(identity, [])), event_view(baseline["by_vehicle"].get(identity, []))
        if a != b:
            changed_unchanged.append({"vehicle_id": identity, "source_events": b, "candidate_events": a,
                "field_bin_signature_changed": [(e["field"], e["begin"]) for e in a] != [(e["field"], e["begin"]) for e in b],
                "source_complete_events": len(b), "candidate_complete_events": len(a)})
    prefix_keys = [k for k in after["periodic"] if k[2] <= scope["first_changed_requested_departure_s"]]
    prefix_differences = [k for k in prefix_keys if after["periodic"][k] != baseline["periodic"][k]]
    dual_complete = all(r["complete_exact_two_in_order"] for r in dual)
    accepted = (after["safe"] and not unexpected and not repeats and dual_complete
        and after["metrics130"]["SSE"] < baseline["metrics130"]["SSE"] and after["metrics130"]["MAE"] < baseline["metrics130"]["MAE"]
        and after["completion"]["waiting"] <= 7 and after["completion"]["waiting"] + after["completion"]["running"] <= 21)
    assert verdict["after"] == after["recorded"] and verdict["all182_TAE"] == after["metrics182"]["TAE"]
    assert verdict["dual_contributions_complete"] == dual_complete
    assert bool(verdict["unexpected_contributions"]) == bool(unexpected) and bool(verdict["repeated_vehicle_fields"]) == bool(repeats)
    assert (verdict["status"] == "diagnostic_candidate") == accepted
    assert verdict["unchanged_prefix_rows"] == len(prefix_keys)
    output.mkdir(parents=True, exist_ok=True)
    table(output / "cohort-delta208.csv", decomp)
    table(output / "modified-trips.csv", dual)
    table(output / "unchanged-trip-responses.csv", changed_unchanged)
    for name in ["main", "initial", "stations"]:
        table(output / f"{name}-comparison.csv", after[name])
    field_rows = []
    for field in sorted({k[0] for k in after["periodic"]}):
        a, b = [metrics([r for r in data["main"] if r["detector_id"] == field]) for data in [after, baseline]]
        field_rows.append({"field": field, "baseline_SSE": b["SSE"], "candidate_SSE": a["SSE"], "SSE_change": a["SSE"] - b["SSE"],
                           "baseline_TAE": b["TAE"], "candidate_TAE": a["TAE"], "TAE_change": a["TAE"] - b["TAE"]})
    table(output / "field13-main.csv", field_rows)
    summary = {"status": "pass", "case": case.name, "raw_verdict": verdict["status"], "independent_acceptance_gate": accepted,
        **{k: after[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count"]},
        "SSE_change_from_reference": after["metrics130"]["SSE"] - baseline["metrics130"]["SSE"],
        "MAE_change_from_reference": after["metrics130"]["MAE"] - baseline["metrics130"]["MAE"],
        "all_modified_dual_complete": dual_complete, "new535_same_selected_bin_count": sum(r["new535_same_selected_pair_bin"] for r in dual),
        "unexpected_count": len(unexpected), "repeated_vehicle_field_count": len(repeats),
        "prefix_all_native_attributes_equal": not prefix_differences, "prefix_rows": len(prefix_keys), "prefix_differences": prefix_differences,
        "unchanged_vehicle_field_bin_changes": sum(r["field_bin_signature_changed"] for r in changed_unchanged),
        "unchanged_vehicle_any_timing_changes": len(changed_unchanged),
        "unchanged_cohort_main_count_L1_delta": sum(abs(r["unchanged_delta"]) for r in decomp if r["region"] == "main"),
        "unchanged_cohort_main_count_net_delta": sum(r["unchanged_delta"] for r in decomp if r["region"] == "main"),
        "source_hashes": after["source_hashes"], "input_scope": scope,
        "claim_boundary": "Cohort differences close the native count arithmetic; they do not causally isolate interference. New dual events are actual native nVehContrib, not relabelled source events. Fixed OD, natural lane choice and true trip equivalence are not established."}
    save(output / "audit.json", summary)
    return {k: v for k, v in summary.items() if k not in ["source_hashes", "input_scope", "claim_boundary"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-only", action="store_true")
    parser.add_argument("--output-dir", type=Path, default=OUT / "complete")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    assert output.is_relative_to(OUT) and output != OUT
    compact = SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz"
    # The selected demand is in evaluation; its fixed network/control/observations are in BASE.
    baseline = evidence(BASE, SOURCE, compact, 8640)
    summary = {"status": "pass", "native_runs": 0, "baseline": {k: baseline[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "source_hashes"]},
               "complete_cases": [], "skipped_without_verdict": []}
    if not args.baseline_only:
        for count in (1, 20):
            case = STUDY / f"substitute-{count}pair"
            if not (case / "verdict.json").exists():
                summary["skipped_without_verdict"].append({"case": case.name, "reason": "No complete verdict seal; candidate native XML not read"})
                continue
            summary["complete_cases"].append(compare_case(count, baseline, output / case.name))
    save(output / "scan.json", summary)
    save(output / "manifest.json", {"files": [{"path": p.relative_to(output).as_posix(), "size_bytes": p.stat().st_size, "sha256": digest(p)}
        for p in sorted(output.rglob("*")) if p.is_file() and p.name != "manifest.json"], "native_runs": 0})
    save(OUT / "manifest.json", {"files": [{"path": p.relative_to(OUT).as_posix(), "size_bytes": p.stat().st_size, "sha256": digest(p)}
        for p in sorted(OUT.rglob("*")) if p.is_file() and p != OUT / "manifest.json" and "__pycache__" not in p.parts], "native_runs": 0})
    print(json.dumps({k: v for k, v in summary.items() if k != "baseline"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
