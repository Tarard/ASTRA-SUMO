# 两项行程替代的独立离线核对

本目录只读主任务生成的显式输入和完成后的原生结果。`measure.py`及其执行快照保持原字节。这里的工具不启动SUMO、不修改候选或原生文件，也不循环等待。

`audit_scope.py`已独立核过1/20对输入。它从原车辆XML的真实`depart`计算两方出发窗，验证每一对与声明相同；直接展开计划多字段签名，再逐项比较完整14×字段库存。每个保留车辆的全部属性、原stop及所有非修改子项相同；新route精确等于静态witness，只增加535第二moving stop。1对有8638辆未改车辆XML完全相同，20对有8600辆。未修改车辆的排列和所有非vehicle子项也保留。网络、控制、检测布局、130主窗和52初始化targets逐字节相同。

当前driver给保留车保持原119首字段的rear-clear hold。535第二字段只添加原生moving stop，未伪称增加了第二个rear-clear hold。预期字段签名是对新真实事件的检查条件；不能把它写回旧计数。输入审查不证明新的检测、时刻或间隙。

在主任务通知候选verdict完成后，从仓库根目录单次执行：

```powershell
$env:PYTHONUTF8 = '1'
$env:PYTHONPATH = "$PWD/plugins/astra-sumo/src"
.venv/Scripts/python.exe outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py
```

只有`substitute-1pair/verdict.json`或`substitute-20pair/verdict.json`存在时，工具才读取对应原生结果。没有verdict的候选记为跳过，不解析半写XML。两项各自与同一selected来源比较。

`--baseline-only --output-dir .../response-audit/baseline-check`只核固定selected来源；该检查已经通过，未读取正在运行的候选原生输出。它逐行核208原生计数、130/52/182真实行、40派生站点及完整nVehContrib事件。初始化与尾窗分开，40派生行不进入独立损失。所有原生输出和compact sidecar的原始输入哈希在结束前再次核验。

封口后的`complete/`包括：

- `scan.json`：两项完整结果与原verdict、独立gate、全安全和积压指标；未封口项另列。
- 每项`main-comparison.csv`、`initial-comparison.csv`、`stations-comparison.csv`：重算130/52/40；`audit.json`另列182指标。
- `modified-trips.csv`：每辆改路线车的新完整字段序列、两个事件时刻/窗及是否在原配对窗完成第二字段；原两辆车事件同时保留，未据原事件重标。
- `cohort-delta208.csv`：每字段/窗的新旧总计数，以及保留改路线群、被移除请求群和其余未改群的变化。三项差值之和必须精确闭合总差。
- `unchanged-trip-responses.csv`：其余未改车辆的完整事件窗或时刻变化，包括丢失/新增完整事件。
- `field13-main.csv`：13字段的主窗SSE/TAE变化。

工具逐行比较首个修改请求出发前的全部原生E1属性，不只比较计数。预期完整prefix行数分别为156和52，但实际数由XML出发时刻与原生区间计算。安全、summary完整144000步、实际请求数、完成状态、重复字段、意外字段以及全部改路线车辆双字段完成均单列核对。

独立选择条件与运行前声明一致：130项SSE和MAE都严格下降，等待不超过7，总等待加在途不超过21，无安全/重复/意外字段，全部替代车实际完成两字段。原verdict不改写。差值分解是原生事件记账，不能作干扰效应的因果分离，也不能识别真实OD或证明自然选道。
