"""Select fixed, read-only matched-trip proposals; do not materialize demand."""

from collections import Counter, defaultdict
import csv
import gzip
from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BASE = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1"
SELECTED = BASE / "probe-minus1/evaluation"
COMPACT = BASE / "selected-next-diagnosis/selected-contributing-passages.json.gz"
WITNESSES = ROOT / "outputs/hamburg-joint-od-spsa-20261023-v1/support-audit/multi-field-witnesses.json"
FIELD119 = "hh_0119_Z_12_31546"
FIELD535 = "hh_0535_Z_4_33055"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write_json(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    paths = [SELECTED / "demand.rou.xml", SELECTED / "lane-intentions.json", SELECTED / "od-vector.json",
             SELECTED / "native/vehicle-routes.xml", SELECTED / "native/field-counts.xml",
             SELECTED / "native/field-comparison.csv", COMPACT, WITNESSES]
    paths += [ROOT / "outputs/hamburg-joint-od-spsa-20261023-v1/prepared" / name
              for name in ["network.net.xml", "control.add.xml", "od-model.json", "expected-counts.csv", "initialization-counts.csv"]]
    hashes = {str(p): digest(p) for p in paths}
    witnesses = json.loads(WITNESSES.read_bytes())
    vehicles = {x.get("id"): x for x in ET.parse(SELECTED / "demand.rou.xml").getroot().findall("vehicle")}
    with gzip.open(COMPACT, "rt", encoding="utf-8") as handle:
        compact = json.load(handle)
    assert compact["reconciled"] and compact["measurement_attribute"] == "nVehContrib"
    by_vehicle = defaultdict(list)
    for passage in compact["passages"]:
        by_vehicle[passage["vehicle_id"]].append(passage)
    native_routes = {x.get("id"): x for x in ET.parse(SELECTED / "native/vehicle-routes.xml").getroot().findall("vehicle")}
    first, second = [], []
    for identity, events in by_vehicle.items():
        if len(events) != 1:
            continue
        event = events[0]
        if not 3600 <= event["interval_begin_s"] < 12600:
            continue
        vehicle = vehicles[identity]
        route = vehicle.find("route").get("edges").split()
        depart = float(vehicle.get("depart"))
        item = {"id": identity, "route": route, "depart_s": depart, "departure_bin": int(depart // 900),
                "event": event, "origin": route[0], "destination": route[-1],
                "vehicle_xml": ET.tostring(vehicle, encoding="unicode")}
        if event["detector_id"] == FIELD535:
            second.append(item)
        if event["detector_id"] != FIELD119 or route[0] not in {"44532531", "25866659#1"} or identity not in native_routes:
            continue
        witness = next(w for w in witnesses if w["origin"] == route[0])
        k = witness["edges"].index("186821034#0")
        if route[:k + 1] != witness["edges"][:k + 1]:
            continue
        native = native_routes[identity].find("route")
        assert native.get("edges").split() == route
        exits = [float(t) for t in native.get("exitTimes").split()]
        assert len(exits) == len(route)
        original_exit = exits[k]
        proxy_bin = int(original_exit // 900) * 900
        if not 3600 <= proxy_bin < 12600:
            continue
        first.append({**item, "witness": witness, "original_exit535_s": original_exit,
                      "proxy_bin": proxy_bin, "common_prefix_edge_count": k + 1, "exit_times": exits})
    candidates = []
    for a in first:
        for b in second:
            if a["proxy_bin"] == b["event"]["interval_begin_s"]:
                candidates.append((a["departure_bin"] != b["departure_bin"],
                    a["event"]["interval_begin_s"] != b["event"]["interval_begin_s"],
                    abs(a["original_exit535_s"] - b["event"]["notification_time_s"]), a["id"], b["id"], a, b))
    chosen, retained_used, removed_used = [], set(), set()
    for rank in sorted(candidates):
        a, b = rank[-2:]
        if a["id"] in retained_used or b["id"] in removed_used:
            continue
        retained_used.add(a["id"])
        removed_used.add(b["id"])
        witness = a["witness"]
        k = a["common_prefix_edge_count"]
        chosen.append({"rank": len(chosen) + 1, "retained_vehicle_id": a["id"], "removed_vehicle_id": b["id"],
            "witness_id": witness["id"], "expected_fields": [FIELD119, FIELD535],
            "original_exit535_s": a["original_exit535_s"], "removed_passage_s": b["event"]["notification_time_s"],
            "retained_departure_bin": a["departure_bin"], "removed_departure_bin": b["departure_bin"],
            "selected_event_bin": a["proxy_bin"], "selected_event_bin_end_s": a["proxy_bin"] + 900,
            "retained_original_119_event_bin": a["event"]["interval_begin_s"],
            "retained_original_119_passage_s": a["event"]["notification_time_s"],
            "absolute_proxy_time_difference_s": rank[2], "same_departure_bin": not rank[0],
            "all_three_original_timing_bins_equal": not rank[1],
            "retained_depart_s": a["depart_s"], "removed_depart_s": b["depart_s"],
            "retained_original_origin": a["origin"], "retained_original_destination": a["destination"],
            "removed_original_origin": b["origin"], "removed_original_destination": b["destination"],
            "retained_original_route_edges": a["route"], "removed_original_route_edges": b["route"],
            "replacement_route_edges": witness["edges"], "common_prefix_edge_count": k,
            "last_shared_edge": "186821034#0", "first_changed_original_edge": a["route"][k],
            "first_changed_replacement_edge": witness["edges"][k],
            "retained_original_vehicle_xml": a["vehicle_xml"], "removed_original_vehicle_xml": b["vehicle_xml"],
            "retained_actual_exit_times_s": a["exit_times"],
            "retained_original_stops": [dict(stop.attrib) for stop in vehicles[a["id"]].findall("stop")],
            "removed_original_stops": [dict(stop.attrib) for stop in vehicles[b["id"]].findall("stop")]})
        if len(chosen) == 20:
            break
    assert len(chosen) == 20 and all(p["same_departure_bin"] and p["all_three_original_timing_bins_equal"] for p in chosen)
    inventory = Counter((int(float(vehicles[row["vehicle_id"]].get("depart")) // 900), row["field_id"])
                        for row in json.loads((SELECTED / "lane-intentions.json").read_bytes())["vehicles"])
    planned = inventory.copy()
    for pair in chosen:
        planned[pair["removed_departure_bin"], FIELD535] -= 1
        planned[pair["retained_departure_bin"], FIELD535] += 1
    assert inventory == planned and len(vehicles) == 8640
    with (SELECTED / "native/field-comparison.csv").open(encoding="utf-8", newline="") as handle:
        residuals = [row for row in csv.DictReader(handle) if row["detector_id"] in {FIELD119, FIELD535}]
    field_summary = {}
    for field in [FIELD119, FIELD535]:
        rows = [r for r in residuals if r["detector_id"] == field]
        errors = [int(r["diff_nVehContrib_minus_expected"]) for r in rows]
        field_summary[field] = {"rows": len(rows), "target": sum(int(r["expected_total"]) for r in rows),
            "actual": sum(int(r["measured_nVehContrib"]) for r in rows), "SSE": sum(e * e for e in errors),
            "TAE": sum(abs(e) for e in errors), "residual_actual_minus_target": errors}
    source = {"selected_evaluation": str(SELECTED), "source_hashes": hashes,
              "witness_file": str(WITNESSES), "network_sha256": hashes[str(paths[-5])]}
    common = {"schema": "astra.hamburg.multifield-substitution-proposal/v1", "status": "review_required",
        "native_runs": 0, "demand_materialized": False, "source": source,
        "ranking": ["same original native 900s main bin for old 535-approach exit and removed 535 E1",
                    "same requested departure bin preferred", "same retained119 E1 bin preferred",
                    "nearest absolute old535 exit to removed535 notification time", "vehicle IDs for ties"],
        "field_summary130": field_summary,
        "claim_boundary": "Matched event timing and fixed route-prefix compatibility are proposal criteria, not observed OD equivalence or predictions of new native E1 counts. The old approach exit is a front-edge exit, not a complete detector passage. Changed final turn, lane strategy and traffic interaction can change all counts and delays. Real targets remain unchanged; full native measurement is required."}
    for filename, count in [("plan.json", 20), ("one-pair.json", 1), ("twenty-pairs.json", 20)]:
        write_json(filename, {**common, "pair_count": count, "pairs": chosen[:count],
            "planned_request_count": len(vehicles) - count,
            "planned_field_intention_event_count": sum(inventory.values()),
            "planned_intention_inventory_by_departure_bin_unchanged": True,
            "departure_retiming": False, "scope": "Retain first request at its exact original departure; replace only its post-prefix route to the existing boundary and add the second field waypoint as a proposed driver constraint. Omit the matched second request before departure. No network/control/target changes, OD regeneration or early in-network removal."})
    write_json("basis.json", {"eligible_retained119_requests": len(first), "eligible_removed535_main_requests": len(second),
        "same535_main_bin_pair_combinations": len(candidates), "same_departure_bin_combinations": sum(not c[0] for c in candidates),
        "ranked20_origin_counts": dict(Counter(p["retained_original_origin"] for p in chosen)),
        "ranked20_departure_bins": dict(Counter(p["retained_departure_bin"] for p in chosen)),
        "ranked20_removed_origin_counts": dict(Counter(p["removed_original_origin"] for p in chosen)),
        "max20_proxy_time_difference_s": max(p["absolute_proxy_time_difference_s"] for p in chosen),
        "all20_same_departure_bin": True, "all20_same_original119_event_and535_proxy_and_removed535_bins": True,
        "original_residual_rows": residuals,
        "inventory": [{"departure_bin": h, "field": f, "before_event_intentions": n,
                       "planned_after_event_intentions": planned[h, f]} for (h, f), n in sorted(inventory.items())],
        "source_hashes": hashes, "source_unchanged": hashes == {str(p): digest(p) for p in paths}})
    print(json.dumps({"pairs": len(chosen), "first": chosen[0]["retained_vehicle_id"], "removed": chosen[0]["removed_vehicle_id"],
                      "output": str(OUT / "plan.json"), "field_summary": field_summary}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
