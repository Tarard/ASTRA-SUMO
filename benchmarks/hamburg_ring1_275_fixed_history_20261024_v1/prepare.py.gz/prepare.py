"""Bind two controls to the new275 simulated history only after recording parity."""

import argparse
import shutil
import xml.etree.ElementTree as ET

import common as c


def prepare():
    gate = c.record_gate()
    assert gate["status"] == "pass", gate
    assert not (c.ROOT / "preparation.json").exists(), "Preserve prepared conditions."
    runtime = c.runtime()
    program = c.RECORD / "tls-recorded-programs.add.xml"
    reference = c.SOURCES["reference"][0] / "prepared"
    for source, count in c.SOURCES.values():
        assert len(ET.parse(source / "prepared/demand.rou.xml").getroot().findall("vehicle")) == count
        for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
            assert (source / "prepared" / name).read_bytes() == (reference / name).read_bytes()
        assert c.full_widths(source / "prepared") == gate["widths"]
        source_monitor = c.load(source / "evaluation/native/stall-monitor.json")
        assert source_monitor["native_library"] == runtime["native_library"]
        source_request = c.load(source / "evaluation/native/native-request.json")
        assert source_request["all_stopped_timeout_s"] == 300 and source_request["monitor_interval_s"] is None
        assert all(float(source_request["command"][source_request["command"].index(flag) + 1]) == value for flag, value in (("--end", 14400), ("--step-length", .1), ("--seed", 104)))
        for name in c.CORE:
            c.core_snapshot(source, name)
    for label, (source, count) in c.SOURCES.items():
        case, prepared = c.ROOT / label, c.ROOT / label / "prepared"
        prepared.mkdir(parents=True)
        for name in c.NAMES:
            shutil.copyfile(source / "prepared" / name, prepared / name)
        shutil.copyfile(program, prepared / "control.add.xml")
        assert len(ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")) == count
        scenario = c.load(prepared / "scenario.json")
        scenario.update(control_sha256=c.sha(program), formal_result=False, control_treatment=dict(kind="new275_recorded_simulated_history_static",
            source=str(program), sha256=c.sha(program), horizon_s=14400, observed_field_spat=False, post_horizon_extrapolation=False,
            phase_ordinal_is_original_phase_index=False, current_source_record_parity_sha256=gate["record_result_sha256"]))
        c.save(prepared / "scenario.json", scenario)
        native, target = source / "evaluation/native", case / "evaluation/native"
        request = c.load(native / "native-request.json")
        command = [part.replace(str(native), str(target)) for part in request["command"]]
        command[command.index("--additional-files") + 1] += "," + str(target / "tls-observer.add.xml")
        planned = {**request, "command": command, "monitor_file": str(target / "stall-monitor.json")}
        for key in ("lane_intentions_file", "route_file", "e1_file"):
            planned[key] = planned[key].replace(str(native), str(target))
        assert request["backend"] == "libsumo" and request["end_s"] == 14400 and request["junction_body_hold_nodes"] == ["14398547", "205069138", "18653534", "LSA104_part0"]
        c.save(case / "planned-native-request.json", planned)
        implementation = case / "implementation"
        implementation.mkdir()
        code = [c.core_snapshot(source, name) for name in c.CORE]
        for path in code:
            shutil.copyfile(path, implementation / path.name)
        bound = [source / "prepared" / n for n in (*c.NAMES, "control.add.xml")]
        bound += [program, c.RECORD / "record-result.json", c.RECORD / "tls-switch-states.xml", native / "native-request.json", source / "verdict.json",
            c.RECORD.parent / "postcheck-recovery.json", c.RECORD.parent / "offline_postcheck.py", c.RECORD / "execution.log", c.RECORD / "record_tls.snapshot.py",
            c.OLD / "run.py", c.OLD / "independent/audit_fixed.py", c.Path(c.PURE.audit.__file__), c.Path(c.PURE.audit.__file__).parent / "audit_scope.py",
            c.ROOT / "common.py", c.ROOT / "prepare.py", c.ROOT / "run.py", c.ROOT / "audit.py"]
        binaries = [c.REPO / ".venv/Scripts/python.exe", c.REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe", c.Path(runtime["native_library"]["path"])]
        c.save(case / "preflight.json", dict(status="prepared", native_runs=0, formal_result=False, source_case=str(source), source_native=str(native), count=count,
            frozen_history_sha256=c.sha(program), source_hashes={str(p): c.sha(p) for p in bound + binaries}, versions={n: "1.27.1" for n in runtime["modules"]},
            actual_binary_paths={str(p): c.sha(p) for p in binaries}, core_source_hashes={p.name: c.sha(p) for p in code},
            prepared_hashes={p.name: c.sha(p) for p in prepared.iterdir()}, runtime=runtime, end_s=14400, step_s=.1, seed=104,
            post_horizon_extrapolation=False, phase_index_equality_required=False, reference_full_native_parity_required_before_interpretation=True))
    assert (c.ROOT / "reference/prepared/control.add.xml").read_bytes() == (c.ROOT / "warmup9/prepared/control.add.xml").read_bytes() == program.read_bytes()
    c.save(c.ROOT / "preparation.json", dict(status="prepared", native_runs=0, gate=gate, counts={k: n for k, (_, n) in c.SOURCES.items()},
        claim_boundary="Current275 simulated history only. Counterpart interpretation waits for reference strict self-parity; no fieldSPaT or fit acceptance."))
    return dict(status="prepared", native_runs=0, history_sha256=c.sha(program))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--prepare", action="store_true")
    args = parser.parse_args()
    print(c.json.dumps(c.record_gate() if args.check_only else prepare()))
