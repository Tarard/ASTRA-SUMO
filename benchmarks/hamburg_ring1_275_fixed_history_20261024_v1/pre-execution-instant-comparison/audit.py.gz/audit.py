"""Reuse raw evidence/timeline readers; reference parity gates interpretation."""

import argparse
import xml.etree.ElementTree as ET

import common as c


def audit_case(label):
    case = c.ROOT / label
    source, count = c.SOURCES[label]
    prepared, evaluation, native = case / "prepared", case / "evaluation", case / "evaluation/native"
    p = c.load(case / "preflight.json")
    report, prior = [c.load(folder / "run.json") for folder in (native, source / "evaluation/native")]
    actual = c.evidence(prepared, evaluation, count)
    baseline = c.evidence(source / "prepared", source / "evaluation", count)
    widths = c.full_widths(source / "prepared")
    target = c.PURE.histories(c.RECORD / "tls-switch-states.xml", widths)
    states = c.PURE.histories(native / "tls-switch-states.xml", widths)
    programmed, _ = c.PURE.program_histories(prepared / "control.add.xml", widths)
    differences = {tls: dict(actual_vs_recorded=c.PURE.difference_ticks(states[tls], target[tls]), exported_vs_recorded=c.PURE.difference_ticks(programmed[tls], target[tls])) for tls in widths}
    old_native = source / "evaluation/native"
    comparisons = {name: c.PURE.compare_rows(old_native / filename, native / filename, tag, ignored) for name, filename, tag, ignored in
        (("E1", "field-counts.xml", "interval", ()), ("summary", "summary.xml", "step", ("duration",)), ("instant", "instant-e1.xml", "instantOut", ()))}
    trips = [c.PURE.keyed(folder / "tripinfo.xml", "tripinfo") for folder in (old_native, native)]
    routes = [c.PURE.keyed(folder / "vehicle-routes.xml", "vehicle") for folder in (old_native, native)]
    requests = {r.get("id"): r.find("route").get("edges") for r in ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")}
    intended = {r["vehicle_id"]: r["field_id"] for r in c.load(prepared / "lane-intentions.json")["vehicles"]}
    arrived = ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle")
    checks = dict(fresh_native_completed=report["native_status"] == "pass" and not report["errors"] and report["stall_monitor"]["status"] == "completed",
        input_hashes_unchanged=all(c.sha(path) == digest for path, digest in p["source_hashes"].items()) and all(c.sha(prepared / name) == digest for name, digest in p["prepared_hashes"].items()),
        exact50_color_and_program_histories=all(not r["actual_vs_recorded"] and not r["exported_vs_recorded"] for r in differences.values()),
        full14400_horizon=report["end_s"] == 14400 and report["step_length_s"] == .1 and report["stall_monitor"]["simulation_time_s"] == 14400,
        raw208_E1_and144000_summary_complete=len(actual["periodic"]) == 208 and comparisons["summary"]["rows"] == 144000,
        complete_population_IDs_and_routes=len(requests) == count and actual["healthy"] and requests.keys() == intended.keys() == actual["tripinfo"].keys() == actual["by_vehicle"].keys() == {r.get("id") for r in arrived} and all(r.find("route").get("edges") == requests[r.get("id")] for r in arrived) and all(len(events) == 1 and events[0]["detector_id"] == intended[identity] for identity, events in actual["by_vehicle"].items()),
        no_unsafe=actual["safe"])
    reference_checks = dict(E1_208_allattrs_exact=comparisons["E1"]["same"] and comparisons["E1"]["rows"] == 208,
        summary_144000_exceptCPUduration_exact=comparisons["summary"]["same"] and comparisons["summary"]["rows"] == 144000,
        all_instant_events_exact=comparisons["instant"]["same"], all_tripinfo_exact=trips[0] == trips[1], all_arrived_routes_stops_exitTimes_exact=routes[0] == routes[1],
        all_driver_holds_exact=prior["stall_monitor"]["lane_section_hold"] == report["stall_monitor"]["lane_section_hold"],
        completion_health_and_metrics_exact=all(actual[k] == baseline[k] for k in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "healthy", "event_count")))
    required = {**checks, **reference_checks} if label == "reference" else checks
    report = dict(schema="astra.hamburg.275-fixed-history-audit/v1", status="pass" if all(required.values()) else "blocked", formal_result=False, variant=label,
        checks=required, comparisons_with_original_same_demand=reference_checks, raw_comparisons=comparisons, color_program_difference_ticks=differences,
        actual_N=count, after={k: actual[k] for k in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "healthy", "safe", "event_count")},
        phase_index_equality_required=False, MAE_is_not_acceptance=True, counterpart_interpretation_pending_reference=True,
        claim_boundary="Conditional current275 simulated color/program history. Reference14 strict gates must pass before counterpart interpretation. No fieldSPaT, trueOD or calibration acceptance.")
    c.save(case / "parity.json", report)
    return report


def pair():
    reports = {label: audit_case(label) for label in c.SOURCES}
    eligible = all(r["status"] == "pass" for r in reports.values())
    result = dict(status="pass" if eligible else "blocked", formal_result=False, reference_parity_passed=reports["reference"]["status"] == "pass",
        conditional_comparison_interpretable=eligible, results=reports, claim_boundary="Keep counterpart on failed reference, without interpreting its conditional response. No fieldSPaT or improvement acceptance.")
    c.save(c.ROOT / "paired-result.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--case", choices=c.SOURCES)
    action.add_argument("--pair", action="store_true")
    args = parser.parse_args()
    print(c.json.dumps(pair() if args.pair else audit_case(args.case)))
