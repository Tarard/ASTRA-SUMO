"""Bindings and existing pure timeline helpers for the275 simulated-history pair."""

from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OLD = REPO / "outputs/hamburg-healthy-z4-fixed-history-20261024-v1"
RECORD = REPO / "outputs/hamburg-275-control-history-20261024-v1/reference"
PREFIX = REPO / "outputs/hamburg-chronological-prefix-calibration-20261024-v1/cases"
SOURCES = {"reference": (PREFIX / "h4_counter_z11_minus5_z5", 8589), "warmup9": (PREFIX / "h3_counter_add9", 8598)}
NAMES = ("network.net.xml", "demand.rou.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json")
CORE = ("detector_demand.py", "detector_demand_replay.py", "hamburg_od_spsa.py", "hamburg_readme_results.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")
RECORD_SHA = "58f9735c4ce7238412831b7604a3692ff269cf2acf631cffb4eff29c99a7a0b5"
RECOVERY_SHA = "737d4cc5db2680b8140be9aaa542fc42dd9d0bc86788e29117da5db4b5ae60f8"


def sha(path):
    return file_sha256(Path(path))


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def module(name, path):
    spec = spec_from_file_location(name, path)
    result = module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


PURE = module("existing_fixed_history_pure", OLD / "independent/audit_fixed.py")


def full_widths(prepared):
    programs = ET.parse(prepared / "control.add.xml").getroot().findall("tlLogic")
    assert len(programs) == len({p.get("id") for p in programs}) == 50
    widths = {}
    for program in programs:
        sizes = {len(p.get("state")) for p in program.findall("phase")}
        assert len(sizes) == 1
        widths[program.get("id")] = sizes.pop()
    bound = set()
    for row in ET.parse(prepared / "network.net.xml").getroot().findall("connection"):
        if row.get("tl"):
            identity = row.get("tl")
            assert identity in widths and 0 <= int(row.get("linkIndex")) < widths[identity]
            bound.add(identity)
    assert bound == widths.keys() and widths["266197525"] == 9
    return widths


def record_gate():
    path = RECORD / "record-result.json"
    if not path.is_file():
        return dict(status="not_ready", native_runs=0, reason="Wait for the new275 source recording and its traffic parity.")
    record = load(path)
    recovery_path = RECORD.parent / "postcheck-recovery.json"
    assert sha(path) == RECORD_SHA and sha(recovery_path) == RECOVERY_SHA
    recovery = load(recovery_path)
    assert recovery["status"] == "pass" and recovery["new_native_runs"] == 0 and recovery["wall_elapsed_seconds"] is None
    assert sha(RECORD.parent / "offline_postcheck.py") == recovery["offline_postcheck_sha256"]
    assert sha(recovery["original_execution_error_log"]["path"]) == recovery["original_execution_error_log"]["sha256"]
    assert record["status"] == "pass" and len(record["checks"]) >= 20 and all(record["checks"].values())
    source = SOURCES["reference"][0] / "evaluation/native"
    assert all(sha(source / name) == digest for name, digest in record["source_hashes"].items())
    assert sha(RECORD / "network.net.xml") == sha(source / "network.net.xml") == "6c52382e7664eca33fceff6fd02ae700d93139a316a3f9f5139d0e139d7a18ce"
    widths = full_widths(SOURCES["reference"][0] / "prepared")
    states = PURE.histories(RECORD / "tls-switch-states.xml", widths)
    exported, phases = PURE.program_histories(RECORD / "tls-recorded-programs.add.xml", widths)
    assert all(PURE.difference_ticks(states[t], exported[t]) == 0 for t in widths)
    return dict(status="pass", native_runs=0, checks=len(record["checks"]), widths=widths, phase_counts=phases,
        record_result_sha256=sha(path), history_sha256=sha(RECORD / "tls-recorded-programs.add.xml"),
        switch_states_sha256=sha(RECORD / "tls-switch-states.xml"), recovery_sha256=RECOVERY_SHA,
        record_origin="Native completed; original recorder serialization exited1. The preserved offline postcheck recovered21 gates without a new native run; wall duration remains null.")


def evidence(prepared, evaluation, count):
    return PURE.audit.evidence(prepared, evaluation, evaluation / "contributing-passages.json.gz", count)


def core_snapshot(source, name):
    current = REPO / "plugins/astra-sumo/src/astra_sumo/core" / name
    candidates = [source / folder / name for folder in ("measurement-implementation", "additional-measurement-implementation", "implementation")]
    assert any(p.is_file() and p.read_bytes() == current.read_bytes() for p in candidates), name
    return current


def runtime():
    helper = module("existing_fixed_pair_runtime", REPO / "outputs/hamburg-119-saturated-service-20261024-v1/run_fixture.py")
    assert Path(sys.executable).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    info, _ = helper.check_runtime()
    return info
