"""Explicitly execute one prepared condition through the existing fixed-history runner."""

import argparse
import shutil

import common as c


def runner():
    old = c.module("existing_fixed_history_runner", c.OLD / "run.py")
    old.ROOT, old.REPO = c.ROOT, c.REPO
    return old


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=c.SOURCES, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    old = runner()
    p = old.check(c.ROOT / args.case)
    c.runtime()
    if args.check_only:
        print(c.json.dumps(dict(status="pass", native_runs=0, count=p["count"], history_sha256=p["frozen_history_sha256"])))
    else:
        case = c.ROOT / args.case
        assert not (case / "executed-wrapper.py").exists(), "Preserve executed wrappers."
        shutil.copyfile(__file__, case / "executed-wrapper.py")
        old.run(args.case)
