"""Add nine declared warm-up requests without changing any existing request."""
import argparse
from collections import Counter
import copy
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET

import prepare_prefix as shared

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cases/h4_counter_z11_minus5_z5"
DONOR = ROOT / "cases/h4_counter_fill9"
NAME = "h3_counter_add9"
CASE = ROOT / "cases" / NAME


def data():
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    matches = list(shared.VEHICLE.finditer(raw))
    assert len(matches)==8589 and all(raw[a.end():b.start()]==b"" for a,b in zip(matches,matches[1:]))
    original = {ET.fromstring(m.group()).get("id"):m.group() for m in matches}
    donor_raw = (DONOR / "prepared/demand.rou.xml").read_bytes()
    donor_fragments = {ET.fromstring(m.group()).get("id"):m.group() for m in shared.VEHICLE.finditer(donor_raw)}
    donor_intent = {r["vehicle_id"]:r for r in json.loads((DONOR / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    donor_ids = [r["vehicle_id"] for r in json.loads((DONOR / "proposal.json").read_bytes())["request_changes"]]
    donor_ids.sort(key=lambda i:Decimal(ET.fromstring(donor_fragments[i]).get("depart")))
    events = json.loads(gzip.decompress((DONOR / "evaluation/contributing-passages.json.gz").read_bytes()))["passages"]
    event_map = {r["vehicle_id"]:r for r in events}
    assert len(event_map)==len(events)==8589
    arrivals = {v.get("id"):v for v in ET.parse(DONOR / "evaluation/native/tripinfo.xml").getroot().findall("tripinfo")}
    actual_routes = {v.get("id"):v.find("route").get("edges") for v in ET.parse(DONOR / "evaluation/native/vehicle-routes.xml").getroot().findall("vehicle")}
    vector = json.loads((SOURCE / "od-vector.json").read_bytes())
    pairs = [(r["origin_edge"],r["destination_edge"]) for r in vector["od_pairs"]]
    assert len(donor_ids)==9 and len(pairs)==22 and len(vector["integer_counts"])==308
    metadata = json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())
    source_rows = {r["vehicle_id"]:r for r in metadata["vehicles"]}
    records = [(Decimal(ET.fromstring(fragment).get("depart")),rank,fragment) for rank,fragment in enumerate(original.values())]
    additions = []
    for rank,identity in enumerate(donor_ids):
        fragment = donor_fragments[identity]
        v = ET.fromstring(fragment)
        edges = v.find("route").get("edges").split()
        assert edges[0]=="25866659#1" and actual_routes[identity]==" ".join(edges)
        assert float(arrivals[identity].get("arrival"))>=0
        assert event_map[identity]["detector_id"]==donor_intent[identity]["field_id"]
        new_id = f"warmup_counter_{rank:03d}"
        depart = str(3580+2*rank)
        assert new_id not in original
        clone,count = re.subn(rb'(?<=\s)id="[^"]+"',b'id="'+new_id.encode()+b'"',fragment,count=1)
        assert count==1
        clone,count = shared.DEPART.subn(b'depart="'+depart.encode()+b'"',clone,count=1)
        assert count==1
        restored = re.sub(rb'(?<=\s)id="[^"]+"',b'id="'+identity.encode()+b'"',clone,count=1)
        restored = shared.DEPART.sub(b'depart="'+v.get("depart").encode()+b'"',restored,count=1)
        assert restored==fragment
        row = copy.deepcopy(donor_intent[identity])
        row.update(vehicle_id=new_id,od_cell=3*22+pairs.index((edges[0],edges[-1])))
        for key in ("depart","depart_s","departure_s","requested_departure_s"):
            if key in row:
                row[key]=depart if isinstance(row[key],str) else int(depart)
        metadata["vehicles"].append(row)
        records.append((Decimal(depart),8589+rank,clone))
        additions.append(dict(vehicle_id=new_id,depart_s=depart,field_id=row["field_id"],od_cell=row["od_cell"],
            donor_vehicle_id=identity,donor_request_depart_s=v.get("depart"),donor_actual_E1_notification_s=event_map[identity]["notification_time_s"],
            donor_arrival_s=arrivals[identity].get("arrival"),donor_route=edges,
            donor_XML_sha256=hashlib.sha256(fragment).hexdigest(),new_XML_sha256=hashlib.sha256(clone).hexdigest()))
    records.sort(key=lambda r:(r[0],r[1]))
    payload = raw[:matches[0].start()]+b"".join(r[2] for r in records)+raw[matches[-1].end():]
    after = {ET.fromstring(m.group()).get("id"):m.group() for m in shared.VEHICLE.finditer(payload)}
    assert len(after)==len(metadata["vehicles"])==8598
    assert [i for i in after if i in original]==list(original)
    assert all(after[i]==fragment for i,fragment in original.items())
    assert metadata["vehicles"][:8589]==list(source_rows.values())
    q = [0]*308
    for row in metadata["vehicles"]:
        v = ET.fromstring(after[row["vehicle_id"]])
        edges=v.find("route").get("edges").split()
        cell = int(Decimal(v.get("depart"))//900)*22+pairs.index((edges[0],edges[-1]))
        assert row["od_cell"]==cell
        q[cell]+=1
    changes=[dict(cell=i,source=vector["integer_counts"][i],candidate=q[i],delta=q[i]-vector["integer_counts"][i]) for i in range(308) if q[i]!=vector["integer_counts"][i]]
    assert [(r["cell"],r["delta"]) for r in changes]==[(74,3),(75,2),(76,4)]
    assert Counter(r["field_id"] for r in additions)=={"hh_0119_Z_12_31546":5,"hh_0119_Z_13_34018":4}
    return payload,metadata,vector,q,changes,additions


def prepare():
    assert not CASE.exists(), "Preserve earlier cases."
    for source in (SOURCE,DONOR):
        verdict=json.loads((source / "verdict.json").read_bytes())
        assert verdict["healthy"] and verdict["safe"] and verdict["after"]["completion"]["arrived"]==8589
    payload,intent,old_vector,q,changes,additions=data()
    prepared=CASE / "prepared"
    shutil.copytree(SOURCE / "prepared",prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    shared.save(prepared / "lane-intentions.json",intent)
    scenario=json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    init=sum(Decimal(v.get("depart"))<3600 for v in ET.fromstring(payload).findall("vehicle"))
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,vehicles=8598,
        initialization_vehicles=init,main_vehicles=8598-init,demand_sha256=shared.sha(prepared / "demand.rou.xml"),
        demand_prior="Preserve all8589 source request XML and relative order. Add nine explicitly identified counter-route warm-up requests at3580..3596 from complete safe native donor journeys; only new IDs/departures differ from donor XML. No resampling or runtime removal.",
        initialization_demand_hypothesis="Estimate nine additional hypothetical pre3600 requests. All52 real initialization observations remain unchanged and are remeasured; only39 native intervals before2700 are protected.")
    scenario["warmup_add9_candidate"]=dict(additions=additions,native_response_verified=False)
    shared.save(prepared / "scenario.json",scenario)
    shared.save(CASE / "od-vector.json",dict(schema="astra.hamburg.explicit22pair-request-vector/v1",vehicle_count=8598,
        pair_count=22,time_bins=14,dimension=308,od_pairs=old_vector["od_pairs"],source_integer_counts=old_vector["integer_counts"],
        integer_counts=q,changed_cells=changes,l1_change=9))
    shared.save(CASE / "proposal.json",dict(schema="astra.hamburg.warmup-counter-add9-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        prepare_script="prepare_warmup9.py",source_case=str(SOURCE.relative_to(shared.REPO)).replace("\\","/"),
        donor_case=str(DONOR.relative_to(shared.REPO)).replace("\\","/"),source_N=8589,candidate_N=8598,
        additions=additions,added_requests=9,removed_requests=0,q_dimension=308,q_changes=changes,q_L1=9,
        prefix_end_s=2700,protected_end_s=2700,protected_rows=39,stage_end_s=4500,
        selection_rule={"replaces_prior_fixed52_constraint":True,"required":["Protect39 native intervals through2700.","Report all52 real initialization rows and all130 real main rows from a fresh14400 native run.","Preserve complete identity, unique intended fields and healthy native completion."],
                        "first13_role":"Diagnostic stage objective; nine added requests do not predict nine additional contributions.","final_target":"Healthy full14400 native130-zero result; no fixed52 initialization claim."},
        claim_boundary="One warm-up demand hypothesis. New requests are hypothetical, not observed vehicles; donor route safety does not establish a count gain, trueOD or field SPaT."))
    shutil.copy2(__file__,CASE / "executed-prepare.py")
    paths=[*[SOURCE / "prepared" / n for n in shared.NAMES],SOURCE / "verdict.json",SOURCE / "od-vector.json",
        DONOR / "prepared/demand.rou.xml",DONOR / "prepared/lane-intentions.json",DONOR / "proposal.json",DONOR / "verdict.json",
        DONOR / "evaluation/contributing-passages.json.gz",DONOR / "evaluation/native/tripinfo.xml",DONOR / "evaluation/native/vehicle-routes.xml",Path(__file__),Path(shared.__file__)]
    shared.save(CASE / "scope-proof.json",dict(schema="astra.hamburg.warmup-counter-add9-scope/v1",status="pass",N=8598,source_N=8589,
        source_hashes={str(p.resolve()):shared.sha(p) for p in paths},prepared_hashes={n:shared.sha(prepared/n) for n in shared.NAMES},
        proposal_sha256=shared.sha(CASE / "proposal.json"),od_vector_sha256=shared.sha(CASE / "od-vector.json"),
        checks=dict(all8589_source_vehicle_bytes_and_relative_order_exact=True,nine_new_unique_IDs=True,
            donor_clone_changes_only_ID_departure=True,donors_complete_safe_unique_correct_field=True,
            new_times3580_to3596_in_donor_order=True,existing22pair_library_unchanged=True,actual308q_rebuilt=True,
            original_intent_rows_exact_and_nine_added=True,network_control_all130_and52_truth_bytes_exact=True,
            prior_fixed52_gate_explicitly_replaced=True)))
    return check(NAME)


def check(case_name=NAME):
    assert case_name==NAME
    proof=json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(proof["checks"].values()) and all(shared.sha(p)==h for p,h in proof["source_hashes"].items())
    assert all(shared.sha(CASE / "prepared" / n)==h for n,h in proof["prepared_hashes"].items())
    assert shared.sha(CASE / "proposal.json")==proof["proposal_sha256"] and shared.sha(CASE / "od-vector.json")==proof["od_vector_sha256"]
    payload,intent,_,q,_,_=data()
    assert payload==(CASE / "prepared/demand.rou.xml").read_bytes() and intent==json.loads((CASE / "prepared/lane-intentions.json").read_bytes())
    assert q==json.loads((CASE / "od-vector.json").read_bytes())["integer_counts"] and sum(q)==8598 and len(q)==308
    for name in shared.NAMES:
        if name not in ("demand.rou.xml","lane-intentions.json","scenario.json"):
            assert (CASE / "prepared" / name).read_bytes()==(SOURCE / "prepared" / name).read_bytes()
    return dict(status="pass",case=NAME,source_N=8589,candidate_N=8598,actual_N=8598,added_requests=9,OD_pairs=22,
                q_dimension=308,protected_end_s=2700,protected_rows=39,new_native_runs=0,scope_sha256=shared.sha(CASE / "scope-proof.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=[NAME],default=NAME)
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
