"""Offline preparation guards; never execute a traffic simulation."""

from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import common as c  # noqa: E402
import prepare  # noqa: E402
import audit  # noqa: E402


def test_missing_record_does_not_materialize(monkeypatch, tmp_path):
    monkeypatch.setattr(c, "RECORD", tmp_path / "missing")
    monkeypatch.setattr(c, "ROOT", tmp_path)
    assert c.record_gate()["status"] == "not_ready"
    with pytest.raises(AssertionError):
        prepare.prepare()
    assert not list(tmp_path.iterdir())


def test_full_state_width_keeps_sparse525_nine_characters():
    source = c.SOURCES["reference"][0] / "prepared"
    assert c.full_widths(source)["266197525"] == 9
    bound = [int(r.get("linkIndex")) for r in ET.parse(source / "network.net.xml").getroot().findall("connection") if r.get("tl") == "266197525"]
    assert set(bound) == {0, 1}


def test_counterpart_unequal_instant_length_is_not_a_reference_gate(tmp_path):
    old, new = tmp_path / "old", tmp_path / "new"
    for folder, events in ((old, 1), (new, 2)):
        folder.mkdir()
        (folder / "field-counts.xml").write_text('<root><interval id="f"/></root>', encoding="utf-8")
        (folder / "summary.xml").write_text('<root><step time="0"/></root>', encoding="utf-8")
        (folder / "instant-e1.xml").write_text('<root>' + '<instantOut id="f"/>' * events + '</root>', encoding="utf-8")
    counterpart = audit.traffic_comparisons(old, new, False)
    assert counterpart["instant"]["status"] == "not_applicable" and counterpart["instant"]["same"] is None and counterpart["instant"]["rows"] is None
    assert counterpart["E1"]["same"] and counterpart["summary"]["same"]
    with pytest.raises(AssertionError, match="row count differs"):
        audit.traffic_comparisons(old, new, True)


@pytest.mark.skipif(not (ROOT / "preparation.json").is_file(), reason="Wait for real recording parity and preparation.")
def test_prepared_sources_are_distinct_and_control_only():
    for label, (source, count) in c.SOURCES.items():
        prepared = ROOT / label / "prepared"
        assert len(ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")) == count
        for name in c.NAMES:
            if name != "scenario.json":
                assert (prepared / name).read_bytes() == (source / "prepared" / name).read_bytes()
        assert (prepared / "control.add.xml").read_bytes() == (c.RECORD / "tls-recorded-programs.add.xml").read_bytes()
