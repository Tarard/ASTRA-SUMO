"""Recover the completed native record by offline checks only; never invoke SUMO."""
from decimal import Decimal
import hashlib
import itertools
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
EXECUTED_SHA = "9a4725148504aaa7764216776200c3d2ca89e1d53cd591691a1d0ef09bc63cad"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def elements(path, tag):
    for _, row in ET.iterparse(path, events=('end',)):
        if row.tag == tag:
            yield row
            row.clear()


def verify():
    assert Path(sys.executable).resolve() == (REPO/'.venv/Scripts/python.exe').resolve()
    variant, end, out = 'reference', 14400, ROOT/'reference'
    preflight = json.loads((out/'preflight.json').read_bytes())
    source = Path(preflight['source'])
    assert digest(ROOT/'record_tls.py') == digest(out/'record_tls.snapshot.py') == preflight['script_sha256'] == EXECUTED_SHA
    assert not (out/'record-result.json').exists(), 'Preserve an existing postcheck result.'
    names = list(preflight['source_hashes'])
    hashes = preflight['source_hashes']
    source_monitor = json.loads((source/'stall-monitor.json').read_bytes())
    source_widths = preflight['source_program_widths']
    duration_match = re.search(r'^ Duration: ([0-9.]+)s$', (out/'sumo.log').read_text(encoding='utf-8'), re.M)
    native_duration = float(duration_match.group(1)) if duration_match else None
    checks = {'source_inputs_unchanged': hashes == {name: digest(source/name) for name in names},
        'network_demand_control_intentions_identical': all((out/name).read_bytes() == (source/name).read_bytes()
            for name in ('network.net.xml', 'demand.rou.xml', 'signal-programs.add.xml', 'lane-intentions.json', 'source-e1.add.xml'))}
    reference_counts = {(r.get('id'), r.get('begin'), r.get('end')): r.attrib
        for r in elements(source/'field-counts.xml', 'interval') if Decimal(r.get('end')) <= end}
    actual_counts = {(r.get('id'), r.get('begin'), r.get('end')): r.attrib
        for r in elements(out/'field-counts.xml', 'interval') if Decimal(r.get('begin')) < Decimal(r.get('end'))}
    checks['all_closed_e1_attributes_identical'] = actual_counts == reference_counts
    checks['expected_closed_e1_count'] = len(actual_counts) == 208
    summary_differences, last_summary, step_count = [], None, 0
    reference_steps = (r for r in elements(source/'summary.xml', 'step') if Decimal(r.get('time')) < end)
    for original, current in itertools.zip_longest(reference_steps, elements(out/'summary.xml', 'step')):
        if original is None or current is None:
            summary_differences.append({'reason': 'step count differs'})
            break
        before = {k: v for k, v in original.attrib.items() if k != 'duration'}
        after = {k: v for k, v in current.attrib.items() if k != 'duration'}
        step_count += 1
        last_summary = dict(current.attrib)
        if before != after and len(summary_differences) < 10:
            summary_differences.append({'reference': before, 'recording': after})
    checks['all_prefix_traffic_summary_attributes_identical'] = not summary_differences
    checks['expected_native_step_count'] = step_count == end*10
    instant_differences, instant_count = [], 0
    reference_events = (r for r in elements(source/'instant-e1.xml', 'instantOut') if Decimal(r.get('time')) < end)
    actual_events = (r for r in elements(out/'instant-e1.xml', 'instantOut') if Decimal(r.get('time')) < end)
    for original, current in itertools.zip_longest(reference_events, actual_events):
        if original is None or current is None:
            instant_differences.append({'reason': 'event count differs'})
            break
        instant_count += 1
        if original.attrib != current.attrib and len(instant_differences) < 10:
            instant_differences.append({'reference': dict(original.attrib), 'recording': dict(current.attrib)})
    checks['all_prefix_instant_e1_attributes_identical'] = not instant_differences
    reference_vehicles = {v.get('id'): ET.canonicalize(ET.tostring(v, encoding='unicode'), strip_text=True)
        for v in elements(source/'vehicle-routes.xml', 'vehicle') if Decimal(v.get('arrival')) <= end}
    actual_vehicles = {v.get('id'): ET.canonicalize(ET.tostring(v, encoding='unicode'), strip_text=True)
        for v in elements(out/'vehicle-routes.xml', 'vehicle')}
    checks['all_arrived_prefix_vehicle_routes_and_exit_times_identical'] = actual_vehicles == reference_vehicles
    checks['zero_collisions'] = not ET.parse(out/'collisions.xml').getroot().findall('collision')
    reference_trips = {r.get('id'): ET.canonicalize(ET.tostring(r, encoding='unicode'), strip_text=True) for r in elements(source/'tripinfo.xml', 'tripinfo')}
    actual_trips = {r.get('id'): ET.canonicalize(ET.tostring(r, encoding='unicode'), strip_text=True) for r in elements(out/'tripinfo.xml', 'tripinfo')}
    checks['all_tripinfo_attributes_identical'] = reference_trips == actual_trips
    checks['zero_unsafe_summary'] = all(int(last_summary[k]) == 0 for k in ('collisions','teleports','discarded'))
    checks['source_raw_outputs_unchanged'] = preflight['source_output_hashes'] == {name: digest(source/name) for name in preflight['source_output_hashes']}
    monitor = json.loads((out/'stall-monitor.json').read_bytes())
    checks['driver_hold_report_identical'] = monitor.get('lane_section_hold') == source_monitor.get('lane_section_hold')
    checks['monitor_completed'] = monitor['status'] == 'completed' and monitor['simulation_time_s'] == end
    programs = ET.parse(source/'signal-programs.add.xml').getroot().findall('tlLogic')
    kinds = {r.get('id'): r.get('type') for r in programs}
    initial = {r.get('id'): dict(r.attrib) for r in elements(out/'tls-switch-states.xml', 'tlsState') if Decimal(r.get('time')) == 0}
    checks['all_50_tls_initialized_at_zero'] = initial.keys() == kinds.keys() and len(initial) == 50
    exported = None
    if True:
        exported_root = ET.parse(out/'tls-recorded-programs.add.xml').getroot()
        exported = exported_root.findall('tlLogic')
        checks['native_program_export_complete'] = exported_root.tag == 'additional' and len(exported) == 50 and {
            r.get('id') for r in exported} == kinds.keys() and all(r.get('type') == 'static' and sum(
                Decimal(p.get('duration')) for p in r.findall('phase')) == end for r in exported)
    widths = {}
    for con in ET.parse(out/'network.net.xml').getroot().findall('connection'):
        if con.get('tl'):
            widths[con.get('tl')] = max(widths.get(con.get('tl'), 0), int(con.get('linkIndex'))+1)
    checks['exact_50_tls_bindings'] = len(widths) == 50 and widths.keys() == kinds.keys()
    checks['unique_50_direct_programs'] = len(exported_root) == len(exported) == len({p.get('id') for p in exported}) == 50
    checks['every_export_state_width_bound'] = all(len(p.get('state')) == source_widths[t.get('id')] and Decimal(p.get('duration')) > 0 for t in exported for p in t.findall('phase')) and all(widths[identity] <= source_widths[identity] for identity in widths)
    checks['driver_inputs_and_output_paths_only'] = preflight['exact_command_rollback'] and preflight['no_hook_or_setter_added']
    # Compare the two native observers as color intervals, without inferring phase indices.
    def merge_colors(rows):
        merged = []
        for begin, finish, state in rows:
            if merged and merged[-1][1] == begin and merged[-1][2] == state:
                merged[-1] = (merged[-1][0], finish, state)
            else:
                merged.append((begin, finish, state))
        return merged
    state_events = {identity: [] for identity in kinds}
    for row in elements(out/'tls-switch-states.xml', 'tlsState'):
        if Decimal(row.get('time')) < end:
            state_events[row.get('id')].append((Decimal(row.get('time')), row.get('state')))
    observer_color_differences = []
    for program in exported:
        identity = program.get('id')
        events = state_events[identity]
        assert events and events[0][0] == 0 and all(len(state) == source_widths[identity] for _, state in events)
        actual = merge_colors([(begin, events[index+1][0] if index+1 < len(events) else Decimal(end), state)
                               for index, (begin, state) in enumerate(events)])
        program_time, rows = Decimal(0), []
        for phase in program.findall('phase'):
            finish = program_time + Decimal(phase.get('duration'))
            rows.append((program_time, finish, phase.get('state')))
            program_time = finish
        if merge_colors(rows) != actual:
            observer_color_differences.append(identity)
    checks['native_program_export_matches_switch_state_colors'] = not observer_color_differences
    result = {'status': 'pass' if all(checks.values()) else 'blocked', 'variant': variant, 'end_s': end,
        'elapsed_seconds': None, 'formal_result': False, 'checks': checks,
        'closed_e1_rows': len(actual_counts), 'summary_steps_checked': step_count,
        'instant_e1_events_checked': instant_count, 'arrived_routes_checked': len(actual_vehicles),
        'completion': last_summary, 'tls_types': kinds, 'summary_differences': summary_differences,
        'instant_e1_differences': instant_differences, 'source_hashes': hashes,
        'native_observer_color_difference_TLS': observer_color_differences,
        'state_log': {'path': str(out/'tls-switch-states.xml'), 'sha256': digest(out/'tls-switch-states.xml')},
        'program_export': {'path': str(out/'tls-recorded-programs.add.xml'),
                           'sha256': digest(out/'tls-recorded-programs.add.xml')} if exported is not None else None,
        'claim_boundary': 'Read-only native recording. Exact step colors/program can be reconstructed; phase is known only at emitted events. Same-state phase boundaries may be absent. SaveTLSProgram gives color durations, not the original phase-index history. No frozen replay or controller treatment was performed.'}
    (out/'record-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    result['elapsed_seconds_unavailable_reason'] = 'Original wall duration was overwritten by a Decimal program-time variable before JSON serialization.'
    result['native_reported_duration_s'] = native_duration
    (out/'record-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    return result

def inventory(path):
    return {str(p.resolve()): digest(p) for p in path.rglob('*') if p.is_file() and p.name != 'record-result.json'}


if __name__ == '__main__':
    out = ROOT/'reference'
    preflight = json.loads((out/'preflight.json').read_bytes())
    source = Path(preflight['source'])
    before_source, before_output = inventory(source), inventory(out)
    result = verify()
    unchanged = before_source == inventory(source) and before_output == inventory(out)
    recovery = {'schema': 'astra.hamburg.275-tls-postcheck-recovery/v1',
        'status': 'pass' if unchanged and result['status'] == 'pass' else 'blocked',
        'executed_script_sha256': EXECUTED_SHA, 'offline_postcheck_sha256': digest(Path(__file__)),
        'new_native_runs': 0, 'reason': 'The added color-audit loop shadowed float wall elapsed with Decimal program time; original native outputs completed, but original result serialization failed.',
        'fix': 'Recompute the original20 parity gates plus the native observer color gate offline. Use program_time for program accumulation and null for the lost wall duration.',
        'wall_elapsed_seconds': None, 'native_reported_duration_s': result['native_reported_duration_s'],
        'original_execution_error_log': {'path': str(out/'execution.log'), 'sha256': digest(out/'execution.log')},
        'source_and_existing_output_bytes_unchanged': unchanged,
        'source_file_hashes': before_source, 'existing_output_file_hashes': before_output,
        'record_result_sha256': digest(out/'record-result.json'),
        'checks_total': len(result['checks']), 'checks_passed': sum(result['checks'].values())}
    (ROOT/'postcheck-recovery.json').write_text(json.dumps(recovery, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': recovery['status'], 'checks': result['checks'], 'new_native_runs': 0,
                      'record_result_sha256': recovery['record_result_sha256']}))
    assert recovery['status'] == 'pass'
