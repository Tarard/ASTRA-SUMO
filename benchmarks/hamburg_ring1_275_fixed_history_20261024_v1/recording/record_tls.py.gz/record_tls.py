"""Record native TLS events with the original monitor and driver in one process."""
import argparse
from decimal import Decimal
import hashlib
import itertools
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import libsumo
import sumolib
import traci

from astra_sumo.core.simulation_stall import monitor_sumo


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASES = {'reference': (REPO/'outputs/hamburg-chronological-prefix-calibration-20261024-v1/cases/h4_counter_z11_minus5_z5/evaluation/native', 14400)}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def elements(path, tag):
    for _, row in ET.iterparse(path, events=('end',)):
        if row.tag == tag:
            yield row
            row.clear()


def main(variant, execute=False):
    label, end = CASES[variant]
    source = Path(label).resolve(strict=True)
    out = ROOT/variant
    assert not (out/'summary.xml').exists() and not (out/'record-result.json').exists(), 'Preserve existing native outputs.'
    out.mkdir(exist_ok=True)
    assert Path(sys.executable).resolve() == (REPO/'.venv/Scripts/python.exe').resolve()
    assert libsumo.__version__ == '1.27.1'
    module_paths = {name: str(Path(module.__file__).resolve()) for name, module in
                    (('libsumo', libsumo), ('traci', traci), ('sumolib', sumolib))}
    assert all(Path(path).is_relative_to((REPO/'.venv').resolve()) for path in module_paths.values()), module_paths
    assert all(version(name) == '1.27.1' for name in module_paths)
    source_programs = ET.parse(source/'signal-programs.add.xml').getroot().findall('tlLogic')
    source_widths = {row.get('id'): {len(phase.get('state')) for phase in row.findall('phase')} for row in source_programs}
    assert len(source_programs) == len(source_widths) == 50 and all(len(widths) == 1 for widths in source_widths.values())
    source_widths = {identity: next(iter(widths)) for identity, widths in source_widths.items()}
    source_bindings = {}
    for connection in ET.parse(source/'network.net.xml').getroot().findall('connection'):
        if connection.get('tl'):
            source_bindings.setdefault(connection.get('tl'), set()).add(int(connection.get('linkIndex')))
    assert source_bindings.keys() == source_widths.keys()
    assert all(0 <= index < source_widths[identity] for identity, indices in source_bindings.items() for index in indices)
    assert source_widths['266197525'] == 9 and source_bindings['266197525'] == {0, 1}
    names = ['network.net.xml', 'demand.rou.xml', 'signal-programs.add.xml', 'lane-intentions.json',
             'source-e1.add.xml', 'expected-counts.csv', 'e1.add.xml', 'instant.add.xml', 'native-request.json']
    hashes = {name: digest(source/name) for name in names}
    for name in names:
        shutil.copyfile(source/name, out/name)
    shutil.copyfile(Path(__file__), out/'record_tls.snapshot.py')
    for name in ('e1.add.xml', 'instant.add.xml'):
        tree = ET.parse(out/name)
        for row in tree.getroot():
            row.set('file', str(out/Path(row.get('file')).name))
            if row.tag == 'inductionLoop':
                row.set('end', str(end))
        tree.write(out/name, encoding='utf-8', xml_declaration=True)
    observer = ET.Element('additional')
    ET.SubElement(observer, 'timedEvent', type='SaveTLSSwitchStates', dest=str(out/'tls-switch-states.xml'))
    if True:
        ET.SubElement(observer, 'timedEvent', type='SaveTLSProgram', dest=str(out/'tls-recorded-programs.add.xml'))
    ET.ElementTree(observer).write(out/'tls-observer.add.xml', encoding='utf-8', xml_declaration=True)
    request = json.loads((source/'native-request.json').read_bytes())
    command = [part.replace(str(source), str(out)) for part in request['command']]
    command[command.index('--end')+1] = str(end)
    position = command.index('--additional-files')+1
    command[position] += ','+str(out/'tls-observer.add.xml')
    request.update(command=command, end_s=end, monitor_file=str(out/'stall-monitor.json'))
    for key in ('lane_intentions_file', 'route_file', 'e1_file'):
        request[key] = request[key].replace(str(source), str(out))
    assert request['backend'] == 'libsumo' and request['monitor_interval_s'] is None
    assert command[command.index('--step-length')+1] == '0.1'
    (out/'native-request.json').write_text(json.dumps(request, indent=2)+'\n', encoding='utf-8')
    preflight = {'variant': variant, 'source': str(source), 'end_s': end, 'source_hashes': hashes,
        'script_sha256': digest(out/'record_tls.snapshot.py'),
        'driver_hashes': {name: digest(REPO/'plugins/astra-sumo/src/astra_sumo/core'/name)
                         for name in ('simulation_stall.py', 'lane_section_hold.py')},
        'observer_sha256': digest(out/'tls-observer.add.xml'), 'formal_result': False,
        'actual_module_paths': module_paths, 'source_program_widths': source_widths,
        'source_max_bound_widths': {identity: max(indices)+1 for identity, indices in source_bindings.items()},
        'unbound_source_signal_bits': {identity: sorted(set(range(width))-source_bindings[identity])
                                       for identity, width in source_widths.items() if set(range(width)) != source_bindings[identity]}}
    (out/'preflight.json').write_text(json.dumps(preflight, indent=2)+'\n', encoding='utf-8')
    from libsumo import _libsumo
    monitor_module = sys.modules[monitor_sumo.__module__]
    source_monitor = json.loads((source/'stall-monitor.json').read_bytes())
    assert digest(Path(_libsumo.__file__)) == source_monitor['native_library']['sha256']
    assert request['junction_body_hold'] and request['junction_body_hold_nodes'] == ['14398547', '205069138', '18653534', 'LSA104_part0']
    assert end == 14400 and command[command.index('--seed')+1] == '104'
    assert not any('fcd' in part.lower() or 'load-state' in part for part in command)
    for name in ('simulation_stall.py', 'lane_section_hold.py'):
        assert (source.parents[1]/'measurement-implementation'/name).read_bytes() == (REPO/'plugins/astra-sumo/src/astra_sumo/core'/name).read_bytes()
    restored = [part.replace(str(out), str(source)) for part in command]
    restored[position] = restored[position].removesuffix(','+str(source/'tls-observer.add.xml'))
    assert restored == json.loads((source/'native-request.json').read_bytes())['command']
    preflight.update(native_library={'path': str(Path(_libsumo.__file__).resolve()), 'sha256': digest(Path(_libsumo.__file__))},
        actual_monitor_module={'path': str(Path(monitor_module.__file__).resolve()), 'sha256': digest(Path(monitor_module.__file__))},
        python={'path': sys.executable, 'sha256': digest(Path(sys.executable))},
        sumo_binary={'path': command[0], 'sha256': digest(Path(command[0]))},
        source_output_hashes={name: digest(source/name) for name in ('field-counts.xml','summary.xml','instant-e1.xml','vehicle-routes.xml','tripinfo.xml','collisions.xml','stall-monitor.json')},
        no_hook_or_setter_added=True, empty_start=True, no_fcd=True, exact_command_rollback=True)
    (out/'preflight.json').write_text(json.dumps(preflight, indent=2)+'\n', encoding='utf-8')
    if not execute:
        print(json.dumps({'status': 'prepared', 'variant': variant, 'native_runs': 0}), flush=True)
        return
    start = time.perf_counter()
    monitor_sumo(request)
    elapsed = time.perf_counter()-start
    checks = {'source_inputs_unchanged': hashes == {name: digest(source/name) for name in names},
        'network_demand_control_intentions_identical': all((out/name).read_bytes() == (source/name).read_bytes()
            for name in ('network.net.xml', 'demand.rou.xml', 'signal-programs.add.xml', 'lane-intentions.json', 'source-e1.add.xml'))}
    reference_counts = {(r.get('id'), r.get('begin'), r.get('end')): r.attrib
        for r in elements(source/'field-counts.xml', 'interval') if Decimal(r.get('end')) <= end}
    actual_counts = {(r.get('id'), r.get('begin'), r.get('end')): r.attrib
        for r in elements(out/'field-counts.xml', 'interval') if Decimal(r.get('begin')) < Decimal(r.get('end'))}
    checks['all_closed_e1_attributes_identical'] = actual_counts == reference_counts
    checks['expected_closed_e1_count'] = len(actual_counts) == 208
    summary_differences, last_summary, step_count = [], None, 0
    reference_steps = (r for r in elements(source/'summary.xml', 'step') if Decimal(r.get('time')) < end)
    for original, current in itertools.zip_longest(reference_steps, elements(out/'summary.xml', 'step')):
        if original is None or current is None:
            summary_differences.append({'reason': 'step count differs'})
            break
        before = {k: v for k, v in original.attrib.items() if k != 'duration'}
        after = {k: v for k, v in current.attrib.items() if k != 'duration'}
        step_count += 1
        last_summary = dict(current.attrib)
        if before != after and len(summary_differences) < 10:
            summary_differences.append({'reference': before, 'recording': after})
    checks['all_prefix_traffic_summary_attributes_identical'] = not summary_differences
    checks['expected_native_step_count'] = step_count == end*10
    instant_differences, instant_count = [], 0
    reference_events = (r for r in elements(source/'instant-e1.xml', 'instantOut') if Decimal(r.get('time')) < end)
    actual_events = (r for r in elements(out/'instant-e1.xml', 'instantOut') if Decimal(r.get('time')) < end)
    for original, current in itertools.zip_longest(reference_events, actual_events):
        if original is None or current is None:
            instant_differences.append({'reason': 'event count differs'})
            break
        instant_count += 1
        if original.attrib != current.attrib and len(instant_differences) < 10:
            instant_differences.append({'reference': dict(original.attrib), 'recording': dict(current.attrib)})
    checks['all_prefix_instant_e1_attributes_identical'] = not instant_differences
    reference_vehicles = {v.get('id'): ET.canonicalize(ET.tostring(v, encoding='unicode'), strip_text=True)
        for v in elements(source/'vehicle-routes.xml', 'vehicle') if Decimal(v.get('arrival')) <= end}
    actual_vehicles = {v.get('id'): ET.canonicalize(ET.tostring(v, encoding='unicode'), strip_text=True)
        for v in elements(out/'vehicle-routes.xml', 'vehicle')}
    checks['all_arrived_prefix_vehicle_routes_and_exit_times_identical'] = actual_vehicles == reference_vehicles
    checks['zero_collisions'] = not ET.parse(out/'collisions.xml').getroot().findall('collision')
    reference_trips = {r.get('id'): ET.canonicalize(ET.tostring(r, encoding='unicode'), strip_text=True) for r in elements(source/'tripinfo.xml', 'tripinfo')}
    actual_trips = {r.get('id'): ET.canonicalize(ET.tostring(r, encoding='unicode'), strip_text=True) for r in elements(out/'tripinfo.xml', 'tripinfo')}
    checks['all_tripinfo_attributes_identical'] = reference_trips == actual_trips
    checks['zero_unsafe_summary'] = all(int(last_summary[k]) == 0 for k in ('collisions','teleports','discarded'))
    checks['source_raw_outputs_unchanged'] = preflight['source_output_hashes'] == {name: digest(source/name) for name in preflight['source_output_hashes']}
    monitor = json.loads((out/'stall-monitor.json').read_bytes())
    checks['driver_hold_report_identical'] = monitor.get('lane_section_hold') == source_monitor.get('lane_section_hold')
    checks['monitor_completed'] = monitor['status'] == 'completed' and monitor['simulation_time_s'] == end
    programs = ET.parse(source/'signal-programs.add.xml').getroot().findall('tlLogic')
    kinds = {r.get('id'): r.get('type') for r in programs}
    initial = {r.get('id'): dict(r.attrib) for r in elements(out/'tls-switch-states.xml', 'tlsState') if Decimal(r.get('time')) == 0}
    checks['all_50_tls_initialized_at_zero'] = initial.keys() == kinds.keys() and len(initial) == 50
    exported = None
    if True:
        exported_root = ET.parse(out/'tls-recorded-programs.add.xml').getroot()
        exported = exported_root.findall('tlLogic')
        checks['native_program_export_complete'] = exported_root.tag == 'additional' and len(exported) == 50 and {
            r.get('id') for r in exported} == kinds.keys() and all(r.get('type') == 'static' and sum(
                Decimal(p.get('duration')) for p in r.findall('phase')) == end for r in exported)
    widths = {}
    for con in ET.parse(out/'network.net.xml').getroot().findall('connection'):
        if con.get('tl'):
            widths[con.get('tl')] = max(widths.get(con.get('tl'), 0), int(con.get('linkIndex'))+1)
    checks['exact_50_tls_bindings'] = len(widths) == 50 and widths.keys() == kinds.keys()
    checks['unique_50_direct_programs'] = len(exported_root) == len(exported) == len({p.get('id') for p in exported}) == 50
    checks['every_export_state_width_bound'] = all(len(p.get('state')) == source_widths[t.get('id')] and Decimal(p.get('duration')) > 0 for t in exported for p in t.findall('phase')) and all(widths[identity] <= source_widths[identity] for identity in widths)
    checks['driver_inputs_and_output_paths_only'] = preflight['exact_command_rollback'] and preflight['no_hook_or_setter_added']
    # Compare the two native observers as color intervals, without inferring phase indices.
    def merge_colors(rows):
        merged = []
        for begin, finish, state in rows:
            if merged and merged[-1][1] == begin and merged[-1][2] == state:
                merged[-1] = (merged[-1][0], finish, state)
            else:
                merged.append((begin, finish, state))
        return merged
    state_events = {identity: [] for identity in kinds}
    for row in elements(out/'tls-switch-states.xml', 'tlsState'):
        if Decimal(row.get('time')) < end:
            state_events[row.get('id')].append((Decimal(row.get('time')), row.get('state')))
    observer_color_differences = []
    for program in exported:
        identity = program.get('id')
        events = state_events[identity]
        assert events and events[0][0] == 0 and all(len(state) == source_widths[identity] for _, state in events)
        actual = merge_colors([(begin, events[index+1][0] if index+1 < len(events) else Decimal(end), state)
                               for index, (begin, state) in enumerate(events)])
        elapsed, rows = Decimal(0), []
        for phase in program.findall('phase'):
            finish = elapsed + Decimal(phase.get('duration'))
            rows.append((elapsed, finish, phase.get('state')))
            elapsed = finish
        if merge_colors(rows) != actual:
            observer_color_differences.append(identity)
    checks['native_program_export_matches_switch_state_colors'] = not observer_color_differences
    result = {'status': 'pass' if all(checks.values()) else 'blocked', 'variant': variant, 'end_s': end,
        'elapsed_seconds': elapsed, 'formal_result': False, 'checks': checks,
        'closed_e1_rows': len(actual_counts), 'summary_steps_checked': step_count,
        'instant_e1_events_checked': instant_count, 'arrived_routes_checked': len(actual_vehicles),
        'completion': last_summary, 'tls_types': kinds, 'summary_differences': summary_differences,
        'instant_e1_differences': instant_differences, 'source_hashes': hashes,
        'native_observer_color_difference_TLS': observer_color_differences,
        'state_log': {'path': str(out/'tls-switch-states.xml'), 'sha256': digest(out/'tls-switch-states.xml')},
        'program_export': {'path': str(out/'tls-recorded-programs.add.xml'),
                           'sha256': digest(out/'tls-recorded-programs.add.xml')} if exported is not None else None,
        'claim_boundary': 'Read-only native recording. Exact step colors/program can be reconstructed; phase is known only at emitted events. Same-state phase boundaries may be absent. SaveTLSProgram gives color durations, not the original phase-index history. No frozen replay or controller treatment was performed.'}
    (out/'record-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'variant': variant, 'elapsed_seconds': elapsed, 'checks': checks}), flush=True)
    assert all(checks.values()), checks


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant', choices=CASES, required=True)
    parser.add_argument('--run', action='store_true', help='Explicitly run the planned read-only replay once; omission only prepares.')
    args = parser.parse_args()
    main(args.variant, args.run)
