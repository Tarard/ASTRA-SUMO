"""Apply the existing substitution audit to the one observed-service pair."""

import argparse
import json
from pathlib import Path
import sys


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
PREVIOUS = STUDY.parent / "hamburg-multifield-substitution-20261023-v1"
sys.path.insert(0, str(PREVIOUS / "response-audit"))
import audit_scope as scope  # noqa: E402

scope.OUT, scope.STUDY = OUT, STUDY
import audit_response as audit  # noqa: E402
from summarize_response import backlog  # noqa: E402


def seal():
    audit.save(OUT / "manifest.json", {"native_runs": 0, "files": [
        {"path": p.relative_to(OUT).as_posix(), "size_bytes": p.stat().st_size, "sha256": scope.digest(p)}
        for p in sorted(OUT.rglob("*")) if p.is_file() and p != OUT / "manifest.json" and "__pycache__" not in p.parts]})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scope-only", action="store_true")
    args = parser.parse_args()
    inspected = scope.inspect_scope(1)
    audit.save(OUT / "input-scope-review.json", inspected)
    helper_hashes = {str(PREVIOUS / "response-audit" / name): scope.digest(PREVIOUS / "response-audit" / name)
                     for name in ["audit_scope.py", "audit_response.py", "summarize_response.py"]}
    audit.save(OUT / "reused-analysis-implementation.json", {"source_helpers": helper_hashes,
        "scope": "Only bind analysis output/study directory to this one case. No source implementation or measure.py changes."})
    if args.scope_only:
        seal()
        print(json.dumps({"status": "pass", "scope_only": True, "candidate_N": inspected["candidate_N"],
            "actual14bin_inventory_equal": inspected["actual14bin_signature_inventory_equal"],
            "first_changed_departure_s": inspected["first_changed_requested_departure_s"]}, indent=2))
        return
    case = STUDY / "substitute-1pair"
    if not (case / "verdict.json").exists():
        print(json.dumps({"status": "review_required", "reason": "No complete verdict seal; native output not read"}))
        return
    compact = scope.SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz"
    baseline = audit.evidence(scope.BASE, scope.SOURCE, compact, 8640)
    output = OUT / "complete"
    result = audit.compare_case(1, baseline, output / "substitute-1pair")
    previous_case = PREVIOUS / "substitute-1pair"
    previous = audit.evidence(previous_case / "prepared", previous_case / "evaluation",
                              previous_case / "evaluation/contributing-passages.json.gz", 8639)
    current_rows = audit.read_csv_rows(output / "substitute-1pair/cohort-delta208.csv")
    previous_delta = [{"field": r["field"], "begin": float(r["begin"]), "end": float(r["end"]), "region": r["region"],
        "previous_nearest_time_1pair": int(previous["periodic"][r["field"], float(r["begin"]), float(r["end"])]["nVehContrib"]),
        "new_service_pair": int(r["candidate_count"]), "delta": int(r["candidate_count"]) - int(previous["periodic"][r["field"], float(r["begin"]), float(r["end"])]["nVehContrib"])}
        for r in current_rows]
    audit.table(output / "previous-1pair-delta208.csv", previous_delta)
    signatures = json.loads((case / "preflight.json").read_bytes())["signatures"]
    terminal, groups = backlog(case / "evaluation", signatures)
    audit.table(output / "terminal-vehicles.csv", terminal)
    focal = audit.read_csv_rows(output / "substitute-1pair/modified-trips.csv")[0]
    old_focal = audit.read_csv_rows(PREVIOUS / "response-audit/complete/substitute-1pair/modified-trips.csv")[0]
    summary = {"schema": "astra.hamburg.multifield-service-pair-response/v1", "status": "pass", "native_runs": 0, "reference": {k: baseline[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion"]},
        "previous_nearest_time_1pair": {k: previous[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion"]},
        "new_service_pair": result,
        "change_from_previous_1pair": {"SSE": result["metrics130"]["SSE"] - previous["metrics130"]["SSE"],
            "TAE": result["metrics130"]["TAE"] - previous["metrics130"]["TAE"],
            "MAE": result["metrics130"]["MAE"] - previous["metrics130"]["MAE"],
            "waiting": result["completion"]["waiting"] - previous["completion"]["waiting"],
            "running": result["completion"]["running"] - previous["completion"]["running"]},
        "focal_new_actual_events": json.loads(focal["candidate_retained_events"]),
        "focal_previous_1pair_actual_events": json.loads(old_focal["candidate_retained_events"]),
        "terminal_groups": groups, "source_helpers": helper_hashes,
        "claim_boundary": "One observed service-leader pairing compared with the original selected reference and the prior nearest-time pairing. Complete raw counts and coupled cohort differences are not a causal separation or evidence of true OD. Source-control review does not authorize changing controls."}
    audit.save(output / "scan.json", summary)
    audit.save(output / "manifest.json", {"native_runs": 0, "files": [
        {"path": p.relative_to(output).as_posix(), "size_bytes": p.stat().st_size, "sha256": scope.digest(p)}
        for p in sorted(output.rglob("*")) if p.is_file() and p != output / "manifest.json"]})
    seal()
    print(json.dumps({k: v for k, v in summary.items() if k not in ["source_helpers", "claim_boundary", "terminal_groups"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
