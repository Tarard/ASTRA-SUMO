# 观测服务前车配对的独立核对

本项保留`od_0266_v00020`，改为省去原左转队列前车`od_0271_v00019`的出发请求。来源仍是原selected，不叠加前一次1对。两车真实出发窗均为h12；字段计划库存不变，N为8639。`input-scope-review.json`已独立验证全部14×字段库存、所有存活车辆属性、8638辆未改车辆XML、原前缀和新witness尾段，以及不变的网络、控制、检测点和真实targets。没有修改运行中的脚本或输入。

`audit_service_pair.py`是现有substitution离线核对函数的一次薄调用，不复制计数或配对算法。所用三个分析实现的哈希保留在`reused-analysis-implementation.json`。`--scope-only`只读取已准备输入，不读正在写的原生文件。

主任务通知verdict完成后，从仓库根目录单次执行：

```powershell
$env:PYTHONUTF8 = '1'
$env:PYTHONPATH = "$PWD/plugins/astra-sumo/src"
.venv/Scripts/python.exe outputs/hamburg-multifield-service-pair-20261023-v1/response-audit/audit_service_pair.py
```

没有verdict时不读取候选原生输出。封口后，`complete/scan.json`分列原selected、前一次近时1对、本次服务配对及两种差值，不把前一次1对当成输入来源。130/52/182/208、40派生站点、真实双字段事件、全部车辆群记账、安全、重复、意外字段、prefix全部属性和终态积压沿用已核逻辑。

`complete/substitute-1pair/`保留相对selected的完整细表。`previous-1pair-delta208.csv`另给相对前一次1对的原生逐字段/窗变化。`terminal-vehicles.csv`只按请求入口、意向字段和实际完整事件分组，不推断最终排队道路。

这次只检验需求配对。多字段支持和控制来源审查均不授权改变控制。车辆群差异是完整运行的记账，不能当作因果分离，也不确认真实OD或服务替代关系。原选择条件保持：SSE和MAE均严格优于selected、等待不超过7、总等待加在途不超过21，以及安全和实际双字段完成等条件。
