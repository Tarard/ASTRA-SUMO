"""Retain exact native row equality, event identities and terminal inventory."""

from collections import Counter, defaultdict
import gzip
import json
import xml.etree.ElementTree as ET

from audit_service_pair import OUT, STUDY, audit, scope, seal


def periodic(path):
    return {(r.get("id"), float(r.get("begin")), float(r.get("end"))): dict(r.attrib)
            for r in ET.parse(path).getroot().findall("interval")}


def terminal(evaluation, signatures):
    vehicles = {v.get("id"): v for v in ET.parse(evaluation / "demand.rou.xml").getroot().findall("vehicle")}
    trips = {t.get("id"): t for t in ET.parse(evaluation / "native/tripinfo.xml").getroot().findall("tripinfo")}
    return {identity: {"state": "not_inserted" if identity not in trips else "running",
                      "requested_origin": v.find("route").get("edges").split()[0], "intended_fields": signatures[identity]}
            for identity, v in vehicles.items() if identity not in trips or float(trips[identity].get("arrival")) < 0}


def main():
    output = OUT / "complete"
    evaluation = STUDY / "substitute-1pair/evaluation"
    source_periodic = periodic(scope.SOURCE / "native/field-counts.xml")
    new_periodic = periodic(evaluation / "native/field-counts.xml")
    assert source_periodic.keys() == new_periodic.keys() and len(new_periodic) == 208
    source_rows = audit.read_csv_rows(scope.BASE / "expected-counts.csv")
    initial_rows = audit.read_csv_rows(scope.BASE / "initialization-counts.csv")
    groups = {"main130": {audit.key(r) for r in source_rows}, "initial52": {audit.key(r) for r in initial_rows},
              "all182": {audit.key(r) for r in source_rows + initial_rows}, "native208": set(new_periodic)}
    equality = {name: {"rows": len(keys), "nVehContrib_differences": [k for k in sorted(keys)
        if source_periodic[k]["nVehContrib"] != new_periodic[k]["nVehContrib"]]} for name, keys in groups.items()}
    assert all(not value["nVehContrib_differences"] for value in equality.values())
    other_differences = [{"field": k[0], "begin": k[1], "end": k[2], "attribute_changes": {
        name: {"reference": source_periodic[k].get(name), "candidate": new_periodic[k].get(name)}
        for name in set(source_periodic[k]) | set(new_periodic[k]) if source_periodic[k].get(name) != new_periodic[k].get(name)}}
        for k in sorted(new_periodic) if source_periodic[k] != new_periodic[k]]
    source_stations = {(r["station_stream_id"], float(r["begin"]), float(r["end"])): r
                       for r in audit.read_csv_rows(scope.SOURCE / "station-comparison.csv")}
    new_stations = audit.read_csv_rows(output / "substitute-1pair/stations-comparison.csv")
    assert len(new_stations) == 40 and all(all(int(source_stations[r["station_stream_id"], float(r["begin"]), float(r["end"])][name]) == int(r[name])
        for name in ["expected_total", "measured_nVehContrib", "residual"]) for r in new_stations)
    original_signatures = {r["vehicle_id"]: [r["field_id"]] for r in json.loads((scope.SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    current_signatures = json.loads((STUDY / "substitute-1pair/preflight.json").read_bytes())["signatures"]
    before_terminal, after_terminal = terminal(scope.SOURCE, original_signatures), terminal(evaluation, current_signatures)
    assert before_terminal == after_terminal and len(after_terminal) == 21
    event_stats = []
    for label, path in [("reference", scope.SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz"),
                        ("service_pair", evaluation / "contributing-passages.json.gz")]:
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            compact = json.load(handle)
        events = defaultdict(list)
        for event in compact["passages"]:
            events[event["vehicle_id"]].append(event)
        event_stats.append({"case": label, "complete_events": len(compact["passages"]), "unique_complete_vehicles": len(events),
                           "complete_fields_per_vehicle": dict(Counter(len(rows) for rows in events.values()))})
    assert event_stats[0]["complete_events"] == event_stats[1]["complete_events"] == 8626
    timing_rows = audit.read_csv_rows(output / "substitute-1pair/unchanged-trip-responses.csv")
    focal = audit.read_csv_rows(output / "substitute-1pair/modified-trips.csv")[0]
    focal119, focal535 = json.loads(focal["candidate_retained_events"])
    removed535 = json.loads(focal["source_removed_events"])[0]
    timing = []
    for r in timing_rows:
        old, new = json.loads(r["source_events"])[0], json.loads(r["candidate_events"])[0]
        assert old["field"] == new["field"] and old["begin"] == new["begin"]
        timing.append({"vehicle_id": r["vehicle_id"], "field": old["field"], "bin": old["begin"],
                       "reference_notification_s": old["notification_s"], "candidate_notification_s": new["notification_s"],
                       "shift_s": new["notification_s"] - old["notification_s"]})
    audit.table(output / "four-unchanged-event-time-shifts.csv", timing)
    audit.table(output / "terminal-reference-candidate-identical.csv", [{"vehicle_id": identity, **row} for identity, row in sorted(after_terminal.items())])
    proof = {"schema": "astra.hamburg.native-count-vector-equality/v1", "status": "pass", "new_native_runs": 0,
        "exact_row_count_equality": equality, "all40_derived_count_rows_identical": True,
        "other_E1_attribute_differences": other_differences, "complete_event_stats": event_stats,
        "same_terminal_vehicle_ID_state_origin_and_intended_fields": True, "terminal_count": 21,
        "terminal_state_counts": dict(Counter(r["state"] for r in after_terminal.values())),
        "terminal_origins": dict(Counter(r["requested_origin"] for r in after_terminal.values())),
        "focal119_s": focal119["notification_s"], "focal535_s": focal535["notification_s"], "removed_source_leader535_s": removed535["notification_s"],
        "focal535_later_than_removed_leader_s": focal535["notification_s"] - removed535["notification_s"],
        "focal535_change_from_previous1pair_s": focal535["notification_s"] - json.loads((output / "scan.json").read_bytes())["focal_previous_1pair_actual_events"][1]["notification_s"],
        "unchanged_complete_event_field_bin_changes": 0, "unchanged_event_time_change_count": len(timing),
        "source_hashes": {str(p): scope.digest(p) for p in [scope.SOURCE / "native/field-counts.xml",
            scope.SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz",
            evaluation / "native/field-counts.xml", evaluation / "contributing-passages.json.gz"]},
        "claim_boundary": "These two explicit demand/route inputs have different trip counts and exactly the same observed native count vector for one fixed seed/control/driver treatment. This is an empirical non-injective observation example in the expanded explicit route support, not identification of true OD or proof about every parameter in the original 21-OD model. Other E1 attributes and event identities/times differ; full simulation equivalence and fit improvement are not claimed."}
    audit.save(output / "exact-count-equality-proof.json", proof)
    scan = json.loads((output / "scan.json").read_bytes())
    scan["schema"] = "astra.hamburg.multifield-service-pair-response/v1"
    audit.save(output / "scan.json", scan)
    audit.save(output / "manifest.json", {"native_runs": 0, "files": [
        {"path": p.relative_to(output).as_posix(), "size_bytes": p.stat().st_size, "sha256": scope.digest(p)}
        for p in sorted(output.rglob("*")) if p.is_file() and p != output / "manifest.json"]})
    seal()
    print(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
