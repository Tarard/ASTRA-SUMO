"""Prepare one existing legal lane-template share change; no simulation."""

from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
DONOR, WITNESS = "od_0209_v00026", "od_0209_v00027"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prepare():
    case, source = ROOT / "one-share", SOURCE / "prepared"
    assert not case.exists(), "Preserve earlier candidates."
    old = ET.parse(source / "demand.rou.xml").getroot()
    original = {v.get("id"): v for v in old.findall("vehicle")}
    donor, witness = original[DONOR], original[WITNESS]
    def attributes(vehicle):
        return {k: x for k, x in vehicle.attrib.items() if k not in {"id", "depart"}}
    assert attributes(donor) == attributes(witness)
    assert donor.find("route").attrib == witness.find("route").attrib
    assert len(donor.find("route").get("edges").split()) == 19
    assert float(donor.get("depart")) >= 3600
    ds, ws = donor.findall("stop"), witness.findall("stop")
    assert len(ds) == len(ws) == 1
    assert ds[0].get("lane") == "24483344#1_0" and ws[0].get("lane") == "24483344#1_1"
    assert {k: v for k, v in ds[0].attrib.items() if k != "lane"} == {
        k: v for k, v in ws[0].attrib.items() if k != "lane"}
    new = deepcopy(old)
    generated = {v.get("id"): v for v in new.findall("vehicle")}
    generated[DONOR].find("stop").set("lane", ws[0].get("lane"))
    old_intents = json.loads((source / "lane-intentions.json").read_bytes())
    new_intents = deepcopy(old_intents)
    before = {r["vehicle_id"]: r for r in old_intents["vehicles"]}
    after = {r["vehicle_id"]: r for r in new_intents["vehicles"]}
    assert before[DONOR]["field_id"] == "hh_0119_Z_4_29437"
    assert before[WITNESS]["field_id"] == "hh_0119_Z_5_30494"
    after[DONOR]["field_id"] = before[WITNESS]["field_id"]
    assert len(original) == len(generated) == len(before) == len(after) == 8640
    assert original.keys() == generated.keys() == before.keys() == after.keys()
    assert all(ET.tostring(original[i]) == ET.tostring(generated[i]) and before[i] == after[i]
               for i in original if i != DONOR)
    restored = deepcopy(generated[DONOR])
    restored.find("stop").set("lane", ds[0].get("lane"))
    assert ET.tostring(restored) == ET.tostring(donor)
    assert before[DONOR] | {"field_id": before[WITNESS]["field_id"]} == after[DONOR]
    assert [v.get("id") for v in old.findall("vehicle")] == [v.get("id") for v in new.findall("vehicle")]
    assert [ET.tostring(r) for r in old if r.tag != "vehicle"] == [ET.tostring(r) for r in new if r.tag != "vehicle"]
    totals = Counter(r["field_id"] for r in new_intents["vehicles"])
    assert totals["hh_0119_Z_4_29437"] == 760 and totals["hh_0119_Z_5_30494"] == 624
    prepared = case / "prepared"
    prepared.mkdir(parents=True)
    names = ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv",
             "initialization-counts.csv", "scenario.json", "demand.rou.xml", "lane-intentions.json")
    for name in names:
        shutil.copyfile(source / name, prepared / name)
    ET.ElementTree(new).write(prepared / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    save(prepared / "lane-intentions.json", new_intents)
    counts = Counter(r["od_cell"] for r in after.values())
    assert counts == Counter(r["od_cell"] for r in before.values()) and set(counts) == set(range(294))
    save(case / "od-vector.json", {"values": [counts[i] for i in range(294)],
         "integer_counts": [counts[i] for i in range(294)], "vehicle_count": 8640,
         "source": "Unchanged current explicit OD inventory; field share only, no quantile regeneration."})
    change = {"vehicle_id": DONOR, "witness_id": WITNESS, "depart_s": float(donor.get("depart")),
              "stop_lane_before": ds[0].get("lane"), "stop_lane_after": ws[0].get("lane"),
              "field_before": before[DONOR]["field_id"], "field_after": after[DONOR]["field_id"],
              "unchanged_vehicles": 8639, "all_departures_and_routes_unchanged": True,
              "all294_OD_counts_unchanged": True, "planned_field_totals": dict(totals)}
    save(case / "generation-audit.json", change)
    save(case / "scope-proof.json", {"status": "pass", "N": 8640, "formal_result": False,
         "actual_changes": 1, "demand_generation_changes": change,
         "source_hashes": {str(p.resolve()): sha(p) for p in [*(source / n for n in names), Path(__file__)]},
         "prepared_hashes": {p.name: sha(p) for p in prepared.iterdir()},
         "original_driver_scope": _body_hold_nodes(prepared),
         "claim_boundary": "One existing legal lane template changes the planned field share. It removes a necessary quantity shortfall only. Native count fit, actual changed-vehicle passage and completion remain unmeasured."})
    shutil.copyfile(__file__, case / "executed-prepare.py")
    print(json.dumps({"status": "prepared", "native_runs": 0, "changed_vehicles": 1,
                      "all_departures_unchanged": True, "Z4": 760, "Z5": 624}))


if __name__ == "__main__":
    prepare()
