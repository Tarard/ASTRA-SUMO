"""Check a necessary count-capacity bound under fixed field membership."""

from collections import Counter
import csv
import gzip
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"


def main():
    prepared, native = SOURCE / "prepared", SOURCE / "evaluation/native"
    intent = {r["vehicle_id"]: r["field_id"] for r in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
    planned = Counter(intent.values())
    periodic = {(r.get("id"), float(r.get("begin")), float(r.get("end"))): int(r.get("nVehContrib"))
                for r in ET.parse(native / "field-counts.xml").getroot()}
    init_target, init_actual, main_target, main_actual = Counter(), Counter(), Counter(), Counter()
    for name, target, measured in (("initialization-counts.csv", init_target, init_actual),
                                    ("expected-counts.csv", main_target, main_actual)):
        for r in csv.DictReader((prepared / name).open(encoding="utf-8", newline="")):
            field = r["detector_id"]
            target[field] += int(r["expected_total"])
            measured[field] += periodic[field, float(r["begin"]), float(r["end"])]
    compact_path = SOURCE / "evaluation/contributing-passages.json.gz"
    compact = json.loads(gzip.decompress(compact_path.read_bytes()))
    visits = Counter(e["vehicle_id"] for e in compact["passages"])
    assert len(visits) == len(compact["passages"]) == len(intent) == 8640
    assert max(visits.values()) == 1 and all(e["detector_id"] == intent[e["vehicle_id"]] for e in compact["passages"])
    rows = [dict(field=f, planned_total=planned[f], real_initial_target=init_target[f],
                 actual_fixed_initial_count=init_actual[f], real_main_target=main_target[f],
                 current_actual_main_count=main_actual[f],
                 conditional_main_capacity=planned[f]-init_actual[f],
                 conditional_main_TAE_lower_bound=max(0, main_target[f]-planned[f]+init_actual[f]))
            for f in sorted(planned)]
    assert len(rows) == 13
    lower = sum(r["conditional_main_TAE_lower_bound"] for r in rows)
    assert lower == 1 and next(r for r in rows if r["conditional_main_TAE_lower_bound"])["field"] == "hh_0119_Z_5_30494"
    with (ROOT / "fields13.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    result = dict(status="pass", native_runs=0, formal_result=False, main130_TAE_lower_bound=lower,
        main130_MAE_lower_bound=lower/130, rows=rows,
        conditions=["Every vehicle retains its assigned field and contributes to it at most once in the horizon.",
                    "Pre3600 request traffic and its actual initial field counts remain fixed.",
                    "No added vehicles, duplicate field contributions or reassignment to another field."],
        baseline_native_check=dict(requests=8640, complete_events=8640, unique_vehicles=8640,
                                   maximum_contributions_per_vehicle=1, contributions_outside_intention=0),
        formula="main_capacity_f = planned_total_f - actual_fixed_initial_f; L1 >= sum_f max(0, main_target_f-main_capacity_f)",
        source_hashes={str(p): sha(p) for p in (prepared / "lane-intentions.json", prepared / "demand.rou.xml",
            prepared / "initialization-counts.csv", prepared / "expected-counts.csv", native / "field-counts.xml", compact_path)},
        claim_boundary="Necessary condition only for this fixed-field-total realization with fixed initialization and at most one contribution per vehicle. It is not a contradiction in observed truth or a proof that the overall task cannot reach zero. Legal OD/lane-field share changes can alter these planned totals; the bound does not explain the other residuals.")
    (ROOT / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(dict(status="pass", lower_bound=lower, native_runs=0)))


if __name__ == "__main__":
    main()
