"""Trace13 planned field inventories through the four frozen classical probes."""

from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
FROZEN = REPO / "benchmarks/hamburg_ring1_classical_od_response_20261023_v1"
HEALTHY = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/prepared"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    manifest = {r["path"]: r["sha256"] for r in json.loads((FROZEN / "manifest.json").read_bytes())["files"]}
    sources = {}

    def read(name):
        path = FROZEN / name
        raw = path.read_bytes()
        assert digest(raw) == manifest[name]
        payload = gzip.decompress(raw) if name.endswith(".gz") else raw
        sources[name] = dict(path=str(path), compressed_sha256=digest(raw), payload_sha256=digest(payload))
        return payload

    model = json.loads(read("prepared/od-model.json.gz"))
    q0 = json.loads(read("prepared/initial-od-vector.json.gz"))["values"]
    initial = json.loads(read("prepared/lane-intentions.json.gz"))
    inventories = {"initial": Counter(r["field_id"] for r in initial["vehicles"])}
    assert inventories["initial"] == Counter(t["prior_field_intention"] for c in model["cells"] for t in c["templates"])
    runs = ("probe-plus6", "probe-minus6", "probe-plus1", "probe-minus1")
    vector_changes, vectors, intentions = {}, {}, {}
    for run in runs:
        vector = json.loads(read(run + "/evaluation/od-vector.json.gz"))["integer_counts"]
        intentions[run] = json.loads(read(run + "/evaluation/lane-intentions.json.gz"))
        inventories[run] = Counter(r["field_id"] for r in intentions[run]["vehicles"])
        vectors[run] = vector
        vector_changes[run] = [dict(cell=i, initial=int(a), changed=int(b)) for i, (a, b) in enumerate(zip(q0, vector)) if a != b]
        assert len(vector) == 294 and sum(vector) == 8640
    healthy_raw = (HEALTHY / "lane-intentions.json").read_bytes()
    healthy = json.loads(healthy_raw)
    inventories["healthy"] = Counter(r["field_id"] for r in healthy["vehicles"])
    field_rows = [dict(field=f, **{name.replace("-", "_"): inventory[f] for name, inventory in inventories.items()})
                  for f in sorted(inventories["initial"])]
    with (ROOT / "fields13-lineage.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(field_rows[0]))
        writer.writeheader()
        writer.writerows(field_rows)
    changes = []
    for index in (125, 146):
        cell, count = model["cells"][index], vectors["probe-minus1"][index]
        selected = Counter(min(len(cell["templates"])-1, int(((i+.5)/count)*len(cell["templates"]))) for i in range(count))
        repeated = [dict(rank=i, copies=n, original_vehicle_id=cell["templates"][i]["prior_vehicle_id"],
                         field=cell["templates"][i]["prior_field_intention"]) for i, n in selected.items() if n > 1]
        omitted = [dict(rank=i, original_vehicle_id=t["prior_vehicle_id"], field=t["prior_field_intention"])
                   for i, t in enumerate(cell["templates"]) if i not in selected]
        actual = Counter(r["field_id"] for r in intentions["probe-minus1"]["vehicles"] if r["od_cell"] == index)
        derived = Counter()
        for rank, copies in selected.items():
            derived[cell["templates"][rank]["prior_field_intention"]] += copies
        assert derived == actual
        changes.append(dict(cell=index, origin=cell["origin"], destination=cell["destination"],
                            begin_s=cell["begin_s"], end_s=cell["end_s"], prior_count=cell["initial_flow"],
                            changed_count=count, repeated_ranks=repeated, omitted_ranks=omitted,
                            initial_fields=dict(Counter(t["prior_field_intention"] for t in cell["templates"])),
                            changed_fields=dict(actual)))
    minus_demand = read("probe-minus1/evaluation/demand.rou.xml.gz")
    minus_intent = read("probe-minus1/evaluation/lane-intentions.json.gz")
    assert minus_demand == (HEALTHY / "demand.rou.xml").read_bytes() and minus_intent == healthy_raw
    q_healthy = Counter(r["od_cell"] for r in healthy["vehicles"])
    assert [q_healthy[i] for i in range(294)] == vectors["probe-minus1"]
    code = "probe-minus1/code-source/hamburg_od_spsa.py.gz"
    read(code)
    result = dict(status="pass", native_runs=0, formal_result=False,
        reviewed_chain=["model256472/prepared initial", *runs, "current healthy full-priority"],
        first761_623_in_reviewed_frozen_chain="probe-minus1/evaluation",
        model_sha256=sources["prepared/od-model.json.gz"]["payload_sha256"],
        field_inventory_rows=field_rows, q_changes=vector_changes, rank_mechanism=changes,
        healthy_equals_frozen_minus1=dict(demand_rawbytes=True, intentions_rawbytes=True, all294_counts=True,
            demand_sha256=digest(minus_demand), intentions_sha256=digest(minus_intent)),
        sources=sources, frozen_manifest_sha256=digest((FROZEN / "manifest.json").read_bytes()),
        source_scope="Only model256472, its frozen initial demand and the four classical probes were reviewed; no broad historical scan.",
        claim_boundary="The quantile policy introduced +1Z4/-1Z5 in the native-improving minus1 proposal. Locking that field prior for later pure retiming creates the conditional zero-error barrier. This is not a SUMO count bug, not the cause of all MAE, and not a claim that the historical minus1 study had completed calibration.")
    (ROOT / "lineage.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(dict(status="pass", first="probe-minus1", model=result["model_sha256"],
                         current_input_equals_minus1=True)))


if __name__ == "__main__":
    main()
