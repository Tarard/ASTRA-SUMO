"""Audit a sealed single-lane share response; never launch a native process."""

from collections import Counter
import gzip
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from inspect_input import CASE, DONOR, OUT, REPO, SOURCE, STUDY, Z5, digest, inspect

HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPERS))
import audit_response as audit  # noqa: E402
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages  # noqa: E402

FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def main():
    assert (CASE / "verdict.json").exists(), "Read only completed native results."
    verdict = json.loads((CASE / "verdict.json").read_bytes())
    assert verdict["native_response_measured"] and verdict["status"] != "invalid"
    scope = inspect()
    preflight = json.loads((CASE / "preflight.json").read_bytes())
    assert preflight["source_proof_sha256"] == digest(CASE / "scope-proof.json")
    assert set(preflight["versions"].values()) == {"1.27.1"} and preflight["backend"] == "libsumo"
    assert digest(CASE / "executed-driver.py") == preflight["executed_driver_sha256"]
    assert (CASE / "executed-driver.py").read_bytes() == (STUDY / "run_candidate.py").read_bytes()
    assert digest(HELPERS / "audit_response.py") == preflight["helper_sha256"]
    assert digest(HELPERS / "audit_scope.py") == preflight["helper_scope_sha256"]
    for path, expected in preflight["binaries"].items():
        assert digest(Path(path)) == expected
    for name, expected in preflight["implementation_sha256"].items():
        assert digest(CASE / "implementation" / name) == expected
        assert (CASE / "implementation" / name).read_bytes() == (SOURCE / "implementation" / name).read_bytes()
    for name, expected in preflight["prepared_hashes"].items():
        assert digest(CASE / "prepared" / name) == expected
    before, after = [audit.evidence(folder / "prepared", folder / "evaluation", folder / "evaluation/contributing-passages.json.gz", 8640) for folder in [SOURCE, CASE]]
    native = CASE / "evaluation/native"
    run = json.loads((native / "run.json").read_bytes())
    raw = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=run["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(CASE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        assert raw == json.load(handle) and raw["reconciled"]
    requests = [json.loads((folder / "evaluation/native/native-request.json").read_bytes()) for folder in [SOURCE, CASE]]
    normalized = [json.dumps(r,sort_keys=True).replace(str(folder).replace("\\","\\\\"),"{case}") for r,folder in zip(requests,[SOURCE,CASE])]
    assert normalized[0] == normalized[1]
    monitor = json.loads((native / "stall-monitor.json").read_bytes())
    assert monitor["library_completed"] and monitor["native_returncode"] is None and monitor["native_version"] == [22,"SUMO 1.27.1"]
    assert digest(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    metadata = {r["vehicle_id"]:r for r in json.loads((CASE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    vehicles = {r.get("id"):r for r in ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle")}
    for label,measured in [("before",before),("after",after)]:
        assert all(measured[k] == verdict[label][k] for k in verdict[label])
        for name,rows in [("130",measured["main"]),("52",measured["initial"]),("182",measured["initial"]+measured["main"]),("40",measured["stations"])]:
            audit.table(OUT / f"{label}-{name}.csv",rows)
    repeat=[(i,f,n) for i,events in after["by_vehicle"].items() for f,n in Counter(e["detector_id"] for e in events).items() if n>1]
    outside=[(i,e["detector_id"]) for i,events in after["by_vehicle"].items() for e in events if e["detector_id"]!=metadata[i]["field_id"]]
    assert not repeat and not outside
    rows535=[r for r in after["initial"]+after["main"] if r["detector_id"] in FIELDS535]
    assert len(rows535)==56 and audit.metrics(rows535)["TAE"]==0
    holds=[r for r in monitor["lane_section_hold"]["events"] if r["vehicle_id"]==DONOR]
    donor_events=after["by_vehicle"].get(DONOR,[])
    donor_trip=after["tripinfo"].get(DONOR,{})
    donor=dict(vehicle_id=DONOR,before_events=before["by_vehicle"].get(DONOR,[]),after_events=donor_events,
        before_tripinfo=before["tripinfo"].get(DONOR,{}),after_tripinfo=donor_trip,actual_lane_section_hold=holds)
    recorded_donor=json.loads((CASE / "changed-vehicle-native.json").read_bytes())
    assert recorded_donor==dict(vehicle_id=DONOR,events=donor_events,tripinfo=donor_trip,lane_section_hold=holds)
    audit.save(OUT / "changed-vehicle-independent.json",donor)
    gates=dict(safe=after["safe"],healthy=after["healthy"],all53556_zero=audit.metrics(rows535)["TAE"]==0,
        no_repeated_vehicle_fields=not repeat,no_contributions_outside_primary_intention=not outside,
        main130_MAE_improves=after["metrics130"]["MAE"]<before["metrics130"]["MAE"],main130_SSE_not_worse=after["metrics130"]["SSE"]<=before["metrics130"]["SSE"],all182_TAE_not_worse=after["metrics182"]["TAE"]<=before["metrics182"]["TAE"],
        changed_vehicle_exactly_one_Z5=len(donor_events)==1 and donor_events[0]["detector_id"]==Z5,
        changed_vehicle_arrived=float(donor_trip.get("arrival",-1))>=0 and not donor_trip.get("vaporized",""),
        changed_vehicle_lane1_hold_and_release=[r["event"] for r in holds]==["held","released"] and holds[0].get("lane")=="24483344#1_1")
    assert gates==verdict["gates"] and verdict["status"]==("diagnostic_candidate" if all(gates.values()) else "rejected")
    fields=[]
    for field in sorted({k[0] for k in before["periodic"]}):
        a,b=[audit.metrics([r for r in d["main"] if r["detector_id"]==field]) for d in [before,after]]
        fields.append(dict(field=field,before_TAE=a["TAE"],after_TAE=b["TAE"],delta_TAE=b["TAE"]-a["TAE"],before_SSE=a["SSE"],after_SSE=b["SSE"],delta_SSE=b["SSE"]-a["SSE"]))
    audit.table(OUT / "field13-response.csv",fields)
    counts={name:[audit.counts(d["by_vehicle"],ids) for d in [before,after]] for name,ids in {"changed1":{DONOR},"unmodified8639":set(vehicles)-{DONOR}}.items()}
    response=[]
    for k in sorted(before["periodic"]):
        a,b=[int(d["periodic"][k]["nVehContrib"]) for d in [before,after]]
        row=dict(field=k[0],begin_s=k[1],end_s=k[2],before=a,after=b,delta=b-a)
        row.update({name+"_delta":c[1][k]-c[0][k] for name,c in counts.items()})
        assert row["changed1_delta"]+row["unmodified8639_delta"]==b-a
        response.append(row)
    audit.table(OUT / "native208-cohort-accounting.csv",response)
    arrived={i for i,t in after["tripinfo"].items() if float(t["arrival"])>=0}
    route_rows=ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle")
    assert {r.get("id") for r in route_rows}==arrived and len(route_rows)==len(arrived)==after["completion"]["arrived"]
    assert all(r.find("route").get("edges")==vehicles[r.get("id")].find("route").get("edges") for r in route_rows)
    terminal=[]
    for identity in sorted(set(vehicles)-arrived):
        trip=after["tripinfo"].get(identity)
        route=vehicles[identity].find("route").get("edges").split()
        terminal.append(dict(vehicle_id=identity,origin=route[0],destination=route[-1],field=metadata[identity]["field_id"],state="not_inserted" if trip is None or float(trip["depart"])<0 else "inserted_unfinished",before_events=audit.event_view(before["by_vehicle"].get(identity,[])),after_events=audit.event_view(after["by_vehicle"].get(identity,[]))))
    assert len(terminal)==after["completion"]["running"]+after["completion"]["waiting"]
    audit.table(OUT / "terminal-unfinished-inputs-and-events.csv",terminal)
    initial_keys=[(r["detector_id"],float(r["begin"]),float(r["end"])) for r in before["initial"]]
    report=dict(schema="astra.hamburg.single-z5-share-independent/v1",audit_status="pass",native_runs_by_audit=0,selection=verdict["status"],gates=gates,input_scope=scope,
        before={k:before[k] for k in verdict["before"]},after={k:after[k] for k in verdict["after"]},station40_max=max(abs(r["residual"]) for r in after["stations"]),
        actual_donor=donor,field_rows=fields,all53556=audit.metrics(rows535),unique_complete_contributing_vehicles=len(after["by_vehicle"]),repeat=repeat,outside=outside,
        initial52_count_rows_exact=all(before["periodic"][k]["nVehContrib"]==after["periodic"][k]["nVehContrib"] for k in initial_keys),
        terminal_count=len(terminal),terminal_by_origin=dict(Counter(r["origin"] for r in terminal)),terminal_by_field=dict(Counter(r["field"] for r in terminal)),
        source_raw_hashes=before["source_hashes"],candidate_raw_hashes=after["source_hashes"],source_binding_hashes={str(p):digest(p) for p in [CASE / "verdict.json",CASE / "preflight.json",CASE / "changed-vehicle-native.json",CASE / "executed-driver.py",native / "vehicle-routes.xml"]},
        claim_boundary="A single legal existing-route lane waypoint changes field share, rather than relabeling old events. Fresh native passages decide the result. Removing the fixed-field-total quantity deficit does not establish zero fit, trueOD, natural driver behavior or field control. Unmodified-cohort arithmetic is not causal separation.")
    audit.save(OUT / "summary.json",report)
    print(json.dumps({k:report[k] for k in ["audit_status","selection","before","after","gates"]}))


if __name__=="__main__":
    main()
