"""Independently check a single physical lane-waypoint and field-share change."""

from collections import Counter
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
CASE = STUDY / "one-share"
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
SUPPORT = REPO / "outputs/hamburg-z5-single-share-support-20261024-v1"
DONOR, WITNESS = "od_0209_v00026", "od_0209_v00027"
Z4, Z5 = "hh_0119_Z_4_29437", "hh_0119_Z_5_30494"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect():
    proof = json.loads((CASE / "scope-proof.json").read_bytes())
    assert proof["status"] == "pass" and proof["N"] == 8640
    for path, expected in proof["source_hashes"].items():
        assert digest(Path(path)) == expected
    for name, expected in proof["prepared_hashes"].items():
        assert digest(CASE / "prepared" / name) == expected
    folders = [SOURCE / "prepared", CASE / "prepared"]
    for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "scenario.json"]:
        assert (folders[0] / name).read_bytes() == (folders[1] / name).read_bytes()
    roots = [ET.parse(folder / "demand.rou.xml").getroot() for folder in folders]
    vehicles = [{v.get("id"): v for v in r.findall("vehicle")} for r in roots]
    assert len(vehicles[0]) == len(vehicles[1]) == 8640 and list(vehicles[0]) == list(vehicles[1])
    assert all(len(r.findall("vehicle")) == 8640 for r in roots)
    assert [ET.tostring(r) for r in roots[0] if r.tag != "vehicle"] == [ET.tostring(r) for r in roots[1] if r.tag != "vehicle"]
    changed = []
    for identity in vehicles[0]:
        a, b = [v[identity] for v in vehicles]
        assert a.attrib == b.attrib
        if ET.tostring(a) != ET.tostring(b):
            changed.append(identity)
        restored = deepcopy(b)
        if identity == DONOR:
            assert len(a.findall("stop")) == len(b.findall("stop")) == 1
            assert a.find("stop").get("lane") == "24483344#1_0" and b.find("stop").get("lane") == "24483344#1_1"
            restored.find("stop").set("lane", a.find("stop").get("lane"))
        assert ET.tostring(a) == ET.tostring(restored)
    assert changed == [DONOR]
    metadata_top = [json.loads((folder / "lane-intentions.json").read_bytes()) for folder in folders]
    metadata = [{r["vehicle_id"]: r for r in d["vehicles"]} for d in metadata_top]
    assert list(metadata[0]) == list(metadata[1]) and len(metadata[0]) == len(metadata[1]) == 8640
    assert [i for i in metadata[0] if metadata[0][i] != metadata[1][i]] == [DONOR]
    restored = deepcopy(metadata_top[1])
    next(r for r in restored["vehicles"] if r["vehicle_id"] == DONOR)["field_id"] = Z4
    assert restored == metadata_top[0]
    assert metadata[0][DONOR]["field_id"] == Z4 and metadata[1][DONOR]["field_id"] == Z5
    assert metadata[0][DONOR]["od_cell"] == metadata[1][DONOR]["od_cell"] == 209
    model = json.loads((REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json").read_bytes())
    cell_keys = {(c["origin"], c["destination"], int(c["begin_s"])): i for i,c in enumerate(model["cells"])}
    inventory = [Counter(), Counter()]
    for side in (0,1):
        for identity,v in vehicles[side].items():
            edges = v.find("route").get("edges").split()
            native_ms = math.floor(float(v.get("depart"))*1000+.5)
            index = cell_keys[edges[0], edges[-1], native_ms//900000*900]
            assert metadata[side][identity]["od_cell"] == index
            inventory[side][index] += 1
    assert inventory[0] == inventory[1] and set(inventory[1]) == set(range(294))
    vector = json.loads((CASE / "od-vector.json").read_bytes())
    assert vector["values"] == vector["integer_counts"] == [inventory[0][i] for i in range(294)]
    totals = [Counter(r["field_id"] for r in d.values()) for d in metadata]
    assert (totals[0][Z4],totals[0][Z5],totals[1][Z4],totals[1][Z5]) == (761,623,760,624)
    assert len(vehicles[0][DONOR].find("route").get("edges").split()) == 19
    assert vehicles[1][DONOR].find("route").attrib == vehicles[1][WITNESS].find("route").attrib
    assert vehicles[1][DONOR].find("stop").attrib == vehicles[1][WITNESS].find("stop").attrib
    evidence = json.loads((SUPPORT / "source-proof.json").read_bytes())
    assert digest(SUPPORT / "source-proof.json") == "1431ae3d60836679ad7008a827dd4ffaf08bc5c9ce9c375fd0b7c11394feedaf"
    assert digest(SUPPORT / "manifest.json") == "c5be6bc58bb642a230a606fe643b545d94da72d7ef81862d82dee057bb700353"
    assert evidence["route_edges"] == vehicles[1][DONOR].find("route").get("edges").split()
    assert evidence["all_ordinary_and_internal_chain_lanes_allow_passenger"]
    for path, expected in evidence["source_hashes"].items():
        assert digest(Path(path)) == expected
    destination = OUT / "source-support"
    if not destination.exists():
        shutil.copytree(SUPPORT,destination)
    assert all((destination/name).read_bytes() == (SUPPORT/name).read_bytes() for name in ["source-proof.json","manifest.json"])
    report = dict(schema="astra.hamburg.single-z5-share-input-independent/v1",status="pass",native_runs=0,
        donor_vehicle_id=DONOR,witness_vehicle_id=WITNESS,N=8640,only_donor_stop_lane_and_intent_field_changed=True,
        all8639_vehicle_XML_and_intents_exact=True,all_vehicle_attributes_departures_route_edges_order_vtypes_exact=True,
        same294_actual_requested_cells=True,same21_OD_totals=True,planned_Z4=760,planned_Z5=624,
        full_legal19edge37lane_passenger_support=True,support_manifest_sha256=digest(SUPPORT / "manifest.json"),
        field_share_change_is_physical_stop_lane_plus_local_hold=True,
        donor_requested_depart_s=vehicles[1][DONOR].get("depart"),
        source_hashes={str(p):digest(p) for p in [CASE / "scope-proof.json",CASE / "generation-audit.json",CASE / "od-vector.json"]},
        claim_boundary="One existing physical moving-stop lane and matching local intention change. Static and existing-witness support do not prove the new donor will reachZ5. Native uniqueZ5 contribution, lane1 hold/release, arrival, all counts and health must be remeasured.")
    (OUT / "input-scope.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return report


if __name__ == "__main__":
    print(json.dumps(inspect()))
