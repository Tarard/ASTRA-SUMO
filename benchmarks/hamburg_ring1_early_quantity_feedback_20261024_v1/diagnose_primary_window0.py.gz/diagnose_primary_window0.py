"""Compare completed ordinary-edge times and sampled queues on the primary approach."""

from collections import defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
from statistics import median
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASES = {"source": REPO / "outputs/hamburg-119-late-demand-thinning-20261024-v1/cases/remove43", "window0": ROOT / "cases/window0"}
EDGES = ["44532531", "761590046", "199500674#0", "199500674#1", "199500674#2", "24483192", "43866090#0"]
FIELDS = {"hh_0119_Z_12_31546", "hh_0119_Z_13_34018"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    dwell_rows, greens, results, hashes, actual_routes = [], [], {}, {}, {}
    net = ET.parse(CASES["source"] / "prepared/network.net.xml").getroot()
    lengths = {edge.get("id"): float(edge.find("lane").get("length")) for edge in net.findall("edge") if edge.find("lane") is not None}
    for label, case in CASES.items():
        prepared, native = case / "prepared", case / "evaluation/native"
        requested = {row.get("id"): float(row.get("depart")) for row in ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")}
        fields = {row["vehicle_id"]: row["field_id"] for row in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
        with gzip.open(case / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
            events = json.load(handle)["passages"]
        event_by_id = {row["vehicle_id"]: row for row in events}
        selected = {identity for identity, field in fields.items() if field in FIELDS and 3600 <= requested[identity] < 4500}
        dwells, exits, inserted, vehicle_examples = defaultdict(list), defaultdict(list), [], []
        actual_routes[label] = {}
        for vehicle in ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle"):
            identity = vehicle.get("id")
            route = vehicle.find("route")
            edges, times = route.get("edges").split(), list(map(float, route.get("exitTimes").split()))
            actual_routes[label][identity] = {"requested_s": requested[identity], "actual_depart_s": float(vehicle.get("depart")),
                "notification_s": event_by_id[identity]["notification_time_s"], **{edge+"_exit_s": time for edge, time in zip(edges, times) if edge in EDGES}}
            for edge, time in zip(edges, times):
                if edge in EDGES:
                    exits[edge].append(time)
            if identity not in selected:
                continue
            depart = float(vehicle.get("depart"))
            inserted.append(depart-requested[identity])
            for index, (edge, time) in enumerate(zip(edges, times)):
                if edge in EDGES:
                    start = depart if index == 0 else times[index-1]
                    dwells[edge].append(time-start)
                    vehicle_examples.append({"vehicle_id": identity, "edge": edge, "start_s": start, "exit_s": time,
                        "ordinary_exit_difference_s": time-start, "requested_s": requested[identity], "actual_depart_s": depart,
                        "notification_s": event_by_id[identity]["notification_time_s"]})
        queues = {}
        for _, element in ET.iterparse(native / "queues.xml", events=("end",)):
            if element.tag != "data":
                continue
            time = float(element.get("timestep"))
            if 3600 <= time < 4500:
                queues[int(time)] = {row.get("id"): float(row.get("queueing_length")) for row in element.findall("lanes/lane")}
            element.clear()
        assert len(queues) == 900
        for edge in EDGES:
            values = sorted(dwells[edge])
            if values:
                dwell_rows.append({"case": label, "edge": edge, "length_m": lengths[edge], "h4_requested_vehicles": len(values),
                    "median_ordinary_exit_difference_s": median(values), "p90_s": values[math.ceil(.9*len(values))-1], "max_s": max(values), "sum_s": sum(values)})
        for cycle in range(40, 51):
            start, end = max(3600, 90*cycle+21), min(4500, 90*cycle+50)
            if start >= end:
                continue
            row = {"case": label, "begin": start, "end": end, "full29s_green": end-start == 29,
                "E1_Z12": sum(start <= e["notification_time_s"] < end and e["detector_id"] == "hh_0119_Z_12_31546" for e in events),
                "E1_Z13": sum(start <= e["notification_time_s"] < end and e["detector_id"] == "hh_0119_Z_13_34018" for e in events),
                "ordinary438_exits_all_requests": sum(start <= t < end for t in exits["43866090#0"]),
                "ordinary244_exits_all_requests": sum(start <= t < end for t in exits["24483192"])}
            front_exits = [t for t in exits["43866090#0"] if start <= t < end]
            row["ordinary438_first_exit_s"] = min(front_exits, default=None)
            row["ordinary438_last_exit_s"] = max(front_exits, default=None)
            for number in (12, 13):
                values = sorted(e["notification_time_s"] for e in events if e["detector_id"].startswith(f"hh_0119_Z_{number}_") and start <= e["notification_time_s"] < end)
                row[f"Z{number}_first_notification_s"] = values[0] if values else None
                row[f"Z{number}_last_notification_s"] = values[-1] if values else None
                row[f"Z{number}_gap_to_green_end_s"] = end-values[-1] if values else None
            for lane in ("43866090#0_0", "43866090#0_1", "24483192_1", "24483192_2"):
                values = [queues[t][lane] for t in range(start, end) if lane in queues[t]]
                row[lane+"_listed_samples"] = len(values)
                row[lane+"_positive_stopped_samples"] = sum(v > 0 for v in values)
                row[lane+"_min_listed_m"] = min(values, default=None)
                row[lane+"_max_listed_m"] = max(values, default=None)
            greens.append(row)
        results[label] = {"h4_requested_Z12Z13": len(selected), "actual_insertion_lag_median_s": median(inserted), "actual_insertion_lag_max_s": max(inserted),
            "largest_edge_instances": sorted(vehicle_examples, key=lambda row: row["ordinary_exit_difference_s"], reverse=True)[:6],
            "actual_h4_Z12Z13_ids": sorted(e["vehicle_id"] for e in events if e["detector_id"] in FIELDS and e["interval_begin_s"] == 3600)}
        results[label]["queue_lane_summary"] = {lane: {"listed_samples": len(values), "positive_stopped_samples": sum(v > 0 for v in values),
            "minimum_listed_m": min(values, default=None), "maximum_listed_m": max(values, default=None)}
            for lane in ("44532531_0", "199500674#0_1", "199500674#0_2", "24483192_1", "24483192_2", "43866090#0_0", "43866090#0_1")
            for values in [[row[lane] for row in queues.values() if lane in row]]}
        for path in (prepared / "demand.rou.xml", prepared / "lane-intentions.json", prepared / "network.net.xml", prepared / "control.add.xml",
            native / "queues.xml", native / "vehicle-routes.xml", case / "evaluation/contributing-passages.json.gz"):
            hashes[str(path)] = sha(path)
    before, after = [set(results[label]["actual_h4_Z12Z13_ids"]) for label in ("source", "window0")]
    added = {row["vehicle_id"] for row in json.loads((CASES["window0"] / "proposal.json").read_bytes())["additions"]}
    results["actual_438_response"] = {"source_h4": len(before), "candidate_h4": len(after), "new_h4": len(after & added),
        "old_out": sorted(before-after), "old_in": sorted(after-before-added)}
    displaced = [{"case": label, "vehicle_id": identity, **actual_routes[label][identity]} for identity in sorted(before-after) for label in CASES]
    for label in CASES:
        results[label].pop("actual_h4_Z12Z13_ids")
    results["claim_boundary"] = "Ordinary exit-time differences include the intervening internal path. Queue values are anonymous one-second stopped-length samples; an unlisted lane is not assumed empty. Primary119 links0/1 declared static green is[6,35) with offset15, giving[90k+21,90k+50). Upstream6390683114/244203524/244203525 are actuated; no actual switch history is available here. E1 is complete rear notification, not front-entry capacity. No hard capacity or unique cause is inferred."
    results["source_hashes"] = {**hashes, str(Path(__file__)): sha(Path(__file__))}
    table(ROOT / "primary-window0-edge-times.csv", dwell_rows)
    table(ROOT / "primary-window0-green-queues.csv", greens)
    table(ROOT / "primary-window0-displaced8.csv", displaced)
    (ROOT / "primary-window0-diagnosis.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"edge_times": dwell_rows, "response": results["actual_438_response"], "source_early_greens": greens[:4]}))


if __name__ == "__main__":
    main()
