"""Prepare the three deletions alone, from remove43, with no added requests."""
import argparse
import copy
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import prepare_case as helpers

ROOT=Path(__file__).resolve().parent
SOURCE=helpers.SOURCE
CASE=ROOT/"cases/window0_remove3"


def prepare():
    assert not CASE.exists(),"Preserve existing candidates."
    source=SOURCE/"prepared"
    source_health=json.loads((SOURCE/"verdict.json").read_bytes())
    assert source_health["healthy"] and source_health["safe"] and source_health["after"]["metrics130"]["TAE"]==324
    parent_proposal=ROOT/"cases/window0/proposal.json"
    parent=json.loads(parent_proposal.read_bytes())
    removed=set(parent["removed_vehicle_ids"])
    assert removed=={"od_0104_v00015","od_0104_v00049","od_0088_v00008"}
    before=ET.parse(source/"demand.rou.xml").getroot()
    old={v.get("id"):v for v in before.findall("vehicle")}
    metadata=json.loads((source/"lane-intentions.json").read_bytes())
    intent={r["vehicle_id"]:r for r in metadata["vehicles"]}
    assert len(old)==len(intent)==8597
    after=copy.deepcopy(before)
    for vehicle in list(after.findall("vehicle")):
        if vehicle.get("id") in removed:
            assert helpers.begin(vehicle)==3600
            after.remove(vehicle)
    new={v.get("id"):v for v in after.findall("vehicle")}
    assert len(new)==8594 and set(new)==set(old)-removed
    assert all(ET.tostring(v)==ET.tostring(old[i]) for i,v in new.items())
    assert list(new)==[v.get("id") for v in before.findall("vehicle") if v.get("id") not in removed]
    assert [ET.tostring(v) for v in before if v.tag!="vehicle"]==[ET.tostring(v) for v in after if v.tag!="vehicle"]
    source_q=[0]*294
    new_q=[0]*294
    actual_cells={}
    for identity,v in old.items():
        edges=v.find("route").get("edges").split()
        key=edges[0],edges[-1],helpers.begin(v)
        cell=intent[identity]["od_cell"]
        assert key not in actual_cells or actual_cells[key]==cell
        actual_cells[key]=cell
        source_q[cell]+=1
    for identity,v in new.items():
        edges=v.find("route").get("edges").split()
        cell=actual_cells[edges[0],edges[-1],helpers.begin(v)]
        assert cell==intent[identity]["od_cell"]
        new_q[cell]+=1
    changes=[dict(cell=i,source=source_q[i],candidate=new_q[i],delta=new_q[i]-source_q[i]) for i in range(294) if source_q[i]!=new_q[i]]
    assert [(r["cell"],r["delta"]) for r in changes]==[(88,-1),(104,-2)]
    metadata["vehicles"]=[r for r in metadata["vehicles"] if r["vehicle_id"] in new]
    assert all(r==intent[r["vehicle_id"]] for r in metadata["vehicles"])
    prepared=CASE/"prepared"
    shutil.copytree(source,prepared)
    ET.ElementTree(after).write(prepared/"demand.rou.xml",encoding="utf-8",xml_declaration=True)
    helpers.save(prepared/"lane-intentions.json",metadata)
    scenario=json.loads((source/"scenario.json").read_bytes())
    init=sum(float(v.get("depart"))<3600 for v in new.values())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,vehicles=8594,main_vehicles=8594-init,
        initialization_vehicles=init,demand_sha256=helpers.sha(prepared/"demand.rou.xml"),
        demand_prior="Only the same three hypothetical h4 requests from failed combined window0 are removed before simulation. Source is healthy remove43/TAE324,not failed window0. All8594 survivor XML/times/routes/stops/fields/IDs/order remain exact;no additions or runtime removal.",
        time_prior="Every surviving source request time is exact. This isolates the removal component;actual native effect is unmeasured.")
    helpers.save(prepared/"scenario.json",scenario)
    proposal=dict(schema="astra.hamburg.chronological-remove3-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        source_case=helpers.SOURCE_CASE,prefix_end_s=3600,prepare_script="prepare_removal.py",source_N=8597,candidate_N=8594,
        source_main130_TAE=324,additions=[],added_vehicles=0,removed_requests=3,removed_vehicle_ids=sorted(removed),
        parent_combined_proposal_sha256=helpers.sha(parent_proposal),q_changes=changes,q_L1=3,
        claim_boundary="One empirical removal-only response,not inferred from the failed10-add/3-delete case. All real130+52 observations and infrastructure stay fixed;no native measurement yet.")
    helpers.save(CASE/"proposal.json",proposal)
    helpers.save(CASE/"od-vector.json",dict(schema="astra.hamburg.explicit-request-od-vector/v1",vehicle_count=8594,source_integer_counts=source_q,integer_counts=new_q,changed_cells=changes,l1_change=3))
    shutil.copy2(__file__,CASE/"executed-prepare.py")
    paths=[source/name for name in helpers.NAMES]+[SOURCE/"verdict.json",parent_proposal,Path(helpers.__file__),Path(__file__)]
    helpers.save(CASE/"scope-proof.json",dict(schema="astra.hamburg.chronological-remove3-scope/v1",status="pass",formal_result=False,new_native_runs=0,
        source_N=8597,N=8594,added_IDs=0,removed_IDs=3,common_survivors=8594,
        source_hashes={str(p.resolve()):helpers.sha(p) for p in paths},prepared_hashes={name:helpers.sha(prepared/name) for name in helpers.NAMES},
        proposal_sha256=helpers.sha(CASE/"proposal.json"),od_vector_sha256=helpers.sha(CASE/"od-vector.json"),
        checks=dict(source_remove43_324_exact=True,no_additions=True,same_three_delete_IDs=True,survivor_XML_exact=True,survivor_order_exact=True,
                    survivor_intent_exact_subset=True,actual294_q_rebuilt=True,network_control_real_observations_exact=True,no_runtime_remove=True)))
    return check("window0_remove3")


def check(case_name):
    assert case_name=="window0_remove3"
    proof=json.loads((CASE/"scope-proof.json").read_bytes())
    assert all(proof["checks"].values())
    assert all(helpers.sha(Path(p))==h for p,h in proof["source_hashes"].items())
    assert all(helpers.sha(CASE/"prepared"/n)==h for n,h in proof["prepared_hashes"].items())
    assert helpers.sha(CASE/"proposal.json")==proof["proposal_sha256"] and helpers.sha(CASE/"od-vector.json")==proof["od_vector_sha256"]
    current=ET.parse(CASE/"prepared/demand.rou.xml").getroot().findall("vehicle")
    intent=json.loads((CASE/"prepared/lane-intentions.json").read_bytes())["vehicles"]
    assert len(current)==len(intent)==8594 and {v.get("id") for v in current}=={r["vehicle_id"] for r in intent}
    for name in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
        assert (CASE/"prepared"/name).read_bytes()==(SOURCE/"prepared"/name).read_bytes()
    return dict(status="pass",new_native_runs=0,source_case=helpers.SOURCE_CASE,prefix_end_s=3600,source_N=8597,candidate_N=8594,
                added=0,removed=3,scope_sha256=helpers.sha(CASE/"scope-proof.json"),proposal_sha256=helpers.sha(CASE/"proposal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=["window0_remove3"],default="window0_remove3")
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
