"""Prepare one first-main-window quantity response; preserve survivor requests."""
import argparse
from collections import Counter
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
SOURCE_CASE="outputs/hamburg-119-late-demand-thinning-20261024-v1/cases/remove43"
SOURCE=REPO/SOURCE_CASE
CASE=ROOT/"cases/window0"
NAMES=["network.net.xml","control.add.xml","demand.rou.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv","lane-intentions.json","scenario.json"]
ADD={"hh_0119_Z_11_28853":{97:1},"hh_0119_Z_12_31546":{98:1,99:2,100:2},"hh_0119_Z_13_34018":{98:1,99:1,100:2}}
DELETE={"hh_0119_Z_4_29437":{104:2},"hh_0535_Z_4_33055":{88:1}}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def begin(vehicle):
    return (math.floor(float(vehicle.get("depart"))*1000+.5)//900000)*900


def prepare():
    assert not CASE.exists(),"Preserve prior candidates."
    source=SOURCE/"prepared"
    before=ET.parse(source/"demand.rou.xml").getroot()
    old={v.get("id"):v for v in before.findall("vehicle")}
    metadata=json.loads((source/"lane-intentions.json").read_bytes())
    intent={r["vehicle_id"]:r for r in metadata["vehicles"]}
    payload=json.loads(gzip.decompress((SOURCE/"evaluation/contributing-passages.json.gz").read_bytes()))
    events={r["vehicle_id"]:r for r in payload["passages"]}
    health=json.loads((SOURCE/"verdict.json").read_bytes())
    assert health["healthy"] and health["safe"] and health["after"]["metrics130"]["TAE"]==324
    assert len(old)==len(intent)==len(events)==8597 and payload["reconciled"]

    def pool(field,cell):
        return sorted([i for i in old if intent[i]["field_id"]==field and intent[i]["od_cell"]==cell and begin(old[i])==3600 and events[i]["interval_begin_s"]==3600],key=lambda i:(float(old[i].get("depart")),i))

    removed=[]
    for field,quotas in DELETE.items():
        for cell,n in quotas.items():
            ids=pool(field,cell)
            assert len(ids)>=n
            removed += [ids[math.floor((j+.5)*len(ids)/n)] for j in range(n)]
    assert len(set(removed))==3
    after=copy.deepcopy(before)
    for vehicle in list(after.findall("vehicle")):
        if vehicle.get("id") in removed:
            after.remove(vehicle)
    additions=[]
    new_intents=[]
    used_native_times={math.floor(float(v.get("depart"))*1000+.5) for v in old.values()}
    for field,quotas in ADD.items():
        for cell,n in sorted(quotas.items()):
            ids=pool(field,cell)
            gaps=[]
            for first,second in zip(ids,ids[1:]):
                t1,t2=float(old[first].get("depart")),float(old[second].get("depart"))
                proposed=round((t1+t2)/2,9)
                native_ms=math.floor(proposed*1000+.5)
                proxies=[events[first]["notification_time_s"]+proposed-t1,events[second]["notification_time_s"]+proposed-t2]
                if native_ms in used_native_times or not 3600<=proposed<4500 or not all(3600<=x<=4350 for x in proxies):
                    continue
                # Require identical existing OD/field route and moving-stop template.
                one,two=copy.deepcopy(old[first]),copy.deepcopy(old[second])
                for vehicle in [one,two]:
                    vehicle.attrib.pop("id")
                    vehicle.attrib.pop("depart")
                assert ET.tostring(one)==ET.tostring(two)
                gaps.append((first,second,proposed,proxies))
            assert len(gaps)>=n,(field,cell,len(gaps),n)
            for j in range(n):
                first,second,proposed,proxies=gaps[math.floor((j+.5)*len(gaps)/n)]
                identity=f"hyp_w0_{field.split('_Z_')[1].split('_')[0]}_c{cell}_a{j}"
                assert identity not in old and identity not in {r["vehicle_id"] for r in additions}
                vehicle=copy.deepcopy(old[first])
                vehicle.set("id",identity)
                vehicle.set("depart",f"{proposed:.9f}")
                used_native_times.add(math.floor(proposed*1000+.5))
                after.append(vehicle)
                row=copy.deepcopy(intent[first])
                row.update(vehicle_id=identity,source_template_vehicle_id=first,hypothetical_new_request=True)
                for key in ["depart_s","requested_depart_s","requested_departure_s"]:
                    if key in row:
                        row[key]=proposed
                new_intents.append(row)
                additions.append(dict(vehicle_id=identity,field_id=field,od_cell=cell,requested_depart_s=proposed,
                    source_template_vehicle_id=first,source_gap_end_vehicle_id=second,source_gap_request_s=[float(old[first].get("depart")),float(old[second].get("depart"))],
                    source_endpoint_notifications_s=[events[first]["notification_time_s"],events[second]["notification_time_s"]],
                    unverified_endpoint_lag_proxies_s=proxies,minimum_proxy_margin_to4500_s=4500-max(proxies)))
    assert len(additions)==10
    assert Counter(r["field_id"] for r in additions)==Counter({"hh_0119_Z_11_28853":1,"hh_0119_Z_12_31546":5,"hh_0119_Z_13_34018":4})
    assert Counter(intent[i]["field_id"] for i in removed)==Counter({"hh_0119_Z_4_29437":2,"hh_0535_Z_4_33055":1})
    # Stable chronological compilation; the source survivor order must remain exact.
    vehicles=after.findall("vehicle")
    for vehicle in vehicles:
        after.remove(vehicle)
    after.extend(sorted(vehicles,key=lambda v:(float(v.get("depart")),v.get("id"))))
    new={v.get("id"):v for v in after.findall("vehicle")}
    survivor=set(old)-set(removed)
    assert len(new)==8604 and set(new)==survivor|{r["vehicle_id"] for r in additions}
    assert all(ET.tostring(new[i])==ET.tostring(old[i]) for i in survivor)
    assert [v.get("id") for v in after.findall("vehicle") if v.get("id") in survivor]==[v.get("id") for v in before.findall("vehicle") if v.get("id") in survivor]
    assert [ET.tostring(v) for v in after if v.tag!="vehicle"]==[ET.tostring(v) for v in before if v.tag!="vehicle"]
    metadata["vehicles"]=[r for r in metadata["vehicles"] if r["vehicle_id"] in survivor]+new_intents
    actual_intent={r["vehicle_id"]:r for r in metadata["vehicles"]}
    assert set(actual_intent)==set(new) and all(actual_intent[i]==intent[i] for i in survivor)
    source_keys={}
    source_q=[0]*294
    new_q=[0]*294
    for identity,v in old.items():
        edges=v.find("route").get("edges").split()
        key=edges[0],edges[-1],begin(v)
        cell=intent[identity]["od_cell"]
        assert key not in source_keys or source_keys[key]==cell
        source_keys[key]=cell
        source_q[cell]+=1
    for identity,v in new.items():
        edges=v.find("route").get("edges").split()
        cell=source_keys[edges[0],edges[-1],begin(v)]
        assert cell==actual_intent[identity]["od_cell"]
        new_q[cell]+=1
    changes=[dict(cell=i,source=source_q[i],candidate=new_q[i],delta=new_q[i]-source_q[i]) for i in range(294) if source_q[i]!=new_q[i]]
    assert sum(new_q)==8604 and sum(abs(r["delta"]) for r in changes)==13
    prepared=CASE/"prepared"
    shutil.copytree(source,prepared)
    ET.ElementTree(after).write(prepared/"demand.rou.xml",encoding="utf-8",xml_declaration=True)
    save(prepared/"lane-intentions.json",metadata)
    scenario=json.loads((source/"scenario.json").read_bytes())
    init=sum(float(v.get("depart"))<3600 for v in new.values())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,vehicles=8604,main_vehicles=8604-init,
        initialization_vehicles=init,demand_sha256=sha(prepared/"demand.rou.xml"),
        demand_prior="First-main-window input quantity response from healthy remove43/TAE324.10 explicit new hypothetical template clones and3 removed hypothetical requests. All8594 survivors retain exact XML/times/routes/stops/field/ID/order; all real130+52 observations remain; no quantile regeneration/runtime removal.",
        time_prior="Survivor times fixed. New requests lie inside source-successful sameOD/field gaps after3600;two-endpoint native-lag proxies retain at least150s margin before4500. This is unverified response, not a prediction or independent-bin optimizer.",
        chronological_quantity_feedback=dict(window=[3600,4500],source_N=8597,candidate_N=8604,added=10,removed=3,native_response_verified=False))
    save(prepared/"scenario.json",scenario)
    proposal=dict(schema="astra.hamburg.chronological-count-feedback-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        source_case=SOURCE_CASE,prefix_end_s=3600,window=[3600,4500],source_N=8597,candidate_N=8604,
        source_main130_TAE=324,additions=additions,removed_vehicle_ids=removed,added_vehicles=10,removed_requests=3,
        desired_count_response={"hh_0119_Z_11_28853":1,"hh_0119_Z_12_31546":5,"hh_0119_Z_13_34018":4,"hh_0119_Z_4_29437":-2,"hh_0535_Z_4_33055":-1},
        add_field_OD_quotas=ADD,remove_field_OD_quotas=DELETE,q_changes=changes,q_L1=13,
        source_proven_template_rule="source request>=3600 and native contribution in3600–4500;initial carry is excluded;both field/OD gap endpoints are successful,all template attributes/route/stops identical.",
        claim_boundary="Request inventories already matched several real targets;the deficit/surplus need not be a true quantity error. This is one empirical input-count probe. Changed queues/control realization can move other windows;all130/52/182/40/208 and remaining/newID completion/safety must be measured.")
    save(CASE/"proposal.json",proposal)
    save(CASE/"od-vector.json",dict(schema="astra.hamburg.explicit-request-od-vector/v1",vehicle_count=8604,source_integer_counts=source_q,integer_counts=new_q,changed_cells=changes,l1_change=13))
    shutil.copy2(__file__,CASE/"executed-prepare.py")
    paths=[source/name for name in NAMES]+[SOURCE/"verdict.json",SOURCE/"evaluation/contributing-passages.json.gz",Path(__file__)]
    save(CASE/"scope-proof.json",dict(schema="astra.hamburg.chronological-count-feedback-scope/v1",status="pass",formal_result=False,new_native_runs=0,
        source_N=8597,N=8604,added_IDs=10,removed_IDs=3,common_survivors=8594,source_hashes={str(p.resolve()):sha(p) for p in paths},
        prepared_hashes={name:sha(prepared/name) for name in NAMES},proposal_sha256=sha(CASE/"proposal.json"),od_vector_sha256=sha(CASE/"od-vector.json"),
        checks=dict(survivor_XML_exact=True,survivor_order_exact=True,survivor_intent_rows_exact=True,
            new_IDs_explicit_hypothetical=True,successful_noninitial_templates=True,new_request_bin3600=True,all_lag_proxy_margins150s=True,
            routes_stops_vtypes_from_source_only=True,actual294_q_rebuilt=True,network_control_all_observations_exact=True,no_runtime_removal=True)))
    return check("window0")


def check(case_name):
    assert case_name=="window0"
    proof=json.loads((CASE/"scope-proof.json").read_bytes())
    assert all(proof["checks"].values())
    assert all(sha(Path(p))==h for p,h in proof["source_hashes"].items())
    assert all(sha(CASE/"prepared"/n)==h for n,h in proof["prepared_hashes"].items())
    assert sha(CASE/"proposal.json")==proof["proposal_sha256"] and sha(CASE/"od-vector.json")==proof["od_vector_sha256"]
    proposal=json.loads((CASE/"proposal.json").read_bytes())
    assert Counter(r["field_id"] for r in proposal["additions"])==Counter({"hh_0119_Z_11_28853":1,"hh_0119_Z_12_31546":5,"hh_0119_Z_13_34018":4})
    current=ET.parse(CASE/"prepared/demand.rou.xml").getroot().findall("vehicle")
    intent=json.loads((CASE/"prepared/lane-intentions.json").read_bytes())["vehicles"]
    assert len(current)==len(intent)==8604 and {v.get("id") for v in current}=={r["vehicle_id"] for r in intent}
    for name in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
        assert (CASE/"prepared"/name).read_bytes()==(SOURCE/"prepared"/name).read_bytes()
    return dict(status="pass",new_native_runs=0,source_case=SOURCE_CASE,prefix_end_s=3600,source_N=8597,candidate_N=8604,
                added=10,removed=3,scope_sha256=sha(CASE/"scope-proof.json"),proposal_sha256=sha(CASE/"proposal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=["window0"],default="window0")
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
