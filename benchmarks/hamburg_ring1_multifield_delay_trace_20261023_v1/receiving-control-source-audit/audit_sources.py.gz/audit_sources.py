"""Read frozen sources for one receiving controller; no edits or native execution."""

from dataclasses import asdict
from hashlib import sha256
import gzip
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from pyproj import Transformer
from astra_sumo.core.digital_twin import parse_mapem
from astra_sumo.core.digital_twin_mapping import project_point_to_polyline


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BENCH = ROOT / "benchmarks"
OFFICIAL = BENCH / "hamburg_ring1_official_sources_20261020_v1"
OSM = BENCH / "hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz"
OLD_OSM = BENCH / "hamburg_ring1_end_to_end_20261021_v1/source-stages/ring1-full_filtered.osm.xml.gz"
ORIGINAL = BENCH / "hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml"
LEGACY = BENCH / "hamburg_ring1_readme_v1_zero_20261023_v1/inputs/network.net.xml.gz"
CURRENT = ROOT / "outputs/hamburg-joint-od-spsa-20261023-v1/prepared/network.net.xml"
CONTROL = CURRENT.with_name("control.add.xml")
AERIAL_DIR = BENCH / "hamburg_ring1_lsa535_binding_probe_20261021_v1"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def raw(path):
    return gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()


def local(tag):
    return tag.rsplit("}", 1)[-1]


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def logic(root, identity):
    tls = root.find(f"tlLogic[@id='{identity}']")
    return None if tls is None else {"attributes": tls.attrib, "children": [{"tag": e.tag, "attributes": e.attrib} for e in tls]}


def main():
    official_manifest = json.loads((OFFICIAL / "manifest.json").read_bytes())
    files = [OSM, OLD_OSM, ORIGINAL, LEGACY, CURRENT, CONTROL, OFFICIAL / "manifest.json", OFFICIAL / "lsa-identities.json",
             AERIAL_DIR / "aerial.png", AERIAL_DIR / "aerial-source.json"]
    official_records = [r for r in official_manifest["files"] if r["node_id"] == "535"]
    for record in official_records:
        path = OFFICIAL / record["path"]
        assert digest(path) == record["compressed_sha256"] and sha256(raw(path)).hexdigest() == record["sha256"]
        files.append(path)
    hashes = {str(p): digest(p) for p in files}
    osm = ET.fromstring(raw(OSM))
    nodes = {n.get("id"): n for n in osm.findall("node")}
    old_nodes = {n.get("id"): n for n in ET.fromstring(raw(OLD_OSM)).findall("node")}
    project = Transformer.from_crs(4326, 25832, always_xy=True)

    def node_record(identity):
        n = nodes[identity]
        assert n.attrib == old_nodes[identity].attrib and [t.attrib for t in n] == [t.attrib for t in old_nodes[identity]]
        coordinate = float(n.get("lon")), float(n.get("lat"))
        ways = [{"id": w.get("id"), "node_refs": [nd.get("ref") for nd in w.findall("nd")],
                 "tags": {t.get("k"): t.get("v") for t in w.findall("tag")}}
                for w in osm.findall("way") if any(nd.get("ref") == identity for nd in w.findall("nd"))]
        return {"id": identity, "attributes": n.attrib, "tags": {t.get("k"): t.get("v") for t in n.findall("tag")},
                "lon_lat": coordinate, "epsg25832": project.transform(*coordinate), "member_ways": ways,
                "two_frozen_OSM_snapshots_agree": True}

    target, signal = node_record("1975693623"), node_record("4031208918")
    original, current, legacy = [ET.fromstring(raw(p)) for p in [ORIGINAL, CURRENT, LEGACY]]
    assert logic(original, "1975693623") == logic(current, "1975693623")
    additional_logic = logic(ET.parse(CONTROL).getroot(), "1975693623")
    original_logic = logic(original, "1975693623")
    assert additional_logic["children"] == original_logic["children"]
    assert {k: v for k, v in additional_logic["attributes"].items() if k != "programID"} == {
        k: v for k, v in original_logic["attributes"].items() if k != "programID"}
    configuration = re.search(r"(<netconvertConfiguration[\s\S]*?</netconvertConfiguration>)", raw(ORIGINAL).decode("utf-8")).group(1)
    (OUT / "original-netconvert-configuration.xml").write_text(configuration + "\n", encoding="utf-8")
    flags = {e.tag: e.get("value") for e in ET.fromstring(configuration).find("tls_building")}
    assert flags["tls.guess"] == flags["tls.guess-signals"] == "true" and flags["tls.default-type"] == "actuated"
    net_records = []
    for label, root in [("original_generated", original), ("current238", current), ("legacy_V1_144", legacy)]:
        loc = root.find("location").attrib
        offset = [float(v) for v in loc["netOffset"].split(",")]
        junction = root.find("junction[@id='1975693623']")
        coordinate = float(junction.get("x")) - offset[0], float(junction.get("y")) - offset[1]
        nearest = sorted([{"id": j.get("id"), "type": j.get("type"),
            "distance_m": math.dist((float(j.get("x")) - offset[0], float(j.get("y")) - offset[1]), signal["epsg25832"])}
            for j in root.findall("junction") if not j.get("id", "").startswith(":" )], key=lambda r: r["distance_m"])[:3]
        net_records.append({"case": label, "location": loc, "junction197_attributes": junction.attrib,
            "junction197_OSM_coordinate_difference_m": math.dist(coordinate, target["epsg25832"]),
            "junction197_program": logic(root, "1975693623"), "junction403_present": root.find("junction[@id='4031208918']") is not None,
            "nearest_existing_junctions_to_OSM403": nearest})
    movements = [c.attrib for c in current.findall("connection") if c.get("tl") == "1975693623" and c.get("linkIndex") in {"0", "1", "4", "6"}]
    with gzip.open(OFFICIAL / "535-map_xml.xml.gz", "rb") as handle:
        map_lanes, map_connections = parse_mapem(handle)
    kml = ET.fromstring(raw(OFFICIAL / "535-map_kml.kml.gz"))
    selected_shapes = []
    names = {"Lane 1", "Lane 2", "Lane 3", "Lane 4", "Lane 5", "Lane 6", "LISA object 64 (Stop line)", "LISA object 64 (Shape)"}
    for placemark in [e for e in kml.iter() if local(e.tag) == "Placemark"]:
        name = next((e.text for e in placemark if local(e.tag) == "name"), "")
        if name not in names:
            continue
        coords = [e for e in placemark.iter() if local(e.tag) == "coordinates" and e.text and e.text.strip()]
        lonlat = [tuple(float(v) for v in p.split(",")[:2]) for c in coords for p in c.text.split()]
        points = [project.transform(*p) for p in lonlat]
        selected_shapes.append({"name": name, "lon_lat_points": lonlat, "epsg25832_points": points,
            "distance197_to_polyline_m": project_point_to_polyline(target["epsg25832"], points)[1],
            "distance403_to_polyline_m": project_point_to_polyline(signal["epsg25832"], points)[1],
            "distance197_to_first_point_m": math.dist(target["epsg25832"], points[0]),
            "distance403_to_first_point_m": math.dist(signal["epsg25832"], points[0])})
    identities = json.loads((OFFICIAL / "lsa-identities.json").read_bytes())
    registered = []
    for feature in identities["features"]:
        p = feature["geometry"]["coordinates"][0]
        registered.append({"properties": feature["properties"], "lon_lat": p,
                           "distance197_m": math.dist(project.transform(*p), target["epsg25832"])})
    registered.sort(key=lambda r: r["distance197_m"])
    aerial = json.loads((AERIAL_DIR / "aerial-source.json").read_bytes())
    assert digest(AERIAL_DIR / "aerial.png") == aerial["image_sha256"]
    xmin, ymin, xmax, ymax = aerial["bounds"]
    width, height = aerial["image_size"]
    placements = []
    for node in [target, signal]:
        x, y = node["epsg25832"]
        placements.append({"node": node["id"], "in_declared_aerial_bounds": xmin <= x <= xmax and ymin <= y <= ymax,
                           "pixel_xy_from_declared_bounds": [(x - xmin) / (xmax - xmin) * width, (ymax - y) / (ymax - ymin) * height]})
    save("OSM-nodes-and-ways.json", [target, signal])
    save("current-original-legacy-controls.json", {"networks": net_records, "original_conversion_tls_flags": flags,
         "current_additional197_program": additional_logic,
         "additional197_only_programID_renamed": True, "current_shared_movements": movements})
    save("official535-spatial-evidence.json", {"official_source_records": official_records,
         "official_retrieval_utc": official_manifest["retrieved_at_utc"], "MAP_name": "MAP_ITS_05_535_9.2",
         "MAP_revision": 2, "vehicle_approach1_lanes": [asdict(lane) for lane in map_lanes if lane.ingress_approach == "1" and lane.is_vehicle],
         "approach1_connections": [asdict(c) for c in map_connections if c.ingress_lane_id in {"1", "2", "3", "4"}],
         "selected_KML_shapes": selected_shapes, "nearest_three_in_frozen68_registry": registered[:3],
         "claim_boundary": "Approach lane extent and distance locate the source geometry. They do not assign a controller, prove a second signal absent, or justify merging/removing controls."})
    save("existing-aerial-relation.json", {"source_metadata": aerial, "placements": placements,
         "pixel_size_m_from_bbox_and_image": [(xmax - xmin) / width, (ymax - ymin) / height],
         "metadata_derived_pixel_size_disagrees": abs(aerial["display_pixel_size_m"] - (xmax - xmin) / width) > 1e-9,
         "viewed_existing_image": True, "rerendered": False,
         "visual_observation": "Broad 535 eastern approach with a marked stop/crossing region west of node197's declared image position. The image alone does not identify an independent controller or prove that no signal head exists at197.",
         "uncertainty": "Use recorded request bbox/image dimensions for placement; the separate display_pixel_size_m metadata conflicts. Image is 2026-03-19 context, not October SPaT or controller-wiring evidence."})
    assert hashes == {str(p): digest(p) for p in files}
    save("report.json", {"status": "review_required", "source_read_checks": "pass", "native_runs": 0, "candidates_created": 0,
         "independent_field_controller197_established": False, "duplicate_controller_proven": False,
         "facts": ["OSM197 is untagged in two frozen snapshots;403 is an explicit forward road traffic signal on186821027.",
                   "Current197 actuated states/timings/type inherit original generated logic; additional programID is renamed readme_fixed_A. Original converter enables TLS guessing and defaults to actuated.",
                   "Legacy V1 retains the same georeferenced197 junction as priority without a TLS; scenarios are otherwise different and not a causal comparison.",
                   "Official535 MAP/KML approach1 extends across the197 vicinity, while its stop line is near the403 signal point.",
                   "Existing aerial covers both points but does not establish controller ownership or historical actuation."],
         "interpretation": "Independent actuation is an inherited modelling assumption. A separate or duplicate representation of the535 approach is a source-review hypothesis, not a verified repair.",
         "missing_evidence": ["Exact signal-head/stop-line to controller identity and signal-group mapping at197 versus535", "Dated wiring/engineering plan establishing independent versus common ownership", "Contemporaneous operating mode or field SPaT"],
         "no_edit_scope": "No merge, signal deletion, phase change, road edit or demand change. Distance and map coverage have no edit authority.",
         "source_hashes": hashes})
    print(json.dumps({"status": "review_required", "source_checks": "pass", "OSM197_tags": target["tags"],
         "original_TLS_flags": flags, "legacy197_type": net_records[-1]["junction197_attributes"]["type"],
         "independent_control_established": False, "duplicate_proven": False}, indent=2))


if __name__ == "__main__":
    main()
