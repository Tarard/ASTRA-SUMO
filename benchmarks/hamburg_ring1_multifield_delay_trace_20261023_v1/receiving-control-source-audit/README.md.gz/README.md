# 1975693623接收路口的控制来源

结论为`review_required`。现有资料没有证实1975693623是独立现场控制器，也没有证实它是应移除的重复控制。当前actuated设置是继承的生成假设；它可能把535进口道的一段另作控制，但这仍是待核归属问题。本审查没有新仿真、候选、重绘或路网/控制改动。

## 原OSM位置与生成控制分开

两个冻结原OSM副本给出完全相同的节点：1975693623位于经度10.0045770、纬度53.5542567，标签为空。它本身没有`highway=traffic_signals`、控制器身份或独立运行方式声明。其相邻道路包括Ernst-Merck-Straße和`service=parking_aisle`的28665128。空标签不证明现场没有信号。

OSM4031208918位于经度10.0041373、纬度53.5541918，明确有`highway=traffic_signals`、`traffic_signals=signal`、`traffic_signals:direction=forward`和`crossing=no`。它是186821027有向道路的中间节点，两点相距约30.01 m。`OSM-nodes-and-ways.json`保留两点的原标签、成员道路和坐标，未按距离推定归属。

冻结的`original-osm.net.xml`已把197建成`traffic_light`和actuated程序。其头部实际转换配置是：`tls.guess=true`、`tls.guess-signals=true`、`tls.default-type=actuated`、`tls.rebuild=true`、`tls.join=true`、`tls.join-dist=0`。原配置片段逐字提取在`original-netconvert-configuration.xml`。因此不能把转换后的独立TLS反当作原OSM独立控制的证据，也不能只凭配置确定究竟由哪条猜测规则建立了这个节点。

当前238路网保留该生成程序的type、offset、全部state、duration、minDur和maxDur。实际`control.add.xml`另载入同样的状态与时长，只把programID从`0`改名为`readme_fixed_A`；名称含fixed不表示该程序变成static。当前共享节点的links0/1连接`-186821028→186821027#0`，links4/6连接`186821029#1→28665128#0`。这些均保存在`current-original-legacy-controls.json`。

## 历史V1对照

历史V1冻结144路网中，同一197节点为`priority`，没有tlLogic。按各自netOffset还原后，它与同一OSM坐标只差0.0038 m；当前和原始生成网差约0.00013 m，身份匹配不只依赖相同ID。V1中4031208918没有独立junction/TLS；其地理点最近的保留节点为LSA535_part0，距26.716 m。这只是定位，不能单凭最近关系认定所有权。

V1与当前场景的道路、车道、需求、驾驶规则、窗口和指标均有其他差异。这不是对197控制的配对试验，不能用V1的完成或历史零指标证明当前应撤灯。

## 官方535车道和停线关系

使用2026-10-20冻结的官方535 MAP XML、KML、OCIT组，三份压缩和解压原始SHA均核对通过。MAP名称`MAP_ITS_05_535_9.2`，revision2；它不声明本次十月运行的现场SPaT。原始来源为[MAP XML](https://daten-hamburg.de/tlf_public/MAP_ITS_05_535_9.2_R2_Quelle_ETRS89.xml)、[KML](https://daten-hamburg.de/tlf_public/MAP_ITS_05_535_9.2_R2_Quelle_ETRS89.kml)和[OCIT](https://daten-hamburg.de/tlf_public/OCIT-C/MAP_ITS_05_535_9.2.xml)。本次只读冻结副本，没有重新联网取得新版。

下表用官方KML明确的经纬度折线投影到EPSG:25832；距离仅说明空间对应。

| 官方535几何 | 到197的折线距离 | 到403信号点的折线距离 | 首端到197 |
|---|---:|---:|---:|
| 进口1，Lane1 | 1.754 m | 4.696 m | 28.360 m |
| 进口1，Lane2 | 5.003 m | 1.589 m | 28.867 m |
| 进口1，Lane3 | 8.448 m | 2.286 m | 29.703 m |
| 进口1，Lane4 | 11.272 m | 5.450 m | 30.732 m |
| KML LISA object64 Stop line | 30.240 m | 3.890 m | 30.240 m |

MAP XML给进口1的Lane1/2信号组5，Lane3/4信号组6。官方535进口车道延伸至197附近，其停线几何更接近OSM403信号点。这支持把197作为535进口范围与额外控制假设的核查对象。MAP道路范围包含某点不证明该点属于同一个物理冲突区，也不排除另有独立、重复或协调信号。

冻结68项登记点中，最近的是535（Glockengießerwall/Georgsplatz，53.464 m），其次903（Ernst-Merck-Straße/Holzdamm，132.852 m）、2032（174.586 m）。这是该冻结列表中的近邻，不能把列表缺项当作不存在另一控制器的证明。

## 既有航片与原生记录

本次只查看既有LGV航片，没有重绘。记录的EPSG:25832范围是`[566440,5934320,566640,5934520]`，图片1100×1100。197和403均在范围内；197投影坐标约`[566550.0094,5934399.2337]`。2026-03-19航片显示535东侧宽进口道及其西侧停线/过街区域，但无法辨认控制器身份、接线或十月实际运行方式，不能据图断言197处没有任何信号头。

航片来源记录的`display_pixel_size_m=0.1272727`与明确bbox和图片尺寸计算的0.1818182 m不一致。本审查保留该元数据分歧，只用记录的bbox/尺寸说明覆盖关系；不把像素定位当作测绘或撤控依据。图像原SHA已核对，原图未改。

另与已通过12/12对应检查的1对focal重放衔接：11487–11493 s，`od_0266_v00020`停在`186821029#1_2`，197 link6为r；11494 s变g并起步，11495 s进入`:1975693623_6_0`。这说明该模型控制确实约束了过535后的出口通行。它不能解释此前在535前形成的180.1 s主要差值，也不是撤控反事实。该窗11200–11510 s的selected与1对197实际phase/state相同。`existing-trace-crosscheck.json`绑定已有记录与这些样本；空leader记录不被解释为空下游。

仍缺少信号头/停线到控制器及信号组的准确对应、能区分独立与共同控制的同期工程接线资料，以及运行方式或现场SPaT。没有这些证据，本目录不提出并点、删控或相位修改。`report.json`、全部来源哈希和`manifest.json`保留这一边界。
