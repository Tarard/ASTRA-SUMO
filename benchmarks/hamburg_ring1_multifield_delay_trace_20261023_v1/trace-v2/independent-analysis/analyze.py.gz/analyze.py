"""Read a completed, parity-checked observer replay. Never start SUMO."""

from bisect import bisect_right
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
TRACE = OUT.parent / "baseline"
ROOT = OUT.parents[3]
FOCAL = "od_0266_v00020"
OLD_TRACE = ROOT / "outputs/hamburg-z5-upstream-delay-20261023-v1/trace/baseline"
TIME_LOOKUPS = {}


def read(path):
    return json.loads(path.read_bytes())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def tls_history(path):
    values = defaultdict(list)
    for _, row in ET.iterparse(path, events=("end",)):
        if row.tag == "tlsState" and row.get("id") in ("205069138", "1975693623", "315029332", "LSA535_part0"):
            values[row.get("id")].append(row.attrib.copy())
        row.clear()
    return values


def at(history, identity, time):
    rows = history[identity]
    if id(rows) not in TIME_LOOKUPS:
        TIME_LOOKUPS[id(rows)] = [float(r["time"]) for r in rows]
    index = bisect_right(TIME_LOOKUPS[id(rows)], time) - 1
    assert index >= 0
    return rows[index]


def number(value):
    return None if value in (None, "None", "") else float(value)


def main():
    gate = read(TRACE / "record-result.json")
    assert gate["status"] == "pass" and gate["checks"] and all(gate["checks"].values())
    assert gate["closed_e1_rows"] == 208 and gate["summary_steps_checked"] == 144000
    history, old_history = tls_history(TRACE / "tls-switch-states.xml"), tls_history(OLD_TRACE / "tls-switch-states.xml")
    samples, all_samples = [], []
    for _, row in ET.iterparse(TRACE / "cohort-fcd.xml", events=("end",)):
        if row.tag != "timestep":
            continue
        time = float(row.get("time"))
        for vehicle in row.findall("vehicle"):
            if vehicle.get("id") == FOCAL:
                value = {"time_s": time, **vehicle.attrib}
                all_samples.append(value)
                if 11200 <= time <= 11510:
                    for identity, link in (("205069138", 5), ("1975693623", 6), ("LSA535_part0", 26)):
                        signal = at(history, identity, time)
                        value[identity + "_phase"] = signal["phase"]
                        value[identity + "_link_" + str(link)] = signal["state"][link]
                    samples.append(value)
        row.clear()
    assert samples and all_samples
    columns = list(dict.fromkeys(key for row in samples for key in row))
    with (OUT / "focal-fcd.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(samples)
    segments = []
    for row in samples:
        if not segments or segments[-1]["lane"] != row["lane"]:
            segments.append({"lane": row["lane"], "rows": []})
        segments[-1]["rows"].append(row)
    compact = []
    for segment in segments:
        rows = segment["rows"]
        gaps = [number(r.get("leaderGap")) for r in rows if number(r.get("leaderGap")) is not None and number(r.get("leaderGap")) >= 0]
        compact.append({"lane": segment["lane"], "first_sample_s": rows[0]["time_s"], "last_sample_s": rows[-1]["time_s"],
                        "samples": len(rows), "first_position_m": float(rows[0]["pos"]), "last_position_m": float(rows[-1]["pos"]),
                        "stopped_samples_speed_lt_0_1": sum(float(r["speed"]) < .1 for r in rows),
                        "min_speed_m_s": min(float(r["speed"]) for r in rows), "min_recorded_leader_gap_m": min(gaps, default=None),
                        "recorded_leaders": dict(Counter(r.get("leaderID", "") for r in rows))})
    write("lane-segments.json", {"vehicle_id": FOCAL, "rows": compact,
          "limit": "One-second FCD samples bound lane presence; they do not locate an exact lane-entry time. Reported leader data does not provide a complete dynamic conflict/foe state. Negative leader gaps are missing-leader sentinels."})
    changes = [r.attrib for _, r in ET.iterparse(TRACE / "lanechanges.xml", events=("end",)) if r.get("id") == FOCAL]
    monitor = read(TRACE / "stall-monitor.json")
    holds = monitor["lane_section_hold"]
    write("focal-changes-holds.json", {"lanechanges": changes,
          "field_holds": [r for r in holds["events"] if r.get("vehicle_id") == FOCAL],
          "body_holds": [r for r in holds["junction_body_hold"]["events"] if r.get("vehicle_id") == FOCAL],
          "focal_tripinfo": next(v.attrib for v in ET.parse(TRACE / "tripinfo.xml").getroot().findall("tripinfo") if v.get("id") == FOCAL),
          "limit": "Lanechange output records completed changes, not every desire, failed attempt or rejected gap."})
    windows = []
    for begin, end in ((11295, 11317), (11385, 11407), (11475, 11497)):
        rows = [r for r in samples if begin <= r["time_s"] < end]
        windows.append({"begin_s": begin, "end_s": end, "focal_samples": len(rows),
                        "lanes": dict(Counter(r["lane"] for r in rows)),
                        "stopped_samples_speed_lt_0_1": sum(float(r["speed"]) < .1 for r in rows),
                        "leaders": dict(Counter(r.get("leaderID", "") for r in rows)),
                        "samples": rows})
    write("left-turn-windows.json", {"vehicle_id": FOCAL, "windows": windows,
          "limit": "The 535 indication is permissive g. Green plus a stopped vehicle does not establish receiving blockage. The leader field does not provide a complete foe table or a direct gap-acceptance decision."})
    comparisons = []
    for identity in history:
        for begin, end in ((11200, 11510), (0, 14400)):
            differences = []
            for tick in range(begin * 10, end * 10):
                time = tick / 10
                new, old = at(history, identity, time), at(old_history, identity, time)
                if (new["state"], new["phase"]) != (old["state"], old["phase"]):
                    differences.append(time)
            comparisons.append({"tls": identity, "time_begin_s": begin, "time_end_s": end,
                                "different_0_1s_samples": len(differences), "first_difference_s": min(differences, default=None),
                                "last_difference_s": max(differences, default=None)})
    write("actual-tls-comparison.json", {"selected_vs_one_pair": comparisons,
          "one_pair_switches": {i: [r for r in rows if 11200 <= float(r["time"]) <= 11510] for i, rows in history.items()},
          "limit": "Recorded model states, not field SPaT. Equality is checked at recorded state timestamps on the 0.1s grid, subject to observer output timing at switch boundaries."})
    paths = [TRACE / n for n in ("record-result.json", "cohort-fcd.xml", "lanechanges.xml", "tls-switch-states.xml", "stall-monitor.json", "network.net.xml")]
    paths.append(OLD_TRACE / "tls-switch-states.xml")
    leader = "od_0271_v00019"
    leader_rows = {}
    for label, native in (("reference", ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"),
                          ("one_pair", TRACE)):
        paths.extend(native / n for n in ("demand.rou.xml", "tripinfo.xml", "vehicle-routes.xml", "lane-intentions.json"))
        demand = next(v for v in ET.parse(native / "demand.rou.xml").getroot().findall("vehicle") if v.get("id") == leader)
        route = next(v for v in ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle") if v.get("id") == leader)
        trip = next(v for v in ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo") if v.get("id") == leader)
        intention = next(v for v in read(native / "lane-intentions.json")["vehicles"] if v["vehicle_id"] == leader)
        leader_rows[label] = {"demand_xml": ET.tostring(demand, encoding="unicode"), "route_xml": ET.tostring(route, encoding="unicode"),
                              "tripinfo": trip.attrib, "intention": intention}
    assert leader_rows["reference"] == leader_rows["one_pair"]
    write("leader-equivalence.json", {"status": "pass", "leader_id": leader, "demand_route_exits_tripinfo_intention_identical": True,
          "reference_and_one_pair": leader_rows["reference"],
          "limit": "Equal source XML, completed-route exit times and trip totals do not establish identical unobserved continuous trajectories."})
    hashes = []
    for path in paths:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(part)
        hashes.append({"path": path.relative_to(ROOT).as_posix(), "sha256": digest.hexdigest()})
    write("source-hashes.json", {"parity_checks": gate["checks"], "sources": hashes})
    print("Completed observer parity gate passed; focal trajectory and actual TLS extracted offline.")


if __name__ == "__main__":
    main()
