"""Read existing one-pair outputs; do not prepare demand or run SUMO."""

from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.local_network_conversion import loaded_turn_permissions

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
OLD = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"
NEW = STUDY / "substitute-1pair/evaluation/native"
TRACE = ROOT / "outputs/hamburg-z5-upstream-delay-20261023-v1/trace/baseline"
IDENTITY = "od_0266_v00020"


def read(path):
    return json.loads(path.read_bytes())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def vehicle_map(path):
    return {row.get("id"): row for row in ET.parse(path).getroot() if row.tag in ("vehicle", "tripinfo")}


def main():
    sources = [STUDY / "proposal/one-pair.json", TRACE / "tls-switch-states.xml",
               TRACE / "record-result.json", TRACE / "observed-vehicle-ids.json", STUDY / "substitute-1pair/verdict.json"]
    terminal, tables, times = {}, [], {}
    for label, native in (("reference", OLD), ("one_pair", NEW)):
        sources.extend(native / name for name in ("demand.rou.xml", "lane-intentions.json", "tripinfo.xml",
                                                 "vehicle-routes.xml", "queues.xml", "network.net.xml", "signal-programs.add.xml", "summary.xml"))
        demand = vehicle_map(native / "demand.rou.xml")
        trips = vehicle_map(native / "tripinfo.xml")
        routes = vehicle_map(native / "vehicle-routes.xml")
        fields = {r["vehicle_id"]: r["field_id"] for r in read(native / "lane-intentions.json")["vehicles"]}
        waiting = sorted(set(demand) - set(trips))
        running = sorted(i for i, t in trips.items() if float(t.get("arrival")) < 0)
        final = None
        for _, row in ET.iterparse(native / "summary.xml", events=("end",)):
            if row.tag == "step":
                final = row.attrib.copy()
            row.clear()
        assert int(final["loaded"]) == len(demand) and int(final["inserted"]) == len(trips)
        assert int(final["waiting"]) == len(waiting) and int(final["running"]) == len(running)
        assert int(final["arrived"]) == len(routes)
        terminal[label] = {}
        for status, identities in (("waiting", waiting), ("running", running)):
            terminal[label][status] = {"count": len(identities), "ids": identities,
                "origins": dict(Counter(demand[i].find("route").get("edges").split()[0] for i in identities)),
                "fields": dict(Counter(fields[i] for i in identities))}
            for identity in identities:
                tables.append({"case": label, "status": status, "vehicle_id": identity,
                               "field_intention": fields[identity], "planned_route": demand[identity].find("route").get("edges"),
                               "actual_depart_s": trips[identity].get("depart") if identity in trips else "",
                               "actual_depart_lane": trips[identity].get("departLane") if identity in trips else "",
                               "terminal_lane": "unknown"})
        assert all(i not in routes for i in running)
        route = routes[IDENTITY].find("route")
        times[label] = list(zip(route.get("edges").split(), map(float, route.get("exitTimes").split())))
    write("terminal-backlog.json", {"status": "pass", "cases": terminal,
        "limit": "Unfinished trips have no arrival lane and are absent from vehroute output. Their final edge, lane and position are unknown. Waiting IDs are requests absent from tripinfo; summary agrees."})
    with (OUT / "terminal-backlog.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(tables[0]))
        writer.writeheader()
        writer.writerows(tables)
    old_times = dict(times["reference"])
    delta = []
    for label in times:
        previous = float(vehicle_map((OLD if label == "reference" else NEW) / "vehicle-routes.xml")[IDENTITY].get("depart"))
        for edge, time in times[label]:
            delta.append({"case": label, "edge": edge, "exit_s": time, "since_previous_normal_edge_exit_s": round(time - previous, 3),
                          "exit_delta_vs_reference_s": round(time - old_times[edge], 3) if edge in old_times else None})
            previous = time
    write("retained-edge-exits.json", {"vehicle_id": IDENTITY, "rows": delta,
        "limit": "Exit-to-exit duration includes the intervening junction. It is not an observed normal-edge entry time or a lane trace."})
    net = ET.parse(NEW / "network.net.xml").getroot()
    loaded = loaded_turn_permissions(net)
    programs = {t.get("id"): t for t in ET.parse(NEW / "signal-programs.add.xml").getroot().findall("tlLogic")}
    chain = [("186713428", 1, "551303409", 2), ("551303409", 2, "551303410", 2),
             ("551303410", 2, "551303417", 3), ("551303417", 3, "186722706", 4),
             ("186722706", 4, "551303416", 2), ("551303416", 2, "551303423", 3),
             ("551303423", 3, "551303424", 4), ("551303424", 4, "189775480", 4),
             ("189775480", 4, "186821034#0", 5), ("186821034#0", 5, "186821029#1", 2),
             ("186821029#1", 2, "28665128#0", 0)]
    connections = []
    for key in chain:
        assert "passenger" in loaded[key]
        row = next(c for c in net.findall("connection") if
                   (c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))) == key)
        connections.append({**row.attrib, "compiled_passenger_permission": True,
                            "control_type": programs[row.get("tl")].get("type") if row.get("tl") else "unsignalized"})
    states = defaultdict(list)
    for _, row in ET.iterparse(TRACE / "tls-switch-states.xml", events=("end",)):
        if row.tag == "tlsState" and row.get("id") in ("205069138", "1975693623", "315029332", "LSA535_part0"):
            states[row.get("id")].append(row.attrib.copy())
        row.clear()
    declarations = {identity: {"attributes": programs[identity].attrib,
                               "phases": [p.attrib for p in programs[identity].findall("phase")],
                               "recorded_selected_switches": len(states[identity])}
                    for identity in states}
    write("lane-control-path.json", {"status": "pass", "early_lane_continuation": connections,
        "control": declarations,
        "selected_actual_switches_11260_11510": {i: [r for r in rows if 11260 <= float(r["time"]) <= 11510] for i, rows in states.items()},
        "retained_vehicle_in_existing_selected_fcd_cohort": IDENTITY in str(read(TRACE / "observed-vehicle-ids.json")),
        "limits": ["This is a legal lane continuation, not the native lane chosen by this vehicle.",
                   "Getting to 186722706 lane4 may require earlier lane changes. Legal connections do not prove available gaps under congestion.",
                   "Selected actual model TLS history is recorded. One-pair actual TLS history is unavailable, so a phase response difference is not yet observed.",
                   "A recorded model signal is not field SPaT."]})
    windows = (("retained_delay", 11270, 11480), ("tail", 13500, 14400))
    wanted = ("-142944318_", "-186821026_", "-186821028_", "186821027#0_", "186821029#1_", "186821034#0_", "189775480_")
    queue_rows = []
    for label, native in (("reference", OLD), ("one_pair", NEW)):
        aggregates = {}
        for _, row in ET.iterparse(native / "queues.xml", events=("end",)):
            if row.tag != "data":
                continue
            time = float(row.get("timestep"))
            window = next((n for n, a, b in windows if a <= time < b), None)
            if window:
                for lane in row.findall("lanes/lane"):
                    identity = lane.get("id")
                    if identity.startswith(wanted):
                        key = window, identity
                        record = aggregates.setdefault(key, {"observed_rows": 0, "max_queueing_length_m": 0})
                        record["observed_rows"] += 1
                        record["max_queueing_length_m"] = max(record["max_queueing_length_m"], float(lane.get("queueing_length")))
            row.clear()
        queue_rows.extend({"case": label, "window": window, "lane": lane, **v} for (window, lane), v in sorted(aggregates.items()))
    write("queue-extents.json", {"windows": windows, "rows": queue_rows,
        "limit": "Queue extent is a lane-level stopped rear-to-lane-end maximum, not a continuous queue or any named vehicle position. Missing rows do not establish empty or free reception."})
    old_events = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/selected-next-diagnosis/selected-contributing-passages.json.gz"
    event_sources = (("reference", old_events), ("one_pair", NEW.parent / "contributing-passages.json.gz"))
    sources.extend(path for _, path in event_sources)
    hashes = []
    for path in sources:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(part)
        hashes.append({"path": path.relative_to(ROOT).as_posix(), "sha256": digest.hexdigest()})
    write("source-hashes.json", hashes)
    # Small native complete-passages files are sufficient here; do not scan or alter raw events.
    pair_events = {}
    for label, path in event_sources:
        data = json.loads(gzip.decompress(path.read_bytes()))
        pair_events[label] = [r for r in data["passages"] if r["vehicle_id"] in (IDENTITY, "od_0256_v00006")]
    write("paired-native-events.json", pair_events)
    print("Read-only one-pair diagnosis complete; no candidate or native run created.")


if __name__ == "__main__":
    main()
