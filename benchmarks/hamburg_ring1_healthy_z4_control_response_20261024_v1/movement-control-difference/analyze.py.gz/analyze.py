"""Classify actual controlled bits and compare existing native state histories."""

from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import runpy
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.local_network_conversion import loaded_turn_permissions
from astra_sumo.core.osm_access import _MOTOR_MODES, _permission_set

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
RECORD = REPO / "outputs/hamburg-healthy-z4-control-response-20261023-v1"
NET = RECORD / "reference/network.net.xml"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
                         for k, v in row.items()} for row in rows)


def category(modes, unknown):
    if unknown or not modes:
        return "unknown"
    if modes == {"pedestrian"}:
        return "ped-only"
    if modes == {"bicycle"}:
        return "bike-only"
    if modes <= _MOTOR_MODES:
        return "motor"
    if modes <= (_MOTOR_MODES | {"pedestrian", "bicycle"}):
        return "mixed"
    return "unknown"


def main():
    net = ET.parse(NET).getroot()
    loaded = loaded_turn_permissions(net)
    lane_map = {(e.get("id"), int(lane.get("index", i))): lane
                for e in net.findall("edge") for i, lane in enumerate(e.findall("lane"))}
    control = ET.parse(RECORD / "reference/signal-programs.add.xml").getroot()
    widths = {t.get("id"): len(t.find("phase").get("state")) for t in control.findall("tlLogic")}
    bound, all_connections = defaultdict(list), []
    for c in net.findall("connection"):
        if not c.get("tl"):
            continue
        tls, index = c.get("tl"), int(c.get("linkIndex"))
        key = (c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane")))
        unknown = False
        if key in loaded:
            modes = loaded[key]
            basis = "loaded_turn_permissions: complete ordinary-road/internal chain"
        elif not c.get("via") and (key[0], key[1]) in lane_map and (key[2], key[3]) in lane_map:
            modes = _permission_set(lane_map[key[0], key[1]].attrib, network_version=net.get("version")) & _permission_set(lane_map[key[2], key[3]].attrib, network_version=net.get("version"))
            basis = "explicit direct internal connection endpoint permission intersection"
        else:
            modes, basis, unknown = set(), "unresolved controlled connection", True
        row = dict(tls_id=tls, link_index=index, connection=dict(c.attrib), loaded_modes=sorted(modes),
                   passenger="passenger" in modes, motor=bool(modes & _MOTOR_MODES),
                   permission_basis=basis, unresolved=unknown)
        bound[tls, index].append(row)
        all_connections.append(row)
    inventory = {r["tls_id"]: r for r in csv.DictReader((RECORD / "control-inventory/tls-inventory.csv").open(encoding="utf-8", newline=""))}
    bits = {}
    for tls, width in widths.items():
        for index in range(width):
            connections = bound[tls, index]
            modes = set().union(*(set(c["loaded_modes"]) for c in connections))
            unknown = not connections or any(c["unresolved"] for c in connections)
            bits[tls, index] = dict(tls_id=tls, link_index=index, category=category(modes, unknown),
                passenger_available=True if any(c["passenger"] for c in connections) else None if unknown else False,
                motor_available=True if any(c["motor"] for c in connections) else None if unknown else False, loaded_modes=sorted(modes),
                controlled_connection_count=len(connections), permission_unresolved=unknown,
                current_active_type=inventory[tls]["current_active_type"],
                current_program_origin=inventory[tls]["current_program_origin"])
    helper = runpy.run_path(str(RECORD / "compare_tls.py"))
    records = {v: json.loads((RECORD / v / "record-result.json").read_bytes()) for v in ("reference", "one-car")}
    assert all(r["status"] == "pass" and all(r["checks"].values()) for r in records.values())
    states = {v: helper["read_states"](RECORD / v / "tls-switch-states.xml", widths) for v in records}
    intervals, summaries, bins = [], [], []
    first_passenger = first_motor = None
    for tls in sorted(widths):
        a, b = states["reference"][tls], states["one-car"][tls]
        edges = sorted({0, 144000} | {r["tick"] for r in a + b})
        ai = bi = 0
        durations, firsts, bin_counts = Counter(), {}, defaultdict(Counter)
        for begin, end in zip(edges, edges[1:]):
            while ai+1 < len(a) and a[ai+1]["tick"] <= begin:
                ai += 1
            while bi+1 < len(b) and b[bi+1]["tick"] <= begin:
                bi += 1
            changed = [i for i, (x, y) in enumerate(zip(a[ai]["state"], b[bi]["state"])) if x != y]
            if not changed:
                continue
            passenger = [i for i in changed if bits[tls, i]["passenger_available"]]
            motor = [i for i in changed if bits[tls, i]["motor_available"]]
            groups = {"all": changed, "passenger": passenger, "motor": motor}
            groups.update({name: [i for i in changed if bits[tls, i]["category"] == name]
                           for name in ("ped-only", "bike-only", "mixed", "unknown")})
            for group, indices in groups.items():
                if not indices:
                    continue
                durations[group] += end - begin
                firsts.setdefault(group, begin)
                for window in range(begin // 9000, (end - 1) // 9000 + 1):
                    bin_counts[window][group] += min(end, (window+1)*9000) - max(begin, window*9000)
            row = dict(tls_id=tls, begin_tick=begin, end_tick=end, begin_s=begin/10, end_s=end/10,
                       changed_indices=changed, passenger_indices=passenger, motor_indices=motor,
                       reference_state=a[ai]["state"], one_car_state=b[bi]["state"])
            intervals.append(row)
            for name, selected in (("passenger", passenger), ("motor", motor)):
                previous = first_passenger if name == "passenger" else first_motor
                if selected and (previous is None or begin < previous["begin_tick"]):
                    first = {**row, "selected_indices": selected,
                             "actual_controlled_links": [r for i in selected for r in bound[tls, i]]}
                    if name == "passenger":
                        first_passenger = first
                    else:
                        first_motor = first
        summary = dict(tls_id=tls, current_active_type=inventory[tls]["current_active_type"],
                       current_program_origin=inventory[tls]["current_program_origin"])
        for group in ("all", "passenger", "motor", "ped-only", "bike-only", "mixed", "unknown"):
            summary[group+"_first_difference_s"] = firsts[group]/10 if group in firsts else None
            summary[group+"_different_seconds"] = durations[group]/10
        summaries.append(summary)
        for index in range(16):
            bins.append(dict(tls_id=tls, begin=index*900, end=(index+1)*900,
                             all_color_difference_s=bin_counts[index]["all"]/10,
                             passenger_color_difference_s=bin_counts[index]["passenger"]/10,
                             motor_color_difference_s=bin_counts[index]["motor"]/10))
    intervals.sort(key=lambda r: (r["begin_tick"], r["tls_id"]))
    assert intervals[0]["begin_tick"] == 89430 and intervals[0]["changed_indices"] == [22, 24]
    assert all(bits["18653534", i]["category"] == "ped-only" for i in (22, 24))
    table(ROOT / "controlled-bits.csv", list(bits.values()))
    table(ROOT / "controlled-connections.csv", all_connections)
    table(ROOT / "difference-intervals.csv", intervals)
    table(ROOT / "per-tls.csv", summaries)
    table(ROOT / "per-tls-900s.csv", bins)
    sources = [NET, RECORD / "reference/signal-programs.add.xml", RECORD / "compare_tls.py", RECORD / "control-inventory/tls-inventory.csv"]
    sources += [RECORD / v / n for v in records for n in ("record-result.json", "tls-switch-states.xml")]
    sources += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / n for n in ("local_network_conversion.py", "osm_access.py", "connection_mode_audit.py")]
    save(ROOT / "results.json", dict(status="pass", formal_result=False, native_runs=0, tls_count=50,
         controlled_bit_count=len(bits), controlled_connection_count=len(all_connections),
         categories=dict(Counter(r["category"] for r in bits.values())),
         passenger_capable_bits=sum(r["passenger_available"] is True for r in bits.values()),
         unbound_or_unresolved_bit_count=sum(r["permission_unresolved"] for r in bits.values()),
         taxonomy_unknown_but_passenger_proven_count=sum(r["category"] == "unknown" and r["passenger_available"] is True for r in bits.values()),
         first_all_color_difference=intervals[0], first_passenger_difference=first_passenger, first_motor_difference=first_motor,
         passenger_different_controllers=[r for r in summaries if r["passenger_different_seconds"]],
         motor_different_controllers=[r for r in summaries if r["motor_different_seconds"]],
         source_hashes={str(p): sha(p) for p in sources},
         category_definition="Permission union per controlled bit: ped-only/bike-only exact singleton; motor subset of existing repository_MOTOR_MODES; mixed combines these known classes; unresolved/empty/other classes unknown. Passenger availability is a separate explicit membership test.",
         duration_definition="Controller seconds with any selected movement bit unequal, not summed bit-seconds or observed vehicle delay.",
         claim_boundary="Static loaded model permissions and existing parity-verified simulated color histories only. No count fields removed, no new simulation, no direct phase-history inference, and no attribution of all count loss or fieldSPaT."))
    print(json.dumps(dict(first_passenger_s=first_passenger["begin_s"], first_motor_s=first_motor["begin_s"],
                         tls=first_passenger["tls_id"], indices=first_passenger["selected_indices"],
                         passenger_different_controllers=sum(bool(r["passenger_different_seconds"]) for r in summaries),
                         categories=dict(Counter(r["category"] for r in bits.values()))), ensure_ascii=False))


if __name__ == "__main__":
    main()
