# 实际灯色差中的 passenger 可用 movement

**首个 passenger 可用、同时也是已证明 motor 可用的控制位差为 8948.0 秒，TLS 18653534。** reference 为 y，one-car 为 g/G，首次区间为 8948–8951 秒，涉及 index 1、2、4、12、13、15、16。来源是两份已通过 20/20 交通复核的原生 SwitchStates 完整状态串，没有新仿真。原始全颜色结果保持原样：8943.0 秒仅 index22/24 的 pedestrian crossing 由 r→G，未改变此刻的 passenger 位。

| index | 实际受控连接 | via | reference→one-car |
|---:|---|---|---|
| 1 | -983227468#0 lane1→139083723#0 lane2 | :18653534_0_1 | y→g |
| 2 | -983227468#0 lane1→-448511533#3 lane1 | :18653534_2_0 | y→G |
| 4 | -983227468#0 lane1→983227468#0 lane1 | :18653534_4_0 | y→g |
| 12 | 448511533#3 lane1→-139083714#2 lane1 | :18653534_12_0 | y→g |
| 13 | 448511533#3 lane1→983227468#0 lane1 | :18653534_13_0 | y→G |
| 15 | 448511533#3 lane1→139083723#0 lane3 | :18653534_14_1 | y→g |
| 16 | 448511533#3 lane1→-448511533#3 lane1 | :18653534_16_0 | y→g |

所有这些连接均由 `loaded_turn_permissions` 的完整普通路/内部通路权限链证实允许 vClass passenger。`controlled-connections.csv` 保存原始受控 connection 属性、允许类和权限依据；`controlled-bits.csv` 保存全部 50 TLS 的 431 位分类。类别按该位允许类的并集：ped-only、bike-only、motor、mixed；另保留 unknown。motor 使用现有仓库 `_MOTOR_MODES` 定义，passenger 是独立的明确成员判断，不靠类别名称猜测。

共有 59 个 unknown 类别：58 位在当前 XML 找不到受控 connection，其 passenger/motor 可用性保留为空；另 1 位有已证明的 passenger 权限，但还含该 road-mode 分类外的类，类别仍为 unknown。未把 unknown 当成机动车不可用。分类没有删除任何控制位、真实计数字段或原 130 行目标。

全窗有 **17 个控制器**出现已证明 passenger/motor 可用位的字元差，少于全颜色结果的 18 个；3673603285 只有非 passenger 位变化。首差和累计持续时间见 `per-tls.csv`，每 900 秒段见 `per-tls-900s.csv`，精确状态串与变动位见 `difference-intervals.csv`。持续时间是每控制器“任一选中位不同”的区间并集，不是 bit-seconds 之和，也不是车辆延误。

18653534 的当前 type=actuated，程序来源在现有 inventory 中为继承/推断，现场控制归属未确认。programID 名称不能证明它是固定式。该分析只细化模型中的信号响应；既不证明所有计数损失来自信号，也不推断完整 phase index 历史或现场 SPaT。全部来源哈希保存在 `results.json`，原网络、控制和两份记录均未改。
