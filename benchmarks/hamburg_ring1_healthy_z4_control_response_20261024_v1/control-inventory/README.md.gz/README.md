# 旧V1与当前健康基准的控制清单（只读）

| 冻结输入 | 普通road | SUMO TLS ID | static | actuated |
|---|---:|---:|---:|---:|
| 历史README V1 | 144 | 26 | 26 | 0 |
| 当前健康full-priority | 238 | 50 | 10 | 40 |

共同ID **18**、仅当前 **32**、仅旧V1 **8**；完整名单与逐项来源见 [CSV](tls-inventory.csv) 和 [集合清单](inventory-summary.json)。共同ID中12项由旧文件static变为当前actuated。TLS数按模型ID计，不是现场独立控制柜数量；共同ID也不证明控制域或程序相同。

当前应按外部control解释实际记录：网络内嵌为41 actuated/9 static，外部程序将6390683126设为static，成为40/10。programID虽名为readme_fixed_A，类型仍以type属性为准。外部control与原生快照字节相同。

| 官方LSA | 当前模型TLS | OCIT引用 | 来源边界 |
|---|---|---|---|
| 104 | LSA104_part0 | SP5 | 固定替代感应是声明等效 |
| 118 | LSA118_part0/1 | SP5 | 固定替代感应是声明等效 |
| 119 | LSA119_part0 | SP1 | 官方时序派生，含声明绑定/补充 |
| 200 | LSA200_part0/1/2/3 | SP5 | 施工阶段对应仍有限制 |
| 535 | LSA535_part0 | SP1 | 官方时序派生，含声明绑定/补充 |

这五个官方身份展开为9个static模型TLS。另1个static是6390683126：Z15备选A声明对应119 SP1/K9，不能因有source_program_reference就称为已证实官方绑定。其余40个actuated归“继承/推断程序”；本清单没有逐点确认现场控制归属或感应参数。所有当前项均未取得现场SPaT来确认绝对相位和实际响应。

197已有单点证据：旧网为priority，原OSM无标签，原生成网建立推断TLS；当前另含声明的连接优先级适配，独立现场控制归属仍未知。266在旧网未单列节点，当前为既定条件priority，不在50个TLS内。两处既有证据不能推广到其他ID。

解释后续colour首差时，可按CSV的current_active_type与current_program_origin归类；实际感应颜色可随交通改变，输入清单不能代替实际记录。道路覆盖和路口分割不同，缺少ID不证明多余，也不据此撤灯。本次没有新候选、仿真、网上SPaT或逐点航片审计。来源及原始字节哈希见 [source-hashes](source-hashes.json)。
