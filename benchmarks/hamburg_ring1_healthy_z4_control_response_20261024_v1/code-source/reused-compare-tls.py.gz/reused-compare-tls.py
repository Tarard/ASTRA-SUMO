"""Compare native state histories on integer ticks and audit the program export."""
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tick(value):
    number = Decimal(value)*10
    assert number == number.to_integral_value(), value
    return int(number)


def read_states(path, widths):
    events = defaultdict(list)
    for _, row in ET.iterparse(path, events=('end',)):
        if row.tag != 'tlsState':
            continue
        identity, time = row.get('id'), tick(row.get('time'))
        assert identity in widths and len(row.get('state')) == widths[identity]
        values = events[identity]
        assert not values or values[-1]['tick'] < time
        values.append({'tick': time, 'state': row.get('state'), 'programID': row.get('programID'),
                       'phase': int(row.get('phase'))})
        row.clear()
    assert events.keys() == widths.keys() and len(events) == 51
    assert all(rows[0]['tick'] == 0 for rows in events.values())
    return events


def main():
    result_paths = {name: ROOT/name/'record-result.json' for name in ('baseline', 'batch64')}
    records = {name: json.loads(path.read_bytes()) for name, path in result_paths.items()}
    assert all(row['status'] == 'pass' and all(row['checks'].values()) for row in records.values())
    assert records['baseline']['source_hashes']['network.net.xml'] == records['batch64']['source_hashes']['network.net.xml']
    assert records['baseline']['source_hashes']['signal-programs.add.xml'] == records['batch64']['source_hashes']['signal-programs.add.xml']
    kinds = records['baseline']['tls_types']
    assert kinds == records['batch64']['tls_types'] and Counter(kinds.values()) == {'actuated': 40, 'static': 11}
    network = ROOT/'baseline/network.net.xml'
    widths = defaultdict(int)
    for row in ET.parse(network).getroot().findall('connection'):
        if row.get('tl'):
            widths[row.get('tl')] = max(widths[row.get('tl')], int(row.get('linkIndex'))+1)
    logs = {name: ROOT/name/'tls-switch-states.xml' for name in records}
    state = {name: read_states(path, widths) for name, path in logs.items()}
    horizon = 54000
    differences, per_tls = [], []
    for identity in sorted(widths):
        a, b = state['baseline'][identity], state['batch64'][identity]
        boundaries = sorted({0, horizon} | {r['tick'] for r in a+b if r['tick'] < horizon})
        ai = bi = 0
        changed_ticks = program_ticks = 0
        first = None
        for begin, end in zip(boundaries, boundaries[1:]):
            while ai+1 < len(a) and a[ai+1]['tick'] <= begin:
                ai += 1
            while bi+1 < len(b) and b[bi+1]['tick'] <= begin:
                bi += 1
            if a[ai]['programID'] != b[bi]['programID']:
                program_ticks += end-begin
            if a[ai]['state'] == b[bi]['state']:
                continue
            changed_ticks += end-begin
            first = begin if first is None else first
            differences.append({'tls_id': identity, 'type': kinds[identity], 'begin_tick': begin, 'end_tick': end,
                'begin_s': begin/10, 'end_s': end/10, 'baseline_state': a[ai]['state'], 'batch64_state': b[bi]['state'],
                'baseline_programID': a[ai]['programID'], 'batch64_programID': b[bi]['programID'],
                'baseline_phase': a[ai]['phase'], 'batch64_phase': b[bi]['phase']})
        per_tls.append({'tls_id': identity, 'type': kinds[identity], 'first_difference_tick': first,
            'first_difference_s': first/10 if first is not None else None, 'different_state_ticks': changed_ticks,
            'different_state_seconds': changed_ticks/10, 'different_program_ticks': program_ticks})
    differences.sort(key=lambda r: (r['begin_tick'], r['tls_id']))
    program_path = ROOT/'baseline/tls-recorded-programs.add.xml'
    exported_root = ET.parse(program_path).getroot()
    exported = exported_root.findall('tlLogic')
    checks = {'additional_root': exported_root.tag == 'additional', 'exactly_51_direct_tlLogic': len(exported_root) == len(exported) == 51,
        'unique_51_bound_tls': len({r.get('id') for r in exported}) == 51 and {r.get('id') for r in exported} == widths.keys()}
    program_audits = []
    for program in exported:
        identity = program.get('id')
        duration = 0
        timeline = []
        valid = program.get('type') == 'static' and program.get('programID') == state['baseline'][identity][0]['programID']
        for phase in program.findall('phase'):
            length = tick(phase.get('duration'))
            valid = valid and length > 0 and len(phase.get('state')) == widths[identity]
            if not timeline or timeline[-1][1] != phase.get('state'):
                timeline.append((duration, phase.get('state')))
            duration += length
        reference, previous = [], None
        for event in state['baseline'][identity]:
            if event['state'] != previous:
                reference.append((event['tick'], event['state']))
                previous = event['state']
        same = timeline == reference
        program_audits.append({'tls_id': identity, 'phase_count': len(program.findall('phase')),
            'duration_ticks': duration, 'duration_seconds': duration/10, 'state_width': widths[identity],
            'states_and_positive_tick_durations_valid': valid, 'state_timeline_equals_independent_switch_log': same})
    checks['all_phase_states_and_durations_valid'] = all(r['states_and_positive_tick_durations_valid'] for r in program_audits)
    checks['all_51_durations_exactly_14400s'] = all(r['duration_ticks'] == 144000 for r in program_audits)
    checks['all_51_exported_timelines_equal_independent_log'] = all(r['state_timeline_equals_independent_switch_log'] for r in program_audits)
    static_unchanged = all(r['different_state_ticks'] == r['different_program_ticks'] == 0 for r in per_tls if r['type'] == 'static')
    result = {'schema': 'astra.hamburg-native-tls-feedback-diagnosis/v1', 'formal_result': False,
        'paired_horizon_s': 5400, 'step_s': .1, 'tls_types': {'actuated': 40, 'static': 11},
        'recording_reference_checks_passed': True, 'all_static_11_state_and_program_histories_identical': static_unchanged,
        'first_actual_state_divergence': differences[0] if differences else None,
        'different_tls_count': sum(r['different_state_ticks'] > 0 for r in per_tls),
        'different_actuated_tls_count': sum(r['different_state_ticks'] > 0 and r['type'] == 'actuated' for r in per_tls),
        'per_tls': per_tls, 'native_program_export': {'path': str(program_path), 'sha256': digest(program_path),
             'status': 'pass' if all(checks.values()) else 'blocked', 'checks': checks, 'program_audits': program_audits},
        'source_hashes': {str(p): digest(p) for p in list(result_paths.values())+list(logs.values())+[network]},
        'claim_boundary': 'The histories are actual native outputs from count- and traffic-matched recordings. '
            'A state divergence establishes an endogenous signal-history difference, not exclusive causation of every shifted vehicle. '
            'No recorded-program replay or new controller was executed.'}
    (ROOT/'comparison.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    with (ROOT/'different-state-intervals.csv').open('w', encoding='utf-8', newline='') as stream:
        fields = list(differences[0]) if differences else ['tls_id', 'begin_tick', 'end_tick']
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(differences)
    print(json.dumps({'first_actual_state_divergence': result['first_actual_state_divergence'],
        'different_actuated_tls_count': result['different_actuated_tls_count'], 'static_11_identical': static_unchanged,
        'program_export': result['native_program_export']['status']}))
    assert static_unchanged and all(checks.values()), checks


if __name__ == '__main__':
    main()
