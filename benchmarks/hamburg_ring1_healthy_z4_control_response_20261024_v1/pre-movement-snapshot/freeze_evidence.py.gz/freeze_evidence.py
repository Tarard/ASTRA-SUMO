"""Freeze the two sealed passive TLS records; no native run is started."""
import argparse
from collections import Counter
import contextlib
import gzip
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import io
import itertools
import json
from pathlib import Path
import tempfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
SOURCE = REPO / 'outputs/hamburg-healthy-z4-control-response-20261023-v1'
GS = REPO / 'benchmarks/hamburg_ring1_119_receiving_priority_20261023_v1'
FEEDBACK = REPO / 'benchmarks/hamburg_ring1_healthy_z4_feedback_20261023_v1'
SOURCES = {'reference': GS / 'full-priority', 'one-car': FEEDBACK / 'batch-1'}
INVENTORY_SHA = '659cdd60de16bc70716cb2c1ed79f770a62015c2077fff688ef340b2d50c7217'
INPUTS = {'network.net.xml', 'demand.rou.xml', 'lane-intentions.json', 'source-e1.add.xml', 'expected-counts.csv', 'signal-programs.add.xml'}
LOCAL = {'instant-e1.xml', 'queues.xml'}
spec = spec_from_file_location('GS_freeze_helpers', GS / 'freeze_evidence.py')
prior = module_from_spec(spec)
spec.loader.exec_module(prior)
raw, load, sha, raw_sha = prior.raw, prior.load, prior.sha, prior.raw_sha
verify_manifest = prior.verify_manifest


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def safe_relative(name):
    path = Path(name)
    assert not path.anchor and '..' not in path.parts and name not in ('', '.')
    return path


def snapshot_relative(name):
    name = safe_relative(str(name))
    return Path('study-source') / name if len(name.parts) == 1 else name


def manifest_paths(directory):
    manifest = load(directory / 'manifest.json')
    paths = []
    for row in manifest['files']:
        name = safe_relative(row['path'])
        path = directory/name
        if path.is_file():
            assert path.stat().st_size == row.get('bytes', row.get('size_bytes')) and sha(path) == row['sha256']
        else:
            value = raw(path)
            assert len(value) == row.get('bytes', row.get('size_bytes')) and hashlib.sha256(value).hexdigest() == row['sha256']
        paths.append(name)
    return [*paths, Path('manifest.json')]


def elements(path, tag):
    for _, row in ET.iterparse(io.BytesIO(raw(path))):
        if row.tag == tag:
            yield row
            row.clear()


def original(variant, name):
    return SOURCES[variant] / 'evaluation/native' / name


def source_parity(case):
    reports = {}
    for variant in SOURCES:
        folder = case/variant
        record = load(folder/'record-result.json')
        preflight = load(folder/'preflight.json')
        assert record['status'] == 'pass' and len(record['checks']) == 20 and all(record['checks'].values())
        assert record['summary_steps_checked'] == 144000 and record['closed_e1_rows'] == 208
        assert Counter(record['tls_types'].values()) == {'actuated': 40, 'static': 10}
        for name in INPUTS:
            assert raw_sha(original(variant, name)) == record['source_hashes'][name]
        for name, expected in preflight['source_hashes'].items():
            assert raw_sha(original(variant, name)) == expected
        assert raw_sha(folder/'record_tls.snapshot.py') == preflight['script_sha256']
        assert raw_sha(folder/'tls-observer.add.xml') == preflight['observer_sha256']
        assert raw_sha(folder/'tls-switch-states.xml') == record['state_log']['sha256']
        assert raw_sha(folder/'tls-recorded-programs.add.xml') == record['program_export']['sha256']
        def intervals(path):
            rows = [dict(r.attrib) for r in elements(path, 'interval') if float(r.get('begin')) < float(r.get('end'))]
            result = {(r['id'], r['begin'], r['end']): r for r in rows}
            assert len(rows) == len(result) == 208
            return result
        assert intervals(folder/'field-counts.xml') == intervals(original(variant, 'field-counts.xml'))
        count, last = 0, None
        for before, after in itertools.zip_longest(elements(original(variant, 'summary.xml'), 'step'), elements(folder/'summary.xml', 'step')):
            assert before is not None and after is not None
            assert {k: v for k, v in before.attrib.items() if k != 'duration'} == {k: v for k, v in after.attrib.items() if k != 'duration'}
            count += 1
            last = dict(after.attrib)
        assert count == 144000 and last == record['completion']
        for name, tag in [('vehicle-routes.xml', 'vehicle'), ('tripinfo.xml', 'tripinfo')]:
            def records(path):
                return {r.get('id'): ET.canonicalize(ET.tostring(r, encoding='unicode'), strip_text=True) for r in elements(path, tag)}
            assert records(folder/name) == records(original(variant, name))
        assert not ET.fromstring(raw(folder/'collisions.xml')).findall('collision')
        monitor = load(folder/'stall-monitor.json')
        source_monitor = load(original(variant, 'stall-monitor.json'))
        assert monitor['status'] == 'completed' and monitor['simulation_time_s'] == 14400
        assert monitor.get('lane_section_hold') == source_monitor.get('lane_section_hold')
        reports[variant] = {'checks': 20, 'E1': 208, 'summary_steps': 144000, 'instant_events': record['instant_e1_events_checked'],
            'arrived': record['arrived_routes_checked'], 'completion': {k: int(last[k]) for k in ('loaded', 'inserted', 'arrived', 'waiting', 'running', 'collisions', 'teleports', 'discarded')}}
    assert reports['reference']['arrived'] == 8640 and reports['one-car']['arrived'] == 8634
    return reports


def recompute(case, output):
    output.mkdir(parents=True, exist_ok=False)
    for variant in SOURCES:
        folder = output/variant
        folder.mkdir()
        for name in ('record-result.json', 'tls-switch-states.xml', 'tls-recorded-programs.add.xml'):
            (folder/name).write_bytes(raw(case/variant/name))
    (output/'reference/network.net.xml').write_bytes(raw(original('reference', 'network.net.xml')))
    script = output/'compare_tls.py'
    script.write_bytes(raw(case/'study-source/compare_tls.py'))
    spec = spec_from_file_location('fixed_TLS_comparison', script)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    reused = output/'reused-compare-tls.py'
    reused.write_bytes(raw(case/'code-source/reused-compare-tls.py'))
    module.REUSED = reused
    with contextlib.redirect_stdout(io.StringIO()):
        module.main()
    measured = load(output/'comparison.json')
    expected = load(case/'study-source/comparison.json')
    def normalized_hashes(values):
        return {'/'.join(k.replace('\\', '/').split('/')[-2:]): v for k, v in values.items()}
    assert normalized_hashes(measured.pop('source_hashes')) == normalized_hashes(expected.pop('source_hashes'))
    assert measured == expected
    for name in ('per-tls.csv', 'per-tls-900s-bins.csv', 'different-color-intervals.csv', 'common-emit-phase-differences.csv'):
        assert (output/name).read_bytes() == raw(case/'study-source'/name)
    assert measured['first_actual_color_difference']['begin_s'] == 8943.0
    assert measured['first_actual_color_difference']['tls_id'] == '18653534'
    assert measured['different_tls_count'] == 18 and measured['all10_static_color_program_histories_equal']
    assert not measured['any_color_difference_before8247_6']
    prefix = load(FEEDBACK/'independent/batch-1/prefix-consistency.json')
    traffic = float(prefix['summary']['first_traffic_excluding_duration_and_loaded']['native_time_s'])
    assert traffic == 8247.6
    return {'first_colour_s': 8943.0, 'first_traffic_s': traffic, 'colour_later_s': round(8943.0-traffic, 1), 'different_actuated_TLS': 18,
        'static_TLS_equal': 10, 'all50_programs_equal': all(r['different_program_ticks'] == 0 for r in measured['per_tls']),
        'phase': 'Emitted events only; no forward filling. First common-emit phase difference8951.0 is not a full-history first phase difference.'}


def verify(case):
    verify_manifest(case)
    prior.verify_manifest(GS)
    prior.verify_manifest(FEEDBACK)
    sources = load(case/'source-references.json')
    assert sha(GS/'manifest.json') == sources['GS_manifest_sha256'] and sha(FEEDBACK/'manifest.json') == sources['feedback_manifest_sha256']
    for row in load(case/'source-provenance.json')['snapshots']:
        value = raw(case/row['relative'])
        assert len(value) == row['raw_bytes'] and hashlib.sha256(value).hexdigest() == row['raw_sha256']
    seal = load(case/'source-manifests.json')
    stage = load(case/'study-source/manifest.json')
    assert len(stage['files']) == seal['original_file_count'] == 74
    assert not any(r['path'] == 'control-inventory/manifest.json' for r in stage['files'])
    assert raw_sha(case/'study-source/manifest.json') == seal['original_manifest_sha256']
    assert raw_sha(case/'control-inventory/manifest.json') == seal['additional_inventory_manifest_sha256'] == INVENTORY_SHA
    stage_hashes = {r['path']: r['sha256'] for r in stage['files']}
    for row in load(case/'external-input-references.json')['files']:
        assert raw_sha(REPO/row['reference']) == row['sha256'] == stage_hashes[row['source_relative']]
    excluded = {r['source_relative']: r for r in load(case/'external-input-references.json')['files']}
    local = {r['source_relative']: r for r in load(case/'local-only-large-traces.json')['files']}
    for row in stage['files']:
        if row['path'] in excluded:
            assert excluded[row['path']]['sha256'] == row['sha256']
        elif row['path'] in local:
            assert local[row['path']]['sha256'] == row['sha256'] and local[row['path']]['bytes'] == row['bytes']
        else:
            value = raw(case/snapshot_relative(row['path']))
            assert len(value) == row['bytes'] and hashlib.sha256(value).hexdigest() == row['sha256']
    manifest_paths(case/'control-inventory')
    result = load(case/'results.json')
    assert source_parity(case) == result['parity']
    with tempfile.TemporaryDirectory() as temporary:
        assert recompute(case, Path(temporary)/'comparison') == result['comparison']
    print('Frozen hashes, original74+separate inventory seal, both20checks, raw50TLS exports/states and exact offline comparison: pass', flush=True)


def freeze():
    assert not (HERE/'manifest.json').exists(), 'Preserve existing frozen or partial evidence.'
    stage = load(SOURCE/'manifest.json')
    assert len(stage['files']) == 74
    assert not any(r['path'] == 'control-inventory/manifest.json' for r in stage['files'])
    assert sha(SOURCE/'control-inventory/manifest.json') == INVENTORY_SHA
    paths = manifest_paths(SOURCE)+[Path('control-inventory/manifest.json')]
    provenance, local, references = [], [], []
    for name in paths:
        p = SOURCE/name
        relative = snapshot_relative(name)
        if name.parts[0] in SOURCES and p.name in LOCAL:
            local.append({'source_relative': name.as_posix(), 'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)})
            continue
        value = p.read_bytes()
        if name.parts[0] in SOURCES and p.name in INPUTS:
            reference = original(name.parts[0], p.name)
            assert hashlib.sha256(value).hexdigest() == raw_sha(reference)
            references.append({'source_relative': name.as_posix(), 'reference': reference.relative_to(REPO).as_posix(), 'sha256': hashlib.sha256(value).hexdigest()})
            continue
        target = HERE/(relative.as_posix()+'.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(value, mtime=0))
        provenance.append({'source': str(p), 'relative': relative.as_posix(), 'raw_bytes': len(value), 'raw_sha256': hashlib.sha256(value).hexdigest()})
    ancestor = REPO/'outputs/hamburg-z5-native-feedback-20261023-v1/tls-feedback-diagnosis/compare_tls.py'
    assert sha(ancestor) == load(SOURCE/'comparison.json')['reused_comparison_source_sha256']
    value = ancestor.read_bytes()
    target = HERE/'code-source/reused-compare-tls.py.gz'
    target.parent.mkdir()
    target.write_bytes(gzip.compress(value, mtime=0))
    provenance.append({'source': str(ancestor), 'relative': 'code-source/reused-compare-tls.py', 'raw_bytes': len(value), 'raw_sha256': hashlib.sha256(value).hexdigest()})
    save(HERE/'source-provenance.json', {'snapshots': provenance, 'source_files_unchanged': True})
    save(HERE/'external-input-references.json', {'files': references, 'source_inputs_not_duplicated': True})
    save(HERE/'local-only-large-traces.json', {'files': local, 'portable_limitation': 'Omitted queues/instant cannot be independently re-read on another machine without these local files. Original20check records and hashes are retained.'})
    save(HERE/'source-manifests.json', {'original_manifest_sha256': sha(SOURCE/'manifest.json'), 'original_file_count': 74,
        'inventory_four_files_already_in_original74': True, 'additional_inventory_manifest_sha256': INVENTORY_SHA,
        'additional_inventory_manifest_was_not_in_original74': True, 'comparison_ancestor_snapshot_is_additional': True})
    save(HERE/'source-references.json', {'GS_commit': '42a827e', 'GS_manifest_sha256': sha(GS/'manifest.json'),
        'feedback_commit': 'f0934b3;current checkout cae62ad', 'feedback_manifest_sha256': sha(FEEDBACK/'manifest.json'),
        'source_study_name_preserved': 'hamburg-healthy-z4-control-response-20261023-v1', 'fixed_history_study_included': False})
    parity = source_parity(HERE)
    with tempfile.TemporaryDirectory() as temporary:
        comparison = recompute(HERE, Path(temporary)/'comparison')
    save(HERE/'results.json', {'status': 'review_required', 'formal_result': False, 'observation_runs': 2, 'native_runs_by_freeze': 0,
        'new_demand_or_control_candidates': 0, 'parity': parity, 'comparison': comparison})
    (HERE/'.gitattributes').write_text('* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n*.gz binary\n', encoding='utf-8')
    (HERE/'README.md').write_text(README_TEXT, encoding='utf-8')
    assert all(sha(Path(r['source'])) == r['raw_sha256'] for r in provenance)
    save(HERE/'manifest.json', {'formal_result': False, 'files': [{'path': p.relative_to(HERE).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(HERE.rglob('*')) if p.is_file() and p != HERE/'manifest.json' and '__pycache__' not in p.parts]})
    verify(HERE)


README_TEXT = '''# 健康Z4基准与单车候选的被动TLS记录

本包按当地24日命名；源study的23日目录名及原始字节不改。只有两次原样只读record，没有新需求、冻结控制或健康候选提升。reference仍是健康3.7153846基准；one-car仍是被拒绝的4.0923077候选，8634辆到达、6辆在途。没有把记录通过当作候选接受或标定完成。

两份均20/20 checks通过：各208行E1全属性、144000步summary（只排CPU duration）、全部instant事件、到达完整route/exitTimes、tripinfo、driver hold及期末状态与原运行一致。两份50个实际programme和SwitchStates原始XML均gzip保存，每个programme恰覆盖14400秒并与switch颜色时间线对应。原来源输入和旧完整native固定引用42a827e的GS包及f0934b3/cae62ad的batch-1包，不重复源network/demand。大instant/queues仅本地哈希；迁机后无这些大文件就不能逐事件重读其原件，不能把摘要当原始数据。

首次实际颜色差为8943.0秒、18653534，晚于已核首次traffic差8247.6秒，间隔695.4秒。18个actuated TLS出现颜色差，10个static的颜色和program历史一致，全部50个programID均未不同。readme_fixed_A只是programID名，不等于static。phase只在实际emit时刻有值；8951.0秒是共同emit事件中的首phase差，不能当完整phase历史首差，也不能前填未发出的phase。颜色反馈差不证明全部计数损失由控制造成。

逐TLS、900秒分段、颜色差区间、共同emit phase差及原脚本/计划/准备失败在study-source按原字节留档。control-inventory含原5文件与其原manifest；source-manifests明确原顶清单74项只含inventory的4数据文件，后来独立封口的inventory manifest（659cdd…）另计，未假称它属于原74。

离线核验：项目`.venv/Scripts/python.exe benchmarks/hamburg_ring1_healthy_z4_control_response_20261024_v1/freeze_evidence.py --verify-only`，会从原始50TLS导出/switches重算比较并逐CSV核对，不启动SUMO。`reproduce.py --output-dir <新目录>`仅离线复算同一比较；原record脚本也保留，但完整原生20check复跑还需按固定引用重定位源输入及本地instant原件。未纳入任何fixed-history试验。
'''


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--freeze', action='store_true')
    mode.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    freeze() if args.freeze else verify(HERE)
