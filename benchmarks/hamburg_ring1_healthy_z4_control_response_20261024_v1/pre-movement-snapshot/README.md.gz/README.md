# 健康Z4基准与单车候选的被动TLS记录

本包按当地24日命名；源study的23日目录名及原始字节不改。只有两次原样只读record，没有新需求、冻结控制或健康候选提升。reference仍是健康3.7153846基准；one-car仍是被拒绝的4.0923077候选，8634辆到达、6辆在途。没有把记录通过当作候选接受或标定完成。

两份均20/20 checks通过：各208行E1全属性、144000步summary（只排CPU duration）、全部instant事件、到达完整route/exitTimes、tripinfo、driver hold及期末状态与原运行一致。两份50个实际programme和SwitchStates原始XML均gzip保存，每个programme恰覆盖14400秒并与switch颜色时间线对应。原来源输入和旧完整native固定引用42a827e的GS包及f0934b3/cae62ad的batch-1包，不重复源network/demand。大instant/queues仅本地哈希；迁机后无这些大文件就不能逐事件重读其原件，不能把摘要当原始数据。

首次实际颜色差为8943.0秒、18653534，晚于已核首次traffic差8247.6秒，间隔695.4秒。18个actuated TLS出现颜色差，10个static的颜色和program历史一致，全部50个programID均未不同。readme_fixed_A只是programID名，不等于static。phase只在实际emit时刻有值；8951.0秒是共同emit事件中的首phase差，不能当完整phase历史首差，也不能前填未发出的phase。颜色反馈差不证明全部计数损失由控制造成。

逐TLS、900秒分段、颜色差区间、共同emit phase差及原脚本/计划/准备失败在study-source按原字节留档。control-inventory含原5文件与其原manifest；source-manifests明确原顶清单74项只含inventory的4数据文件，后来独立封口的inventory manifest（659cdd…）另计，未假称它属于原74。

离线核验：项目`.venv/Scripts/python.exe benchmarks/hamburg_ring1_healthy_z4_control_response_20261024_v1/freeze_evidence.py --verify-only`，会从原始50TLS导出/switches重算比较并逐CSV核对，不启动SUMO。`reproduce.py --output-dir <新目录>`仅离线复算同一比较；原record脚本也保留，但完整原生20check复跑还需按固定引用重定位源输入及本地instant原件。未纳入任何fixed-history试验。
