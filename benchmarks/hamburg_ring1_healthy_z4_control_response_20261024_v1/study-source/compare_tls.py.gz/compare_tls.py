"""Compare two parity-verified native color histories; never run SUMO."""

from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
END = 144000
REUSED = ROOT.parents[1] / "outputs/hamburg-z5-native-feedback-20261023-v1/tls-feedback-diagnosis/compare_tls.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tick(value):
    number = Decimal(value) * 10
    assert number == number.to_integral_value()
    return int(number)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows, empty_fields):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else empty_fields)
        writer.writeheader()
        writer.writerows(rows)


def read_states(path, widths):
    events = defaultdict(list)
    for _, row in ET.iterparse(path):
        if row.tag != "tlsState":
            continue
        identity, time = row.get("id"), tick(row.get("time"))
        assert identity in widths and len(row.get("state")) == widths[identity] and 0 <= time < END
        values = events[identity]
        assert not values or values[-1]["tick"] < time
        values.append(dict(tick=time, state=row.get("state"), programID=row.get("programID"), phase=int(row.get("phase"))))
        row.clear()
    assert events.keys() == widths.keys() and len(events) == 50
    assert all(rows[0]["tick"] == 0 for rows in events.values())
    return events


def audit_program(path, widths, states):
    root = ET.parse(path).getroot()
    programs = root.findall("tlLogic")
    checks = dict(additional_root=root.tag == "additional",
                  exactly50_direct_unique_programs=len(root) == len(programs) == len({p.get("id") for p in programs}) == 50,
                  complete_binding={p.get("id") for p in programs} == widths.keys())
    rows = []
    for program in programs:
        identity = program.get("id")
        duration, timeline = 0, []
        valid = program.get("type") == "static" and program.get("programID") == states[identity][0]["programID"]
        for phase in program.findall("phase"):
            length, state = tick(phase.get("duration")), phase.get("state")
            valid = valid and length > 0 and len(state) == widths[identity]
            if not timeline or timeline[-1][1] != state:
                timeline.append((duration, state))
            duration += length
        expected = []
        for event in states[identity]:
            if not expected or event["state"] != expected[-1][1]:
                expected.append((event["tick"], event["state"]))
        rows.append(dict(tls_id=identity, valid=valid, duration_ticks=duration,
                         color_timeline_equals_switch_log=timeline == expected))
    checks.update(all_valid=all(r["valid"] for r in rows),
                  all_cover14400=all(r["duration_ticks"] == END for r in rows),
                  all_color_timelines_match=all(r["color_timeline_equals_switch_log"] for r in rows))
    return dict(status="pass" if all(checks.values()) else "blocked", checks=checks, programs=rows, sha256=sha(path))


def main():
    variants = ("reference", "one-car")
    records = {v: json.loads((ROOT / v / "record-result.json").read_bytes()) for v in variants}
    assert all(r["status"] == "pass" and all(r["checks"].values()) for r in records.values())
    for name in ("network.net.xml", "signal-programs.add.xml"):
        assert records["reference"]["source_hashes"][name] == records["one-car"]["source_hashes"][name]
    kinds = records["reference"]["tls_types"]
    assert kinds == records["one-car"]["tls_types"] and Counter(kinds.values()) == {"actuated": 40, "static": 10}
    widths = defaultdict(int)
    for row in ET.parse(ROOT / "reference/network.net.xml").getroot().findall("connection"):
        if row.get("tl"):
            widths[row.get("tl")] = max(widths[row.get("tl")], int(row.get("linkIndex")) + 1)
    states = {v: read_states(ROOT / v / "tls-switch-states.xml", widths) for v in variants}
    exports = {v: audit_program(ROOT / v / "tls-recorded-programs.add.xml", widths, states[v]) for v in variants}
    assert all(p["status"] == "pass" for p in exports.values())
    intervals, per_tls, bin_rows, phase_common_differences = [], [], [], []
    for identity in sorted(widths):
        a, b = states["reference"][identity], states["one-car"][identity]
        boundaries = sorted({0, END} | {r["tick"] for r in a + b})
        ai = bi = color_ticks = program_ticks = 0
        first = None
        bins = Counter()
        for begin, end in zip(boundaries, boundaries[1:]):
            while ai + 1 < len(a) and a[ai + 1]["tick"] <= begin:
                ai += 1
            while bi + 1 < len(b) and b[bi + 1]["tick"] <= begin:
                bi += 1
            program_diff = a[ai]["programID"] != b[bi]["programID"]
            color_diff = a[ai]["state"] != b[bi]["state"]
            program_ticks += (end - begin) * program_diff
            if not color_diff:
                continue
            color_ticks += end - begin
            first = begin if first is None else first
            intervals.append(dict(tls_id=identity, type=kinds[identity], begin_tick=begin, end_tick=end,
                                  begin_s=begin / 10, end_s=end / 10,
                                  reference_state=a[ai]["state"], one_car_state=b[bi]["state"],
                                  reference_program=a[ai]["programID"], one_car_program=b[bi]["programID"]))
            for bin_index in range(begin // 9000, (end - 1) // 9000 + 1):
                bins[bin_index] += min(end, (bin_index + 1) * 9000) - max(begin, bin_index * 9000)
        ae, be = {r["tick"]: r for r in a}, {r["tick"]: r for r in b}
        common = ae.keys() & be.keys()
        for time in sorted(common):
            if ae[time]["phase"] != be[time]["phase"]:
                phase_common_differences.append(dict(tls_id=identity, event_tick=time, event_s=time / 10,
                    reference_phase=ae[time]["phase"], one_car_phase=be[time]["phase"],
                    reference_state=ae[time]["state"], one_car_state=be[time]["state"]))
        per_tls.append(dict(tls_id=identity, type=kinds[identity], first_color_difference_s=first / 10 if first is not None else None,
                            different_color_ticks=color_ticks, different_program_ticks=program_ticks,
                            common_emit_events=len(common), reference_only_emit_events=len(ae.keys() - be.keys()),
                            one_car_only_emit_events=len(be.keys() - ae.keys())))
        for index in range(16):
            bin_rows.append(dict(tls_id=identity, type=kinds[identity], begin=index * 900, end=(index + 1) * 900,
                                 different_color_ticks=bins[index], different_color_seconds=bins[index] / 10))
    intervals.sort(key=lambda r: (r["begin_tick"], r["tls_id"]))
    phase_common_differences.sort(key=lambda r: (r["event_tick"], r["tls_id"]))
    result = dict(schema="astra.hamburg.healthy-z4-tls-response/v1", status="pass", formal_result=False, native_runs=2,
                  traffic_parity_passed=True, end_s=14400, step_s=.1, tls_types=dict(Counter(kinds.values())),
                  first_actual_color_difference=intervals[0] if intervals else None,
                  different_tls_count=sum(r["different_color_ticks"] > 0 for r in per_tls),
                  all10_static_color_program_histories_equal=all(r["different_color_ticks"] == r["different_program_ticks"] == 0 for r in per_tls if r["type"] == "static"),
                  any_color_difference_before8247_6=any(r["begin_tick"] < 82476 for r in intervals),
                  first_common_emit_phase_difference=phase_common_differences[0] if phase_common_differences else None,
                  program_exports=exports, per_tls=per_tls,
                  source_hashes={str(p): sha(p) for v in variants for p in (ROOT / v / "record-result.json", ROOT / v / "tls-switch-states.xml", ROOT / v / "tls-recorded-programs.add.xml")},
                  reused_comparison_source_sha256=sha(REUSED),
                  phase_boundary="Only same-time emitted events have compared phase indices. One-sided events remain one-sided observations; no phase forward fill. Exact step colors/programs are reconstructed from switches. Exports give color durations, not original phase indices.",
                  claim_boundary="Actual signal color differences establish endogenous control-history response only, not exclusive causation of the253 unmodified vehicles crossing bins. No frozen-control or newOD trial.")
    save(ROOT / "comparison.json", result)
    table(ROOT / "different-color-intervals.csv", intervals, ["tls_id", "begin_tick", "end_tick"])
    table(ROOT / "per-tls.csv", per_tls, [])
    table(ROOT / "per-tls-900s-bins.csv", bin_rows, [])
    table(ROOT / "common-emit-phase-differences.csv", phase_common_differences, ["tls_id", "event_tick"])
    print(json.dumps({k: result[k] for k in ("status", "first_actual_color_difference", "different_tls_count", "all10_static_color_program_histories_equal", "any_color_difference_before8247_6", "first_common_emit_phase_difference")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
