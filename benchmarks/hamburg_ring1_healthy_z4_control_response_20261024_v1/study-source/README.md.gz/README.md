# 健康源与单车候选的被动 TLS 记录

两次记录均完成，20/20 原生复核通过。reference 耗时 283.08 秒，one-car 耗时 287.79 秒。原生 E1 全属性均为 208 行，summary 均为 144000 行；instant 事件分别为 143159/143734，到达车辆完整 route/exitTimes 分别为 8640/8634，均与各自原运行精确相同。两份 tripinfo、driver hold 报告及期末状态也相同。reference 全部 8640 辆到达；one-car 为 8634 到达、6 辆在途、0 等待。两者均零碰撞/传送/discard。后者仍是已拒绝的原单车候选，没有成为健康基准。

**首次实际颜色差为 8943.0 秒，控制器 18653534，type=actuated。** 8247.6 秒之前全 50 个控制器的颜色均相同；首颜色差比首次交通差晚 695.4 秒。全窗 18 个感应式控制器出现颜色差，10 个固定式控制器的颜色和 program 历史均相同；所有 50 个控制器均未切换为不同 programID。`readme_fixed_A` 只是 programID 名称，不把 type=actuated 变成固定式。

共同 emit 事件中，首次 phase 值差出现在 8951.0 秒的 18653534（reference=0，one-car=5）。这不是完整 phase 历史的首次差。全部控制器的首次颜色差、持续时间和各 900 秒段见 [per-tls.csv](per-tls.csv)、[per-tls-900s-bins.csv](per-tls-900s-bins.csv)；精确差异区间见 [different-color-intervals.csv](different-color-intervals.csv)。两份程序均为 50 个唯一直接 tlLogic、每条恰覆盖 14400 秒，全部颜色时间线与独立 SwitchStates 日志一致。

各从空网原样重放一次：reference 对应已完成的健康 full-priority；one-car 对应已完成的 batch-1。保持各自原始需求、网络、控制、0.1 秒步长、14400 秒终点、seed104、Libsumo 及四个 body-hold 节点。只增加 SaveTLSSwitchStates 和 SaveTLSProgram，没有 FCD、控制改动或新增 setter。

先核每份记录与其原运行的全部 208 行 E1 属性、144000 行 summary（仅排除 CPU duration）、全部 instant 事件、到达车辆完整 routes/exitTimes、tripinfo、期末状态和零事故。另核 50 TLS 在 0 秒初始化、各状态宽度及程序覆盖整段 14400 秒。任一失败均保留，不解释相位因果。

两份均通过后才比较逐 0.1 秒实际颜色向量和 program。phase 仅比较真实 emit 事件中的值；SwitchStates 可能省略同色 phase 边界，不能把旧事件 phase 前向填充成完整 phase 历史。SaveTLSProgram 是颜色与持续时间记录，也不是原 phase index 历史。颜色差异仅证明模型中的控制响应不同，不能归因全部计数损失。没有冻结控制或新 OD 试验。
