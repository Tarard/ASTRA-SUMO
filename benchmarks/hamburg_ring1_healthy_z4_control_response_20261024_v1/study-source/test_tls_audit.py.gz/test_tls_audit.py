"""Small offline checks for complete, correctly bound program exports."""

import importlib.util
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("paired_tls_comparison", ROOT / "compare_tls.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def fixture(path):
    root = ET.Element("additional")
    widths, states = {}, {}
    for i in range(50):
        identity = str(i)
        program = ET.SubElement(root, "tlLogic", id=identity, type="static", programID="0")
        ET.SubElement(program, "phase", duration="14400", state="r")
        widths[identity] = 1
        states[identity] = [dict(tick=0, state="r", programID="0", phase=0)]
    ET.ElementTree(root).write(path, encoding="utf-8")
    return widths, states


def test_complete_export_and_wrong_duration_refused(tmp_path):
    path = tmp_path / "programs.xml"
    widths, states = fixture(path)
    assert MODULE.audit_program(path, widths, states)["status"] == "pass"
    tree = ET.parse(path)
    tree.getroot()[0][0].set("duration", "14399.9")
    tree.write(path, encoding="utf-8")
    result = MODULE.audit_program(path, widths, states)
    assert result["status"] == "blocked" and not result["checks"]["all_cover14400"]


def test_parseable_export_with_duplicate_tls_refused(tmp_path):
    path = tmp_path / "programs.xml"
    widths, states = fixture(path)
    tree = ET.parse(path)
    tree.getroot()[-1].set("id", "0")
    tree.write(path, encoding="utf-8")
    result = MODULE.audit_program(path, widths, states)
    assert result["status"] == "blocked" and not result["checks"]["exactly50_direct_unique_programs"]
