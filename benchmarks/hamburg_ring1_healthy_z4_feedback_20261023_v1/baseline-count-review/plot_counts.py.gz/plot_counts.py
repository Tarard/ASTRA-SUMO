"""Show all 130 native residuals on one shared scale; never alter observations."""
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sources = [
    REPO / "outputs/hamburg-197-through-support-20261023-v1/full-response-audit/complete/main-comparison.csv",
    REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/independent-audit/main-comparison.csv",
]
rows = [list(csv.DictReader(path.open(encoding="utf-8"))) for path in sources]
fields = sorted({r["detector_id"] for r in rows[0]}, key=lambda f: (int(f.split("_")[1]), int(f.split("_")[3])))
times = sorted({float(r["begin"]) for r in rows[0]})
assert len(fields) == 13 and times == list(range(3600, 12600, 900))
matrices = []
for records in rows:
    assert len(records) == 130 and all(r["measurement_status"] == "matched" for r in records)
    indexed = {(r["detector_id"], float(r["begin"])): r for r in records}
    assert len(indexed) == 130 and set(indexed) == {(f, t) for f in fields for t in times}
    matrices.append(np.array([[int(indexed[f, t]["diff_nVehContrib_minus_expected"]) for t in times] for f in fields]))
assert [int(np.abs(m).sum()) for m in matrices] == [605, 483]
labels = [f"{int(f.split('_')[1])} Z{f.split('_')[3]}" for f in fields]
clock = [f"{(330 + 15*i)//60:02}:{(330 + 15*i)%60:02}" for i in range(10)]
fig, axes = plt.subplots(1, 2, figsize=(14, 7.5), sharey=True, layout="constrained")
titles = ["197 correction: MAE 4.653846; 34 unfinished", "Conditional GS merge: MAE 3.715385; 0 unfinished"]
for ax, matrix, title in zip(axes, matrices, titles):
    im = ax.imshow(matrix, cmap="RdBu_r", vmin=-35, vmax=35, aspect="auto")
    ax.set(xticks=range(10), xticklabels=clock, yticks=range(13), yticklabels=labels,
        xlabel="Interval start, 2026-10-19 UTC (15 minutes)", title=title)
    for (i, j), value in np.ndenumerate(matrix):
        ax.text(j, i, f"{value:+d}" if value else "0", ha="center", va="center",
            color="white" if abs(value) >= 20 else "black", fontsize=8)
    ax.tick_params(axis="x", rotation=45)
fig.colorbar(im, ax=axes, shrink=.8, label="Native E1 nVehContrib minus observed count")
fig.suptitle("Hamburg: all 13 fields x 10 intervals; same 8640 requests\nGS priority is a declared model assumption; field control remains unverified", fontsize=12)
fig.savefig(ROOT / "all130-before-after.png", dpi=180)
fig.savefig(ROOT / "all130-before-after.svg")
plt.close(fig)
proof = {"source_hashes": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
    "fields": fields, "interval_starts_s": times, "native_residuals": [m.tolist() for m in matrices],
    "missing_or_excluded_target_rows": 0, "shared_color_limits": [-35, 35], "formal_result": False}
(ROOT / "source-proof.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
