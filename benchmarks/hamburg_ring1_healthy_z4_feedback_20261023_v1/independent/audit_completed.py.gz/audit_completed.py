"""Audit sealed1/3 explicit departure probes; never run or poll SUMO."""

import argparse
from collections import Counter
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPERS))
import audit_response as audit  # noqa: E402
from summarize_response import backlog  # noqa: E402


CASE_COUNTS = {"batch-1": 1, "batch-4": 3}
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def scope(label):
    case = STUDY / label
    proof = json.loads((case / "scope-proof.json").read_bytes())
    proposal = json.loads((case / "proposal.json").read_bytes())
    preflight = json.loads((case / "preflight.json").read_bytes())
    assert all(audit.digest(Path(path)) == value for path, value in proof["source_hashes"].items())
    assert all(audit.digest(case / "prepared" / name) == value for name, value in proof["prepared_hashes"].items())
    assert audit.digest(case / "scope-proof.json") == preflight["source_proof_sha256"]
    assert audit.digest(case / "executed-driver.py") == preflight["executed_driver_sha256"] == audit.digest(STUDY / "run_candidate.py")
    assert preflight["backend"] == "libsumo" and set(preflight["versions"].values()) == {"1.27.1"}
    assert all(audit.digest(Path(path)) == value for path, value in preflight["binaries"].items())
    assert audit.digest(HELPERS / "audit_response.py") == preflight["helper_sha256"]
    assert audit.digest(HELPERS / "audit_scope.py") == preflight["helper_scope_sha256"]
    for name, value in preflight["implementation_sha256"].items():
        assert audit.digest(case / "implementation" / name) == audit.digest(SOURCE / "implementation" / name) == value
    for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]:
        assert (case / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    trees = [ET.parse(folder / "demand.rou.xml").getroot() for folder in [SOURCE / "prepared", case / "prepared"]]
    vehicles = [{v.get("id"): v for v in tree.findall("vehicle")} for tree in trees]
    before, after = vehicles
    assert before.keys() == after.keys() and len(before) == 8640
    selected = {row["vehicle_id"] for row in proposal["proposals"]}
    changed = {identity for identity in before if before[identity].get("depart") != after[identity].get("depart")}
    assert changed == selected and len(changed) == CASE_COUNTS[label] == proof["actual_changes"] == preflight["actual_changed_vehicles"]
    assert [ET.tostring(row) for row in trees[0] if row.tag != "vehicle"] == [ET.tostring(row) for row in trees[1] if row.tag != "vehicle"]
    for identity in before:
        restored = deepcopy(after[identity])
        restored.set("depart", before[identity].get("depart"))
        assert ET.tostring(restored) == ET.tostring(before[identity]), identity
    metadata = [json.loads((folder / "lane-intentions.json").read_bytes()) for folder in [SOURCE / "prepared", case / "prepared"]]
    intent = [{row["vehicle_id"]: row for row in item["vehicles"]} for item in metadata]
    assert intent[0].keys() == intent[1].keys() == before.keys()
    assert {key: value for key, value in metadata[0].items() if key not in {"vehicles", "mechanism"}} == {key: value for key, value in metadata[1].items() if key not in {"vehicles", "mechanism"}}
    assert metadata[1]["mechanism"].startswith(metadata[0]["mechanism"])
    vectors = []
    edits = []
    for index in [0, 1]:
        vector = [0] * 294
        for identity, vehicle in vehicles[index].items():
            old, row = intent[0][identity], intent[index][identity]
            actual_cell = int(Decimal(vehicle.get("depart")) // Decimal(900)) * 21 + old["od_cell"] % 21
            assert actual_cell == row["od_cell"] == old["od_cell"]
            assert row["field_id"] == old["field_id"]
            vector[actual_cell] += 1
            if index == 1:
                if identity not in selected:
                    assert row == old
                else:
                    stripped = dict(row)
                    assert Decimal(str(stripped.pop("depart_s"))) == Decimal(vehicle.get("depart"))
                    assert stripped == old
        vectors.append(vector)
    assert vectors[0] == vectors[1]
    vector_file = json.loads((case / "od-vector.json").read_bytes())
    assert vector_file["values"] == vector_file["integer_counts"] == vectors[1] and sum(vectors[1]) == vector_file["vehicle_count"] == 8640
    source_order = {identity: index for index, identity in enumerate(before)}
    assert list(after) == sorted(after, key=lambda identity: (Decimal(after[identity].get("depart")), source_order[identity]))
    for move in proposal["proposals"]:
        identity = move["vehicle_id"]
        assert float(before[identity].get("depart")) == move["source_depart_s"]
        assert float(after[identity].get("depart")) == move["proposed_depart_s"]
        edits.append({**move, "old_request_depart_text": before[identity].get("depart"), "new_request_depart_text": after[identity].get("depart"),
            "unchanged_od_cell": intent[0][identity]["od_cell"], "origin": before[identity].find("route").get("edges").split()[0]})
    scenarios = [json.loads((folder / "scenario.json").read_bytes()) for folder in [SOURCE / "prepared", case / "prepared"]]
    scenario_changes = {key for key in set(scenarios[0]) | set(scenarios[1]) if scenarios[0].get(key) != scenarios[1].get(key)}
    assert scenario_changes <= {"demand_sha256", "demand_prior", "time_prior"}
    result = {"schema": "astra.hamburg.healthy-z4-scope/v1", "status": "pass", "native_reads": False, "case": label,
        "actual_changed_vehicle_count": len(selected), "N": 8640, "only_depart_changed_in_vehicle_XML": True,
        "all294_OD_counts_exactly_identical": True, "all_selected_departures_stay_same_cell": True,
        "all_routes_stops_vtypes_fields_and_other_attributes_identical": True,
        "selected_metadata_only_depart_s_added_and_same_od_cell": True, "scenario_changed_keys": sorted(scenario_changes),
        "no_quantile_regeneration_evidence": "All8640 request XML elements are exactly identical after restoring only the1/3 depart values; all294 counts, route/stops and field inventory remain identical.",
        "changes": edits, "source_hashes": {str(path): audit.digest(path) for path in [case / "scope-proof.json", case / "proposal.json", case / "preflight.json", case / "od-vector.json", STUDY / "run_candidate.py"]},
        "prepared_hashes": proof["prepared_hashes"]}
    return result, before, intent[0], selected


def stats(data):
    return {**{key: data[key] for key in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count"]},
        "station40_max": max(abs(r["residual"]) for r in data["stations"]), "unique_complete_vehicles": len(data["by_vehicle"])}


def audit_case(label, baseline, scope_data, vehicles, intentions, selected):
    case = STUDY / label
    verdict = json.loads((case / "verdict.json").read_bytes())
    assert "error" not in verdict and "after" in verdict, "Sealed native failure: preserve metadata rather than reading partial XML"
    current = audit.evidence(case / "prepared", case / "evaluation", case / "evaluation/contributing-passages.json.gz", 8640)
    assert all(current[key] == verdict["after"][key] for key in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count"])
    assert current["periodic"].keys() == baseline["periodic"].keys()
    out = OUT / label
    out.mkdir(exist_ok=True)
    audit.save(out / "scope.json", scope_data)
    main_keys, init_keys = [{audit.key(row) for row in current[name]} for name in ["main", "initial"]]
    targets = {audit.key(row): int(row["expected_total"]) for row in current["main"] + current["initial"]}
    unchanged = set(vehicles) - selected
    bm, am = [audit.counts(data["by_vehicle"], selected) for data in [baseline, current]]
    bu, au = [audit.counts(data["by_vehicle"], unchanged) for data in [baseline, current]]
    rows = []
    for key in sorted(current["periodic"], key=lambda key: (key[1], key[0])):
        old, new = int(baseline["periodic"][key]["nVehContrib"]), int(current["periodic"][key]["nVehContrib"])
        assert new - old == am[key] - bm[key] + au[key] - bu[key]
        expected = targets.get(key)
        rows.append({"field": key[0], "begin_s": key[1], "end_s": key[2],
            "region": "main" if key in main_keys else "initialization" if key in init_keys else "tail",
            "real_target": expected if expected is not None else "", "before_count": old, "after_count": new,
            "modified_before": bm[key], "modified_after": am[key], "modified_delta": am[key] - bm[key],
            "unchanged_before": bu[key], "unchanged_after": au[key], "unchanged_delta": au[key] - bu[key],
            "before_residual": old - expected if expected is not None else "", "after_residual": new - expected if expected is not None else ""})
    audit.table(out / "native208-cohort-accounting.csv", rows)
    audit.table(out / "main130-before-after.csv", [r for r in rows if r["region"] == "main"])
    audit.table(out / "initial52-before-after.csv", [r for r in rows if r["region"] == "initialization"])
    audit.table(out / "real182-before-after.csv", [r for r in rows if r["region"] != "tail"])
    rows535 = [r for r in rows if r["field"] in FIELDS535 and r["region"] != "tail"]
    assert len(rows535) == 56
    audit.table(out / "535-all56.csv", rows535)
    audit.table(out / "station40.csv", current["stations"])
    repeated = [{"vehicle_id": identity, "field": field, "count": count} for identity, events in current["by_vehicle"].items()
        for field, count in Counter(e["detector_id"] for e in events).items() if count > 1]
    outside = [{"vehicle_id": identity, **audit.event_view([event])[0]} for identity, events in current["by_vehicle"].items()
        for event in events if event["detector_id"] != intentions[identity]["field_id"]]
    moves = []
    for move in scope_data["changes"]:
        identity = move["vehicle_id"]
        before_events, after_events = [data["by_vehicle"].get(identity, []) for data in [baseline, current]]
        assert len(before_events) == 1
        assert [before_events[0]["detector_id"], before_events[0]["interval_begin_s"], before_events[0]["interval_end_s"]] == move["source_interval"]
        actual = after_events[0] if len(after_events) == 1 else None
        reached = bool(actual and [actual["detector_id"], actual["interval_begin_s"], actual["interval_end_s"]] == move["target_interval"])
        moves.append({**move, "before_actual_events": audit.event_view(before_events), "after_actual_events": audit.event_view(after_events),
            "actual_target_bin_reached": reached, "actual_notification_minus_projection_s": actual["notification_time_s"] - move["projected_notification_time_s"] if actual else "",
            "before_actual_insert_s": baseline["tripinfo"].get(identity, {}).get("depart"), "after_actual_insert_s": current["tripinfo"].get(identity, {}).get("depart")})
    audit.table(out / "modified-vehicle-actual-events.csv", moves)
    responses = []
    for identity in sorted(unchanged):
        a, b = [audit.event_view(data["by_vehicle"].get(identity, [])) for data in [baseline, current]]
        signature_a = [(r["field"], r["begin"], r["end"]) for r in a]
        signature_b = [(r["field"], r["begin"], r["end"]) for r in b]
        responses.append({"vehicle_id": identity, "primary_field": intentions[identity]["field_id"],
            "before_events": a, "after_events": b, "before_complete_events": len(a), "after_complete_events": len(b),
            "field_bin_signature_changed": signature_a != signature_b, "event_time_or_signature_changed": a != b})
    audit.table(out / "all-unchanged-vehicle-responses.csv", responses)
    fields = []
    for field in sorted({r["field"] for r in rows}):
        record = {"field": field}
        for name, data in [("before", baseline), ("after", current)]:
            record.update({name + "_" + key: value for key, value in audit.metrics([r for r in data["main"] if r["detector_id"] == field]).items()})
        record["TAE_change"] = record["after_TAE"] - record["before_TAE"]
        record["SSE_change"] = record["after_SSE"] - record["before_SSE"]
        record["main_modified_count_delta"] = sum(r["modified_delta"] for r in rows if r["field"] == field and r["region"] == "main")
        record["main_unchanged_count_delta"] = sum(r["unchanged_delta"] for r in rows if r["field"] == field and r["region"] == "main")
        fields.append(record)
    audit.table(out / "field13-errors-and-cohorts.csv", fields)
    signs = {identity: [row["field_id"]] for identity, row in intentions.items()}
    terminal, groups = backlog(case / "evaluation", signs)
    audit.table(out / "terminal-vehicles.csv", terminal)
    gates = {"safe": current["safe"], "healthy": current["healthy"], "all53556_zero": all(r["after_residual"] == 0 for r in rows535),
        "no_repeated_vehicle_fields": not repeated, "no_contributions_outside_primary_intention": not outside,
        "main130_MAE_improves": current["metrics130"]["MAE"] < baseline["metrics130"]["MAE"],
        "main130_SSE_not_worse": current["metrics130"]["SSE"] <= baseline["metrics130"]["SSE"],
        "all182_TAE_not_worse": current["metrics182"]["TAE"] <= baseline["metrics182"]["TAE"]}
    assert gates == verdict["gates"]
    report = {"schema": "astra.hamburg.healthy-z4-independent/v1", "audit_status": "pass", "case": label, "native_runs_by_audit": 0,
        "raw_verdict_status": verdict["status"], "predeclared_gates": gates, "passes_predeclared_gate": all(gates.values()),
        "before": stats(baseline), "after": stats(current), "actual_changed_vehicle_count": len(selected),
        "modified_target_bins_reached": sum(r["actual_target_bin_reached"] for r in moves), "modified_actual_rows": moves,
        "unchanged_vehicles": len(unchanged), "unchanged_event_time_or_signature_changed": sum(r["event_time_or_signature_changed"] for r in responses),
        "unchanged_field_bin_signature_changed": sum(r["field_bin_signature_changed"] for r in responses),
        "unchanged_lost_complete_events": sum(r["after_complete_events"] < r["before_complete_events"] for r in responses),
        "unchanged_gained_complete_events": sum(r["after_complete_events"] > r["before_complete_events"] for r in responses),
        "repeated_vehicle_fields": repeated, "contributions_outside_primary_intention": outside, "terminal_groups": groups,
        "native208_rows": len(rows), "53556_exact_rows": sum(r["after_residual"] == 0 for r in rows535),
        "initial52_exact_count_rows_vs_source": sum(r["before_count"] == r["after_count"] for r in rows if r["region"] == "initialization"),
        "source_hashes": {"before": baseline["source_hashes"], "after": current["source_hashes"], "raw_verdict": audit.digest(case / "verdict.json")},
        "claim_boundary": "The1/3 saved departure edits keep every OD cell and all8640 identities/routes/fields fixed. Projected notification bins are unverified proposals; only new native events decide reach. Changed/unchanged cohort deltas close the actual count vector but are not causal separation, and nonlinear loss is not attributed to one cohort. The original8 gates are unchanged. Counts do not establish trueOD, SPaT or field control correctness."}
    audit.save(out / "summary.json", report)
    seal(out)
    print(json.dumps({key: report[key] for key in ["case", "raw_verdict_status", "after", "modified_target_bins_reached", "unchanged_field_bin_signature_changed", "passes_predeclared_gate"]}, ensure_ascii=False))


def seal(directory):
    audit.save(directory / "manifest.json", {"native_runs_by_audit": 0, "files": [
        {"path": p.relative_to(directory).as_posix(), "size_bytes": p.stat().st_size, "sha256": audit.digest(p)}
        for p in sorted(directory.rglob("*")) if p.is_file() and p != directory / "manifest.json" and "__pycache__" not in p.parts]})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=[*CASE_COUNTS, "all"], default="all")
    parser.add_argument("--scope-only", action="store_true")
    args = parser.parse_args()
    labels = list(CASE_COUNTS) if args.case == "all" else [args.case]
    baseline = None
    for label in labels:
        proof, vehicles, intentions, selected = scope(label)
        audit.save(OUT / (label + "-scope.json"), proof)
        if args.scope_only:
            print(json.dumps({"case": label, "scope": "pass", "actual_depart_edits": len(selected), "all294_counts_identical": True, "native_reads": False}))
            continue
        if not (STUDY / label / "verdict.json").exists():
            print(json.dumps({"case": label, "status": "not_sealed", "native_read": False}))
            continue
        if baseline is None:
            baseline = audit.evidence(SOURCE / "prepared", SOURCE / "evaluation", SOURCE / "evaluation/contributing-passages.json.gz", 8640)
        audit_case(label, baseline, proof, vehicles, intentions, selected)
    seal(OUT)


if __name__ == "__main__":
    main()
