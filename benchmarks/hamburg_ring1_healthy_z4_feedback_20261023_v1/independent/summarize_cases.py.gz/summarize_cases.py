"""Seal both rejected temporal probes with unchanged gates and prefix evidence."""

import json

from audit_completed import OUT, SOURCE, CASE_COUNTS, audit, seal


def main():
    result = {"schema": "astra.hamburg.healthy-z4-study-audit/v1", "audit_status": "pass", "native_runs_by_audit": 0,
        "working_base": str(SOURCE), "predeclared_gate_changed": False, "cases": []}
    for label in CASE_COUNTS:
        directory = OUT / label
        summary = json.loads((directory / "summary.json").read_bytes())
        prefix = json.loads((directory / "prefix-consistency.json").read_bytes())
        assert summary["audit_status"] == "pass" and prefix["status"] == "pass"
        assert summary["raw_verdict_status"] == "rejected" and not summary["passes_predeclared_gate"]
        assert summary["initial52_exact_count_rows_vs_source"] == 52 and summary["53556_exact_rows"] == 56
        old_stations = {(r["station_stream_id"], float(r["begin"]), float(r["end"])): r for r in audit.read_csv_rows(SOURCE / "evaluation/station-comparison.csv")}
        station_rows = []
        for row in audit.read_csv_rows(directory / "station40.csv"):
            old = old_stations[row["station_stream_id"], float(row["begin"]), float(row["end"])]
            assert int(old["expected_total"]) == int(row["expected_total"])
            station_rows.append({"station_stream_id": row["station_stream_id"], "begin": row["begin"], "end": row["end"],
                "real_target": row["expected_total"], "before_count": old["measured_nVehContrib"], "after_count": row["measured_nVehContrib"],
                "before_residual": old["residual"], "after_residual": row["residual"], "independent_evidence": False})
        assert len(station_rows) == 40
        audit.table(directory / "station40-before-after.csv", station_rows)
        rows = audit.read_csv_rows(directory / "all-unchanged-vehicle-responses.csv")
        cross_bin = sum(row["field_bin_signature_changed"] == "True" and row["before_complete_events"] == row["after_complete_events"] == "1" for row in rows)
        lost = summary["unchanged_lost_complete_events"]
        assert cross_bin + lost == summary["unchanged_field_bin_signature_changed"]
        record = {"case": label, "actual_depart_edits": CASE_COUNTS[label], "after": summary["after"],
            "predeclared_gates": summary["predeclared_gates"], "modified_actual_rows": summary["modified_actual_rows"],
            "modified_target_bins_reached": summary["modified_target_bins_reached"], "unchanged_both_complete_but_cross_bin": cross_bin,
            "unchanged_lost_complete_events": lost, "unchanged_other_event_times_changed": summary["unchanged_event_time_or_signature_changed"],
            "summary_first_traffic_difference": prefix["summary"]["first_traffic_excluding_duration_and_loaded"],
            "instant_first_semantic_difference": prefix["instant"]["first_time_grouped_semantic_difference"],
            "unmodified_raw_input_relative_order_identical": prefix["unmodified_raw_XML_relative_order_identical"],
            "no_detected_prechanged_insertion_physical_output_difference": not prefix["physical_output_difference_before_first_changed_insertion_detected"],
            "selection": "not_adopted"}
        result["cases"].append(record)
        audit.save(directory / "interpretation.json", record)
        seal(directory)
    result["claim_boundary"] = "Both saved1/3 departure-only probes are rejected by the original eight gates. Input scope and observed prechange prefixes pass; no earlier traffic divergence was detected. Neither result proves control causality or zero-error infeasibility. Changed/unchanged count partition is exact arithmetic accounting, not causal isolation. No new simulation was run by the audit."
    audit.save(OUT / "study-summary.json", result)
    seal(OUT)
    print(json.dumps([{key: case[key] for key in ["case", "modified_target_bins_reached", "unchanged_both_complete_but_cross_bin", "unchanged_lost_complete_events", "no_detected_prechanged_insertion_physical_output_difference", "selection"]} for case in result["cases"]], ensure_ascii=False))


if __name__ == "__main__":
    main()
