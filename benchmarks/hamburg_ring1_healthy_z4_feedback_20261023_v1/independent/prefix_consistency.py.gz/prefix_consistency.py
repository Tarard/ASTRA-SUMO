"""Separate preloading counters from detected physical-output divergence."""

from collections import Counter
from decimal import Decimal
import itertools
import json
import xml.etree.ElementTree as ET

from audit_completed import OUT, SOURCE, STUDY, CASE_COUNTS, audit, seal


def elements(path, tag):
    for _, row in ET.iterparse(path, events=("end",)):
        if row.tag == tag:
            yield row
            row.clear()


def summary_compare(path, cutoff, actual_cutoff):
    first_all = first_traffic = None
    pre_requested_all = pre_requested_traffic = pre_actual_traffic = 0
    count = 0
    for a, b in itertools.zip_longest(elements(SOURCE / "evaluation/native/summary.xml", "step"), elements(path, "step")):
        assert a is not None and b is not None
        assert a.get("time") == b.get("time")
        count += 1
        time = Decimal(a.get("time"))
        diff = {key: [a.get(key), b.get(key)] for key in sorted(set(a.attrib) | set(b.attrib)) if key != "duration" and a.get(key) != b.get(key)}
        traffic = {key: value for key, value in diff.items() if key != "loaded"}
        if diff and first_all is None:
            first_all = {"native_time_s": str(time), "differences": diff}
        if traffic and first_traffic is None:
            first_traffic = {"native_time_s": str(time), "differences": traffic}
        pre_requested_all += bool(diff) and time < cutoff
        pre_requested_traffic += bool(traffic) and time < cutoff
        pre_actual_traffic += bool(traffic) and time < actual_cutoff
    assert count == 144000
    return {"native_steps": count, "first_excluding_duration": first_all,
        "first_traffic_excluding_duration_and_loaded": first_traffic,
        "pre_requested_cutoff_all_different_rows": pre_requested_all,
        "pre_requested_cutoff_traffic_different_rows": pre_requested_traffic,
        "pre_actual_modified_insertion_traffic_different_rows": pre_actual_traffic,
        "excluded_pure_preload_fields": ["loaded"], "other_fields_including_inserted_waiting_running_retained": True}


def instant_data(path):
    sequence, grouped = [], {}
    for row in elements(path, "instantOut"):
        values = dict(row.attrib)
        sequence.append(values)
        grouped.setdefault(Decimal(row.get("time")), Counter())[tuple(sorted(values.items()))] += 1
    return sequence, grouped


def routes(path):
    return {row.get("id"): {"attrs": dict(row.attrib), "canonical": ET.canonicalize(ET.tostring(row, encoding="unicode"), strip_text=True),
        "edges": row.find("route").get("edges").split(), "exits": [Decimal(t) for t in row.find("route").get("exitTimes").split()]}
        for row in elements(path, "vehicle")}


def main():
    original_sequence, original_grouped = instant_data(SOURCE / "evaluation/native/instant-e1.xml")
    original_routes = routes(SOURCE / "evaluation/native/vehicle-routes.xml")
    old_xml = list(ET.parse(SOURCE / "prepared/demand.rou.xml").getroot().findall("vehicle"))
    old_order = [v.get("id") for v in old_xml]
    for label in CASE_COUNTS:
        case, out = STUDY / label, OUT / label
        verdict = json.loads((case / "verdict.json").read_bytes())
        assert "after" in verdict
        proof = json.loads((out / "scope.json").read_bytes())
        changed = {row["vehicle_id"] for row in proof["changes"]}
        cutoff = min(Decimal(row[key]) for row in proof["changes"] for key in ["old_request_depart_text", "new_request_depart_text"])
        move_rows = audit.read_csv_rows(out / "modified-vehicle-actual-events.csv")
        actual_depart = [{"vehicle_id": row["vehicle_id"], "source_actual_depart_s": row["before_actual_insert_s"], "candidate_actual_depart_s": row["after_actual_insert_s"]} for row in move_rows]
        actual_cutoff = min(Decimal(row[key]) for row in actual_depart for key in ["source_actual_depart_s", "candidate_actual_depart_s"] if row[key])
        new_order = [v.get("id") for v in ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle")]
        assert [identity for identity in old_order if identity not in changed] == [identity for identity in new_order if identity not in changed]
        order_rows = [{"vehicle_id": identity, "old_raw_index": old_order.index(identity), "new_raw_index": new_order.index(identity)} for identity in sorted(changed)]
        summary = summary_compare(case / "evaluation/native/summary.xml", cutoff, actual_cutoff)
        sequence, grouped = instant_data(case / "evaluation/native/instant-e1.xml")
        first_seq = None
        for index, (a, b) in enumerate(itertools.zip_longest(original_sequence, sequence)):
            if a != b:
                first_seq = {"row_index": index, "source": a, "candidate": b}
                break
        differing_times = sorted(t for t in original_grouped.keys() | grouped.keys() if original_grouped.get(t, Counter()) != grouped.get(t, Counter()))
        first_semantic = None
        if differing_times:
            first = differing_times[0]
            old, new = original_grouped.get(first, Counter()), grouped.get(first, Counter())
            first_semantic = {"native_event_time_s": str(first), "source_only_events": [dict(row) for row in (old - new).elements()], "candidate_only_events": [dict(row) for row in (new - old).elements()]}
        current_routes = routes(case / "evaluation/native/vehicle-routes.xml")
        a_prefix = {identity: row["canonical"] for identity, row in original_routes.items() if Decimal(row["attrs"]["arrival"]) < cutoff}
        b_prefix = {identity: row["canonical"] for identity, row in current_routes.items() if Decimal(row["attrs"]["arrival"]) < cutoff}
        earliest_exit = None
        first_unmodified_depart = None
        for identity in sorted(original_routes.keys() & current_routes.keys() - changed):
            a, b = original_routes[identity], current_routes[identity]
            assert a["edges"] == b["edges"]
            old_depart, new_depart = Decimal(a["attrs"]["depart"]), Decimal(b["attrs"]["depart"])
            if old_depart != new_depart:
                time = min(old_depart, new_depart)
                if first_unmodified_depart is None or time < Decimal(first_unmodified_depart["earliest_native_time_s"]):
                    first_unmodified_depart = {"vehicle_id": identity, "source_depart_s": str(old_depart), "candidate_depart_s": str(new_depart), "earliest_native_time_s": str(time)}
            for edge, old, new in zip(a["edges"], a["exits"], b["exits"]):
                if old != new:
                    time = min(old, new)
                    if earliest_exit is None or time < Decimal(earliest_exit["earliest_native_time_s"]):
                        earliest_exit = {"vehicle_id": identity, "edge": edge, "source_exit_s": str(old), "candidate_exit_s": str(new), "earliest_native_time_s": str(time)}
        physical_pre = summary["pre_actual_modified_insertion_traffic_different_rows"] or any(t < actual_cutoff for t in differing_times) or a_prefix != b_prefix
        if earliest_exit and Decimal(earliest_exit["earliest_native_time_s"]) < actual_cutoff:
            physical_pre = True
        if first_unmodified_depart and Decimal(first_unmodified_depart["earliest_native_time_s"]) < actual_cutoff:
            physical_pre = True
        result = {"schema": "astra.hamburg.healthy-z4-prefix-consistency/v1", "status": "review_required" if physical_pre else "pass",
            "native_runs_by_audit": 0, "case": label, "earliest_changed_requested_s": str(cutoff),
            "earliest_changed_actual_insertion_s": str(actual_cutoff), "changed_actual_departures": actual_depart,
            "unmodified_raw_XML_relative_order_identical": True, "changed_raw_input_positions": order_rows,
            "summary": summary, "instant": {"source_events": len(original_sequence), "candidate_events": len(sequence),
                "first_file_sequence_difference": first_seq, "first_time_grouped_semantic_difference": first_semantic,
                "pre_requested_cutoff_semantically_different_times": sum(t < cutoff for t in differing_times),
                "pre_actual_insertion_semantically_different_times": sum(t < actual_cutoff for t in differing_times)},
            "arrived_strict_pre_requested_prefix": {"source_vehicles": len(a_prefix), "candidate_vehicles": len(b_prefix), "all_full_XML_and_exitTimes_identical": a_prefix == b_prefix},
            "earliest_unmodified_arrived_vehicle_exit_difference": earliest_exit,
            "earliest_unmodified_actual_departure_difference_among_common_arrived": first_unmodified_depart,
            "physical_output_difference_before_first_changed_insertion_detected": bool(physical_pre),
            "source_hashes": {str(path): audit.digest(path) for path in [SOURCE / "evaluation/native/summary.xml", SOURCE / "evaluation/native/instant-e1.xml", SOURCE / "evaluation/native/vehicle-routes.xml",
                case / "evaluation/native/summary.xml", case / "evaluation/native/instant-e1.xml", case / "evaluation/native/vehicle-routes.xml", SOURCE / "prepared/demand.rou.xml", case / "prepared/demand.rou.xml"]},
            "claim_boundary": "Loaded is an input-prefetch statistic, not physical traffic. Its early change is not called a code bug. Other summary fields, native instant event semantics and observed common-arrived route exits are checked separately. Identical observed prefixes do not prove every microscopic state/RNG state identical. Arrived-only routes cannot locate unfinished vehicles or certify their unrecorded trajectory."}
        audit.save(out / "prefix-consistency.json", result)
        seal(out)
        print(json.dumps({key: result[key] for key in ["case", "status", "earliest_changed_requested_s", "earliest_changed_actual_insertion_s", "changed_actual_departures", "changed_raw_input_positions", "summary", "instant", "arrived_strict_pre_requested_prefix", "earliest_unmodified_arrived_vehicle_exit_difference"]}, ensure_ascii=False))
    seal(OUT)


if __name__ == "__main__":
    main()
