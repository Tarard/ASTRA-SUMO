"""Offline scope and refusal checks; no native runner is invoked."""

import copy
import importlib.util
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("z4_run_candidate", ROOT / "run_candidate.py")
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)


@pytest.mark.parametrize("cap,actual", [(1, 1), (4, 3)])
def test_only_selected_departures_and_explicit_metadata_change(cap, actual):
    case = ROOT / f"batch-{cap}"
    proof = RUNNER.check(case)
    source = Path(json.loads((case / "proposal.json").read_bytes())["source_prepared"])
    old_tree = ET.parse(source / "demand.rou.xml").getroot()
    new_tree = ET.parse(case / "prepared/demand.rou.xml").getroot()
    old = {v.get("id"): v for v in old_tree.findall("vehicle")}
    new = {v.get("id"): v for v in new_tree.findall("vehicle")}
    ids = {r["vehicle_id"] for r in proof["changes"]}
    assert len(ids) == actual and len(new) == len(old) == 8640
    assert [ET.tostring(r) for r in old_tree if r.tag != "vehicle"] == [ET.tostring(r) for r in new_tree if r.tag != "vehicle"]
    for identity, before in old.items():
        after = copy.deepcopy(new[identity])
        if identity in ids:
            assert before.get("depart") != after.get("depart")
        after.set("depart", before.get("depart"))
        assert ET.tostring(before) == ET.tostring(after)
    order = {identity: i for i, identity in enumerate(old)}
    assert list(new) == sorted(old, key=lambda i: (float(new[i].get("depart")), order[i]))
    before_intent = {r["vehicle_id"]: r for r in json.loads((source / "lane-intentions.json").read_bytes())["vehicles"]}
    after_intent = {r["vehicle_id"]: r for r in json.loads((case / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    assert all(before_intent[i]["field_id"] == after_intent[i]["field_id"] for i in old)
    assert all(before_intent[i] == after_intent[i] for i in old.keys() - ids)
    assert not (case / "evaluation").exists() and not (case / "verdict.json").exists()


def test_smaller_cap_is_exact_subset_and_tampered_demand_refused(tmp_path):
    one, four = [json.loads((ROOT / f"batch-{cap}/proposal.json").read_bytes()) for cap in (1, 4)]
    assert one["proposals"] == four["proposals"][:1]
    assert four["max_total"] == 4 and four["changed_vehicles"] == 3
    fake = tmp_path / "tampered"
    shutil.copytree(ROOT / "batch-1/prepared", fake / "prepared")
    shutil.copyfile(ROOT / "batch-1/scope-proof.json", fake / "scope-proof.json")
    demand = fake / "prepared/demand.rou.xml"
    demand.write_bytes(demand.read_bytes() + b"\n")
    with pytest.raises(AssertionError):
        RUNNER.check(fake)
    assert not (fake / "evaluation").exists()
