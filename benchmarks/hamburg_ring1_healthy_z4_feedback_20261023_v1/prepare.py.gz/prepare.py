"""Prepare bounded Z4 request-time feedback from the completed healthy replay."""

import copy
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming
from astra_sumo.core.native_temporal_feedback import propose_native_count_retiming_batch

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
FIELD = "hh_0119_Z_4_29437"
FIXED = ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    assert not (ROOT / "basis").exists(), "Preserve existing prepared candidates."
    prepared, evaluation = SOURCE / "prepared", SOURCE / "evaluation"
    baseline = json.loads((evaluation / "evaluation.json").read_bytes())
    assert baseline["healthy"] and baseline["loss"] == 6709
    assert baseline["completion"]["arrived"] == 8640
    routes = ET.parse(prepared / "demand.rou.xml").getroot()
    old = {v.get("id"): v for v in routes.findall("vehicle")}
    order = {identity: index for index, identity in enumerate(old)}
    intentions = json.loads((prepared / "lane-intentions.json").read_bytes())
    intent = {r["vehicle_id"]: r for r in intentions["vehicles"]}
    assert len(old) == len(intent) == 8640 and old.keys() == intent.keys()
    identities = {i for i, r in intent.items() if r["field_id"] == FIELD}
    requests = [dict(vehicle_id=i, detector_id=FIELD, requested_depart_s=float(v.get("depart")))
                for i, v in old.items() if i in identities]
    compact = evaluation / "contributing-passages.json.gz"
    events = json.loads(gzip.decompress(compact.read_bytes()))
    assert events["reconciled"] and events["inputs_unchanged"] and len(events["passages"]) == 8640
    assert any(Path(r["path"]).name == "field-counts.xml" and r["sha256"] == sha(evaluation / "native/field-counts.xml") for r in events["inputs"])
    passages = [r for r in events["passages"] if r["vehicle_id"] in identities]
    assert len(identities) == len(requests) == len(passages) == 761
    assert {r["vehicle_id"] for r in passages} == identities and all(r["detector_id"] == FIELD for r in passages)
    counts = {(r.get("id"), float(r.get("begin")), float(r.get("end"))): int(r.get("nVehContrib"))
              for r in ET.parse(evaluation / "native/field-counts.xml").getroot()}
    measurements = []
    for name in ("initialization-counts.csv", "expected-counts.csv"):
        for row in csv.DictReader((prepared / name).open(encoding="utf-8", newline="")):
            if row["detector_id"] == FIELD:
                measurements.append({**row, "measured_nVehContrib": counts[FIELD, float(row["begin"]), float(row["end"])]})
    assert len(measurements) == 14
    basis = ROOT / "basis"
    basis.mkdir()
    shutil.copyfile(compact, basis / "contributing-passages.json.gz")
    save(basis / "z4-requests.json", requests)
    table(basis / "z4-real14.csv", measurements)
    source_paths = [*prepared.iterdir(), compact, evaluation / "native/field-counts.xml", evaluation / "evaluation.json", SOURCE / "verdict.json"]
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core"
    source_paths += [core / n for n in ("native_temporal_feedback.py", "hamburg_departure_probe.py")]
    binding = {str(p.resolve()): sha(p) for p in source_paths}
    summaries = []
    for cap in (1, 4):
        out = ROOT / f"batch-{cap}"
        out.mkdir()
        proposal = propose_native_count_retiming_batch(
            requests=requests, passages=passages, measurements=measurements,
            objective_window=(3600, 12600), max_total=cap, per_field=cap,
            per_source_bin=1, max_shift_s=900, margin_s=30, step_s=.1)
        assert proposal["projection_improves"] and proposal["changed_vehicles"] <= cap
        proposal.update(source_prepared=str(prepared.resolve()), source_native=str((evaluation / "native").resolve()),
                        source_hashes=binding, field=FIELD, Z4_requested_and_complete=761,
                        real_measurement_rows=14, main_rows=10, initialization_rows=4,
                        requested_cap=cap, actual_change_count=proposal["changed_vehicles"])
        save(out / "proposal.json", proposal)
        shutil.copytree(prepared, out / "prepared")
        changed = apply_native_count_retiming(routes, proposal["proposals"])
        vehicles = list(changed.findall("vehicle"))
        for v in vehicles:
            changed.remove(v)
        changed.extend(sorted(vehicles, key=lambda v: (float(v.get("depart")), order[v.get("id")])))
        new = {v.get("id"): v for v in changed.findall("vehicle")}
        selected = {r["vehicle_id"] for r in proposal["proposals"]}
        assert old.keys() == new.keys()
        for identity, before in old.items():
            after = copy.deepcopy(new[identity])
            after.set("depart", before.get("depart"))
            assert ET.tostring(before) == ET.tostring(after), identity
        assert [ET.tostring(r) for r in routes if r.tag != "vehicle"] == [ET.tostring(r) for r in changed if r.tag != "vehicle"]
        assert {i for i in old if old[i].get("depart") != new[i].get("depart")} == selected <= identities
        ET.ElementTree(changed).write(out / "prepared/demand.rou.xml", encoding="utf-8", xml_declaration=True)
        metadata = copy.deepcopy(intentions)
        vector, edits = [0] * 294, []
        by_move = {r["vehicle_id"]: r for r in proposal["proposals"]}
        for row in metadata["vehicles"]:
            identity = row["vehicle_id"]
            depart = float(new[identity].get("depart"))
            cell = math.floor(depart / 900) * 21 + row["od_cell"] % 21
            assert 0 <= cell < 294
            if identity in selected:
                previous = row["od_cell"]
                row.update(od_cell=cell, depart_s=depart)
                edits.append({**by_move[identity], "old_od_cell": previous, "new_od_cell": cell,
                              "source_native_depart_s": math.floor(float(old[identity].get("depart")) * 1000 + .5) / 1000,
                              "new_native_depart_s": math.floor(depart * 1000 + .5) / 1000})
            else:
                assert cell == row["od_cell"] and row == intent[identity]
            vector[cell] += 1
        assert sum(vector) == 8640
        metadata["mechanism"] += " Explicit bounded Z4 departure feedback; actual departure-cell metadata synchronized. No quantile regeneration."
        save(out / "prepared/lane-intentions.json", metadata)
        save(out / "od-vector.json", dict(values=vector, integer_counts=vector, vehicle_count=8640,
             generation="Counts of saved explicit requests in actual294 departure cells; not regenerated from an OD model."))
        scenario = json.loads((prepared / "scenario.json").read_bytes())
        scenario.update(demand_sha256=sha(out / "prepared/demand.rou.xml"),
                        demand_prior="Same8640 identities/routes/stops/field intentions; only selected explicit Z4 departures retimed.",
                        time_prior="Bounded proposal from healthy native notifications; unchanged lags are not predictions. No quantile regeneration.")
        save(out / "prepared/scenario.json", scenario)
        assert all((prepared / n).read_bytes() == (out / "prepared" / n).read_bytes() for n in FIXED)
        initial = [r for r in proposal["projection"] if r["end"] <= 3600]
        assert all(r["projected_nVehContrib"] == r["measured_nVehContrib"] for r in initial)
        proof = dict(status="pass", native_runs=0, formal_result=False, requested_cap=cap, actual_changes=len(selected), N=8640,
                     only_selected_depart_attributes_changed=True, all_routes_stops_vtypes_and_other_attributes_exact=True,
                     original_order_retained_for_equal_departures=True, field_intentions_all_unchanged=True,
                     unchanged_other_vehicle_intent_rows=8640-len(selected), initialization4_projection_unchanged=True,
                     original_driver_scope=scenario["junction_body_hold_nodes"], changes=edits,
                     source_hashes=binding, prepared_hashes={p.name: sha(p) for p in (out / "prepared").iterdir()},
                     outside_simulation_evidence="No new native run. Full130/40/52/182,53556 and healthy completion must be measured.")
        save(out / "scope-proof.json", proof)
        summaries.append({k: proposal[k] for k in ("requested_cap", "actual_change_count", "before_objective_l1", "projected_objective_l1", "before_all_l1", "projected_all_l1")})
    save(ROOT / "preparation.json", dict(status="prepared_awaiting_root_review", native_runs=0, formal_result=False,
         source=str(SOURCE.resolve()), source_evaluation=baseline, candidates=summaries,
         cap4_shortfall="Only3 distinct source bins yield eligible core proposals under per_source_bin1; no fourth move fabricated.",
         source_inputs_unchanged=all(sha(Path(p)) == h for p, h in binding.items())))
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
