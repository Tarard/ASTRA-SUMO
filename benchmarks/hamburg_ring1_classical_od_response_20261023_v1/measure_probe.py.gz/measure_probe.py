"""Measure one two-cell OD transfer; --preview-only never starts SUMO."""
import argparse
from collections import Counter
import hashlib
from importlib.metadata import version
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PREPARED = ROOT / 'prepared'
BASELINE = ROOT.parent / 'hamburg-z5-native-feedback-20261023-v1/z15-half-unsplit-full/evaluation'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def requests(path):
    return {v.get('id'): v for v in ET.parse(path).getroot().findall('vehicle')}


def canonical(vehicle):
    return ET.canonicalize(ET.tostring(vehicle, encoding='unicode'), strip_text=True)


def preview_audit(prepared, preview, donor, receiver):
    from astra_sumo.core.detector_demand import write_csv

    model = json.loads((prepared / 'od-model.json').read_bytes())
    before, after = requests(prepared / 'demand.rou.xml'), requests(preview / 'demand.rou.xml')
    old_fields, new_fields = [{r['vehicle_id']: r['field_id'] for r in json.loads(path.read_bytes())['vehicles']}
        for path in (prepared / 'lane-intentions.json', preview / 'lane-intentions.json')]
    counts = json.loads((preview / 'od-vector.json').read_bytes())['integer_counts']
    rows, changed_cells = [], set()
    for identity in sorted(before.keys() | after.keys()):
        column, number = int(identity.split('_')[1]), int(identity.split('_')[2][1:])
        old, new = before.get(identity), after.get(identity)
        index, source_id = None, None
        if new is not None:
            templates = model['cells'][column]['templates']
            index = min(len(templates) - 1, int(((number + .5) / counts[column]) * len(templates)))
            template = templates[index]
            source_id = template['prior_vehicle_id']
            source = ET.fromstring(template['vehicle_xml'])
            assert {k: v for k, v in new.attrib.items() if k not in {'id', 'depart'}} == {
                k: v for k, v in source.attrib.items() if k not in {'id', 'depart'}}
            assert [canonical(c) for c in new] == [canonical(c) for c in source]
            assert new_fields[identity] == template['prior_field_intention']
        changes = []
        if old is None or new is None:
            changes = ['added' if old is None else 'removed']
        else:
            if old.get('depart') != new.get('depart'):
                changes.append('departure')
            if old.find('route').attrib != new.find('route').attrib:
                changes.append('route')
            if [canonical(c) for c in old if c.tag != 'route'] != [canonical(c) for c in new if c.tag != 'route']:
                changes.append('stop_or_other_child')
            if old_fields[identity] != new_fields[identity]:
                changes.append('field')
            if {k: v for k, v in old.attrib.items() if k != 'depart'} != {k: v for k, v in new.attrib.items() if k != 'depart'}:
                changes.append('request_attributes')
            assert bool(changes) == (canonical(old) != canonical(new) or old_fields[identity] != new_fields[identity])
        if changes:
            changed_cells.add(column)
        assert column in {donor, receiver} or not changes
        rows.append({'vehicle_id': identity, 'od_cell': column, 'changes': ','.join(changes),
            'baseline_depart_s': old.get('depart') if old is not None else '',
            'proposed_depart_s': new.get('depart') if new is not None else '',
            'baseline_native_depart_ms': math.floor(float(old.get('depart')) * 1000 + .5) if old is not None else '',
            'proposed_native_depart_ms': math.floor(float(new.get('depart')) * 1000 + .5) if new is not None else '',
            'baseline_field': old_fields.get(identity, ''), 'proposed_field': new_fields.get(identity, ''),
            'proposed_source_template_index': index, 'source_template_vehicle_id': source_id})
    assert changed_cells == {donor, receiver} and len(after) == sum(counts) == 8640
    write_csv(preview / 'vehicle-changes.csv', rows, list(rows[0]))
    result = {'status': 'pass', 'only_two_cells_changed': sorted(changed_cells),
        'non_target_292_cells_identical': True, 'vehicle_count': len(after),
        'changed_vehicle_union_rows': sum(bool(row['changes']) for row in rows),
        'change_category_counts': dict(Counter(c for row in rows for c in row['changes'].split(',') if c)),
        'counts': {str(i): {'before': model['cells'][i]['initial_flow'], 'after': counts[i]} for i in (donor, receiver)},
        'claim_boundary': 'Existing empirical joint quantile resampling changes whole target cohorts, not just six vehicle times. Template indices are zero-based. This is not a new native measurement.'}
    write_json(preview / 'audit.json', result)
    return result


def strict_result(prepared, evaluation, source, result, preview):
    from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv
    from astra_sumo.core.hamburg_od_spsa import summarize_hamburg_od_measurement

    native_dir = evaluation / 'native'
    native = json.loads((native_dir / 'run.json').read_bytes())
    main_expected = read_csv_rows(prepared / 'expected-counts.csv')
    init_expected = read_csv_rows(prepared / 'initialization-counts.csv')
    main = audit_expected_to_e1_strict(main_expected, native_dir / 'field-counts.xml', count_attribute='nVehContrib')
    init = audit_expected_to_e1_strict(init_expected, native_dir / 'field-counts.xml', count_attribute='nVehContrib')
    reference = audit_expected_to_e1_strict(init_expected, source / 'baseline-field-counts.xml', count_attribute='nVehContrib')
    baseline_main = audit_expected_to_e1_strict(main_expected, source / 'baseline-field-counts.xml', count_attribute='nVehContrib')
    assert len(main) == 130 and len(init) == 52 and all(r['measured_nVehContrib'] is not None for r in main + init)
    assert len({(r['detector_id'], float(r['begin']), float(r['end'])) for r in main + init}) == 182
    for name, rows in [('native/field-comparison.csv', main), ('initialization52-comparison.csv', init), ('all182-comparison.csv', main + init)]:
        write_csv(evaluation / name, rows, list(rows[0]))
    measured = summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
    assert measured == result
    baseline_sse = sum(int(r['diff_nVehContrib_minus_expected']) ** 2 for r in baseline_main)
    baseline_tae = sum(abs(int(r['diff_nVehContrib_minus_expected'])) for r in baseline_main)
    assert (baseline_sse, baseline_tae) == (10749, 775)
    same_preview = all((preview / name).read_bytes() == (evaluation / name).read_bytes()
                       for name in ('demand.rou.xml', 'lane-intentions.json', 'od-vector.json'))
    assert same_preview
    completion = native['completion']
    safe = not any(completion[k] for k in ('collisions', 'teleports', 'discarded')) and not ET.parse(native_dir / 'collisions.xml').getroot().findall('collision')
    tae = sum(abs(int(r['diff_nVehContrib_minus_expected'])) for r in main)
    unchanged_init = init == reference
    eligible = safe and unchanged_init and measured['loss'] < baseline_sse and tae <= baseline_tae
    return {'status': 'diagnostic_candidate' if eligible else 'rejected', 'formal_result': False,
        'native_status': native['native_status'], 'safe': safe, 'healthy': measured['healthy'],
        'preview_and_measure_bytes_identical': same_preview, 'initialization52_identical_to_baseline': unchanged_init,
        'main_rows': len(main), 'initialization_rows': len(init), 'all_rows': len(main + init),
        'baseline': {'SSE': baseline_sse, 'TAE': baseline_tae, 'MAE': baseline_tae / 130},
        'measurement': {**measured, 'TAE': tae, 'all182_TAE': sum(abs(int(r['diff_nVehContrib_minus_expected'])) for r in main + init)},
        'completion': completion, 'waiting': completion['waiting'], 'running': completion['running'],
        'claim_boundary': 'A safe SSE decrease with non-increasing main MAE is diagnostic only. All 130 fields and 52 initialization observations remain. This is not formal calibration or proof of true OD.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--name', required=True)
    parser.add_argument('--donor', type=int, required=True)
    parser.add_argument('--receiver', type=int, required=True)
    parser.add_argument('--delta', type=int, required=True)
    parser.add_argument('--preview-only', action='store_true')
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9][a-z0-9_-]*', args.name) and args.delta != 0
    assert Path(sys.executable).resolve() == (REPO / '.venv/Scripts/python.exe').resolve()
    x0 = json.loads((PREPARED / 'initial-od-vector.json').read_bytes())['values']
    assert len(x0) == 294 and sum(x0) == 8640 and 0 <= args.donor < 294 and 0 <= args.receiver < 294 and args.donor != args.receiver
    values = list(x0)
    values[args.donor] -= args.delta
    values[args.receiver] += args.delta
    assert min(values) >= 0 and sum(values) == 8640
    assert [i for i, (a, b) in enumerate(zip(x0, values)) if a != b] == sorted([args.donor, args.receiver])
    out = ROOT / args.name
    out.mkdir(exist_ok=False)
    source = out / 'source'
    prepared = source / 'prepared'
    prepared.mkdir(parents=True)
    hashes = {}
    for path in PREPARED.iterdir():
        if path.is_file():
            hashes[str(path)] = sha(path)
            shutil.copyfile(path, prepared / path.name)
    for name, path in [('baseline-field-counts.xml', BASELINE / 'native/field-counts.xml'), ('baseline-evaluation.json', BASELINE / 'evaluation.json')]:
        hashes[str(path)] = sha(path)
        shutil.copyfile(path, source / name)
    shutil.copyfile(Path(__file__), out / 'measure_probe.snapshot.py')
    implementation = out / 'implementation'
    shutil.copytree(REPO / 'plugins/astra-sumo/src/astra_sumo', implementation / 'astra_sumo', ignore=shutil.ignore_patterns('__pycache__'))
    sys.path.insert(0, str(implementation))
    os.environ['PYTHONPATH'] = str(implementation)
    os.environ['PYTHONUTF8'] = '1'
    os.environ['SUMO_HOME'] = str(REPO / '.venv/Lib/site-packages/sumo')
    import libsumo
    import sumo
    from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od, write_hamburg_od_demand

    binary = Path(sumo.__file__).parent / 'bin/sumo.exe'
    library = Path(libsumo.__file__).parent / '_libsumo.pyd'
    versions = {n: version(n) for n in ('eclipse-sumo', 'sumolib', 'traci', 'libsumo')}
    assert set(versions.values()) == {'1.27.1'}
    metadata = {'arguments': vars(args), 'values': values, 'source_hashes': hashes,
        'python': sys.executable, 'python_sha256': sha(Path(sys.executable)), 'versions': versions,
        'numpy_version': version('numpy'), 'sumo_sha256': sha(binary), 'libsumo_sha256': sha(library),
        'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'implementation_sha256': {str(p.relative_to(implementation)): sha(p) for p in implementation.rglob('*.py')},
        'script_sha256': sha(Path(__file__)), 'formal_result': False, 'backend': 'libsumo', 'new_native_run': False}
    write_json(out / 'execution.json', metadata)
    preview = write_hamburg_od_demand(model_file=prepared / 'od-model.json', values=values, output_dir=out / 'preview')
    audit = preview_audit(prepared, preview, args.donor, args.receiver)
    print(json.dumps({'stage': 'preview_ready', **audit}), flush=True)
    if args.preview_only:
        return
    start = time.perf_counter()
    write_json(out / 'progress.json', {'stage': 'native_running', 'formal_result': False})
    try:
        result = measure_hamburg_od(prepared_dir=prepared, values=values, output_dir=out / 'evaluation', sumo_binary=binary, backend='libsumo')
        verdict = strict_result(prepared, out / 'evaluation', source, result, preview)
        verdict.update(elapsed_seconds=time.perf_counter() - start,
            source_inputs_unchanged=all(sha(Path(path)) == value for path, value in hashes.items()))
        assert verdict['source_inputs_unchanged']
        write_json(out / 'verdict.json', verdict)
        metadata.update(new_native_run=True, completed=True)
        write_json(out / 'execution.json', metadata)
        write_json(out / 'progress.json', {'stage': 'completed', 'status': verdict['status']})
        print(json.dumps(verdict), flush=True)
    except Exception as error:
        write_json(out / 'failure.json', {'status': 'blocked', 'error': f'{type(error).__name__}: {error}',
            'elapsed_seconds': time.perf_counter() - start, 'formal_result': False,
            'claim_boundary': 'Preserve all native outputs and failed checks. No candidate is accepted.'})
        raise


if __name__ == '__main__':
    main()
