"""Audit one completed OD allocation. This script cannot run SUMO."""

from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
CASE = ROOT / "outputs/hamburg-z5-native-feedback-20261023-v1/z15-half-unsplit-full"
NATIVE = CASE / "evaluation/native"
MODEL = ROOT / "outputs/hamburg-directed-backlog-20261023-v1/original-seed-restored-prepared/od-model.json"


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(name, rows):
    with (OUT / name).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
                             for k, v in row.items()})


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def spectral(matrix):
    singular = np.linalg.svd(matrix, compute_uv=False)
    tolerance = float(max(matrix.shape) * np.finfo(float).eps * singular[0])
    rank = int(np.count_nonzero(singular > tolerance))
    return dict(shape=list(matrix.shape), rank=rank, nullity=matrix.shape[1] - rank,
                row_deficiency=matrix.shape[0] - rank, tolerance=tolerance,
                nonzero_condition=float(singular[0] / singular[rank - 1]) if rank else None,
                zero_columns=np.flatnonzero(np.all(matrix == 0, axis=0)).tolist(),
                zero_rows=np.flatnonzero(np.all(matrix == 0, axis=1)).tolist(),
                singular_values=singular.tolist())


OUT.mkdir(parents=True, exist_ok=True)
inputs = [MODEL, CASE / "evaluation/od-vector.json", NATIVE / "demand.rou.xml",
          NATIVE / "lane-intentions.json", NATIVE / "network.net.xml", NATIVE / "signal-programs.add.xml",
          NATIVE / "instant-e1.xml", NATIVE / "field-counts.xml", NATIVE / "tripinfo.xml",
          NATIVE / "run.json", CASE / "evaluation/all182-comparison.csv",
          NATIVE / "expected-counts.csv",
          CASE / "prepared/expected-counts.csv", CASE / "prepared/initialization-counts.csv",
          ROOT / "plugins/astra-sumo/src/astra_sumo/core/route_sensor_matrix.py", Path(__file__).resolve()]
sources = [{"path": str(p.relative_to(ROOT)), "sha256": digest(p)} for p in inputs]
model = json.loads(MODEL.read_bytes())
cells = model["cells"]
keys = [(c["origin"], c["destination"], int(c["begin_s"]) // 900) for c in cells]
assert len(set(keys)) == len(keys) == 294
columns = {key: i for i, key in enumerate(keys)}
x0 = np.array([c["initial_flow"] for c in cells], dtype=np.int64)
vector = json.loads((CASE / "evaluation/od-vector.json").read_bytes())
assert vector["source_model_sha256"] == digest(MODEL)
assert np.array_equal(x0, vector["integer_counts"]) and x0.sum() == 8640 and np.all(x0 > 0)
intent = {r["vehicle_id"]: r for r in json.loads((NATIVE / "lane-intentions.json").read_bytes())["vehicles"]}
requests = {}
for vehicle in ET.parse(NATIVE / "demand.rou.xml").getroot().findall("vehicle"):
    identity = vehicle.get("id")
    route = vehicle.find("route").get("edges").split()
    depart = float(vehicle.get("depart"))
    key = (route[0], route[-1], int(depart // 900))
    column = columns[key]
    assert intent[identity]["od_cell"] == column
    requests[identity] = dict(vehicle_id=identity, column=column, origin=key[0], destination=key[1],
                              departure_period=key[2], requested_depart_s=depart,
                              intended_field=intent[identity]["field_id"])
assert len(requests) == 8640
assert np.array_equal(np.bincount([v["column"] for v in requests.values()], minlength=294), x0)
trips = {e.get("id"): dict(e.attrib) for _, e in ET.iterparse(NATIVE / "tripinfo.xml") if e.tag == "tripinfo"}
run = json.loads((NATIVE / "run.json").read_bytes())
passage = read_contributing_e1_passages(instant_file=NATIVE / "instant-e1.xml",
    periodic_file=NATIVE / "field-counts.xml", detector_ids=run["instant_to_periodic_ids"], step_length=0.1)
assert passage["reconciled"] and passage["inputs_unchanged"]
all_rows = list(csv.DictReader((CASE / "evaluation/all182-comparison.csv").open(encoding="utf-8-sig")))
targets = {(r["detector_id"], float(r["begin"]), float(r["end"])): r for r in all_rows}
declared_targets = {}
for filename, expected_length in [("expected-counts.csv", 130), ("initialization-counts.csv", 52)]:
    declared = list(csv.DictReader((CASE / "prepared" / filename).open(encoding="utf-8-sig")))
    assert len(declared) == expected_length
    for row in declared:
        key = (row["detector_id"], float(row["begin"]), float(row["end"]))
        assert key not in declared_targets
        declared_targets[key] = int(row["expected_total"])
assert declared_targets == {key: int(row["expected_total"]) for key, row in targets.items()}
assert digest(NATIVE / "expected-counts.csv") == digest(CASE / "prepared/expected-counts.csv")
native_rows = passage["interval_comparisons"]
row_keys = [(r["detector_id"], r["begin_s"], r["end_s"]) for r in native_rows]
row_index = {key: i for i, key in enumerate(row_keys)}
assert len(native_rows) == 208 and len(targets) == 182
target_mask = np.array([key in targets for key in row_keys])
main_mask = np.array([key in targets and 3600 <= key[1] < 12600 for key in row_keys])
assert target_mask.sum() == 182 and main_mask.sum() == 130
integer_allocation = np.zeros((208, 294), dtype=np.int64)
vehicle_passes = defaultdict(list)
for event in passage["passages"]:
    identity = event["vehicle_id"]
    request = requests[identity]
    key = (event["detector_id"], event["interval_begin_s"], event["interval_end_s"])
    integer_allocation[row_index[key], request["column"]] += 1
    vehicle_passes[identity].append(event)
observed = np.array([r["periodic_nVehContrib"] for r in native_rows], dtype=np.int64)
assert np.array_equal(integer_allocation.sum(axis=1), observed)
allocation = integer_allocation / x0[None, :]
assert np.allclose(allocation @ x0, observed, rtol=0, atol=1e-10)
target = np.array([int(targets[key]["expected_total"]) if key in targets else 0 for key in row_keys])
for i, key in enumerate(row_keys):
    if key in targets:
        assert observed[i] == int(targets[key]["measured_nVehContrib"])
residual = observed - target
assert abs(residual[main_mask]).sum() == 775 and abs(residual[target_mask]).sum() == 857
row_metadata = []
for i, key in enumerate(row_keys):
    row_metadata.append(dict(row=i, field=key[0], begin_s=key[1], end_s=key[2],
        scope="main" if main_mask[i] else "initialization" if target_mask[i] else "tail_no_target",
        measured=int(observed[i]), target=int(target[i]) if target_mask[i] else None,
        residual=int(residual[i]) if target_mask[i] else None))
write_csv("rows-208.csv", row_metadata)
np.savez_compressed(OUT / "allocation.npz", x0=x0, integer_allocation208=integer_allocation,
                    A208=allocation, A182=allocation[target_mask], A130=allocation[main_mask],
                    row_indices182=np.flatnonzero(target_mask), row_indices130=np.flatnonzero(main_mask),
                    measured208=observed, target182=target[target_mask], target130=target[main_mask])
long_rows = []
for i, j in zip(*np.nonzero(integer_allocation)):
    long_rows.append(dict(row=int(i), column=int(j), field=row_keys[i][0], begin_s=row_keys[i][1],
                         completed_contributions=int(integer_allocation[i, j]), requested_flow=int(x0[j]),
                         allocation_fraction=float(allocation[i, j])))
write_csv("allocation-nonzero.csv", long_rows)
cell_counts = [Counter() for _ in cells]
vehicles = []
for identity, request in requests.items():
    trip = trips.get(identity)
    status = "not_inserted" if trip is None else "running" if float(trip["arrival"]) < 0 else "arrived"
    events = vehicle_passes[identity]
    counts = cell_counts[request["column"]]
    counts["requested"] += 1
    counts[status] += 1
    counts["inserted"] += trip is not None
    counts["no_complete_passage"] += not events
    counts["inserted_no_complete_passage"] += trip is not None and not events
    counts["complete_passage_vehicles"] += bool(events)
    counts["intended_field_not_completed"] += not any(e["detector_id"] == request["intended_field"] for e in events)
    event_rows = [row_index[e["detector_id"], e["interval_begin_s"], e["interval_end_s"]] for e in events]
    counts["initialization_contributions"] += int(sum(target_mask[i] and not main_mask[i] for i in event_rows))
    counts["main_contributions"] += int(sum(main_mask[i] for i in event_rows))
    counts["tail_contributions"] += int(sum(not target_mask[i] for i in event_rows))
    vehicles.append({**request, "status": status,
        "actual_insert_s": float(trip["depart"]) if trip else None,
        "depart_delay_s": float(trip["departDelay"]) if trip else None,
        "completed_contributions": len(events), "completed_fields": [e["detector_id"] for e in events],
        "completed_bins_s": [e["interval_begin_s"] for e in events]})
write_csv("vehicle-outcomes.csv", vehicles)
main_a, full_a = allocation[main_mask], allocation[target_mask]
main_r, full_r = residual[main_mask], residual[target_mask]
column_rows = []
for j, cell in enumerate(cells):
    column_rows.append(dict(column=j, origin=cell["origin"], destination=cell["destination"],
        begin_s=cell["begin_s"], end_s=cell["end_s"], x0=int(x0[j]),
        intended_fields=dict(Counter(r["intended_field"] for r in requests.values() if r["column"] == j)),
        native_outcomes=dict(cell_counts[j]),
        association_main=float(main_a[:, j] @ main_r),
        association_all182=float(full_a[:, j] @ full_r),
        observed_main_yield=float(main_a[:, j].sum()), observed_all182_yield=float(full_a[:, j].sum())))
write_csv("columns-294.csv", column_rows)
pairs = sorted({(c["origin"], c["destination"]) for c in cells})
transfer = np.zeros((294, 21 * 13))
transfer_rows = []
for k, (origin, destination) in enumerate(pairs):
    for h in range(13):
        j, next_j = columns[origin, destination, h], columns[origin, destination, h + 1]
        transfer[j, 13 * k + h], transfer[next_j, 13 * k + h] = -1, 1
        for donor, receiver in [(j, next_j), (next_j, j)]:
            amplitude = min(6, max(1, int(x0[donor] * .1)))
            delta = np.zeros(294)
            delta[donor], delta[receiver] = -amplitude, amplitude
            frozen_main, frozen_full = main_r + main_a @ delta, full_r + full_a @ delta
            transfer_rows.append(dict(origin=origin, destination=destination,
                donor_column=donor, receiver_column=receiver,
                donor_begin_s=cells[donor]["begin_s"], receiver_begin_s=cells[receiver]["begin_s"],
                donor_x0=int(x0[donor]), receiver_x0=int(x0[receiver]), integer_delta=amplitude,
                donor_fraction=amplitude / int(x0[donor]),
                frozen_main_tae=float(abs(frozen_main).sum()), frozen_all182_tae=float(abs(frozen_full).sum()),
                frozen_main_sse=float(frozen_main @ frozen_main),
                main_directional_association=float((main_a[:, receiver] - main_a[:, donor]) @ main_r),
                starts_after_initialization=min(cells[donor]["begin_s"], cells[receiver]["begin_s"]) >= 3600,
                affected_fields=sorted({row_keys[i][0] for i in np.flatnonzero(allocation @ delta)})))
transfer_rows.sort(key=lambda r: (r["frozen_main_tae"], r["frozen_main_sse"]))
write_csv("adjacent-period-transfer-screen.csv", transfer_rows)
group_rows = []
for group_type in ["entry", "od", "departure_period"]:
    groups = defaultdict(list)
    for j, cell in enumerate(cells):
        label = cell["origin"] if group_type == "entry" else (
            cell["origin"] + " -> " + cell["destination"] if group_type == "od" else str(int(cell["begin_s"]) // 900))
        groups[label].append(j)
    for label, group in groups.items():
        contribution = integer_allocation[:, group].sum(axis=1)
        support = contribution[main_mask] > 0
        summary_counts = sum((cell_counts[j] for j in group), Counter())
        group_rows.append(dict(group_type=group_type, group=label, columns=group,
            x0=int(x0[group].sum()), outcomes=dict(summary_counts),
            rank_main130=int(np.linalg.matrix_rank(main_a[:, group])),
            rank_all182=int(np.linalg.matrix_rank(full_a[:, group])),
            main_contribution_total=int(contribution[main_mask].sum()),
            main_residual_association=float((contribution[main_mask] / x0[group].sum()) @ main_r),
            overlapping_main_row_count=int(support.sum()),
            main_residual_on_overlap=int(main_r[support].sum()),
            main_tae_on_overlap=int(abs(main_r[support]).sum()),
            caveat="Overlapping row residuals are associations, not exclusive errors caused by this group"))
write_csv("group-residual-associations.csv", group_rows)
field_rows = []
for field in sorted({k[0] for k in row_keys}):
    mask = np.array([k[0] == field for k in row_keys])
    field_rows.append(dict(field=field, main_measured=int(observed[mask & main_mask].sum()),
        main_target=int(target[mask & main_mask].sum()), main_signed_residual=int(residual[mask & main_mask].sum()),
        main_tae=int(abs(residual[mask & main_mask]).sum()),
        initialization_tae=int(abs(residual[mask & target_mask & ~main_mask]).sum()),
        tail_contributions=int(observed[mask & ~target_mask].sum())))
write_csv("field-residuals.csv", field_rows)
rank_main, rank_full = spectral(main_a), spectral(full_a)
rank_transfer_main, rank_transfer_full = spectral(main_a @ transfer), spectral(full_a @ transfer)
ols = {}
orthogonal_rows = []
for label, matrix, errors in [("main130", main_a, main_r), ("all182", full_a, full_r)]:
    change = np.linalg.lstsq(matrix, -errors, rcond=None)[0]
    remaining = matrix @ change + errors
    conserved_change = transfer @ np.linalg.lstsq(matrix @ transfer, -errors, rcond=None)[0]
    conserved_remaining = matrix @ conserved_change + errors
    ols[label] = dict(unconstrained_frozen_minimum_sse=float(remaining @ remaining),
        unconstrained_solution_negative_cells=int(np.count_nonzero(x0 + change < 0)),
        unconstrained_solution_total_change=float(change.sum()),
        fixed_each_od_total_frozen_minimum_sse=float(conserved_remaining @ conserved_remaining),
        fixed_each_od_total_negative_cells=int(np.count_nonzero(x0 + conserved_change < 0)),
        caveat="Continuous OLS for this frozen allocation only; no integer/bound/native feasibility claim")
    selected_rows = np.flatnonzero(main_mask if label == "main130" else target_mask)
    for i, original_row in enumerate(selected_rows):
        orthogonal_rows.append(dict(scope=label, row=int(original_row), field=row_keys[original_row][0],
            begin_s=row_keys[original_row][1], remaining_after_unconstrained_frozen_ols=float(remaining[i])))
write_csv("frozen-ols-orthogonal-residual.csv", orthogonal_rows)
conservation = np.array([[int((c["origin"], c["destination"]) == pair) for c in cells] for pair in pairs])
assert np.array_equal(conservation @ transfer, np.zeros((21, 273)))
constraint_diagnostics = dict(each_od_total_rows=21,
    conservation_rank=int(np.linalg.matrix_rank(conservation)),
    augmented_main_rank=int(np.linalg.matrix_rank(np.vstack([main_a, conservation]))),
    augmented_all182_rank=int(np.linalg.matrix_rank(np.vstack([full_a, conservation]))),
    caveat="OD total preservation is a chosen engineering restriction, not another field observation")
selected = []
for donor, receiver, reason in [
    (125, 146, "119 Z4/Z5 has main TAE 250 and the origin retains 23 incomplete passes. Test arrival/control coupling at its main OD."),
    (252, 231, "535 Z8 has main TAE 87 and 67 tail contributions. Donor column is invisible in 182 rows but visible in tail; test that window boundary."),
    (112, 91, "119 Z15 has a clean OD cohort and main TAE 56. This is the largest frozen TAE reduction in the bounded adjacent screen.")
]:
    row = next(r for r in transfer_rows if r["donor_column"] == donor and r["receiver_column"] == receiver)
    delta = np.zeros(294, dtype=np.int64)
    delta[donor], delta[receiver] = -row["integer_delta"], row["integer_delta"]
    assert np.all(x0 + delta >= 0) and delta.sum() == 0 and np.array_equal(conservation @ delta, np.zeros(21))
    assert np.all(delta[[int(c["begin_s"]) < 3600 for c in cells]] == 0)
    changed_rows = np.flatnonzero(allocation @ delta)
    changes = [dict(field=row_keys[i][0], begin_s=row_keys[i][1], scope=row_metadata[i]["scope"],
        native_measured=int(observed[i]), target=int(target[i]) if target_mask[i] else None,
        residual=int(residual[i]) if target_mask[i] else None,
        frozen_allocation_delta=float(allocation[i] @ delta)) for i in changed_rows]
    selected.append({**row, "reason": reason, "delta_vector_sparse": {str(donor): int(delta[donor]), str(receiver): int(delta[receiver])},
        "new_cell_flows": {str(donor): int(x0[donor] + delta[donor]), str(receiver): int(x0[receiver] + delta[receiver])},
        "frozen_affected_rows": changes, "amplitude_boundary": "Engineering probe: min(6, floor(10% donor x0)), with at least one. Not a fitted confidence bound.",
        "evaluation_boundary": "Evaluate each separately with unchanged actuated control, source network, all targets and seed. Frozen delta is not a native forecast.",
        "optional_reverse": {str(donor): int(-delta[donor]), str(receiver): int(-delta[receiver])}})
write_json("probe-suggestions.json", selected)
report = dict(source_case=str(CASE.relative_to(ROOT)), source_hashes=sources,
    definition="B[i,j] counts full native nVehContrib passages from actual requested OD/departure cell j. A[i,j]=B[i,j]/x0[j].",
    boundary="Same-run allocation, not a Jacobian or an invariant response to changed demand. No simulation was executed.",
    checks=dict(actual_route_departure_keys_match_intent_columns=True, x0_294_sum=int(x0.sum()),
        all182_targets_match_prepared_130_plus_52=True, native_expected_counts_bytes_match_prepared=True,
        periodic_intervals=len(native_rows), periodic_passages_reconciled=passage["reconciled"],
        exact_integer_B_row_sums_match_native=True, max_float_Ax0_error=float(abs(allocation @ x0 - observed).max()),
        main_tae=int(abs(main_r).sum()), all182_tae=int(abs(full_r).sum()),
        main_sse=int(main_r @ main_r), all182_sse=int(full_r @ full_r),
        early_leave_events=len(passage["early_departures"]), outside_periodic=len(passage["outside_periodic_intervals"])),
    total_vehicle_outcomes=dict(sum(cell_counts, Counter())),
    native_completion=run["completion"],
    complete_passage_multiplicity=dict(Counter(len(v) for v in vehicle_passes.values())),
    rank_main130=rank_main, rank_all182=rank_full,
    rank_all208=spectral(allocation),
    rank_each_od_total_preserved_main130=rank_transfer_main,
    rank_each_od_total_preserved_all182=rank_transfer_full,
    conservation_constraint_diagnostics=constraint_diagnostics,
    ols_frozen_span_diagnostics=ols,
    independent_loss_rows="130 main rows; 52 additional initialization rows reported separately. 40 station sums are not extra independent rows.",
    selected_engineering_probe_suggestions=selected,
    selected_probe_count=len(selected),
    source_inputs_unchanged=all(digest(ROOT / r["path"]) == r["sha256"] for r in sources))
assert report["source_inputs_unchanged"]
write_json("audit.json", report)
print(json.dumps({k: report[k] for k in ["checks", "total_vehicle_outcomes", "ols_frozen_span_diagnostics"]}, indent=2))
print("ranks", rank_main["rank"], rank_full["rank"], rank_transfer_main["rank"], rank_transfer_full["rank"])
print("top transfers", json.dumps(transfer_rows[:5], indent=2))
