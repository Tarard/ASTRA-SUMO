"""Compare two completed OD probes without starting or changing a simulation."""

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np


HERE = Path(__file__).resolve().parent
CASE = HERE.parent
REPO = HERE.parents[2]
CANONICAL = REPO / "outputs/hamburg-z5-native-feedback-20261023-v1/z15-half-unsplit-full"


def load_json(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def counts(path):
    result = {}
    for _, row in ET.iterparse(path):
        if row.tag != "interval":
            continue
        key = row.get("id"), float(row.get("begin")), float(row.get("end"))
        value = float(row.get("nVehContrib"))
        if key in result or not np.isfinite(value) or value < 0 or not value.is_integer():
            raise ValueError(f"Invalid or repeated native E1 count in {path}: {key}")
        result[key] = int(value)
        row.clear()
    return result


def targets(prepared):
    result = {}
    for name, length in [("expected-counts.csv", 130), ("initialization-counts.csv", 52)]:
        with (prepared / name).open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        if len(rows) != length:
            raise ValueError(f"Expected {length} rows in {prepared / name}")
        for row in rows:
            key = row["detector_id"], float(row["begin"]), float(row["end"])
            if key in result:
                raise ValueError(f"Repeated real target: {key}")
            result[key] = int(row["expected_total"])
    return result


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def safety(native, run):
    collision_rows = len(ET.parse(native / "collisions.xml").getroot().findall("collision"))
    final_step = None
    for _, row in ET.iterparse(native / "summary.xml"):
        if row.tag == "step":
            final_step = dict(row.attrib)
            row.clear()
    if (run["native_status"] != "pass" or not run["observer_complete"]
            or run["stall_monitor"]["status"] != "completed" or final_step is None
            or float(final_step["time"]) < 14399.8):
        raise ValueError(f"The native run is not complete: {native}")
    completion = run["completion"]
    safe = collision_rows == 0 and all(completion[k] == 0 for k in ("collisions", "teleports", "discarded"))
    return dict(safe=safe, healthy=run["healthy"], completion=completion,
                unfinished=completion["waiting"] + completion["running"],
                collision_xml_rows=collision_rows, final_summary=final_step,
                native_status=run["native_status"])


def metrics(values, real_targets, mask):
    residual = values[mask] - real_targets[mask]
    return dict(rows=int(mask.sum()), measured=int(values[mask].sum()), target=int(real_targets[mask].sum()),
                signed_residual=int(residual.sum()), TAE=int(abs(residual).sum()),
                SSE=int(residual @ residual), MAE=float(abs(residual).mean()),
                exact_rows=int(np.count_nonzero(residual == 0)), max_abs_error=int(abs(residual).max()))


def change_metrics(values, mask):
    part = values[mask]
    return dict(rows=int(mask.sum()), changed_rows=int(np.count_nonzero(part)),
                signed_change=float(part.sum()), L1_change=float(abs(part).sum()),
                max_abs_change=float(abs(part).max()) if len(part) else 0.0)


def target_cohort_field_inventory(path):
    return dict(Counter(row["field_id"] for row in load_json(path)["vehicles"] if row["od_cell"] in {125, 146}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-dir", type=Path, default=CASE)
    parser.add_argument("--canonical-dir", type=Path, default=CANONICAL)
    parser.add_argument("--output-dir", type=Path, default=HERE / "probe-comparison")
    args = parser.parse_args()
    paths = {"plus": args.case_dir / "probe-plus6", "minus": args.case_dir / "probe-minus6"}
    missing = [str(path / "verdict.json") for path in paths.values() if not (path / "verdict.json").is_file()]
    if missing:
        raise SystemExit("Both completed verdicts are required. Missing: " + ", ".join(missing))
    source_files = [Path(__file__).resolve(), HERE / "allocation.npz", HERE / "rows-208.csv"]
    baseline_native = args.canonical_dir / "evaluation/native"
    baseline_counts = counts(baseline_native / "field-counts.xml")
    keys = sorted(baseline_counts)
    if len(keys) != 208:
        raise ValueError("The canonical reference must contain all 208 native field intervals.")
    real = targets(args.canonical_dir / "prepared")
    real_array = np.array([real.get(key, 0) for key in keys], dtype=np.int64)
    masks = {
        "main130": np.array([key in real and 3600 <= key[1] < 12600 for key in keys]),
        "initialization52": np.array([key in real and key[1] < 3600 for key in keys]),
        "tail26": np.array([key not in real for key in keys]),
    }
    if [int(m.sum()) for m in masks.values()] != [130, 52, 26]:
        raise ValueError("Keep all 130 main, 52 initialization and 26 tail intervals.")
    masks["all182"] = masks["main130"] | masks["initialization52"]
    masks["all208"] = np.ones(208, dtype=bool)
    vectors = {"canonical": np.array([baseline_counts[key] for key in keys], dtype=np.int64)}
    runs = {"canonical": load_json(baseline_native / "run.json")}
    safe = {"canonical": safety(baseline_native, runs["canonical"])}
    source_files += [baseline_native / name for name in ["field-counts.xml", "run.json", "summary.xml", "collisions.xml", "lane-intentions.json"]]
    source_files += [args.canonical_dir / "prepared" / name for name in ["expected-counts.csv", "initialization-counts.csv"]]
    with np.load(HERE / "allocation.npz") as frozen:
        x0 = frozen["x0"].copy()
        allocation = frozen["A208"].copy()
        if not np.array_equal(frozen["measured208"], vectors["canonical"]):
            raise ValueError("The frozen allocation and canonical native counts differ.")
    with (HERE / "rows-208.csv").open(encoding="utf-8", newline="") as stream:
        row_keys = [(r["field"], float(r["begin_s"]), float(r["end_s"])) for r in csv.DictReader(stream)]
    if row_keys != keys:
        raise ValueError("The frozen allocation row order differs from the native reference.")
    direction = np.zeros(294)
    direction[125], direction[146] = -1, 1
    allocation_direction = allocation @ direction
    support = abs(allocation_direction) > 1e-12
    if support.sum() != 6:
        raise ValueError("The declared frozen direction must support exactly six rows.")
    checks, verdicts = {}, {}
    inventories = {"canonical": target_cohort_field_inventory(baseline_native / "lane-intentions.json")}
    for label, path in paths.items():
        native = path / "evaluation/native"
        verdict = load_json(path / "verdict.json")
        execution = load_json(path / "execution.json")
        if not execution.get("completed") or not execution.get("new_native_run"):
            raise ValueError(f"Completed execution evidence is required: {path}")
        prepared = path / "source/prepared"
        equivalence = load_json(prepared / "initial-equivalence.json")
        equiv_checks = equivalence["checks"]
        if len(equiv_checks) != 12 or not all(value is True for value in equiv_checks.values()):
            raise ValueError(f"All 12 explicit initial-input semantics checks are required: {path}")
        if equivalence["model_sha256"] != sha(prepared / "od-model.json"):
            raise ValueError(f"Initial equivalence is bound to another model: {path}")
        if targets(prepared) != real:
            raise ValueError(f"A real target changed: {path}")
        if sha(path / "source/baseline-field-counts.xml") != sha(baseline_native / "field-counts.xml"):
            raise ValueError(f"The probe uses another baseline native count file: {path}")
        for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml",
                     "expected-counts.csv", "initialization-counts.csv", "scenario.json"]:
            if sha(prepared / name) != sha(args.canonical_dir / "prepared" / name):
                raise ValueError(f"An outside-scope prepared input changed: {path / name}")
        preview = load_json(path / "preview/audit.json")
        if preview["only_two_cells_changed"] != [125, 146] or not preview["non_target_292_cells_identical"]:
            raise ValueError(f"The probe changed additional cells: {path}")
        vector_record = load_json(path / "evaluation/od-vector.json")
        if vector_record["source_model_sha256"] != sha(prepared / "od-model.json"):
            raise ValueError(f"Measured demand is bound to another OD model: {path}")
        vector = np.array(vector_record["integer_counts"])
        sign = 1 if label == "plus" else -1
        if not np.array_equal(vector, x0 + sign * 6 * direction):
            raise ValueError(f"The measured vector is not the declared endpoint: {path}")
        for name in ["demand.rou.xml", "lane-intentions.json", "od-vector.json"]:
            if sha(path / "preview" / name) != sha(path / "evaluation" / name):
                raise ValueError(f"Measured input differs from preview: {path / name}")
        for name in ["demand.rou.xml", "lane-intentions.json"]:
            if sha(native / name) != sha(path / "evaluation" / name):
                raise ValueError(f"Native input differs from measured demand: {native / name}")
        native_counts = counts(native / "field-counts.xml")
        if set(native_counts) != set(keys):
            raise ValueError(f"Native count intervals differ: {path}")
        vectors[label] = np.array([native_counts[key] for key in keys], dtype=np.int64)
        runs[label] = load_json(native / "run.json")
        for name in ["seed", "step_length_s", "end_s", "backend", "junction_body_hold_nodes"]:
            if runs[label][name] != runs["canonical"][name]:
                raise ValueError(f"Native treatment differs ({name}): {path}")
        safe[label] = safety(native, runs[label])
        if verdict["safe"] != safe[label]["safe"] or verdict["completion"] != safe[label]["completion"]:
            raise ValueError(f"Verdict and native safety/completion differ: {path}")
        main = metrics(vectors[label], real_array, masks["main130"])
        if (main["TAE"] != verdict["measurement"]["TAE"] or main["SSE"] != verdict["measurement"]["loss"]
                or metrics(vectors[label], real_array, masks["all182"])["TAE"] != verdict["measurement"]["all182_TAE"]):
            raise ValueError(f"Verdict and native loss differ: {path}")
        init_same = np.array_equal(vectors[label][masks["initialization52"]], vectors["canonical"][masks["initialization52"]])
        if verdict["initialization52_identical_to_baseline"] != init_same:
            raise ValueError(f"Verdict and initialization counts differ: {path}")
        checks[label] = dict(initial_input_semantics_checks=equiv_checks,
            equivalence_means="Explicit initial input correspondence, not a fresh x0 native rerun",
            only_cells_changed=[125, 146], total_requests=int(vector.sum()),
            actual_initialization52_identical_to_canonical=init_same,
            preview_change_categories=preview["change_category_counts"],
            changed_vehicle_union_rows=preview["changed_vehicle_union_rows"])
        inventories[label] = target_cohort_field_inventory(path / "evaluation/lane-intentions.json")
        verdicts[label] = verdict
        source_files += [path / name for name in ["verdict.json", "execution.json", "measure_probe.snapshot.py",
            "preview/audit.json", "preview/demand.rou.xml", "preview/lane-intentions.json", "evaluation/od-vector.json",
            "evaluation/demand.rou.xml", "evaluation/lane-intentions.json", "source/baseline-field-counts.xml"]]
        source_files += [prepared / name for name in ["initial-equivalence.json", "od-model.json", "network.net.xml",
            "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "scenario.json"]]
        source_files += [native / name for name in ["field-counts.xml", "run.json", "summary.xml", "collisions.xml", "native-request.json",
                                                  "demand.rou.xml", "lane-intentions.json"]]
    for name in ["python_sha256", "sumo_sha256", "libsumo_sha256", "implementation_sha256"]:
        if load_json(paths["plus"] / "execution.json")[name] != load_json(paths["minus"] / "execution.json")[name]:
            raise ValueError(f"Endpoint execution snapshots differ: {name}")
    plus_change = vectors["plus"] - vectors["canonical"]
    minus_change = vectors["minus"] - vectors["canonical"]
    endpoint_change = vectors["plus"] - vectors["minus"]
    symmetric = vectors["plus"] + vectors["minus"] - 2 * vectors["canonical"]
    vector_rows = []
    for i, key in enumerate(keys):
        scope = "main130" if masks["main130"][i] else "initialization52" if masks["initialization52"][i] else "tail26"
        row = dict(field=key[0], begin_s=key[1], end_s=key[2], scope=scope,
                   target=int(real_array[i]) if key in real else None, frozen_A_support=bool(support[i]))
        for label, values in vectors.items():
            row[label] = int(values[i])
            row[label + "_residual"] = int(values[i] - real_array[i]) if key in real else None
        row.update(plus_minus_canonical=int(plus_change[i]), minus_minus_canonical=int(minus_change[i]),
            endpoint_plus_minus_minus=int(endpoint_change[i]), plus_secant=float(plus_change[i] / 6),
            minus_secant_in_positive_direction=float(-minus_change[i] / 6),
            centered_secant=float(endpoint_change[i] / 12), symmetric_second_difference=int(symmetric[i]),
            midpoint_offset=float(symmetric[i] / 2), frozen_allocation_direction=float(allocation_direction[i]))
        vector_rows.append(row)
    field_rows = []
    for field in sorted({key[0] for key in keys}):
        field_mask = np.array([key[0] == field for key in keys])
        for scope, mask in masks.items():
            selected = mask & field_mask
            row = dict(field=field, scope=scope, target=int(real_array[selected].sum()) if scope not in {"tail26", "all208"} else None)
            for label, values in vectors.items():
                row[label] = int(values[selected].sum())
                row[label + "_TAE"] = int(abs(values[selected] - real_array[selected]).sum()) if scope not in {"tail26", "all208"} else None
                error = values[selected] - real_array[selected]
                row[label + "_SSE"] = int(error @ error) if scope not in {"tail26", "all208"} else None
            row.update(endpoint_difference=int(endpoint_change[selected].sum()),
                       symmetric_second_difference=int(symmetric[selected].sum()))
            field_rows.append(row)
    outside = {}
    for name, change in [("plus_vs_canonical", plus_change), ("minus_vs_canonical", minus_change),
                         ("plus_vs_minus", endpoint_change), ("symmetric_second_difference", symmetric)]:
        outside[name] = {scope: change_metrics(change, mask & ~support) for scope, mask in masks.items()}
    files = [{"path": str(path.resolve()), "sha256": sha(path)} for path in dict.fromkeys(source_files)]
    result = dict(reference="canonical full 208 native E1 nVehContrib intervals", initial_semantics=checks,
        actual_target_cohort_field_inventory=inventories,
        field_inventory_unchanged=all(value == inventories["canonical"] for value in inventories.values()),
        definitions=dict(direction="one request transferred from cell125 to cell146",
            plus_secant="(y_plus-y0)/6", minus_secant_in_positive_direction="(y0-y_minus)/6",
            centered_secant="(y_plus-y_minus)/12", symmetric_second_difference="y_plus+y_minus-2*y0",
            midpoint_offset="(y_plus+y_minus)/2-y0"),
        metrics={label: {scope: metrics(values, real_array, masks[scope]) for scope in ["main130", "initialization52", "all182"]}
                 for label, values in vectors.items()},
        safety_and_backlog=safe, endpoint_verdict_status={key: value["status"] for key, value in verdicts.items()},
        all_three_safe=all(value["safe"] for value in safe.values()),
        all_three_healthy=all(value["healthy"] for value in safe.values()),
        frozen_A_support=[dict(field=keys[i][0], begin_s=keys[i][1], end_s=keys[i][2]) for i in np.flatnonzero(support)],
        outside_frozen_A_support=outside,
        response_totals={scope: {name: change_metrics(value, mask) for name, value in [
            ("plus_vs_canonical", plus_change), ("minus_vs_canonical", minus_change),
            ("plus_vs_minus", endpoint_change), ("symmetric_second_difference", symmetric)]}
            for scope, mask in masks.items()},
        fixed_allocation_rejected_for_pair=bool(np.any(endpoint_change[~support] != 0)),
        source_hashes=files, source_inputs_unchanged=all(sha(Path(r["path"])) == r["sha256"] for r in files),
        independent_loss="130 field rows only; 52 initialization rows reported separately; 40 derived station sums excluded",
        claim_boundary="Total response of the current joint quantile demand generator with original actuated control. Finite secants are not a general derivative. Outside-support differences reject fixed same-run allocation for this pair but do not isolate control, queuing, lane or vehicle-level causes.",
        goal_complete=all(metrics(vectors[label], real_array, masks["main130"])["TAE"] == 0 for label in ["plus", "minus"]))
    if not result["source_inputs_unchanged"]:
        raise ValueError("An input changed during comparison.")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "native-vectors-208.csv", vector_rows)
    write_csv(args.output_dir / "field-totals.csv", field_rows)
    for scope in ["main130", "initialization52", "tail26"]:
        write_csv(args.output_dir / (scope + "-vectors.csv"), [r for r in vector_rows if r["scope"] == scope])
    write_json(args.output_dir / "comparison.json", result)
    print(json.dumps({key: result[key] for key in ["metrics", "all_three_safe", "fixed_allocation_rejected_for_pair"]}, indent=2))


if __name__ == "__main__":
    main()
