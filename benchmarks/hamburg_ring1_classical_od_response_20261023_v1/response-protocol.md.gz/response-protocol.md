# 当前OD模型的最小原生响应核验

日期：2026-10-23。状态：`diagnostic-demo`，仅方法方案。本次未改代码、未生成需求、未启动仿真。原生预算为2次，必要时扩至4次，基线重测也计入预算。

## 固定源与现有实现

源为 `outputs/hamburg-z5-native-feedback-20261023-v1/z15-half-unsplit-full`。保留294个OD出发区间变量、130项真实主观测和52项真实初始化观测。保留当前40个感应、11个静态控制，不换冻结历史，不改车道、路线权限或驾驶规则。固定 `seed=104`、`step=0.1s`、`end=14400s`、`backend=libsumo`，并保留scenario声明的4处junction-body hold，含 `LSA104_part0`。

| 源输入 | SHA-256 |
| --- | --- |
| 道路 | `b6acb7f542abf62b3c3f3fc67db6bad39a71a783cdc61fc71109928aad52df18` |
| 显式需求 | `901c051aec8e3cfc7af068e40fb29345e88ca22c595b9fc82f12fe64cc6c56be` |
| 原控制 | `cc7b9b5f60a93ee6e5bc77352532806746607c371707197344c85bce21e0b39d` |

本次从源 `field-comparison.csv` 重算：主130项SSE=10749、TAE=775、MAE=5.961538、最大绝对误差32。源waiting=68、running=50，碰撞/传送/discard均为0，`healthy=false`。它是当前有效诊断源，尚非正式零误差标定。

`summarize_hamburg_od_measurement` 使用全130项原生 `nVehContrib` 的SSE作为 `loss`，另报MAE和最大误差。40项站点汇总为派生量。该函数没有计算52项初始化损失，不能把其 `evaluation.json` 称为182项评价。

`calibrate_spsa` 的两侧伯努利扰动和递减增益已有定义。但一次随机方向并未测得294项独立响应。现有 `initial_step` 控制首个未裁剪更新的各分量幅度，`c` 也不保证取整后出现有用变化。当前核验直接测少量OD方向，不调用全维SPSA，也不增加预设轮数。默认CLI和SPSA外层会选择 `traci`，本次应直接调用支持显式 `backend` 的 `measure_hamburg_od`。

## 先做不占原生次数的生成核对

新模型必须从当前显式需求建立。用初值x0生成一次候选，逐车核对ID、输入顺序、所有行为属性、路线、车道意图、停靠及实际离散请求时刻。按SUMO毫秒转换核对时刻，并核对0.1秒步长下的请求可用时步。不能仅比较总数或端点。初值应保留8640辆、21个OD对和14个请求区间，各源需求与先验模板可追溯。

只有初值的运行语义与源一致，且二进制、驾驶实现和运行约定也一致，才能把既有源作为x0响应。格式差异可说明，车辆身份或运行设定变化不可忽略。若不一致，先用第1次原生测量建立生成器基线G(x0)，将其与canonical差异单独保存。之后的差分统一相对于G(x0)，剩余预算不超过3次。不得把这个差异写成OD探针收益。

当前生成器按 `floor(x+0.5)` 取整，并依整数数量重新选择经验分位数。每个探针须另存：294项实数和整数向量、请求总数、生成需求SHA、每车所选源模板序号、变化的请求时刻及路线/意图直方图。同ID也可能被重新赋予不同模板，不能把全部变化说成仅增减q辆。未改数量的292项应保持生成内容不变。

## 2—4次测量的有界安排

选择同一OD的相邻请求区间，定义d=e_target−e_source。在x0上预先选定方向后，测量x+=x0+qd及x−=x0−qd。两个区间库存均须不小于q，总请求数保持8640，非目标292项不变。初始化区间也可估计，不另设固定规则。

方向可由当前分配表提出，但只用于安排测量。优先考虑有完整车辆分配、库存充分且关联主要残差的OD。可核对的起点是最大OD `44532531→19728446#0`，共1124辆，主要意图为119 Z12/Z13。另一候选为 `963776077#0→199500676`，共1067辆，主要意图为119 Z4/Z5。相邻请求区间必须依当前分配事实选择，不把测量区间当成请求区间，也不将缺失通过填成零。

q=2可以作为首个工程探针，理由是整数生成能明确改变区间数量，而非文献规定或已知有效步长。保存该选择。先离线确认两侧均有实际需求变化、合法模板和非负库存。若这些条件不满足，停止并调整探针定义，不能靠截断库存制造不对称方向。

| 新增原生次数 | 要测的向量 | 用途和停止条件 |
| --- | --- | --- |
| 1、2，初值可复用时 | x0+qd、x0−qd | 得到完整实际响应。若一侧改善，可直接保留该已测端点作为需求候选。若预算仅2次，到此停止。 |
| 3、4，可选 | 同方向、另一预先记录整数幅度的正负端点 | 若q=2两侧都变差，可测q=1的正负端点，检查较小变化。若主计数两侧均完全无响应，可在库存允许时测q=4的正负端点，检查幅度。不能由平移或局部直线推断结果。 |
| 初值需要原生重测时 | 第1次G(x0)，第2、3次正负端点 | 第4次最多核验一个已选的较小幅度端点。没有另一侧测量就不报告该幅度的中心差分。 |

每次结果完整后再决定后续测量。出现碰撞、传送、discard、缺测或运行未完成，就保留原始结果并停止该方向的后续更新。若有效结果没有降低全130实际误差，保留原源。不得为了凑足次数增加新方向或轮数。

## 测量、更新与验收

每个完整响应记录F0、F+、F−的130项整数向量。可计算方向割线 `s_d(q)=(F+−F−)/(2q)` 和对称变化 `F++F−−2F0`，用于检查非线性。它们是该生成规则和原控制下有限幅度的实际响应，不自动等于连续Jacobian。

本轮保守更新规则为：仅从已完整测量、无异常移除的端点中选择全130 SSE严格下降且MAE不增加的候选。SSE和MAE冲突时保留为 `review_required`，不悄悄改变目标。新的搜索中心可以采用已测候选，不按割线直接外推未测的294项联合更新。这个筛选规则是本轮工程选择，不是经典算法定理。

对每次测量，用 `audit_expected_to_e1_strict(..., count_attribute="nVehContrib")` 分别核对130项主CSV和52项初始化CSV。输入为该次原生 `field-counts.xml`。保存全部182项残差、SSE、TAE和最大误差，初始化退步要显式报告。缺测保留未知状态，并使本次测量无效。初始化观测不固定，观测值也不改。分配表的A*x分值不能接受或拒绝一个正式标定结果。

同时报告loaded、inserted、arrived、waiting、running、碰撞、传送、discard和健康状态。源有未完成车辆，因此改善端点仍可能只是诊断候选。正式验收仍须完整130项MAE=0、最大误差=0，并满足运行有效性检查，不能用SSE较小替代归零。

## 怎样区分三种作用

1. **车辆生成作用**：在运行前核对取整和分位数映射。若两项数量调整引起大量同ID时刻或模板变化，就把这些变化记为生成器的共同处理。它们可以属于声明的OD模型，但不能当成纯粹增减q辆的物理效应。
2. **OD方向的整体响应**：以同一生成器、道路、驾驶和控制下的F+−F0、F−−F0为实测依据。保留未插入及未完整通过车辆的状态。它估计的是完整模型对OD方向的响应，含排队和感应控制反馈。
3. **控制内生变化**：如沿用已经核验的原生 `SaveTLSSwitchStates` 只读记录方式，比较51处完整state(t)及首次分歧时间。状态不同时，记录控制响应确有变化。仅有summary差异时，归因保持未知，不能称某相位造成了损失差。

当前 `measure_hamburg_od` 不导出完整TLS状态，现有 `record_tls.py` 又硬编码旧案例，不能直接声称这组调用已经具备TLS对账。若未扩展记录范围，本轮只识别原控制下的总响应。冻结同一信号历史的额外配对测量，才有助于估计控制反馈影响，而且会占用原生预算并改变条件映射。本轮2—4次不能同时保证分离生成、排队和控制的全部因果贡献，不做这种承诺。

## 已有函数的单次执行方式

下面是交给主任务的调用形式，本次没有执行。`$prepared` 指向已经通过初值核对的新模型目录，`$vector` 指向含294项 `values` 的该次向量JSON，`$out` 必须是新的测量目录。运行前由主任务绑定三者的实际路径和哈希。

```powershell
$repo = 'C:\Users\Danial\.codex\worktrees\hamburg-reproduction\Torii'
$env:PYTHONPATH = Join-Path $repo 'plugins\astra-sumo\src'
@'
import json, sys
from pathlib import Path
from importlib.metadata import version
from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od
repo = Path(r'C:\Users\Danial\.codex\worktrees\hamburg-reproduction\Torii')
assert Path(sys.executable).resolve() == (repo/'.venv/Scripts/python.exe').resolve()
assert {version(n) for n in ('eclipse-sumo','sumolib','traci')} == {'1.27.1'}
prepared, vector, out = map(Path, sys.argv[1:])
values = json.loads(vector.read_bytes())['values']
assert len(values) == 294
result = measure_hamburg_od(prepared_dir=prepared, values=values, output_dir=out,
    sumo_binary=repo/'.venv/Lib/site-packages/sumo/bin/sumo.exe', backend='libsumo')
print(json.dumps(result, ensure_ascii=False, indent=2))
'@ | & (Join-Path $repo '.venv\Scripts\python.exe') - $prepared $vector $out
```

执行证据还须冻结本次函数及驾驶实现、二进制、模型、向量和全部原始输出的哈希。上例只负责测量，不自动完成来源绑定、182项对账或控制归因。
