# Cumulative request supply and native service

The first119 Z4/Z5 cumulative deficits occur at1800s. Both runs requested and inserted enough vehicles. Z4 has80 requested and inserted but73 complete E1 passages. Z5 has48 requested and inserted but45 passages. All ten missing vehicles later pass at1877–1886.7s. Their900s boundary-independent vehicle histories place them after the `24483344#0` exit and before the `24483344#1` exit at1800s.

The main-window problem is broader than one adjacent departure bin. In one-share,361/760 Z4 and226/624 Z5 requests take more than900s to complete E1 passage. Their90th-percentile lags are1752s and1222s. At12600s, Z4 has115 remaining passages:4 vehicles not yet inserted,97 not yet past `24483344#0`, and14 past that road but not the detector. The corresponding Z5 split is72=4+58+10. This accounting does not identify lane positions within an ordinary/internal transition.

The251 long535 Z4 requests share upstream roads with119 traffic, but shared roads do not establish the same lane or a blocking leader. Their `234423652#1` interval median is23.2s, compared with199.9s for119 Z4 and76.4s for Z5. The present output does not establish that this cohort causes the main queue. Previous substitution trials included long-origin vehicles. A future trial would need to state its changed network/control conditions.

The first900s window gives a smaller test. Z11 has8 requested and inserted versus7 passages. Z12 has87 versus79. Z13 has130 versus117. All22 missing vehicles pass at908.0–926.3s. The recorded healthy119 colors show Z12/Z13 green at816–845s and906–935s. Z11 has permissive green at833–845s and923–935s. This is a one-cycle timing distinction.

`late-first900.csv` lists those22 IDs, their original requests, actual insertion, E1 times, and ordinary-edge exit brackets. Advancing only those requests90s would keep them in the same first departure bin. Unchanged old lags predict22 passages one cycle earlier. That prediction is not a native response. An actual900s prefix test must retain all future demand and all13 true target rows, then check safety and every observed row.

Initialization timings, OD totals, field shares, and8640 requests are inherited model or search restrictions. They are not final user constraints. Freezing earlier accepted observations can support a causal prefix study. Lags beyond900s require explicit carry-over accounting. They do not prove global infeasibility or validate a local retiming prediction.

Successive ordinary-edge exit differences include incoming internal traversal or waiting. They are not same-lane queue measurements. Queue records contain no vehicle identity. An unlisted receiving lane does not prove that it is empty. Longer legal routes remain possible under congestion, but this audit supplies no new route-choice evidence or route candidate.

No input, core code, or native run changed. `summary.json` binds the read evidence. `manifest.json` covers this diagnostic only.
