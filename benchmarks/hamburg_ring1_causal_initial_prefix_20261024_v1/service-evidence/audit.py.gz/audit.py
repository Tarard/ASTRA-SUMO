"""Read cumulative supply, native service, and the first initialization deficits."""

from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.detector_demand import e1_counts_by_detector_interval_strict


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
CASES = {"healthy": REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority",
         "one-share": REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"}
Z4, Z5 = "hh_0119_Z_4_29437", "hh_0119_Z_5_30494"
FIRST = ("hh_0119_Z_11_28853", "hh_0119_Z_12_31546", "hh_0119_Z_13_34018")
COMMON = ("234423652#1", "538341584", "51214742#1", "37693933#0", "37693933#1")
SOURCES = {}


def read(path):
    raw = path.read_bytes()
    SOURCES[str(path)] = hashlib.sha256(raw).hexdigest()
    return gzip.decompress(raw) if path.suffix == ".gz" else raw


def csv_rows(path):
    return list(csv.DictReader(read(path).decode("utf-8-sig").splitlines()))


def write_csv(name, rows):
    with (OUT / name).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def describe(values):
    return {"N": len(values), "total_s": sum(values),
            "median_s": float(np.median(values)), "p90_s": float(np.quantile(values, .9)), "max_s": max(values)}


def main():
    cumulative, first_late, case_results, cohort_rows, queue_samples = [], [], {}, [], []
    for label, base in CASES.items():
        prep, native = base / "prepared", base / "evaluation/native"
        requests = {v.get("id"): v for v in ET.fromstring(read(prep / "demand.rou.xml")).findall("vehicle")}
        intent = {r["vehicle_id"]: r for r in json.loads(read(prep / "lane-intentions.json"))["vehicles"]}
        histories = {v.get("id"): v for v in ET.fromstring(read(native / "vehicle-routes.xml")).findall("vehicle")}
        compact = json.loads(read(base / "evaluation/contributing-passages.json.gz"))
        assert compact["reconciled"]
        observed = Counter((r["detector_id"], r["interval_begin_s"], r["interval_end_s"]) for r in compact["passages"])
        periodic = e1_counts_by_detector_interval_strict(native / "field-counts.xml", count_attribute="nVehContrib")
        read(native / "field-counts.xml")
        assert all(observed[(field, float(begin), float(end))] == n for (field, begin, end), n in periodic.items())
        events = {(r["vehicle_id"], r["detector_id"]): r for r in compact["passages"]}
        targets = csv_rows(prep / "initialization-counts.csv") + csv_rows(prep / "expected-counts.csv")
        route_times = {}
        segment_times = {}
        for identity, vehicle in histories.items():
            route = vehicle.find("route")
            edges = route.get("edges").split()
            times = list(map(float, route.get("exitTimes").split()))
            route_times[identity] = dict(zip(edges, times))
            previous = [float(vehicle.get("depart"))] + times[:-1]
            segment_times[identity] = dict(zip(edges, (end - begin for begin, end in zip(previous, times))))
        info = {}
        for field in (Z4, Z5):
            ids = [identity for identity, row in intent.items() if row["field_id"] == field]
            assert all((identity, field) in events for identity in ids)
            lags = [events[i, field]["notification_time_s"] - float(requests[i].get("depart")) for i in ids]
            tail = [i for i in ids if events[i, field]["notification_time_s"] >= 12600]
            info[field] = {"requests": len(ids), "all_passed_by14400": True, "lag": describe(lags),
                           "lag_over900_count": sum(v > 900 for v in lags), "lag_over1800_count": sum(v > 1800 for v in lags),
                           "tail_after12600": len(tail), "tail_origin_counts": dict(Counter(requests[i].find("route").get("edges").split()[0] for i in tail)),
                           "tail_not_rescued_by_minus900_under_fixed_old_lag": sum(events[i, field]["notification_time_s"] >= 13500 for i in tail)}
            for cutoff in range(900, 14401, 900):
                target = sum(int(r["expected_total"]) for r in targets if r["detector_id"] == field and float(r["end"]) <= cutoff)
                eligible = [i for i in ids if float(requests[i].get("depart")) < cutoff]
                stock = Counter()
                for identity in eligible:
                    if events[identity, field]["notification_time_s"] < cutoff:
                        stock["passed"] += 1
                    elif float(histories[identity].get("depart")) >= cutoff:
                        stock["not_inserted"] += 1
                    elif route_times[identity].get("24483344#0", float("inf")) < cutoff:
                        stock["after244_0_before_E1"] += 1
                    else:
                        stock["before244_0_exit"] += 1
                cumulative.append({"case": label, "field": field, "cutoff_s": cutoff,
                    "real_target_cumulative_through12600": target, "requested": len(eligible),
                    "inserted": len(eligible) - stock["not_inserted"], "passed": stock["passed"],
                    "not_inserted": stock["not_inserted"], "after244_0_before_E1": stock["after244_0_before_E1"],
                    "before244_0_exit": stock["before244_0_exit"], "tail_interval_unscored": cutoff > 12600})
        case_results[label] = info
        if label != "one-share":
            continue
        first_counts = []
        for field in FIRST:
            ids = [i for i, r in intent.items() if r["field_id"] == field and float(requests[i].get("depart")) < 900]
            passed = sum(events[i, field]["notification_time_s"] < 900 for i in ids)
            expected = next(int(r["expected_total"]) for r in targets if r["detector_id"] == field and float(r["begin"]) == 0)
            first_counts.append({"field": field, "target": expected, "requested": len(ids),
                                 "inserted": sum(float(histories[i].get("depart")) < 900 for i in ids), "E1": passed})
            for identity in ids:
                time = events[identity, field]["notification_time_s"]
                if time < 900:
                    continue
                request = float(requests[identity].get("depart"))
                actual = float(histories[identity].get("depart"))
                pairs = list(route_times[identity].items())
                index = next(j for j, (_, exit_time) in enumerate(pairs) if exit_time >= 900)
                first_late.append({"vehicle_id": identity, "field_id": field, "requested_depart_s": request,
                    "actual_insert_s": actual, "insertion_delay_s": actual - request, "actual_E1_notification_s": time,
                    "request_to_E1_lag_s": time - request,
                    "previous_ordinary_edge": pairs[index - 1][0] if index else "depart",
                    "previous_exit_s": pairs[index - 1][1] if index else actual,
                    "next_ordinary_edge": pairs[index][0], "next_exit_s": pairs[index][1],
                    "hypothetical_depart_minus90_s": request - 90,
                    "fixed_old_lag_only_hypothetical_E1_minus90_s": time - 90})
        case_results["first900"] = first_counts
        long = [i for i, r in intent.items() if r["field_id"] == "hh_0535_Z_4_33055"
                and requests[i].find("route").get("edges").split()[0] == "-983227468#1"]
        assert len(long) == 251
        for group, ids in [("long535Z4", long)] + [(field, [i for i, r in intent.items() if r["field_id"] == field]) for field in (Z4, Z5)]:
            for edge in COMMON:
                values = [segment_times[i][edge] for i in ids if edge in segment_times[i]]
                cohort_rows.append({"group": group, "edge": edge, **describe(values)})
        queue_file = native / "queues.xml"
        read(queue_file)
        watched = {"24483344#1_0", "24483344#1_1", "79014037#1_0", "79014037#1_1"}
        for _, element in ET.iterparse(queue_file, events=["end"]):
            if element.tag != "data":
                continue
            time = float(element.get("timestep"))
            if time in (1605, 1607, 1609, 1611, 1613, 1615, 1617, 1619, 1695, 1700, 1705, 1709, 1785, 1790, 1795, 1799):
                queue_samples.append({"time_s": time, "listed_lanes": [dict(r.attrib) for r in element.findall("lanes/lane") if r.get("id") in watched]})
            element.clear()
            if time >= 1800:
                break
    tls_path = REPO / "outputs/hamburg-healthy-z4-control-response-20261023-v1/reference/tls-switch-states.xml"
    tls = ET.fromstring(read(tls_path))
    tls_events = [dict(r.attrib) for r in tls if r.get("id") == "LSA119_part0" and 800 <= float(r.get("time")) <= 940]
    assert any(float(r["time"]) == 816 and r["state"][:2] == "GG" for r in tls_events)
    assert len(first_late) == 22
    write_csv("cumulative-119.csv", cumulative)
    write_csv("late-first900.csv", first_late)
    write_csv("shared-road-timing.csv", cohort_rows)
    (OUT / "summary.json").write_text(json.dumps({"status": "review_required", "native_runs": 0,
        "cases": case_results, "first900_healthy_actual_TLS_events": tls_events,
        "one_share_queue_examples": queue_samples, "source_hashes": SOURCES,
        "segment_time_definition": "Difference between successive ordinary-edge front exitTimes. Includes incoming internal traversal or waiting. This is not a measured same-lane queue residence.",
        "queue_boundary": "Queue samples contain no vehicle identity. An unlisted lane does not establish empty receiving space.",
        "recommendation": "One bounded first900 prefix test may advance only these22 actually late initialization requests by90s, with unchanged complete future demand, original controls/routes/driver and all13 real rows. Frozen old lags predict one earlier90s service cycle only; actual counts must be measured. No candidate is prepared here.",
        "claim_boundary": "Initialization timings, field shares, OD totals and N8640 are model/search priors, not final user constraints. Lags above900s prevent treating adjacent-bin effects as independent. No global infeasibility, causal blame for251 shared-road requests, route-choice illegality, C/q proposal or native improvement is inferred."}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "pass", "first900": case_results["first900"], "late_IDs": len(first_late)}))


if __name__ == "__main__":
    main()
