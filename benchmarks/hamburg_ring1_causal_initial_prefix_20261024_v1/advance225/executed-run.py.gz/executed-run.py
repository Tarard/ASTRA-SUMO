"""Measure only a900s prefix, retaining all future demand and full observations."""

import argparse
from collections import Counter
from copy import deepcopy
import gzip
import io
from importlib.metadata import version
import json
import math
from pathlib import Path
import shutil
import sys
import traceback
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
SOURCE=REPO/"outputs/hamburg-z5-single-share-20261024-v1/one-share"
NAMES=("network.net.xml","control.add.xml","demand.rou.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv","lane-intentions.json","scenario.json")
END=900


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def vehicles(folder):
    root=ET.parse(folder/"demand.rou.xml").getroot()
    rows={v.get("id"):v for v in root.findall("vehicle")}
    assert len(rows)==len(root.findall("vehicle"))==8640
    return root,rows


def native_ms(value):
    return math.floor(float(value)*1000+.5)


def check(case,require_reference=False):
    proof=json.loads((case/"scope-proof.json").read_bytes())
    assert proof["status"]=="pass" and proof["N"]==8640
    assert all(sha(Path(p))==h for p,h in proof["source_hashes"].items())
    assert set(proof["prepared_hashes"])==set(NAMES)
    assert all(sha(case/"prepared"/n)==h for n,h in proof["prepared_hashes"].items())
    initial=read_csv_rows(SOURCE/"prepared/initialization-counts.csv")
    prefix=read_csv_rows(ROOT/"prefix13.csv")
    assert len(initial)==52 and prefix==[r for r in initial if float(r["begin"])==0 and float(r["end"])==END]
    assert len(prefix)==len({r["detector_id"] for r in prefix})==13
    assert len(read_csv_rows(case/"prepared/expected-counts.csv"))==130
    for name in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
        assert (case/"prepared"/name).read_bytes()==(SOURCE/"prepared"/name).read_bytes()
    scenes=[json.loads((folder/"prepared/scenario.json").read_bytes()) for folder in [SOURCE,case]]
    changed_scene={k for k in scenes[0].keys()|scenes[1].keys() if scenes[0].get(k)!=scenes[1].get(k)}
    assert changed_scene<={"status","demand_sha256","demand_prior","time_prior","claim_boundary"}
    if changed_scene:
        assert case.name in {"advance22","advance225"} and scenes[1]["demand_sha256"]==sha(case/"prepared/demand.rou.xml")
    old_root,old=vehicles(SOURCE/"prepared")
    new_root,new=vehicles(case/"prepared")
    assert old.keys()==new.keys()
    assert [ET.tostring(r) for r in old_root if r.tag!="vehicle"]==[ET.tostring(r) for r in new_root if r.tag!="vehicle"]
    moves=json.loads((case/"departure-proposals.json").read_bytes())
    selected={r["vehicle_id"]:r for r in moves}
    assert len(selected)==len(moves)
    metadata=[json.loads((folder/"prepared/lane-intentions.json").read_bytes()) for folder in [SOURCE,case]]
    intentions=[{r["vehicle_id"]:r for r in m["vehicles"]} for m in metadata]
    for identity,row in new.items():
        restored=deepcopy(row)
        restored.set("depart",old[identity].get("depart"))
        assert ET.tostring(restored)==ET.tostring(old[identity])
        if identity in selected:
            move=selected[identity]
            a,b=float(old[identity].get("depart")),float(row.get("depart"))
            assert abs(a-move["source_depart_s"])<1e-8 and abs(b-move["proposed_depart_s"])<1e-8
            assert 0<=native_ms(a)<900000 and 0<=native_ms(b)<900000 and native_ms(a)!=native_ms(b)
            assert abs((b-a)+90)<1e-8
            restored_intent=dict(intentions[1][identity])
            assert abs(restored_intent.pop("depart_s")-b)<1e-8
            assert restored_intent==intentions[0][identity]
        else:
            assert ET.tostring(row)==ET.tostring(old[identity]) and intentions[0][identity]==intentions[1][identity]
    assert [i for i in old if i not in selected]==[i for i in new if i not in selected]
    assert {k:v for k,v in metadata[0].items() if k!="vehicles"}=={k:v for k,v in metadata[1].items() if k!="vehicles"}
    if case.name=="reference":
        assert not moves and all((case/"prepared"/n).read_bytes()==(SOURCE/"prepared"/n).read_bytes() for n in NAMES)
    else:
        assert case.name in {"advance22","advance225"} and len(moves)=={"advance22":22,"advance225":225}[case.name]
        if case.name=="advance225":
            groups={"hh_0119_Z_11_28853":8,"hh_0119_Z_12_31546":87,"hh_0119_Z_13_34018":130}
            assert Counter(intentions[0][i]["field_id"] for i in selected)==groups
            assert set(selected)=={i for i,row in old.items() if intentions[0][i]["field_id"] in groups and 0<=native_ms(row.get("depart"))<900000}
        if require_reference:
            reference=json.loads((ROOT/"reference/record-result.json").read_bytes())
            assert reference["status"]=="pass" and len(reference["reference_parity"])==7 and all(reference["reference_parity"].values())
            assert reference["preflight_sha256"]==sha(ROOT/"reference/preflight.json")
            assert all(sha(Path(p))==h for p,h in reference["native_output_hashes"].items())
    driver=proof["original_driver_scope"]
    assert driver["backend"]=="libsumo" and driver["end_s"]==14400 and driver["junction_body_hold"]
    assert float(driver["step_length_s"])==.1 and int(driver["seed"])==104 and int(driver["precision"])==12
    assert driver["all_stopped_timeout_s"]==300 and tuple(driver["junction_body_hold_nodes"])==_body_hold_nodes(case/"prepared")
    return proof


def interval_rows(path):
    rows={}
    for _,row in ET.iterparse(path,events=("end",)):
        if row.tag=="interval" and float(row.get("begin"))==0 and float(row.get("end"))==END:
            key=row.get("id"),float(row.get("begin")),float(row.get("end"))
            assert key not in rows
            rows[key]=dict(row.attrib)
        row.clear()
    return rows


def summaries(path):
    rows=[]
    for _,row in ET.iterparse(path,events=("end",)):
        if row.tag=="step" and float(row.get("time"))<END:
            rows.append({k:v for k,v in row.attrib.items() if k!="duration"})
        row.clear()
    return rows


def arrived_routes(path):
    rows={}
    for _,row in ET.iterparse(path,events=("end",)):
        if row.tag=="vehicle":
            if 0<=float(row.get("arrival"))<END:
                assert row.get("id") not in rows
                rows[row.get("id")]=ET.canonicalize(ET.tostring(row,encoding="unicode"),strip_text=True)
            row.clear()
    return rows


def sorted_events(rows):
    return sorted(rows,key=lambda r:(r["notification_time_s"],r["detector_id"],r["vehicle_id"],r["time_s"]))


def selfcheck():
    assert len(interval_rows(SOURCE/"evaluation/native/field-counts.xml"))==13
    rows=summaries(SOURCE/"evaluation/native/summary.xml")
    assert len(rows)==9000 and float(rows[-1]["time"])==899.9 and all("duration" not in r for r in rows)
    fixture=io.StringIO('<routes><vehicle id="unfinished" arrival="-1"/><vehicle id="end" arrival="900"/><vehicle id="ok" arrival="899.9"/></routes>')
    assert set(arrived_routes(fixture))=={"ok"}
    with gzip.open(SOURCE/"evaluation/contributing-passages.json.gz","rt",encoding="utf-8") as handle:
        passages=json.load(handle)["passages"]
    expected_keys={"detector_id","vehicle_id","time_s","notification_time_s","occupancy_s","interval_begin_s","interval_end_s"}
    assert all(set(r)==expected_keys for r in passages)
    monitor=json.loads((SOURCE/"evaluation/native/stall-monitor.json").read_bytes())
    assert monitor["native_version"]==[22,"SUMO 1.27.1"] and monitor["library_completed"] and monitor["native_returncode"] is None
    source_trips=ET.parse(SOURCE/"evaluation/native/tripinfo.xml").getroot().findall("tripinfo")
    return dict(status="pass",native_runs=0,source_summary_rows=9000,source_interval_rows=13,unfinished_and_end_arrivals_excluded=True,
        source_complete_notifications_equal900=sum(abs(r["notification_time_s"]-END)<1e-8 for r in passages),source_arrivals_equal900=sum(float(r.get("arrival"))==END for r in source_trips),source_native_version=monitor["native_version"])


def run(case):
    proof=check(case,require_reference=True)
    native=case/"native"
    assert not native.exists() and not (case/"record-result.json").exists(),"Preserve previous native evidence."
    assert Path(sys.executable).resolve()==(REPO/".venv/Scripts/python.exe").resolve()
    versions={n:version(n) for n in ["eclipse-sumo","libsumo","traci","sumolib"]}
    assert set(versions.values())=={"1.27.1"}
    implementation=case/"implementation"
    assert not implementation.exists()
    implementation.mkdir()
    core=REPO/"plugins/astra-sumo/src/astra_sumo/core"
    for frozen in (SOURCE/"implementation").glob("*.py"):
        assert (core/frozen.name).read_bytes()==frozen.read_bytes()
        shutil.copyfile(frozen,implementation/frozen.name)
    binaries=[REPO/".venv/Scripts/python.exe",REPO/".venv/Lib/site-packages/sumo/bin/sumo.exe"]+list((REPO/".venv/Lib/site-packages/libsumo").glob("*.pyd"))
    assert len(binaries)>=3
    shutil.copyfile(__file__,case/"executed-run.py")
    source_files=[SOURCE/"evaluation/native"/n for n in ["field-counts.xml","summary.xml","vehicle-routes.xml","tripinfo.xml","stall-monitor.json"]]+[SOURCE/"evaluation/contributing-passages.json.gz"]
    save(case/"preflight.json",dict(source_hashes={str(p):sha(p) for p in source_files},scope_sha256=sha(case/"scope-proof.json"),prefix13_sha256=sha(ROOT/"prefix13.csv"),
        prepared_hashes=proof["prepared_hashes"],implementation_sha256={p.name:sha(p) for p in implementation.iterdir()},binaries={str(p):sha(p) for p in binaries},versions=versions,runner_sha256=sha(case/"executed-run.py"),
        requested_vehicles=8640,authorized_prefix_end_s=END,full_observations_retained=182,native_started=False))
    try:
        core_result=run_point_detector_demand(net_file=case/"prepared/network.net.xml",route_file=case/"prepared/demand.rou.xml",e1_additional_file=case/"prepared/field-loops.add.xml",
            expected_counts_csv=ROOT/"prefix13.csv",output_dir=native,end_s=END,step_length=.1,seed=104,backend="libsumo",sumo_binary=str(binaries[1]),timeout_seconds=4800,
            signal_program_file=case/"prepared/control.add.xml",lane_intentions_file=case/"prepared/lane-intentions.json",junction_body_hold=True,junction_body_hold_nodes=_body_hold_nodes(case/"prepared"))
        save(case/"core-result.json",core_result)
        monitor=json.loads((native/"stall-monitor.json").read_bytes())
        command=json.loads((native/"command.json").read_bytes())
        summary=summaries(native/"summary.xml")
        final=summary[-1]
        trips=ET.parse(native/"tripinfo.xml").getroot().findall("tripinfo")
        arrived=[r for r in trips if float(r.get("arrival"))>=0]
        vapor_ok=all((not r.get("vaporized","") if float(r.get("arrival"))>=0 else r.get("vaporized","") in {"","end"}) for r in trips)
        collisions=ET.parse(native/"collisions.xml").getroot().findall("collision")
        events=read_contributing_e1_passages(instant_file=native/"instant-e1.xml",periodic_file=native/"field-counts.xml",detector_ids=core_result["instant_to_periodic_ids"],step_length=.1)
        complete=events["passages"]+events["outside_periodic_intervals"]
        assignments={r["vehicle_id"]:r["field_id"] for r in json.loads((case/"prepared/lane-intentions.json").read_bytes())["vehicles"]}
        unknown=[r for r in complete if r["vehicle_id"] not in assignments]
        repeated=[dict(vehicle_id=i,detector_id=f,count=n) for (i,f),n in Counter((r["vehicle_id"],r["detector_id"]) for r in complete).items() if n>1]
        outside=[r for r in complete if r["vehicle_id"] in assignments and r["detector_id"]!=assignments[r["vehicle_id"]]]
        (case/"contributing-passages.json.gz").write_bytes(gzip.compress(json.dumps(events).encode(),mtime=0))
        comparisons=audit_expected_to_e1_strict(read_csv_rows(ROOT/"prefix13.csv"),native/"field-counts.xml")
        errors=[int(r["diff_nVehContrib_minus_expected"]) for r in comparisons]
        prefix_stats=dict(rows=13,TAE=sum(abs(v) for v in errors),SSE=sum(v*v for v in errors),MAE=sum(abs(v) for v in errors)/13,max_abs_error=max(abs(v) for v in errors))
        checks=dict(core_errors_empty=not core_result["errors"],core_input_hashes_unchanged=core_result["inputs_unchanged"],
            subprocess_pass=command["status"]=="pass" and command["returncode"]==0 and core_result["native_status"]=="pass" and core_result["native_returncode"]==0,
            library_completed=monitor["status"]=="completed" and monitor["library_completed"] and monitor["native_returncode"] is None,
            exact_prefix_horizon=monitor["simulation_time_s"]==END and len(summary)==9000 and float(final["time"])==899.9,
            native_version_and_library=monitor["native_version"]==[22,"SUMO 1.27.1"] and sha(Path(monitor["native_library"]["path"]))==monitor["native_library"]["sha256"],
            all13_real_measurements=len(comparisons)==13 and len(interval_rows(native/"field-counts.xml"))==13 and core_result["observer_complete"] and core_result["missing_field_bins"]==0,
            full_contribution_reconciliation=events["reconciled"],outside_complete_events_only_boundary=all(abs(r["notification_time_s"]-END)<1e-8 for r in events["outside_periodic_intervals"]),
            trip_records_unique=len({r.get("id") for r in trips})==len(trips),trip_records_match_inserted=len(trips)==int(final["inserted"]),
            trip_IDs_known=all(r.get("id") in assignments for r in trips),trip_departures_within_prefix=all(0<=float(r.get("depart"))<=END for r in trips),trip_vaporization_valid=vapor_ok,
            complete_vehicle_IDs_known=not unknown,no_repeated_vehicle_fields=not repeated,no_outside_primary_intention=not outside,
            prefix_safe=not collisions and not any(int(final[k]) for k in ["collisions","teleports","discarded"]))
        with gzip.open(SOURCE/"evaluation/contributing-passages.json.gz","rt",encoding="utf-8") as handle:
            source_events=json.load(handle)["passages"]
        source_trips=ET.parse(SOURCE/"evaluation/native/tripinfo.xml").getroot().findall("tripinfo")
        boundary=dict(source_complete_notifications_equal900=[r for r in source_events if abs(r["notification_time_s"]-END)<1e-8],
            source_arrivals_equal900=[dict(r.attrib) for r in source_trips if float(r.get("arrival"))==END],
            prefix_outside_periodic_intervals=events["outside_periodic_intervals"])
        parity={}
        if case.name=="reference":
            source_monitor=json.loads((SOURCE/"evaluation/native/stall-monitor.json").read_bytes())
            parity=dict(E1_all13_attributes=interval_rows(native/"field-counts.xml")==interval_rows(SOURCE/"evaluation/native/field-counts.xml"),
                summary_all9000_except_duration=summary==summaries(SOURCE/"evaluation/native/summary.xml"),
                complete_events=sorted_events(events["passages"])==sorted_events([r for r in source_events if r["notification_time_s"]<END]),
                arrived_routes=arrived_routes(native/"vehicle-routes.xml")==arrived_routes(SOURCE/"evaluation/native/vehicle-routes.xml"),
                arrived_tripinfo={r.get("id"):dict(r.attrib) for r in arrived}=={r.get("id"):dict(r.attrib) for r in source_trips if 0<=float(r.get("arrival"))<END},
                detector_holds_before900=[r for r in monitor["lane_section_hold"]["events"] if r["time_s"]<END]==[r for r in source_monitor["lane_section_hold"]["events"] if r["time_s"]<END],
                body_holds_before900=[r for r in monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"]<END]==[r for r in source_monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"]<END])
        measured={(r["detector_id"],float(r["begin"]),float(r["end"])):r for r in comparisons}
        all_rows=read_csv_rows(case/"prepared/initialization-counts.csv")+read_csv_rows(case/"prepared/expected-counts.csv")
        coverage=[dict(detector_id=r["detector_id"],begin=r["begin"],end=r["end"],expected_total=r["expected_total"],measured_nVehContrib=measured.get((r["detector_id"],float(r["begin"]),float(r["end"])),{}).get("measured_nVehContrib"),status="measured_prefix" if float(r["begin"])==0 and float(r["end"])==END else "unmeasured_after_prefix_horizon") for r in all_rows]
        assert len(coverage)==182 and sum(r["measured_nVehContrib"] is None for r in coverage)==169
        save(case/"all182-coverage.json",coverage)
        status="pass" if all(checks.values()) and all(parity.values()) else "blocked"
        save(case/"record-result.json",dict(schema="astra.hamburg.causal-initial-prefix/v1",status=status,checks=checks,reference_parity=parity,boundary_semantics=boundary,
            preflight_sha256=sha(case/"preflight.json"),native_output_hashes={str(native/n):sha(native/n) for n in ["field-counts.xml","summary.xml","instant-e1.xml","tripinfo.xml","vehicle-routes.xml","collisions.xml","stall-monitor.json"]},
            repeated_vehicle_fields=repeated,contributions_outside_primary_intention=outside,unknown_complete_vehicle_IDs=unknown,
            prefix13_metrics=prefix_stats,prefix13_comparison=comparisons,prefix_completion=final,core_status=core_result["status"],core_healthy=core_result["healthy"],core_errors=core_result["errors"],
            full_request_count=8640,full130_calibration_acceptance=False,full130_metrics=None,remaining39_initial_metrics=None,combined182_metrics=None,measured_real_rows=13,unmeasured_real_rows=169,
            full_health_not_claimed=True,claim_boundary="Only the0–900 prefix is measured. Retained8640 future requests make the full-completion core status invalid; unexpected core errors still fail separately.39 initialization and130 main rows remain unmeasured, never zero. Prefix parity/count improvement is not full calibration, full completion, field OD or signal truth."))
        print(json.dumps(dict(status=status,case=case.name,checks=checks,reference_parity=parity,prefix13_metrics=prefix_stats)))
        if status!="pass":
            raise SystemExit(1)
    except Exception as error:
        save(case/"failure.json",dict(status="blocked",error=f"{type(error).__name__}: {error}",partial_outputs_preserved=True,full130_calibration_acceptance=False))
        (case/"failure.log").write_text(traceback.format_exc(),encoding="utf-8")
        raise


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--case",choices=["reference","advance22","advance225"],required=True)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only",action="store_true")
    mode.add_argument("--run",action="store_true")
    args=parser.parse_args()
    if args.check_only:
        check(ROOT/args.case)
        result=selfcheck()
        result.update(case=args.case,runner_sha256=sha(Path(__file__)),prefix13_sha256=sha(ROOT/"prefix13.csv"),reference_parity_required_before_candidate_native=args.case!="reference")
        save(ROOT/(args.case+".selfcheck.json"),result)
        print(json.dumps(result))
    else:
        run(ROOT/args.case)
