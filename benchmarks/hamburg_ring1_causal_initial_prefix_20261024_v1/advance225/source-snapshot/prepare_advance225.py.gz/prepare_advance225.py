"""Prepare the uniform225 one-cycle initialization departure sensitivity, without SUMO."""

from collections import Counter
from copy import deepcopy
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASE = ROOT / "advance225"
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share/prepared"
DIAG = REPO / "outputs/hamburg-119-cumulative-service-20261024-v1"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
         "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def native_ms(value):
    return int(math.floor(float(value) * 1000 + .5))


def blocks(raw):
    matches = list(re.finditer(rb"<vehicle\b[^>]*>.*?</vehicle>", raw, flags=re.S))
    data = {ET.fromstring(m.group()).get("id"): m.group() for m in matches}
    assert len(data) == len(matches) == 8640
    assert all(not raw[a.end():b.start()].strip() for a, b in zip(matches, matches[1:]))
    return data, raw[:matches[0].start()], raw[matches[-1].end():]


def main():
    assert not CASE.exists(), "Keep prior preparation and results."
    source = {name: (SOURCE / name).read_bytes() for name in NAMES}
    routes = ET.fromstring(source["demand.rou.xml"])
    old = {v.get("id"): v for v in routes.findall("vehicle")}
    original_order = {identity: i for i, identity in enumerate(old)}
    metadata = json.loads(source["lane-intentions.json"])
    old_metadata = {r["vehicle_id"]: r for r in metadata["vehicles"]}
    table = list(csv.DictReader((ROOT / "advance225-cohort.csv").open(encoding="utf-8", newline="")))
    assert len(table) == 225 and len({r["vehicle_id"] for r in table}) == 225
    proposals = []
    for row in table:
        identity = row["vehicle_id"]
        depart = float(old[identity].get("depart"))
        assert abs(depart - float(row["requested_depart_s"])) < 1e-8
        assert old_metadata[identity]["field_id"] == row["field_id"]
        proposed = depart - 90
        assert 0 < proposed < depart < 900
        assert native_ms(proposed) == native_ms(depart) - 90000
        proposals.append({"vehicle_id": identity, "source_depart_s": depart, "proposed_depart_s": proposed,
                          "shift_s": -90, "field_id": row["field_id"],
                          "source_actual_E1_notification_s": float(row["actual_E1_notification_s"]),
                          "fixed_old_lag_only_projected_E1_s": float(row["actual_E1_notification_s"]) - 90})
    applied = apply_native_count_retiming(routes, proposals)
    changed = {v.get("id"): v for v in applied.findall("vehicle")}
    chosen = {r["vehicle_id"] for r in proposals}
    sequence = sorted(changed, key=lambda identity: (float(changed[identity].get("depart")), original_order[identity]))
    old_blocks, prefix, suffix = blocks(source["demand.rou.xml"])
    new_blocks = dict(old_blocks)
    for identity in chosen:
        old_text = old[identity].get("depart").encode()
        new_text = changed[identity].get("depart").encode()
        pattern = b'depart="' + old_text + b'"'
        assert new_blocks[identity].count(pattern) == 1
        new_blocks[identity] = new_blocks[identity].replace(pattern, b'depart="' + new_text + b'"', 1)
    candidate = prefix + b"".join(new_blocks[identity] for identity in sequence) + suffix
    check = {v.get("id"): v for v in ET.fromstring(candidate).findall("vehicle")}
    assert check.keys() == old.keys()
    assert [i for i in sequence if i not in chosen] == [i for i in old if i not in chosen]
    for identity, vehicle in check.items():
        restored = deepcopy(vehicle)
        restored.set("depart", old[identity].get("depart"))
        assert ET.tostring(restored) == ET.tostring(old[identity])
        assert ET.tostring(vehicle) == ET.tostring(changed[identity])
        if identity not in chosen:
            assert new_blocks[identity] == old_blocks[identity]
    pairs = sorted({(v.find("route").get("edges").split()[0], v.find("route").get("edges").split()[-1]) for v in old.values()})
    assert len(pairs) == 21
    old_q, new_q = [0] * 294, [0] * 294
    changes = []
    for row in metadata["vehicles"]:
        identity = row["vehicle_id"]
        route = check[identity].find("route").get("edges").split()
        pair = pairs.index((route[0], route[-1]))
        old_cell = native_ms(old[identity].get("depart")) // 900000 * 21 + pair
        new_cell = native_ms(check[identity].get("depart")) // 900000 * 21 + pair
        assert old_cell == new_cell == row["od_cell"]
        old_q[old_cell] += 1
        new_q[new_cell] += 1
        if identity in chosen:
            previous = deepcopy(row)
            row["depart_s"] = float(check[identity].get("depart"))
            assert {k: v for k, v in row.items() if k != "depart_s"} == {k: v for k, v in previous.items() if k != "depart_s"}
            changes.append({"vehicle_id": identity, "source_metadata": previous, "candidate_metadata": deepcopy(row)})
        else:
            assert row == old_metadata[identity]
    assert old_q == new_q and sum(new_q) == 8640 and len(changes) == 225
    prep = CASE / "prepared"
    prep.mkdir(parents=True)
    for name, raw in source.items():
        (prep / name).write_bytes(raw)
    (prep / "demand.rou.xml").write_bytes(candidate)
    save(prep / "lane-intentions.json", metadata)
    scenario = json.loads(source["scenario.json"])
    scenario.update(status="diagnostic_prefix900_candidate", formal_result=False, exact_count_fit=False,
                    demand_sha256=sha(candidate),
                    demand_prior="Same8640 explicit one-share requests, routes, stops, fields and OD inventories. All225 first-bin Z11/Z12/Z13 initialization departures advance90s.",
                    time_prior="Uniform first-period cohort supply advances one90s cycle, preserving its empirical request spacing. Frozen old lags are not predictions of changed native queues or actuated programs. All future demand remains present.",
                    claim_boundary="Prepared first900 prefix test only. Must measure all13 true first-bin counts and safety after reference parity. Full130/40/52/182 fit and fullwindow safety/completion remain unmeasured.")
    save(prep / "scenario.json", scenario)
    save(CASE / "departure-proposals.json", proposals)
    save(CASE / "metadata-changes.json", changes)
    save(CASE / "od-vector.json", {"values": new_q, "integer_counts": new_q, "vehicle_count": 8640,
         "source_vector": old_q, "inventory_unchanged": True,
         "ordering": "native-millisecond departure bin then lexicographic actual origin/destination", "new_OD_generation": False})
    request_path = SOURCE.parent / "evaluation/native/native-request.json"
    native_request = json.loads(request_path.read_bytes())
    driver = {key: native_request[key] for key in ("backend", "end_s", "all_stopped_timeout_s", "junction_body_hold", "junction_body_hold_nodes")}
    command = native_request["command"]
    driver.update({key: command[command.index(flag) + 1] for key, flag in
                   (("step_length_s", "--step-length"), ("seed", "--seed"), ("precision", "--precision"))})
    driver["authorized_prefix_end_s"] = 900
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_departure_probe.py"
    paths = [SOURCE / name for name in NAMES] + [ROOT / "advance225-cohort.csv", DIAG / "manifest.json", core,
            Path(__file__).resolve(), request_path, CASE / "departure-proposals.json"]
    source_hashes = {str(p): sha(p.read_bytes()) for p in paths}
    snapshot = CASE / "source-snapshot"
    snapshot.mkdir()
    for name, raw in source.items():
        (snapshot / (name + ".gz")).write_bytes(gzip.compress(raw, mtime=0))
    (snapshot / "prepare_advance225.py").write_bytes(Path(__file__).read_bytes())
    for label, path in [("hamburg_departure_probe.py", core), ("advance225-cohort.csv", ROOT / "advance225-cohort.csv"),
                        ("diagnostic-manifest.json", DIAG / "manifest.json"), ("native-request.json", request_path)]:
        (snapshot / (label + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    fixed = [name for name in NAMES if name not in {"demand.rou.xml", "lane-intentions.json", "scenario.json"}]
    assert all((prep / name).read_bytes() == source[name] for name in fixed)
    scope = {"status": "pass", "formal_result": False, "native_runs": 0, "N": 8640,
             "source_hashes": source_hashes, "prepared_hashes": {name: sha((prep / name).read_bytes()) for name in NAMES},
             "original_driver_scope": driver, "actual_changes": {"departures": 225, "native_shift_s": -90,
                "field_counts": dict(Counter(r["field_id"] for r in proposals)), "all_native_bins_unchanged": True,
                "OD294_inventory_unchanged": True, "unselected_raw_vehicle_XML_unchanged": 8415,
                "unselected_relative_order_preserved": True, "all_routes_stops_fields_vtypes_other_attributes_unchanged": True,
                "metadata_depart_s_rows_updated": 225, "metadata_od_cell_changes": 0},
             "changes": proposals, "checks": {"all8640_future_requests_retained": True,
                "only225_depart_attributes_changed": True, "all_other_vehicle_contents_preserved": True,
                "only_selected_metadata_depart_s_synced": True, "original_network_control_targets_rawbytes_identical": True,
                "source_one_share_Z5_donor_preserved": check["od_0209_v00026"].find("stop").get("lane") == "24483344#1_1"},
             "prefix_evaluation_scope": {"end_s": 900, "real_observation_rows": 13, "full_targets_retained": "130main+52initial",
                "require_reference900_parity_first": True, "safety_gate": "Native prefix collisions/teleports/discard and actual E1 identities, not unfinished future demand."},
             "claim_boundary": "Prepared one-cycle timing sensitivity only. Old-lag projections are unmeasured. No count/speed/position/phase controller, vehicle deletion, route, field or control change. No fullwindow calibration or safety claim."}
    save(CASE / "scope-proof.json", scope)
    save(CASE / "selfchecks.json", {"status": "pass", "native_runs": 0, "changed_IDs": sorted(chosen),
          "all_checks": scope["checks"], "candidate_departure_min_s": min(float(check[i].get("depart")) for i in chosen),
          "candidate_departure_max_s": max(float(check[i].get("depart")) for i in chosen),
          "first_bin_fixed_old_lag_only_projection_additions": dict(Counter(r["field_id"] for r in proposals
              if r["source_actual_E1_notification_s"] >= 900 and 0 <= r["fixed_old_lag_only_projected_E1_s"] < 900))})
    assert all(scope["checks"].values())
    print(json.dumps({"status": "pass", "prepared": str(prep), "N": 8640, "changed": 225,
                      "demand_sha256": sha(candidate), "scope_sha256": sha((CASE / "scope-proof.json").read_bytes())}))


if __name__ == "__main__":
    main()
