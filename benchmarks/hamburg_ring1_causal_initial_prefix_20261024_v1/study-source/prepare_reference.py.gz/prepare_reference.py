"""Copy the full source inputs and derive a separate real first-interval target."""

import csv
import hashlib
import io
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
SOURCE=REPO/"outputs/hamburg-z5-single-share-20261024-v1/one-share"
NAMES=("network.net.xml","control.add.xml","demand.rou.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv","lane-intentions.json","scenario.json")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def main():
    case=ROOT/"reference"
    assert not case.exists(),"Preserve existing reference evidence."
    with (SOURCE/"prepared/initialization-counts.csv").open(encoding="utf-8",newline="") as handle:
        reader=csv.DictReader(handle)
        names=reader.fieldnames
        all_rows=list(reader)
    rows=[r for r in all_rows if float(r["begin"])==0 and float(r["end"])==900]
    assert len(all_rows)==52 and len(rows)==len({r["detector_id"] for r in rows})==13
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,fieldnames=names,lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    prefix=ROOT/"prefix13.csv"
    raw=buffer.getvalue().encode("utf-8")
    if prefix.exists():
        assert prefix.read_bytes()==raw
    else:
        prefix.write_bytes(raw)
    save(ROOT/"prefix13-provenance.json",dict(source=str(SOURCE/"prepared/initialization-counts.csv"),source_sha256=digest(SOURCE/"prepared/initialization-counts.csv"),prefix13_sha256=digest(prefix),filter="begin==0,end==900",rows=13,original_initial_rows=52,original_main_rows=130,observations_changed=False,unmeasured_rows_after_prefix=169))
    prepared=case/"prepared"
    prepared.mkdir(parents=True)
    for name in NAMES:
        shutil.copyfile(SOURCE/"prepared"/name,prepared/name)
    save(case/"departure-proposals.json",[])
    request=json.loads((SOURCE/"evaluation/native/native-request.json").read_bytes())
    command=request["command"]
    driver={k:request[k] for k in ["backend","end_s","all_stopped_timeout_s","junction_body_hold","junction_body_hold_nodes"]}
    driver.update(step_length_s=command[command.index("--step-length")+1],seed=command[command.index("--seed")+1],precision=command[command.index("--precision")+1])
    save(case/"scope-proof.json",dict(status="pass",N=8640,native_runs=0,formal_result=False,
        source_hashes={str(p):digest(p) for p in [*(SOURCE/"prepared"/n for n in NAMES),case/"departure-proposals.json",Path(__file__)]},
        prepared_hashes={n:digest(prepared/n) for n in NAMES},original_driver_scope=driver,authorized_prefix_end_s=900,
        actual_changes=dict(request_departures_changed=0),
        claim_boundary="Full8640 requests and full130+52 observations copied exactly. Prefix13 is a separate exact real subset. Prefix execution does not establish full completion or full calibration."))
    print(json.dumps(dict(status="prepared",case=str(case),N=8640,prefix13_sha256=digest(prefix),native_runs=0)))


if __name__=="__main__":
    main()
