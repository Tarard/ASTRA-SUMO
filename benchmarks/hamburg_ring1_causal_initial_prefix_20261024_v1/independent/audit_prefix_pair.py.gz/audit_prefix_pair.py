"""Read sealed raw 900 s evidence; perform no native run or input mutation."""

from collections import Counter
from copy import deepcopy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def csv_rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def summary(path):
    return [{k: v for k, v in row.attrib.items() if k != "duration"} for _, row in ET.iterparse(path, events=("end",)) if row.tag == "step" and float(row.get("time")) < 900]


def intervals(path):
    return {(r.get("id"), float(r.get("begin")), float(r.get("end"))): dict(r.attrib) for _, r in ET.iterparse(path, events=("end",)) if r.tag == "interval" and float(r.get("begin")) == 0 and float(r.get("end")) == 900}


def arrived(path):
    rows = {}
    for _, row in ET.iterparse(path, events=("end",)):
        if row.tag == "vehicle":
            if 0 <= float(row.get("arrival")) < 900:
                rows[row.get("id")] = ET.canonicalize(ET.tostring(row, encoding="unicode"), strip_text=True)
            row.clear()
    return rows


def xml_vehicles(path):
    root = ET.parse(path).getroot()
    return root, {r.get("id"): r for r in root.findall("vehicle")}


def event_key(row):
    return (row["vehicle_id"], row["detector_id"], row["notification_time_s"], row["time_s"], row["occupancy_s"])


def endpoint(name):
    case = ROOT / name
    record = load(case / "record-result.json")
    core = load(case / "core-result.json")
    preflight = load(case / "preflight.json")
    proof = load(case / "scope-proof.json")
    assert record["status"] == "pass" and all(record["checks"].values())
    assert not core["errors"] and core["inputs_unchanged"]
    assert record["preflight_sha256"] == sha(case / "preflight.json")
    for mapping in [preflight["source_hashes"], preflight["binaries"], record["native_output_hashes"], proof["source_hashes"]]:
        assert all(sha(Path(p)) == h for p, h in mapping.items())
    assert preflight["scope_sha256"] == sha(case / "scope-proof.json")
    assert preflight["prefix13_sha256"] == sha(ROOT / "prefix13.csv")
    assert preflight["runner_sha256"] == sha(case / "executed-run.py") == "127b69b9b62ea8898f5f71a64f5aa51d8d03ac26f5725790d30765d157c7a798"
    assert preflight["prepared_hashes"] == proof["prepared_hashes"]
    assert all(sha(case / "prepared" / p) == h for p, h in preflight["prepared_hashes"].items())
    assert all(sha(case / "implementation" / p) == h for p, h in preflight["implementation_sha256"].items())
    assert all(sha(Path(r["path"])) == r["sha256"] for r in core["inputs"] + core["snapshots"])
    native = case / "native"
    events = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=core["instant_to_periodic_ids"], step_length=.1)
    complete = events["passages"] + events["outside_periodic_intervals"]
    intents = {r["vehicle_id"]: r for r in load(case / "prepared/lane-intentions.json")["vehicles"]}
    assert len(intents) == 8640 and events["reconciled"]
    assert not events["outside_periodic_intervals"]
    assert all(r["vehicle_id"] in intents and r["detector_id"] == intents[r["vehicle_id"]]["field_id"] for r in complete)
    assert max(Counter((r["vehicle_id"], r["detector_id"]) for r in complete).values(), default=0) <= 1
    values = intervals(native / "field-counts.xml")
    assert len(values) == 13
    target = csv_rows(ROOT / "prefix13.csv")
    comparisons = []
    for row in target:
        field = row["detector_id"]
        actual = int(values[(field, 0., 900.)]["nVehContrib"])
        expected = int(row["expected_total"])
        assert sum(r["detector_id"] == field for r in complete) == actual
        comparisons.append(dict(field_id=field, expected=expected, actual=actual, residual=actual-expected))
    residuals = [r["residual"] for r in comparisons]
    metrics = dict(rows=13, TAE=sum(abs(v) for v in residuals), SSE=sum(v*v for v in residuals), MAE=sum(abs(v) for v in residuals)/13, max_abs_error=max(abs(v) for v in residuals))
    assert metrics == record["prefix13_metrics"]
    rows = summary(native / "summary.xml")
    assert len(rows) == 9000 and float(rows[-1]["time"]) == 899.9
    monitor = load(native / "stall-monitor.json")
    command = load(native / "command.json")
    assert monitor["simulation_time_s"] == 900 and monitor["status"] == "completed" and monitor["library_completed"]
    assert monitor["native_version"] == [22, "SUMO 1.27.1"] and monitor["native_returncode"] is None
    assert command["returncode"] == 0 and command["status"] == "pass"
    assert sha(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    assert not ET.parse(native / "collisions.xml").getroot().findall("collision")
    assert all(int(rows[-1][k]) == 0 for k in ("collisions", "teleports", "discarded"))
    trips = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
    assert len(trips) == len({r.get("id") for r in trips}) == int(rows[-1]["inserted"])
    assert all(r.get("id") in intents and 0 <= float(r.get("depart")) <= 900 for r in trips)
    assert all(r.get("vaporized", "") in ({"", "end"} if float(r.get("arrival")) < 0 else {""}) for r in trips)
    coverage = load(case / "all182-coverage.json")
    assert len(coverage) == 182 and sum(r["measured_nVehContrib"] is None for r in coverage) == 169
    assert record["full130_metrics"] is None and record["remaining39_initial_metrics"] is None and record["combined182_metrics"] is None
    assert not record["full130_calibration_acceptance"] and core["status"] == "invalid" and not core["healthy"]
    return dict(metrics13=metrics, fields=comparisons, prefix_completion=rows[-1], unique_complete_events=len(complete), safety=dict(collisions=0, teleports=0, discarded=0, repeated_vehicle_fields=0, outside_primary=0), checked_hashes=True, core_status=core["status"], full130_acceptance=False), complete, rows, monitor, trips


def main():
    # Both terminal records are required; never inspect half-written native files.
    assert all((ROOT / name / "record-result.json").exists() for name in ("reference", "advance22"))
    before, old_events, old_summary, old_monitor, old_trips = endpoint("reference")
    after, new_events, new_summary, _, _ = endpoint("advance22")
    target = csv_rows(ROOT / "prefix13.csv")
    assert target == [r for r in csv_rows(SOURCE / "prepared/initialization-counts.csv") if float(r["begin"]) == 0 and float(r["end"]) == 900]
    assert all((ROOT / "reference/prepared" / n).read_bytes() == (SOURCE / "prepared" / n).read_bytes() for n in NAMES)
    source_monitor = load(SOURCE / "evaluation/native/stall-monitor.json")
    with gzip.open(SOURCE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        source_events = json.load(handle)["passages"]
    source_trips = ET.parse(SOURCE / "evaluation/native/tripinfo.xml").getroot().findall("tripinfo")
    parity = dict(E1_all13_attributes=intervals(ROOT / "reference/native/field-counts.xml") == intervals(SOURCE / "evaluation/native/field-counts.xml"),
        summary_all9000_except_duration=old_summary == summary(SOURCE / "evaluation/native/summary.xml"),
        complete_events=sorted(map(event_key, old_events)) == sorted(event_key(r) for r in source_events if r["notification_time_s"] < 900),
        arrived_routes=arrived(ROOT / "reference/native/vehicle-routes.xml") == arrived(SOURCE / "evaluation/native/vehicle-routes.xml"),
        arrived_tripinfo={r.get("id"): dict(r.attrib) for r in old_trips if 0 <= float(r.get("arrival")) < 900} == {r.get("id"): dict(r.attrib) for r in source_trips if 0 <= float(r.get("arrival")) < 900},
        detector_holds_before900=[r for r in old_monitor["lane_section_hold"]["events"] if r["time_s"] < 900] == [r for r in source_monitor["lane_section_hold"]["events"] if r["time_s"] < 900],
        body_holds_before900=[r for r in old_monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"] < 900] == [r for r in source_monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"] < 900])
    assert len(parity) == 7 and all(parity.values())
    old_root, old = xml_vehicles(ROOT / "reference/prepared/demand.rou.xml")
    new_root, new = xml_vehicles(ROOT / "advance22/prepared/demand.rou.xml")
    proposals = load(ROOT / "advance22/departure-proposals.json")
    selected = {r["vehicle_id"]: r for r in proposals}
    assert len(selected) == 22 and old.keys() == new.keys() and len(old) == 8640
    for identity in old:
        restored = deepcopy(new[identity])
        restored.set("depart", old[identity].get("depart"))
        assert ET.tostring(restored) == ET.tostring(old[identity])
        delta = float(new[identity].get("depart")) - float(old[identity].get("depart"))
        assert abs(delta - (-90 if identity in selected else 0)) < 1e-8
    assert [i for i in old if i not in selected] == [i for i in new if i not in selected]
    blocks = []
    for name in ("reference", "advance22"):
        raw = (ROOT / name / "prepared/demand.rou.xml").read_bytes()
        blocks.append({re.search(rb'\bid="([^"]+)"', block)[1].decode(): block for block in re.findall(rb"<vehicle\b.*?</vehicle>", raw, re.S)})
    assert all(blocks[0][i] == blocks[1][i] for i in old if i not in selected)
    assert [ET.tostring(r) for r in old_root if r.tag != "vehicle"] == [ET.tostring(r) for r in new_root if r.tag != "vehicle"]
    by_id = [{r["vehicle_id"]: r for r in events} for events in (old_events, new_events)]
    full_by_id = {r["vehicle_id"]: r for r in source_events}
    moved = []
    for identity, proposal in selected.items():
        prior, current = full_by_id[identity], by_id[1].get(identity)
        moved.append(dict(vehicle_id=identity, field_id=proposal["field_id"], source_requested_depart_s=float(old[identity].get("depart")), new_requested_depart_s=float(new[identity].get("depart")), source_full_notification_s=prior["notification_time_s"], old_prefix_complete=identity in by_id[0], new_prefix_complete=current is not None, new_notification_s=current["notification_time_s"] if current else None, new_occupancy_s=current["occupancy_s"] if current else None))
    changes = []
    for field in [r["detector_id"] for r in target]:
        a = {i for i, e in by_id[0].items() if e["detector_id"] == field}
        b = {i for i, e in by_id[1].items() if e["detector_id"] == field}
        gain, loss = b-a, a-b
        changes.append(dict(field_id=field, old_count=len(a), new_count=len(b), changed_vehicle_gain=sorted(gain & selected.keys()), changed_vehicle_loss=sorted(loss & selected.keys()), unchanged_vehicle_gain=sorted(gain-selected.keys()), unchanged_vehicle_loss=sorted(loss-selected.keys()), same_member_notification_changes=sum(by_id[0][i]["notification_time_s"] != by_id[1][i]["notification_time_s"] for i in a & b)))
    first_summary = next((dict(index=i, old=a, new=b) for i, (a, b) in enumerate(zip(old_summary, new_summary)) if a != b), None)
    first_physical = next((dict(index=i, old=a, new=b) for i, (a, b) in enumerate(zip(old_summary, new_summary)) if {k: v for k, v in a.items() if k != "loaded"} != {k: v for k, v in b.items() if k != "loaded"}), None)
    result = dict(schema="astra.hamburg.causal-initial-prefix-independent/v1", audit_status="pass", reference=before, advance22=after, reference_strict_parity=parity,
        input_scope=dict(requests=8640, changed_departures=22, requested_shift_s=-90, other8618_vehicle_rawbytes_and_relative_order_unchanged=True, routes_stops_attributes_unchanged=True, all182_real_targets_retained=True),
        changed_vehicle_outcome=dict(requests=22, reference_prefix_complete=sum(r["old_prefix_complete"] for r in moved), advance22_prefix_complete=sum(r["new_prefix_complete"] for r in moved), by_field=dict(Counter(r["field_id"] for r in moved if r["new_prefix_complete"]))),
        actual_field_membership_changes=changes, first_summary_difference=first_summary, first_summary_difference_except_loaded=first_physical,
        count_improvement=False, full130_calibration_acceptance=False, measured_rows=13, unmeasured_real_rows=169, full130_metrics=None, remaining39_initial_metrics=None,
        claim_boundary="This audit proves only the actual 0–900 s response and exact reference prefix parity. Advancing 22 requests is not equivalent to advancing 22 field contributions. Count membership differences include unchanged vehicles and are not a causal decomposition. No full-run health, later count values, true OD, or physical signal correctness is inferred.")
    save(OUT / "summary.json", result)
    save(OUT / "changed22-actual-events.json", moved)
    inputs = [ROOT / "prefix13.csv", Path(__file__)]
    for name in ("reference", "advance22"):
        inputs.extend(ROOT / name / p for p in ["record-result.json", "core-result.json", "preflight.json", "scope-proof.json", "executed-run.py", "departure-proposals.json"])
    save(OUT / "source-hashes.json", {str(p): sha(p) for p in inputs})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=str(p.relative_to(OUT)), sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(audit_status="pass", reference=before["metrics13"], advance22=after["metrics13"], changed_vehicle_outcome=result["changed_vehicle_outcome"], manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
