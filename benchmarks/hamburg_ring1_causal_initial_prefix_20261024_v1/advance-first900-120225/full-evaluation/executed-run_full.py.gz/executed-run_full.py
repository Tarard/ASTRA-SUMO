"""Validate one saved successful prefix input over14400s; never regenerate demand."""
import argparse
from collections import Counter
import gzip
from importlib.metadata import version
import json
from pathlib import Path
import runpy
import shutil
import sys
import time
import traceback

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
CASES={'225':'advance225','first900':'advance-first900','120225':'advance-first900-120225'}
CHECKER=ROOT/'run_prefix.py'
CHECKER_SHA='303b282d234a901d6b04584b290bf7927532b25d695e29a0f58eef14e44c0471'
SOURCE=REPO/'outputs/hamburg-z5-single-share-20261024-v1/one-share'
BEST=REPO/'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority'
HELPER=REPO/'outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py'


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def check(case):
    assert sha(CHECKER)==CHECKER_SHA, 'Use the declared final prefix checker.'
    checker=runpy.run_path(str(CHECKER))
    proof=checker['check'](case,require_reference=True)
    assert sha(CHECKER)==CHECKER_SHA
    record=json.loads((case/'record-result.json').read_bytes())
    prefix_preflight=json.loads((case/'preflight.json').read_bytes())
    assert record['status']=='pass' and all(record['checks'].values())
    assert record['measured_real_rows']==13 and record['unmeasured_real_rows']==169
    assert record['full130_metrics'] is None and not record['full130_calibration_acceptance']
    assert record['preflight_sha256']==sha(case/'preflight.json')
    assert prefix_preflight['prepared_hashes']==proof['prepared_hashes']
    assert prefix_preflight['runner_sha256']==sha(case/'executed-run.py')
    hashes=dict(record['native_output_hashes'])
    for path,expected in hashes.items():
        assert sha(Path(path))==expected
    for path in [case/n for n in ('scope-proof.json','departure-proposals.json','record-result.json','preflight.json','executed-run.py','core-result.json','contributing-passages.json.gz','all182-coverage.json')]:
        hashes[str(path)]=sha(path)
    for name in ('run.json','native-request.json','command.json'):
        path=case/'native'/name
        hashes[str(path)]=sha(path)
    hashes[str(ROOT/'prefix13.csv')]=sha(ROOT/'prefix13.csv')
    independent=ROOT/(case.name+'-independent')/'manifest.json'
    if independent.is_file():
        hashes[str(independent)]=sha(independent)
    for name,expected in prefix_preflight['implementation_sha256'].items():
        assert sha(case/'implementation'/name)==expected
        assert sha(REPO/'plugins/astra-sumo/src/astra_sumo/core'/name)==expected
    assert set(prefix_preflight['versions'].values())=={'1.27.1'}
    assert tuple(_body_hold_nodes(case/'prepared'))==('14398547','205069138','18653534','LSA104_part0')
    return proof,checker,dict(status='pass',native_runs=0,case=case.name,
        prefix_checker_path=str(CHECKER),prefix_checker_sha256=CHECKER_SHA,
        prefix_executed_runner_sha256=prefix_preflight['runner_sha256'],
        prefix_evidence_hashes=hashes,prepared_hashes=proof['prepared_hashes'],
        prefix13_metrics=record['prefix13_metrics'],full_request_count=8640,
        full_expected_rows=130,initial_expected_rows=52,output=str(case/'full-evaluation'),
        claim_boundary='Ready for one explicit full validation; prefix fit is not full fit or completion.')


def prefix_parity(checker,case,evaluation):
    old=checker['interval_rows'](case/'native/field-counts.xml')
    new=checker['interval_rows'](evaluation/'native/field-counts.xml')
    old_summary=checker['summaries'](case/'native/summary.xml')
    new_summary=checker['summaries'](evaluation/'native/summary.xml')
    checks=dict(all13_intervals=len(old)==len(new)==13,
        all13_native_counts={k:r['nVehContrib'] for k,r in old.items()}=={k:r['nVehContrib'] for k,r in new.items()},
        all13_interval_attributes=old==new,
        all9000_summary_steps=len(old_summary)==len(new_summary)==9000,
        summary_before900_except_CPU_duration=old_summary==new_summary)
    return dict(status='pass' if all(checks.values()) else 'blocked',checks=checks,
        source_prefix_native=str(case/'native'),full_native=str(evaluation/'native'),
        observed_interval_s=[0,900],future_counts_compared_only_from_full_native=True)


def run(case):
    evaluation=case/'full-evaluation'
    assert not evaluation.exists(), 'Preserve any full result or partial failure.'
    evaluation.mkdir()
    started=time.perf_counter()
    attempted=False
    try:
        proof,checker,checked=check(case)
        assert Path(sys.executable).resolve()==(REPO/'.venv/Scripts/python.exe').resolve()
        versions={n:version(n) for n in ('eclipse-sumo','libsumo','traci','sumolib')}
        assert set(versions.values())=={'1.27.1'}
        prepared=case/'prepared'
        for name in ('demand.rou.xml','lane-intentions.json'):
            shutil.copyfile(prepared/name,evaluation/name)
        if (case/'od-vector.json').is_file():
            shutil.copyfile(case/'od-vector.json',evaluation/'od-vector.json')
        shutil.copyfile(__file__,evaluation/'executed-run_full.py')
        shutil.copyfile(CHECKER,evaluation/'executed-prefix-checker.py')
        assert sha(evaluation/'executed-prefix-checker.py')==CHECKER_SHA
        implementation=evaluation/'implementation'
        implementation.mkdir()
        prefix_preflight=json.loads((case/'preflight.json').read_bytes())
        for name,expected in prefix_preflight['implementation_sha256'].items():
            shutil.copyfile(case/'implementation'/name,implementation/name)
            assert sha(implementation/name)==expected
        binaries=[REPO/'.venv/Scripts/python.exe',REPO/'.venv/Lib/site-packages/sumo/bin/sumo.exe']+list((REPO/'.venv/Lib/site-packages/libsumo').glob('*.pyd'))
        assert len(binaries)>=3
        assert {str(p):sha(p) for p in binaries}==prefix_preflight['binaries']
        save(evaluation/'preflight.json',dict(**checked,versions=versions,backend='libsumo',
            binaries={str(p):sha(p) for p in binaries},scope_sha256=sha(case/'scope-proof.json'),
            full_runner_sha256=sha(evaluation/'executed-run_full.py'),
            implementation_sha256={p.name:sha(p) for p in implementation.iterdir()},
            helper_sha256=sha(HELPER),helper_scope_sha256=sha(HELPER.parent/'audit_scope.py'),
            reference_verdict_sha256=sha(SOURCE/'verdict.json'),best_verdict_sha256=sha(BEST/'verdict.json'),
            full_end_s=14400,step_length_s=.1,seed=104,junction_body_hold_nodes=list(_body_hold_nodes(prepared))))
        attempted=True
        native=run_point_detector_demand(net_file=prepared/'network.net.xml',route_file=prepared/'demand.rou.xml',
            e1_additional_file=prepared/'field-loops.add.xml',expected_counts_csv=prepared/'expected-counts.csv',
            output_dir=evaluation/'native',end_s=14400,step_length=.1,seed=104,backend='libsumo',
            sumo_binary=str(binaries[1]),timeout_seconds=4800,signal_program_file=prepared/'control.add.xml',
            lane_intentions_file=prepared/'lane-intentions.json',junction_body_hold=True,junction_body_hold_nodes=_body_hold_nodes(prepared))
        save(evaluation/'core-result.json',native)
        summarize_hamburg_od_measurement(prepared_dir=prepared,proposal_dir=evaluation,native=native)
        events=read_contributing_e1_passages(instant_file=evaluation/'native/instant-e1.xml',periodic_file=evaluation/'native/field-counts.xml',detector_ids=native['instant_to_periodic_ids'],step_length=.1)
        assert events['reconciled']
        compact=evaluation/'contributing-passages.json.gz'
        compact.write_bytes(gzip.compress(json.dumps(events).encode(),mtime=0))
        sys.path.insert(0,str(HELPER.parent))
        tools=runpy.run_path(str(HELPER))
        measured=tools['evidence'](prepared,evaluation,compact,8640)
        fields={r['vehicle_id']:r['field_id'] for r in json.loads((prepared/'lane-intentions.json').read_bytes())['vehicles']}
        repeated=[dict(vehicle_id=i,field=f,count=n) for i,es in measured['by_vehicle'].items() for f,n in Counter(e['detector_id'] for e in es).items() if n>1]
        outside=[dict(vehicle_id=i,actual_field=e['detector_id'],intended_field=fields.get(i)) for i,es in measured['by_vehicle'].items() for e in es if e['detector_id']!=fields.get(i)]
        for name,rows in [('initialization52',measured['initial']),('all182',measured['initial']+measured['main']),('native208',list(measured['periodic'].values()))]:
            tools['table'](evaluation/(name+'-comparison.csv'),rows)
        rows535=[r for r in measured['initial']+measured['main'] if r['detector_id'] in {'hh_0535_Z_5_30894','hh_0535_Z_6_33855','hh_0535_Z_7_29316','hh_0535_Z_8_34287'}]
        assert len(rows535)==56
        tools['table'](evaluation/'535-all56.csv',rows535)
        score535=tools['metrics'](rows535)
        parity=prefix_parity(checker,case,evaluation)
        save(evaluation/'prefix-parity.json',parity)
        reference=json.loads((SOURCE/'verdict.json').read_bytes())['after']
        best=json.loads((BEST/'verdict.json').read_bytes())['candidate']
        stats={k:measured[k] for k in ('metrics130','metrics52','metrics182','station40_MAE','completion','safe','healthy','event_count')}
        common=dict(safe=measured['safe'],healthy=measured['healthy'],all53556_zero=score535['TAE']==0,no_repeated_vehicle_fields=not repeated,no_contributions_outside_primary_intention=not outside)
        def gates(before):
            return dict(**common,main130_MAE_improves=stats['metrics130']['MAE']<before['metrics130']['MAE'],main130_SSE_not_worse=stats['metrics130']['SSE']<=before['metrics130']['SSE'],all182_TAE_not_worse=stats['metrics182']['TAE']<=before['metrics182']['TAE'])
        source_gates,best_gates=gates(reference),gates(best)
        status=('working_best_improved_candidate' if all(best_gates.values()) else 'search_reference_improved_candidate' if all(source_gates.values()) else 'rejected') if parity['status']=='pass' else 'rejected'
        assert all(sha(prepared/n)==h for n,h in proof['prepared_hashes'].items())
        verdict=dict(status=status,formal_result=False,before=reference,global_best=best,after=stats,
            gates=source_gates,global_best_gates=best_gates,prefix_parity_required=True,prefix_parity_pass=parity['status']=='pass',
            prefix13_metrics=json.loads((case/'record-result.json').read_bytes())['prefix13_metrics'],all53556=score535,
            repeated_vehicle_fields=repeated,contributions_outside_prior_primary_intention=outside,
            native_response_measured=True,exact130=stats['metrics130']['TAE']==0,full_exact_and_healthy=stats['healthy'] and stats['metrics130']['TAE']==0,
            claim_boundary='Full14400 validation of the unchanged saved prefix candidate. Prefix parity is mandatory. Initial13 zero alone is not130 fit, completion, field OD or signal truth.')
    except Exception as error:
        verdict=dict(status='invalid',formal_result=False,error=f'{type(error).__name__}: {error}',partial_outputs_preserved=True,native_call_attempted=attempted)
        (evaluation/'failure.log').write_text(traceback.format_exc(),encoding='utf-8')
    verdict['elapsed_s']=time.perf_counter()-started
    save(evaluation/'verdict.json',verdict)
    print(json.dumps(verdict,ensure_ascii=False),flush=True)
    if verdict['status']=='invalid':
        raise SystemExit(1)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case',choices=tuple(CASES),required=True)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check-only',action='store_true')
    mode.add_argument('--run',action='store_true')
    args=parser.parse_args()
    case=ROOT/CASES[args.case]
    if args.check_only:
        print(json.dumps(check(case)[2],ensure_ascii=False,indent=2))
    else:
        run(case)
