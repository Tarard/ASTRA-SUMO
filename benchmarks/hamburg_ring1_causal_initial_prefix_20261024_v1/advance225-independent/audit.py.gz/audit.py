"""Offline raw audit of the separately sealed advance225 prefix."""

from collections import Counter
from copy import deepcopy
import gzip
import importlib.util
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
spec = importlib.util.spec_from_file_location("prefix_pair_reader", ROOT / "independent/audit_prefix_pair.py")
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


def main():
    case = ROOT / "advance225"
    record = reader.load(case / "record-result.json")
    assert record["status"] == "pass" and len(record["checks"]) == 18 and all(record["checks"].values())
    proof = reader.load(case / "scope-proof.json")
    preflight = reader.load(case / "preflight.json")
    core = reader.load(case / "core-result.json")
    assert proof["status"] == "pass" and not core["errors"] and core["inputs_unchanged"]
    assert record["preflight_sha256"] == reader.sha(case / "preflight.json")
    assert preflight["scope_sha256"] == reader.sha(case / "scope-proof.json")
    assert preflight["runner_sha256"] == reader.sha(case / "executed-run.py") == "577701e068bbd801fcc15d0620dedf193510e75be1d346bc5f27a3d85f79cc74"
    assert preflight["prefix13_sha256"] == reader.sha(ROOT / "prefix13.csv")
    for mapping in [proof["source_hashes"], preflight["source_hashes"], preflight["binaries"], record["native_output_hashes"]]:
        assert all(reader.sha(Path(p)) == h for p, h in mapping.items())
    assert all(reader.sha(case / "prepared" / p) == h for p, h in preflight["prepared_hashes"].items())
    assert all(reader.sha(case / "implementation" / p) == h for p, h in preflight["implementation_sha256"].items())
    assert all(reader.sha(Path(r["path"])) == r["sha256"] for r in core["inputs"] + core["snapshots"])
    assert preflight["prepared_hashes"] == proof["prepared_hashes"]
    _, old = reader.xml_vehicles(ROOT / "reference/prepared/demand.rou.xml")
    _, new = reader.xml_vehicles(case / "prepared/demand.rou.xml")
    source_intents = {r["vehicle_id"]: r for r in reader.load(ROOT / "reference/prepared/lane-intentions.json")["vehicles"]}
    intents = {r["vehicle_id"]: r for r in reader.load(case / "prepared/lane-intentions.json")["vehicles"]}
    selected = {r["vehicle_id"]: r for r in reader.load(case / "departure-proposals.json")}
    groups = {"hh_0119_Z_11_28853": 8, "hh_0119_Z_12_31546": 87, "hh_0119_Z_13_34018": 130}
    assert len(selected) == 225 and len(old) == len(new) == 8640 and old.keys() == new.keys()
    assert Counter(intents[i]["field_id"] for i in selected) == groups
    assert set(selected) == {i for i, r in old.items() if intents[i]["field_id"] in groups and 0 <= float(r.get("depart")) < 900}
    for identity in old:
        restored = deepcopy(new[identity])
        restored.set("depart", old[identity].get("depart"))
        assert ET.tostring(restored) == ET.tostring(old[identity])
        assert abs(float(new[identity].get("depart")) - float(old[identity].get("depart")) + (90 if identity in selected else 0)) < 1e-8
        meta = dict(intents[identity])
        if identity in selected:
            assert abs(meta.pop("depart_s") - float(new[identity].get("depart"))) < 1e-8
        assert meta == source_intents[identity]
    assert [i for i in old if i not in selected] == [i for i in new if i not in selected]
    raw_blocks = []
    for folder in [ROOT / "reference", case]:
        raw = (folder / "prepared/demand.rou.xml").read_bytes()
        raw_blocks.append({re.search(rb'\bid="([^"]+)"', b)[1].decode(): b for b in re.findall(rb"<vehicle\b.*?</vehicle>", raw, re.S)})
    assert all(raw_blocks[0][i] == raw_blocks[1][i] for i in old if i not in selected)
    for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]:
        assert (case / "prepared" / name).read_bytes() == (ROOT / "reference/prepared" / name).read_bytes()
    native = case / "native"
    events = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=core["instant_to_periodic_ids"], step_length=.1)
    complete = events["passages"] + events["outside_periodic_intervals"]
    assert events["reconciled"] and not events["outside_periodic_intervals"]
    assert all(r["vehicle_id"] in intents and r["detector_id"] == intents[r["vehicle_id"]]["field_id"] for r in complete)
    assert max(Counter((r["vehicle_id"], r["detector_id"]) for r in complete).values(), default=0) <= 1
    with gzip.open(ROOT / "reference/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        old_events = json.load(handle)["passages"]
    by_id = [{r["vehicle_id"]: r for r in rows} for rows in [old_events, complete]]
    rows = reader.summary(native / "summary.xml")
    monitor = reader.load(native / "stall-monitor.json")
    command = reader.load(native / "command.json")
    assert len(rows) == 9000 and float(rows[-1]["time"]) == 899.9
    assert monitor["simulation_time_s"] == 900 and monitor["status"] == "completed" and monitor["library_completed"] and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"] and reader.sha(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    assert command["status"] == "pass" and command["returncode"] == 0 and not ET.parse(native / "collisions.xml").getroot().findall("collision")
    assert all(int(rows[-1][k]) == 0 for k in ["collisions", "teleports", "discarded"])
    trips = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
    assert len(trips) == len({r.get("id") for r in trips}) == int(rows[-1]["inserted"])
    assert all(r.get("id") in intents and 0 <= float(r.get("depart")) <= 900 for r in trips)
    assert all(r.get("vaporized", "") in ({"", "end"} if float(r.get("arrival")) < 0 else {""}) for r in trips)
    periodic = reader.intervals(native / "field-counts.xml")
    old_periodic = reader.intervals(ROOT / "reference/native/field-counts.xml")
    assert len(periodic) == 13
    fields = []
    for target in reader.csv_rows(ROOT / "prefix13.csv"):
        field = target["detector_id"]
        previous, actual, expected = int(old_periodic[(field, 0., 900.)]["nVehContrib"]), int(periodic[(field, 0., 900.)]["nVehContrib"]), int(target["expected_total"])
        assert actual == sum(r["detector_id"] == field for r in complete)
        a = {i for i, r in by_id[0].items() if r["detector_id"] == field}
        b = {i for i, r in by_id[1].items() if r["detector_id"] == field}
        fields.append(dict(field_id=field, expected=expected, reference=previous, advance225=actual, residual=actual-expected, changed_gained=sorted((b-a) & selected.keys()), changed_lost=sorted((a-b) & selected.keys()), unchanged_gained=sorted((b-a)-selected.keys()), unchanged_lost=sorted((a-b)-selected.keys())))
    residuals = [r["residual"] for r in fields]
    metrics = dict(rows=13, TAE=sum(abs(v) for v in residuals), SSE=sum(v*v for v in residuals), MAE=sum(abs(v) for v in residuals)/13, max_abs_error=max(abs(v) for v in residuals))
    assert metrics == record["prefix13_metrics"]
    coverage = reader.load(case / "all182-coverage.json")
    assert len(coverage) == 182 and sum(r["measured_nVehContrib"] is None for r in coverage) == 169
    assert record["full130_metrics"] is None and record["remaining39_initial_metrics"] is None and record["combined182_metrics"] is None and not record["full130_calibration_acceptance"]
    outcomes = [dict(vehicle_id=i, field_id=intents[i]["field_id"], source_depart_s=float(old[i].get("depart")), new_depart_s=float(new[i].get("depart")), reference_notification_s=by_id[0].get(i, {}).get("notification_time_s"), new_notification_s=by_id[1].get(i, {}).get("notification_time_s")) for i in selected]
    result = dict(schema="astra.hamburg.causal-initial-advance225-independent/v1", audit_status="pass", metrics13=metrics, reference_metrics13=reader.load(ROOT / "reference/record-result.json")["prefix13_metrics"], fields=fields,
        scope=dict(requests=8640, changed_departures=225, shift_s=-90, changed_field_stocks=groups, unchanged_vehicle_rawbytes=8415, all_routes_stops_fields_unchanged=True, source_reference_not_advance22=True),
        selected_complete_before=sum(i in by_id[0] for i in selected), selected_complete_after=sum(i in by_id[1] for i in selected), unique_complete_events=len(complete), prefix_completion=rows[-1],
        checked_hashes=True, safety=dict(collisions=0, teleports=0, discarded=0, repeated_fields=0, outside_primary=0), measured_real_rows=13, unmeasured_real_rows=169, full130_acceptance=False, full130_metrics=None, remaining39_initial_metrics=None,
        claim_boundary="Only 0–900 s is measured. Advancing this cohort improves the measured aggregate counts but changes other vehicles' prefix membership. This is not full calibration acceptance, full-run health, a true OD estimate, or proof that a further time shift will improve counts.")
    reader.save(OUT / "summary.json", result)
    reader.save(OUT / "changed225-actual-events.json", outcomes)
    paths = [Path(__file__), ROOT / "prefix13.csv"] + [case / n for n in ["record-result.json", "preflight.json", "scope-proof.json", "executed-run.py", "departure-proposals.json"]]
    reader.save(OUT / "source-hashes.json", {str(p): reader.sha(p) for p in paths})
    reader.save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=reader.sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(metrics13=metrics, selected_complete_before=result["selected_complete_before"], selected_complete_after=result["selected_complete_after"], manifest_sha256=reader.sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
