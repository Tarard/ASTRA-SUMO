"""Audit the one completed 14400 s validation without running SUMO."""

from collections import Counter
import gzip
import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
CASE = ROOT / "advance-first900-120225"
EVALUATION = CASE / "full-evaluation"
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"
BEST = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPER))
import audit_response as audit  # noqa: E402

spec = importlib.util.spec_from_file_location("prefix_raw_reader", ROOT / "independent/audit_prefix_pair.py")
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def main():
    assert (EVALUATION / "verdict.json").is_file(), "Wait for the terminal verdict; do not inspect partial native files."
    verdict = reader.load(EVALUATION / "verdict.json")
    assert verdict["status"] != "invalid" and verdict["native_response_measured"]
    preflight = reader.load(EVALUATION / "preflight.json")
    core = reader.load(EVALUATION / "core-result.json")
    assert not core["errors"] and core["inputs_unchanged"] and core["native_status"] == "pass" and core["native_returncode"] == 0
    assert preflight["backend"] == "libsumo" and set(preflight["versions"].values()) == {"1.27.1"}
    assert reader.sha(EVALUATION / "executed-run_full.py") == preflight["full_runner_sha256"]
    assert reader.sha(EVALUATION / "executed-prefix-checker.py") == preflight["prefix_checker_sha256"] == "303b282d234a901d6b04584b290bf7927532b25d695e29a0f58eef14e44c0471"
    assert preflight["scope_sha256"] == reader.sha(CASE / "scope-proof.json")
    assert reader.sha(HELPER / "audit_response.py") == preflight["helper_sha256"]
    assert reader.sha(HELPER / "audit_scope.py") == preflight["helper_scope_sha256"]
    for mapping in [preflight["prefix_evidence_hashes"], preflight["binaries"]]:
        assert all(reader.sha(Path(p)) == h for p, h in mapping.items())
    assert all(reader.sha(CASE / "prepared" / p) == h for p, h in preflight["prepared_hashes"].items())
    assert all(reader.sha(EVALUATION / "implementation" / p) == h for p, h in preflight["implementation_sha256"].items())
    assert all(reader.sha(Path(r["path"])) == r["sha256"] for r in core["inputs"] + core["snapshots"])
    assert reader.sha(REPO / "plugins/astra-sumo/src/astra_sumo/core/route_sensor_matrix.py") == preflight["implementation_sha256"]["route_sensor_matrix.py"]
    before = audit.evidence(SOURCE / "prepared", SOURCE / "evaluation", SOURCE / "evaluation/contributing-passages.json.gz", 8640)
    best = audit.evidence(BEST / "prepared", BEST / "evaluation", BEST / "evaluation/contributing-passages.json.gz", 8640)
    after = audit.evidence(CASE / "prepared", EVALUATION, EVALUATION / "contributing-passages.json.gz", 8640)
    native = EVALUATION / "native"
    raw = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=core["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(EVALUATION / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        assert raw == json.load(handle) and raw["reconciled"]
    monitor = reader.load(native / "stall-monitor.json")
    prefix_monitor = reader.load(CASE / "native/stall-monitor.json")
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400 and monitor["library_completed"] and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"] and reader.sha(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    with gzip.open(CASE / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        prefix_events = json.load(handle)["passages"]
    prefix_trips = ET.parse(CASE / "native/tripinfo.xml").getroot().findall("tripinfo")
    full_trips = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
    parity = dict(all13_interval_attributes=reader.intervals(native / "field-counts.xml") == reader.intervals(CASE / "native/field-counts.xml"),
        all9000_summary_except_duration=reader.summary(native / "summary.xml") == reader.summary(CASE / "native/summary.xml"),
        complete_events=sorted(reader.event_key(r) for r in raw["passages"] if r["notification_time_s"] < 900) == sorted(map(reader.event_key, prefix_events)),
        arrived_routes=reader.arrived(native / "vehicle-routes.xml") == reader.arrived(CASE / "native/vehicle-routes.xml"),
        arrived_tripinfo={r.get("id"): dict(r.attrib) for r in full_trips if 0 <= float(r.get("arrival")) < 900} == {r.get("id"): dict(r.attrib) for r in prefix_trips if 0 <= float(r.get("arrival")) < 900},
        detector_holds_before900=[r for r in monitor["lane_section_hold"]["events"] if r["time_s"] < 900] == [r for r in prefix_monitor["lane_section_hold"]["events"] if r["time_s"] < 900],
        body_holds_before900=[r for r in monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"] < 900] == [r for r in prefix_monitor["lane_section_hold"]["junction_body_hold"]["events"] if r["time_s"] < 900])
    assert all(parity.values()) and reader.load(EVALUATION / "prefix-parity.json")["status"] == "pass"
    intents = {r["vehicle_id"]: r for r in reader.load(CASE / "prepared/lane-intentions.json")["vehicles"]}
    _, vehicles = reader.xml_vehicles(CASE / "prepared/demand.rou.xml")
    selected = {r["vehicle_id"] for r in reader.load(CASE / "departure-proposals.json")}
    assert len(selected) == 434 and len(vehicles) == 8640
    unknown = set(after["by_vehicle"]) - set(vehicles)
    repeated = [(i, f, n) for i, es in after["by_vehicle"].items() for f, n in Counter(r["detector_id"] for r in es).items() if n > 1]
    outside = [(i, r["detector_id"]) for i, es in after["by_vehicle"].items() for r in es if r["detector_id"] != intents[i]["field_id"]]
    assert not unknown and not repeated and not outside
    rows535 = [r for r in after["initial"] + after["main"] if r["detector_id"] in FIELDS535]
    assert len(rows535) == 56
    def gates(reference):
        return dict(safe=after["safe"], healthy=after["healthy"], all53556_zero=audit.metrics(rows535)["TAE"] == 0, no_repeated_vehicle_fields=not repeated,
            no_contributions_outside_primary_intention=not outside, main130_MAE_improves=after["metrics130"]["MAE"] < reference["metrics130"]["MAE"],
            main130_SSE_not_worse=after["metrics130"]["SSE"] <= reference["metrics130"]["SSE"], all182_TAE_not_worse=after["metrics182"]["TAE"] <= reference["metrics182"]["TAE"])
    source_gates, best_gates = gates(before), gates(best)
    assert source_gates == verdict["gates"] and best_gates == verdict["global_best_gates"]
    status = "working_best_improved_candidate" if all(best_gates.values()) else "search_reference_improved_candidate" if all(source_gates.values()) else "rejected"
    assert status == verdict["status"]
    for label, data in [("reference", before), ("global-best", best), ("after", after)]:
        for name, rows in [("130", data["main"]), ("40", data["stations"]), ("52", data["initial"]), ("182", data["initial"] + data["main"])]:
            audit.table(OUT / f"{label}-{name}.csv", rows)
    field_rows = []
    for field in sorted({k[0] for k in after["periodic"]}):
        row = dict(field_id=field)
        for label, data in [("reference", before), ("best", best), ("after", after)]:
            scores = audit.metrics([r for r in data["main"] if r["detector_id"] == field])
            row.update({f"{label}_{k}": v for k, v in scores.items() if k in {"TAE", "SSE", "max_abs_error"}})
        field_rows.append(row)
    audit.table(OUT / "field13-main.csv", field_rows)
    cumulative_rows, cumulative_scores = [], []
    for horizon in [900, 1800, 3600]:
        scores = dict(horizon_s=horizon)
        for label, data in [("reference", before), ("global_best", best), ("after", after)]:
            period_rows = [r for r in data["initial"] if float(r["end"]) <= horizon]
            collapsed = []
            for field in sorted({r["detector_id"] for r in period_rows}):
                field_rows_to_sum = [r for r in period_rows if r["detector_id"] == field]
                expected = sum(int(r["expected_total"]) for r in field_rows_to_sum)
                actual = sum(int(r["measured_nVehContrib"]) for r in field_rows_to_sum)
                collapsed.append(dict(detector_id=field, expected_total=expected, measured_nVehContrib=actual, diff_nVehContrib_minus_expected=actual-expected))
                cumulative_rows.append(dict(horizon_s=horizon, case=label, field_id=field, expected=expected, actual=actual, residual=actual-expected))
            scores[label] = dict(cumulative13=audit.metrics(collapsed), periodic_rows=audit.metrics(period_rows), expected_count=sum(r["expected_total"] for r in collapsed), actual_count=sum(r["measured_nVehContrib"] for r in collapsed))
        cumulative_scores.append(scores)
    audit.table(OUT / "initial-cumulative-900-1800-3600.csv", cumulative_rows)
    counts = {label: [audit.counts(data["by_vehicle"], ids) for data in [before, after]] for label, ids in {"changed434": selected, "unchanged8206": set(vehicles)-selected}.items()}
    decomposition = []
    for key in sorted(after["periodic"], key=lambda k: (k[1], k[0])):
        old, new = [int(data["periodic"][key]["nVehContrib"]) for data in [before, after]]
        row = dict(field_id=key[0], begin_s=key[1], end_s=key[2], before=old, after=new, delta=new-old)
        row.update({label+"_delta": c[1][key]-c[0][key] for label, c in counts.items()})
        assert row["changed434_delta"] + row["unchanged8206_delta"] == new-old
        decomposition.append(row)
    audit.table(OUT / "native208-cohort-accounting.csv", decomposition)
    arrived = {i for i, r in after["tripinfo"].items() if float(r["arrival"]) >= 0}
    routes = ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle")
    assert len(routes) == len(arrived) == after["completion"]["arrived"] and {r.get("id") for r in routes} == arrived
    assert all(r.find("route").get("edges") == vehicles[r.get("id")].find("route").get("edges") for r in routes)
    terminal = []
    for identity in sorted(set(vehicles)-arrived):
        edges = vehicles[identity].find("route").get("edges").split()
        trip = after["tripinfo"].get(identity)
        terminal.append(dict(vehicle_id=identity, origin=edges[0], destination=edges[-1], field_id=intents[identity]["field_id"], changed_departure=identity in selected,
            requested_depart_s=float(vehicles[identity].get("depart")), actual_depart_s=None if trip is None else float(trip["depart"]),
            state="not_inserted" if trip is None or float(trip["depart"]) < 0 else "inserted_unfinished", source_events=audit.event_view(before["by_vehicle"].get(identity, [])), actual_events=audit.event_view(after["by_vehicle"].get(identity, []))))
    assert len(terminal) == after["completion"]["running"] + after["completion"]["waiting"]
    audit.table(OUT / "terminal-unfinished.csv", terminal)
    summary = dict(schema="astra.hamburg.causal-initial-full-independent/v1", audit_status="pass", selection=status, gates=source_gates, global_best_gates=best_gates,
        **{label: {k: data[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count"]} for label, data in [("reference", before), ("global_best", best), ("after", after)]},
        first900_strict_parity=parity, all53556=audit.metrics(rows535), unique_contributing_vehicles=len(after["by_vehicle"]), repeated=repeated, outside=outside, unknown_IDs=sorted(unknown),
        terminal_count=len(terminal), terminal_origins=dict(Counter(r["origin"] for r in terminal)), terminal_fields=dict(Counter(r["field_id"] for r in terminal)), field_rows=field_rows,
        terminal_changed434=sum(r["changed_departure"] for r in terminal), terminal_by_state=dict(Counter(r["state"] for r in terminal)), terminal_field_completed=sum(bool(r["actual_events"]) for r in terminal),
        terminal_origin_state=[dict(origin=o, state=s, count=n) for (o, s), n in sorted(Counter((r["origin"], r["state"]) for r in terminal).items())],
        initial_cumulative_scores=cumulative_scores,
        exact_main130=after["metrics130"]["TAE"] == 0, exact_all182=after["metrics182"]["TAE"] == 0, full_exact_and_healthy=after["healthy"] and after["metrics130"]["TAE"] == 0,
        raw_source_hashes=before["source_hashes"], raw_candidate_hashes=after["source_hashes"],
        claim_boundary="The full native run now measures all 130 main and 52 initialization rows. Prefix zero and improved scalar scores do not prove true OD or physical control. Changed versus unchanged vehicle accounting is arithmetic, not a causal separation. Unfinished trip records do not identify final road positions.")
    audit.save(OUT / "summary.json", summary)
    reader.save(OUT / "source-hashes.json", {str(p): reader.sha(p) for p in [Path(__file__), EVALUATION / "verdict.json", EVALUATION / "preflight.json", EVALUATION / "executed-run_full.py", EVALUATION / "executed-prefix-checker.py", CASE / "scope-proof.json", EVALUATION / "prefix-parity.json"]})
    reader.save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=reader.sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(selection=status, after=summary["after"], manifest_sha256=reader.sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
