"""Read-only local source audit:445 fork,one-lane761,and199500674 fanout."""
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import tempfile
import xml.etree.ElementTree as ET

from PIL import Image
from shapely.geometry import LineString
import sumolib
from astra_sumo.core.digital_twin import parse_mapem
from astra_sumo.core.hamburg_map_kml import parse_hamburg_map_kml,bind_hamburg_map_kml_to_mapem

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[1]
CURRENT=REPO/"outputs/hamburg-119-late-demand-thinning-20261024-v1/cases/remove43/prepared"
ORIGINAL=REPO/"benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml"
V1=REPO/"benchmarks/hamburg_ring1_readme_v1_zero_20261023_v1/inputs/network.net.xml.gz"
OSM=REPO/"benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz"
MAP=REPO/"outputs/hamburg-119-downstream-control-source-20261024-v1/official-209-retry"
ROADS=["44532531","761590046","199500674#0","199780796#0"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def raw(path):
    data=path.read_bytes()
    return gzip.decompress(data) if path.suffix==".gz" else data


def main():
    assert not (OUT/"manifest.json").exists(),"Preserve sealed sources."
    versions={}
    for label,path in [("current",CURRENT/"network.net.xml"),("original_osm_import",ORIGINAL),("frozen_V1",V1)]:
        payload=raw(path)
        root=ET.fromstring(payload)
        edges={e.get("id"):e for e in root.findall("edge")}
        header=re.search(r"<!--(.*?)-->",payload.decode("utf-8"),re.S)
        versions[label]=dict(path=path.relative_to(REPO).as_posix(),sha256=sha(path),
            coordinate_system=dict(root.find("location").attrib),
            header=header.group(1).strip() if header else None,
            roads={i:dict(edge=edges[i].attrib,lanes=[dict(lane.attrib) for lane in edges[i].findall("lane")]) for i in ROADS},
            ordinary_connections=[dict(c.attrib) for c in root.findall("connection") if c.get("from") in ROADS],
            nodes={i:dict(root.find(f"junction[@id='{i}']").attrib) for i in ["7115619107","7115619106"]})
    def get_fanout(label):
        return sorted(int(c["toLane"]) for c in versions[label]["ordinary_connections"] if c["from"]=="761590046" and c["to"]=="199500674#0")

    assert get_fanout("current")==get_fanout("original_osm_import")==[0]
    assert get_fanout("frozen_V1")==[0,1,2]
    osm=ET.fromstring(raw(OSM))
    ways={i:dict(tags={r.get("k"):r.get("v") for r in osm.find(f"way[@id='{i}']").findall("tag")},nodes=[r.get("ref") for r in osm.find(f"way[@id='{i}']").findall("nd")]) for i in ["44532531","761590046","199500674","199780796"]}
    assert [ways[i]["tags"]["lanes"] for i in ["44532531","761590046","199500674","199780796"]]==["3","1","3","2"]
    net=sumolib.net.readNet(str(CURRENT/"network.net.xml"),withInternal=True)
    with tempfile.TemporaryDirectory() as temporary:
        folder=Path(temporary)
        (folder/"209.xml").write_bytes(raw(MAP/"map_xml.xml.gz"))
        (folder/"209.kml").write_bytes(raw(MAP/"map_kml.xml.gz"))
        lanes,cons=parse_mapem(folder/"209.xml")
        bound=bind_hamburg_map_kml_to_mapem(parse_hamburg_map_kml(folder/"209.kml"),lanes,cons,expected_node_id="209")
    semantic={r.lane_id:r for r in lanes}
    official={r["lane_id"]:[net.convertLonLat2XY(*xy[:2]) for xy in r["coordinates"]] for r in bound["lanes"]}
    matches=[]
    for native,lane_id,sg,egress in [("199500674#0_0","24","17","19"),("199500674#0_1","23","17","18"),("199500674#0_2","22","17","17"),("199780796#0_0","103","12","10"),("199780796#0_1","20","12","9")]:
        curve=net.getLane(native).getShape()
        target=official[lane_id]
        assert any(c.ingress_lane_id==lane_id and c.egress_lane_id==egress and str(c.signal_group)==sg for c in cons)
        matches.append(dict(native_lane=native,MAP_lane=lane_id,ingress_approach=semantic[lane_id].ingress_approach,
            egress_lane=egress,signal_group=sg,minimum_curve_distance_m=LineString(curve).distance(LineString(target)),
            native_lane_end_to_MAP_stopline_m=math.dist(curve[-1],target[0]),MAP_stopline_native_xy=target[0],MAP_upstream_reference_end_xy=target[-1]))
    with (OUT/"MAP-lane-axis-candidates.csv").open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(matches[0]))
        writer.writeheader()
        writer.writerows(matches)
    crop=json.loads((OUT/"crop-source.json").read_bytes())
    aerial=REPO/crop["source_path"]
    assert sha(aerial)==crop["source_sha256"]
    expected=Image.open(aerial).crop(crop["pixel_box"])
    assert expected.tobytes()==Image.open(OUT/"native-pixel-crop.png").tobytes()
    assert expected.resize((expected.width*3,expected.height*3),Image.Resampling.NEAREST).tobytes()==Image.open(OUT/"nearest3-view.png").tobytes()
    demand=ET.parse(CURRENT/"demand.rou.xml").getroot()
    selected=[v.find("route").get("edges").split() for v in demand.findall("vehicle") if v.find("route").get("edges").split()[0]=="44532531"]
    report=dict(schema="astra.hamburg.445-761-source-audit/v1",status="review_required",native_runs=0,inputs_changed=0,
        versions=versions,osm_ways=ways,MAP_reader_gates=bound["gates"],MAP_axis_candidates=matches,
        current_demand_from445=dict(vehicles=len(selected),via761=sum("761590046" in p for p in selected),via_parallel199780=sum("199780796#0" in p for p in selected)),
        aerial=dict(crop_source="crop-source.json",pixel_hashes_verified=True,reading="Two-way fork and downstream widening are visible. Native0.407m pixels, trees/vehicles and marked taper details do not independently certify exact lane count or lane-to-lane ordinal. Nearest3 adds no information."),
        conclusion="The3→1 entry is source-declared route selection at a2+1 fork,not proof that three lanes merged or that newcode removed lanes. BothV1/current contain one-lane761. The concrete difference is the source-imported0→0-only exit versus V1's0→0/1/2 fanout. Official209 has three right-arm vehicle references22/23/24 to17/18/19 viaSG17 and two parallel-arm references20/103 viaSG12. This supports a bounded existing-lane fanout hypothesis,not extra761 lanes or redirecting all445 lanes.",
        boundaries=["2022 MAP publication and2026 aerial are separate dated sources,not dated fieldSPaT or perfect geometric truth.",
            "Minimum curve distance is a spatial candidate measure,not a registered lane binding or Hausdorff error.",
            "The original_osm.net already has the current exit restriction;later197/209 candidates did not introduce it.",
            "Both final headers showSUMO1.27.1,butV1 header is a later net-file/535 conversion,not evidence of its initialOSM import flags.",
            "No new candidate,permission change,road length change or native run was made."])
    (OUT/"summary.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    sources=[CURRENT/"network.net.xml",CURRENT/"control.add.xml",CURRENT/"demand.rou.xml",ORIGINAL,V1,OSM,MAP/"manifest.json",MAP/"map_xml.xml.gz",MAP/"map_kml.xml.gz",aerial]
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sources],indent=2)+"\n",encoding="utf-8")
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=files),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="review_required",manifest_sha256=sha(OUT/"manifest.json"),route_prior=report["current_demand_from445"])))


if __name__=="__main__":
    main()
