"""Measure a saved demand candidate with the established native runtime and audit."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import time
import traceback
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SHARED = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/run_full.py"
SHARED_SHA = "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


assert sha(SHARED) == SHARED_SHA
BASE = runpy.run_path(str(SHARED))


def check(case):
    proposal = json.loads((case / "proposal.json").read_bytes())
    prepare_script = (ROOT / proposal.get("prepare_script", "prepare_case.py")).resolve()
    assert prepare_script.parent == ROOT and prepare_script.suffix == ".py"
    assert runpy.run_path(str(prepare_script))["check"](case.name)["status"] == "pass"
    source = (REPO / proposal["source_case"]).resolve()
    assert source.is_relative_to(REPO / "outputs") and source != case
    before = json.loads((source / "verdict.json").read_bytes())
    assert before["healthy"] and before["safe"] and before["unique_intended_fields"]
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    parent_runtime = json.loads((source / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent_runtime["modules"] and runtime["native_library"] == parent_runtime["native_library"]
    assert all(sha(path) == digest for path, digest in parent_runtime["binaries"].items())
    runtime["binaries"] = parent_runtime["binaries"]
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    prepared = case / "prepared"
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
    assert _body_hold_nodes(prepared) == _body_hold_nodes(source / "prepared")
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert (prepared / name).read_bytes() == (source / "prepared" / name).read_bytes()
    request = json.loads((source / "evaluation/native/native-request.json").read_bytes())
    assert request["backend"] == "libsumo" and request["junction_body_hold"] and request["monitor_interval_s"] is None
    assert tuple(request["junction_body_hold_nodes"]) == _body_hold_nodes(prepared) and request["all_stopped_timeout_s"] == 300
    count = len(ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle"))
    paths = [Path(__file__), prepare_script, SHARED, BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"],
        BASE["AUDIT_HELPER"].parent / "audit_scope.py", case / "proposal.json", case / "scope-proof.json", case / "od-vector.json",
        source / "verdict.json", source / "preflight.json", source / "evaluation/native/native-request.json"]
    paths += list((source / "prepared").iterdir())
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "detector_demand.py", "hamburg_od_spsa.py", "hamburg_readme_results.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    plan = {"source_case": str(source), "source_hashes": {str(path): sha(path) for path in paths},
        "prepared_hashes": {path.name: sha(path) for path in prepared.iterdir()}, "candidate_N": count,
        "source_N": before["after"]["event_count"], "prefix_end_s": proposal["prefix_end_s"],
        "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo"}
    plan_path = case / "measurement-plan.json"
    if plan_path.exists():
        assert json.loads(plan_path.read_bytes()) == plan, "Preserve the recorded inputs and implementation."
    else:
        save(plan_path, plan)
    return {"status": "pass", "runtime": runtime, **plan}


def run(case, checked):
    from astra_sumo.core.detector_demand_replay import run_point_detector_demand
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages
    prepared, evaluation = case / "prepared", case / "evaluation"
    source, count = Path(checked["source_case"]), checked["candidate_N"]
    assert not evaluation.exists() and not (case / "verdict.json").exists(), "Preserve previous and partial runs."
    evaluation.mkdir()
    for name in ("demand.rou.xml", "lane-intentions.json"):
        shutil.copyfile(prepared / name, evaluation / name)
    implementation = case / "measurement-implementation"
    implementation.mkdir()
    for path in checked["source_hashes"]:
        path = Path(path)
        if path.suffix == ".py":
            target = implementation / path.name
            assert not target.exists(), "Do not silently overwrite an implementation snapshot."
            shutil.copyfile(path, target)
    save(case / "preflight.json", {**checked, "implementation_sha256": {path.name: sha(path) for path in implementation.iterdir()}})
    started = time.perf_counter()
    try:
        native = run_point_detector_demand(net_file=prepared / "network.net.xml", route_file=prepared / "demand.rou.xml",
            e1_additional_file=prepared / "field-loops.add.xml", expected_counts_csv=prepared / "expected-counts.csv",
            output_dir=evaluation / "native", end_s=14400, timeout_seconds=4800, step_length=.1, seed=104, backend="libsumo",
            all_stopped_timeout_s=300, sumo_binary=str(REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe"),
            signal_program_file=prepared / "control.add.xml", lane_intentions_file=prepared / "lane-intentions.json",
            junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared))
        assert native["vehicle_count"] == count and Path(native["stall_monitor"]["traci_module"]).resolve().is_relative_to(REPO / ".venv")
        assert native["stall_monitor"]["native_library"] == checked["runtime"]["native_library"]
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        events = read_contributing_e1_passages(instant_file=evaluation / "native/instant-e1.xml", periodic_file=evaluation / "native/field-counts.xml",
            detector_ids=native["instant_to_periodic_ids"], step_length=.1)
        assert events["reconciled"]
        compact = evaluation / "contributing-passages.json.gz"
        compact.write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        audit = BASE["audit_tools"]()
        measured = audit["evidence"](prepared, evaluation, compact, count)
        fields = {row["vehicle_id"]: row["field_id"] for row in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
        requested = {row.get("id"): row.find("route").get("edges") for row in ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")}
        routes = ET.parse(evaluation / "native/vehicle-routes.xml").getroot().findall("vehicle")
        ids = set(requested)
        identity_checks = {"all_ID_sets_equal": len(routes) == count == len(ids) and ids == fields.keys() == measured["tripinfo"].keys() == {r.get("id") for r in routes} == measured["by_vehicle"].keys(),
            "one_intended_contribution_each": all(len(rows) == 1 and rows[0]["detector_id"] == fields.get(identity) for identity, rows in measured["by_vehicle"].items()),
            "complete_original_routes": all(float(r.get("arrival", "-1")) >= 0 and r.find("route").get("edges") == requested.get(r.get("id")) for r in routes)}
        for name, rows in (("main130", measured["main"]), ("initialization52", measured["initial"]), ("all182", measured["initial"] + measured["main"]),
                ("native208", list(measured["periodic"].values())), ("station40", measured["stations"])):
            audit["table"](evaluation / (name + "-comparison.csv"), rows)
        end = checked["prefix_end_s"]
        old = {(r.get("id"), float(r.get("begin")), float(r.get("end"))): dict(r.attrib)
            for r in ET.parse(source / "evaluation/native/field-counts.xml").getroot().findall("interval") if float(r.get("end")) <= end}
        new = {key: row for key, row in measured["periodic"].items() if key[2] <= end}
        assert len(old) == len(new) == 13 * int(end / 900)
        prefix = {"end_s": end, "rows": len(old), "all_native_attributes_identical": old == new,
            "differences": [{"key": key, "before": old.get(key), "after": new.get(key)} for key in sorted(old.keys() | new.keys()) if old.get(key) != new.get(key)]}
        save(evaluation / "prefix-comparison.json", prefix)
        protected = [r for r in measured["initial"] + measured["main"] if r["detector_id"] in {
            "hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}]
        assert len(protected) == 56
        audit["table"](evaluation / "535-all56.csv", protected)
        after = {key: measured[key] for key in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}
        before = json.loads((source / "verdict.json").read_bytes())["after"]
        verdict = {"status": "diagnostic_measurement_complete", "formal_result": False, "source_N": checked["source_N"], "candidate_N": count,
            "source_parent": before, "after": after, "identity_checks": identity_checks, "unique_intended_fields": all(identity_checks.values()),
            "all53556": audit["metrics"](protected), "healthy": measured["healthy"], "safe": measured["safe"], "prefix": prefix,
            "main130_TAE_delta": after["metrics130"]["TAE"] - before["metrics130"]["TAE"],
            "main130_zero_and_healthy": after["metrics130"]["TAE"] == 0 and measured["healthy"] and measured["safe"] and all(identity_checks.values()),
            "claim_boundary": "Explicit input demand feedback only. All real targets remain. Fitted requests and inherited route/lane/control assumptions do not establish true OD or field control. Native counts, complete trips and unsafe events are measured again; historical assignment is not a derivative."}
    except Exception as error:
        verdict = {"status": "invalid", "formal_result": False, "candidate_N": count, "error": f"{type(error).__name__}: {error}", "partial_outputs_preserved": True}
        (case / "failure.log").write_text(traceback.format_exc(), encoding="utf-8")
    verdict["elapsed_s"] = time.perf_counter() - started
    save(case / "verdict.json", verdict)
    print(json.dumps(verdict, ensure_ascii=False))
    if verdict["status"] == "invalid":
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    case = (ROOT / "cases" / args.case).resolve()
    assert case.parent == ROOT / "cases"
    checked = check(case)
    if args.check_only:
        print(json.dumps({k: checked[k] for k in ("status", "candidate_N", "source_N", "prefix_end_s")}))
    else:
        run(case, checked)
