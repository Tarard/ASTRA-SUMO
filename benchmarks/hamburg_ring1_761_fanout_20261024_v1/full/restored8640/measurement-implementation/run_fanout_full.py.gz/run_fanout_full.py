"""Measure the reviewed761 network with either of two already evaluated demands."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASES = {
    "retained8597": ("outputs/hamburg-119-late-demand-thinning-20261024-v1/cases/remove43", 8597, 324),
    "restored8640": ("outputs/hamburg-535z4-tail-offset-20261024-v1/cases/minus30", 8640, 365),
}
SOURCE, COUNT, PARENT_TAE, CASE = None, None, None, None
CANDIDATE = ROOT / "candidate-v2"
SHARED = REPO / "outputs/hamburg-chronological-count-feedback-20261024-v1/run_case.py"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


API = runpy.run_path(str(SHARED))
BASE = API["BASE"]
MEASURE_SAVE = API["save"]


def measured_save(path, value):
    if path.name == "prefix-comparison.json":
        value.pop("all_native_attributes_identical", None)
        value.update(status="not_applicable", reason="The network differs from time zero; no unchanged prefix is claimed.")
    if path == CASE / "verdict.json":
        value.update(study_role="761_native_fanout_with_fixed_parent_demand", demand_unchanged=True,
            claim_boundary=f"Only the declared761 fanout and native internal group-length representation differ from this case's parent. All{COUNT} complete requests, control definitions, driving rules and real observations stay fixed. Full native counts and health are remeasured; count fit does not establish field topology, true OD or field SPaT.")
    MEASURE_SAVE(path, value)


API["run"].__globals__["save"] = measured_save


def evidence_gate():
    manifest = json.loads((CANDIDATE / "manifest.json").read_bytes())
    assert manifest["status"] == "review_required" and manifest["checks"] and all(manifest["checks"].values())
    assert manifest["source_unchanged"] and sha(CANDIDATE / "network.net.xml") == manifest["candidate_sha256"]
    assert sha(CANDIDATE / "candidate.net.xml") == manifest["candidate_sha256"]
    assert all(sha(path) == digest for path, digest in manifest["source_hashes"].items())
    independent = json.loads((ROOT / "independent-candidate.json").read_bytes())
    assert independent["checks"] and all(independent["checks"].values())
    assert independent["candidate_sha256"] == manifest["candidate_sha256"]
    assert independent["manifest_sha256"] == sha(CANDIDATE / "manifest.json")
    for row in independent["source_hashes"]:
        assert sha(row["path"]) == row["sha256"]
    binding = json.loads((ROOT / "smoke/candidate-binding.json").read_bytes())
    assert binding["network_sha256"] == manifest["candidate_sha256"] and binding["manifest_sha256"] == sha(CANDIDATE / "manifest.json")
    for label in ("source", "candidate"):
        result = json.loads((ROOT / f"smoke/native-{label}/result.json").read_bytes())
        assert result["status"] == "pass" and result["checks"] and all(result["checks"].values())
        network = SOURCE / "prepared/network.net.xml" if label == "source" else CANDIDATE / "network.net.xml"
        assert result["network_sha256"] == sha(network) and result["control_sha256"] == sha(SOURCE / "prepared/control.add.xml")
    return manifest


def prepare():
    manifest = evidence_gate()
    assert not CASE.exists(), "Preserve prior full inputs and evaluations."
    prepared = CASE / "prepared"
    shutil.copytree(SOURCE / "prepared", prepared)
    shutil.copyfile(CANDIDATE / "network.net.xml", prepared / "network.net.xml")
    scenario = json.loads((prepared / "scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False,
        network_sha256=manifest["candidate_sha256"],
        connection_candidate="At7115619106 only, add native761_0 continuations to existing199#0 lanes1/2, retaining0. Ordinary roads and original curve remain; SUMO derives a new internal group mean logical length. Source-supported hypothesis, not field-turn certification. All parent demand/control/driver/observations unchanged.")
    save(prepared / "scenario.json", scenario)
    save(CASE / "scope-proof.json", {"status": "pass", "candidate_N": COUNT,
        "source_prepared_hashes": {p.name: sha(p) for p in (SOURCE / "prepared").iterdir()},
        "prepared_hashes": {p.name: sha(p) for p in prepared.iterdir()},
        "candidate_manifest_sha256": sha(CANDIDATE / "manifest.json"),
        "claim_boundary": "Fixed-input network comparison after independent static and three-car source/candidate checks. No full-traffic or count result yet."})
    return check()


def check():
    manifest = evidence_gate()
    prepared = CASE / "prepared"
    proof = json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(sha(SOURCE / "prepared" / name) == digest for name, digest in proof["source_prepared_hashes"].items())
    assert all(sha(prepared / name) == digest for name, digest in proof["prepared_hashes"].items())
    assert sha(prepared / "network.net.xml") == manifest["candidate_sha256"]
    for path in (SOURCE / "prepared").iterdir():
        if path.name not in ("network.net.xml", "scenario.json"):
            assert path.read_bytes() == (prepared / path.name).read_bytes()
    assert len(ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")) == COUNT
    before = json.loads((SOURCE / "verdict.json").read_bytes())
    assert before["healthy"] and before["safe"] and before["unique_intended_fields"] and before["after"]["metrics130"]["TAE"] == PARENT_TAE
    assert before["after"]["event_count"] == COUNT
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    parent = json.loads((SOURCE / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent["modules"] and runtime["native_library"] == parent["native_library"]
    assert all(sha(path) == digest for path, digest in parent["binaries"].items())
    runtime.update(binaries=parent["binaries"], child_pythonpath=os.environ["PYTHONPATH"])
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
    assert _body_hold_nodes(prepared) == _body_hold_nodes(SOURCE / "prepared")
    request = json.loads((SOURCE / "evaluation/native/native-request.json").read_bytes())
    assert request["backend"] == "libsumo" and request["junction_body_hold"] and request["monitor_interval_s"] is None
    assert request["all_stopped_timeout_s"] == 300 and tuple(request["junction_body_hold_nodes"]) == _body_hold_nodes(prepared)
    command = request["command"]
    assert all(float(command[command.index(flag) + 1]) == value for flag, value in (("--end", 14400), ("--step-length", .1), ("--seed", 104)))
    paths = [Path(__file__), SHARED, API["SHARED"], BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"], BASE["AUDIT_HELPER"].parent / "audit_scope.py",
        CANDIDATE / "manifest.json", ROOT / "independent-candidate.json", ROOT / "smoke/candidate-binding.json", ROOT / "smoke/plan.json",
        ROOT / "smoke/native-source/result.json", ROOT / "smoke/native-candidate/result.json", CASE / "scope-proof.json",
        SOURCE / "verdict.json", SOURCE / "preflight.json", SOURCE / "evaluation/native/native-request.json"]
    paths += list((SOURCE / "prepared").iterdir())
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "detector_demand.py", "hamburg_od_spsa.py", "hamburg_readme_results.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py", "hamburg_761_connection_support.py")]
    plan = {"source_case": str(SOURCE), "source_hashes": {str(path): sha(path) for path in paths},
        "prepared_hashes": {p.name: sha(p) for p in prepared.iterdir()}, "candidate_N": COUNT, "source_N": COUNT,
        "prefix_end_s": 0, "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo", "demand_unchanged": True}
    target = CASE / "measurement-plan.json"
    if target.exists():
        assert json.loads(target.read_bytes()) == plan, "Preserve the bound implementation and inputs."
    else:
        save(target, plan)
    return {"status": "pass", "runtime": runtime, **plan}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=CASES, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare", action="store_true")
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    source_name, COUNT, PARENT_TAE = CASES[args.case]
    SOURCE, CASE = REPO / source_name, ROOT / "full" / args.case
    checked = prepare() if args.prepare else check()
    if args.run:
        API["run"](CASE, checked)
    else:
        print(json.dumps({k: checked[k] for k in ("status", "candidate_N", "source_N", "demand_unchanged")}))
