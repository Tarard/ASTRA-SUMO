"""Compile the one761 static review candidate; do not run traffic."""

import json
from pathlib import Path
import shutil

from astra_sumo.core.candidate_contracts import file_sha256
from astra_sumo.core.hamburg_761_connection_support import materialize_hamburg_761_connection_support


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-late-demand-thinning-20261024-v1/cases/remove43/prepared"
REVIEW = REPO / "outputs/hamburg-445-761-source-audit-20261024-v1/manifest.json"
assert file_sha256(REVIEW) == "b2b91220d59cc22f9e345c4ff05e001f67e1ed09b765a0aa30e23868fac33040"
report = materialize_hamburg_761_connection_support(source_file=SOURCE / "network.net.xml", control_file=SOURCE / "control.add.xml",
    output_dir=ROOT / "candidate-v2", netconvert_binary=REPO / ".venv/Lib/site-packages/sumo/bin/netconvert.exe")
output = ROOT / "candidate-v2/implementation"
output.mkdir()
paths = [Path(__file__), REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_761_connection_support.py",
    REPO / "tests/test_hamburg_761_connection_support.py"]
for path in paths:
    shutil.copyfile(path, output / path.name)
proof = {"status": "review_required", "traffic_simulation_run": False, "source_review_manifest": {"path": str(REVIEW), "sha256": file_sha256(REVIEW)},
    "implementation": {str(path): file_sha256(path) for path in paths},
    "netconvert": {"path": str(REPO / ".venv/Lib/site-packages/sumo/bin/netconvert.exe"), "sha256": file_sha256(REPO / ".venv/Lib/site-packages/sumo/bin/netconvert.exe")},
    "claim_boundary": "V1 and MAP lane ordinals support review of a fan-out. They do not supply these native curves or independent field-turn proof. All failed development builds and candidate-v1 metadata history remain separate; v2 reports the actual three-native-arc mean and explicitly excludes declared internal lane.length normalization from the width/access/LC guard."}
(ROOT / "candidate-v2/source-support.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: report.get(key) for key in ("status", "candidate_file", "candidate_sha256", "checks", "geometry", "error")}))
