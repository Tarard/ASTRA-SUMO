"""Prepare three ordinary-entry fan-out witnesses; traffic execution is explicit."""

import argparse
from collections import Counter
from copy import deepcopy
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import shutil
import time
import xml.etree.ElementTree as ET

from astra_sumo.core.local_network_conversion import loaded_turn_permissions


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / "outputs/hamburg-119-late-demand-thinning-20261024-v1/cases/remove43"
CANDIDATE = ROOT.parent / "candidate-v2/candidate.net.xml"
RUNTIME_HELPER = REPO / "outputs/hamburg-119-saturated-service-20261024-v1/run_fixture.py"
INPUTS = ROOT / "inputs"
END = 1200
INCOMING, RECEIVING = "761590046", "199500674#0"
SPECS = (("od_0016_v00001", "hh_0119_Z_12_31546", 0, 0),
         ("od_0016_v00000", "hh_0119_Z_13_34018", 1, 5),
         ("od_0013_v00000", "hh_0119_Z_11_28853", 2, 10))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def runtime():
    spec = spec_from_file_location("existing_fixture_runtime", RUNTIME_HELPER)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    info, api = module.check_runtime()
    binary = REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe"
    info["sumo_binary"] = dict(path=str(binary), sha256=sha(binary))
    return info, api


def path_support(network, candidate):
    root = ET.parse(network).getroot()
    permissions = loaded_turn_permissions(root)
    routes = ET.parse(INPUTS / "demand.rou.xml").getroot().findall("vehicle")
    for vehicle in routes:
        edges = vehicle.find("route").get("edges").split()
        assert len(edges) == len(set(edges))
        assert all(any(key[0] == a and key[2] == b and "passenger" in modes for key, modes in permissions.items()) for a, b in zip(edges, edges[1:]))
    movements = {}
    for lane in range(3):
        key = INCOMING, 0, RECEIVING, lane
        found = [c for c in root.findall("connection") if (c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))) == key]
        if not found:
            assert not candidate and lane in (1, 2)
            movements[str(lane)] = dict(available=False, key=list(key), via_lanes=[])
            continue
        assert len(found) == 1 and "passenger" in permissions[key]
        via, chain = found[0].get("via"), []
        while via:
            assert via not in chain
            chain.append(via)
            edge, index = via.rsplit("_", 1)
            onward = [c for c in root.findall("connection") if c.get("from") == edge and c.get("fromLane") == index]
            assert len(onward) == 1
            via = onward[0].get("via")
        movements[str(lane)] = dict(available=True, key=list(key), via_lanes=chain)
    return movements


def prepare():
    assert not INPUTS.exists(), "Preserve prepared inputs."
    INPUTS.mkdir(parents=True)
    source = ET.parse(SOURCE / "prepared/demand.rou.xml").getroot()
    old = {v.get("id"): v for v in source.findall("vehicle")}
    intents = {r["vehicle_id"]: r for r in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    demand, jobs, assigned = ET.Element("routes", source.attrib), [], []
    for element in source:
        if element.tag != "vehicle":
            demand.append(deepcopy(element))
    lanes = {lane.get("id"): lane for lane in ET.parse(SOURCE / "prepared/network.net.xml").getroot().iter("lane")}
    for identity, field, target, depart in SPECS:
        original = old[identity]
        assert intents[identity]["field_id"] == field
        vehicle = deepcopy(original)
        vehicle.set("depart", str(depart))
        edges = vehicle.find("route").get("edges").split()
        assert edges[:3] == ["44532531", INCOMING, RECEIVING]
        waypoint = ET.Element("stop", lane=f"{RECEIVING}_{target}", endPos=f"{float(lanes[f'{RECEIVING}_{target}'].get('length')) - 7.5:.9f}", speed="13.888889")
        vehicle.insert(list(vehicle).index(vehicle.find("stop")), waypoint)
        demand.append(vehicle)
        jobs.append(dict(vehicle_id=identity, source_field=field, depart_s=depart, target_receiver_lane=target,
            probe_only_moving_waypoint=waypoint.attrib, original_field_stops=[r.attrib for r in original.findall("stop")], complete_original_route=edges))
        assigned.append(dict(vehicle_id=identity, field_id=field))
    ET.ElementTree(demand).write(INPUTS / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    save(INPUTS / "lane-intentions.json", dict(vehicles=assigned, claim="Three toy requests; original field assignment only, no OD estimate."))
    paths = [SOURCE / "prepared" / n for n in ("demand.rou.xml", "lane-intentions.json", "network.net.xml", "control.add.xml", "field-loops.add.xml")]
    paths += [SOURCE / "evaluation/native" / n for n in ("native-request.json", "e1.add.xml", "instant.add.xml")]
    paths += [Path(__file__), RUNTIME_HELPER]
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / n for n in ("simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py", "local_network_conversion.py")]
    save(ROOT / "plan.json", dict(schema="astra.hamburg.761-fanout-smoke-plan/v1", status="prepared_unbound_candidate", native_runs=0,
        source_hashes={str(path): sha(path) for path in paths}, inputs={p.name: sha(p) for p in INPUTS.iterdir()}, jobs=jobs,
        source_network=str(SOURCE / "prepared/network.net.xml"), control=str(SOURCE / "prepared/control.add.xml"), candidate_network=str(CANDIDATE),
        end_s=END, step_s=.1, seed=104, backend="libsumo", vehicles=3,
        driving="Original vType, complete routes, original field moving-stops and unchanged core field/body LaneSectionHold. Only toy departure0/5/10 plus one native moving waypoint each. No speed/position/lane/TLS setters.",
        claim_boundary="Actual via-to-receiver support for three ordinary-entry cars only; not full-traffic safety, capacity, real OD or count calibration. Source may reach receiver lanes1/2 by downstream LC; that is not direct fan-out coverage."))
    return check(False)


def check(require_candidate=True):
    plan = json.loads((ROOT / "plan.json").read_bytes())
    assert all(sha(path) == digest for path, digest in plan["source_hashes"].items())
    assert all(sha(INPUTS / name) == digest for name, digest in plan["inputs"].items())
    source = ET.parse(SOURCE / "prepared/demand.rou.xml").getroot()
    toy = ET.parse(INPUTS / "demand.rou.xml").getroot()
    original = {v.get("id"): v for v in source.findall("vehicle")}
    assert [ET.tostring(v) for v in source if v.tag != "vehicle"] == [ET.tostring(v) for v in toy if v.tag != "vehicle"]
    assert len(toy.findall("vehicle")) == 3
    for vehicle, job in zip(toy.findall("vehicle"), plan["jobs"], strict=True):
        restored = deepcopy(vehicle)
        assert restored.findall("stop")[0].attrib == job["probe_only_moving_waypoint"]
        restored.remove(restored.findall("stop")[0])
        restored.set("depart", original[job["vehicle_id"]].get("depart"))
        assert ET.tostring(restored) == ET.tostring(original[job["vehicle_id"]])
        assert float(vehicle.get("depart")) == job["depart_s"]
    source_support = path_support(SOURCE / "prepared/network.net.xml", False)
    bound = ROOT / "candidate-binding.json"
    if require_candidate:
        binding = json.loads(bound.read_bytes())
        assert sha(CANDIDATE) == binding["network_sha256"] and sha(Path(binding["manifest"])) == binding["manifest_sha256"]
        assert path_support(CANDIDATE, True) == binding["movements"]
    return dict(status="pass", native_runs=0, candidate_bound=bound.exists(), source_support=source_support)


def bind_candidate():
    check(False)
    assert not (ROOT / "candidate-binding.json").exists()
    manifest_path = CANDIDATE.parent / "manifest.json"
    manifest = json.loads(manifest_path.read_bytes())
    assert manifest["checks"] and all(manifest["checks"].values()) and manifest["source_unchanged"]
    assert sha(CANDIDATE) == manifest["candidate_sha256"]
    assert sha(SOURCE / "prepared/control.add.xml") == manifest["control_sha256"]
    movements = path_support(CANDIDATE, True)
    save(ROOT / "candidate-binding.json", dict(network=str(CANDIDATE), network_sha256=sha(CANDIDATE), manifest=str(manifest_path),
        manifest_sha256=sha(manifest_path), control_sha256=sha(SOURCE / "prepared/control.add.xml"), movements=movements))
    return check()


def run(label):
    check()
    info, api = runtime()
    from astra_sumo.core.simulation_stall import monitor_sumo
    out = ROOT / ("native-" + label)
    out.mkdir(exist_ok=False)
    network = CANDIDATE if label == "candidate" else SOURCE / "prepared/network.net.xml"
    for name, tag, filename in (("e1.add.xml", "inductionLoop", "field-counts.xml"), ("instant.add.xml", "instantInductionLoop", "instant-e1.xml")):
        tree = ET.parse(SOURCE / "evaluation/native" / name)
        for row in tree.getroot().findall(tag):
            row.set("file", str(out / filename))
            if tag == "inductionLoop":
                row.set("end", str(END))
        tree.write(out / name, encoding="utf-8", xml_declaration=True)
    request = json.loads((SOURCE / "evaluation/native/native-request.json").read_bytes())
    command = [value.replace(str(SOURCE / "evaluation/native"), str(out)) for value in request["command"]]
    for flag, value in {"--net-file": network, "--route-files": INPUTS / "demand.rou.xml", "--end": END,
        "--additional-files": ",".join(map(str, (SOURCE / "prepared/control.add.xml", out / "e1.add.xml", out / "instant.add.xml")))}.items():
        command[command.index(flag) + 1] = str(value)
    command += ["--fcd-output", str(out / "fcd.xml"), "--lanechange-output", str(out / "lanechanges.xml")]
    request.update(command=command, end_s=END, monitor_file=str(out / "stall-monitor.json"), route_file=str(INPUTS / "demand.rou.xml"),
        lane_intentions_file=str(INPUTS / "lane-intentions.json"), e1_file=str(SOURCE / "prepared/field-loops.add.xml"))
    save(out / "native-request.json", request)
    save(out / "runtime.json", info)
    shutil.copyfile(__file__, out / "executed-runner.py")
    modes, lane_modes, focal_modes, held_samples = set(), set(), [], []
    original_step = api.simulationStep
    def observed_step(*args, **kwargs):
        value = original_step(*args, **kwargs)
        for identity in api.vehicle.getIDList():
            speed_mode, lane_mode = api.vehicle.getSpeedMode(identity), api.vehicle.getLaneChangeMode(identity)
            lane = api.vehicle.getLaneID(identity)
            modes.add(speed_mode)
            lane_modes.add(lane_mode)
            sample = dict(vehicle_id=identity, api_time_s=api.simulation.getTime(), native_time_s=round(api.simulation.getTime() - .1, 10),
                lane=lane, position_m=api.vehicle.getLanePosition(identity), speed_mode=speed_mode, lane_change_mode=lane_mode)
            if lane.startswith((INCOMING + "_", RECEIVING + "_", ":7115619106_")):
                focal_modes.append(sample)
            if lane_mode == 512:
                held_samples.append(sample)
        if api.simulation.getCollidingVehiclesNumber() or api.simulation.getStartingTeleportNumber():
            raise RuntimeError("Unsafe collision or teleport; preserve this fixture output.")
        return value
    api.simulationStep = observed_step
    started = time.perf_counter()
    try:
        monitor_sumo(request)
    finally:
        api.simulationStep = original_step
        save(out / "speed-modes.json", sorted(modes))
        save(out / "lane-change-modes.json", dict(observed_modes=sorted(lane_modes), original_allowed_modes=[1621, 512],
            existing_hold512_samples=held_samples, focal_761_711_199_samples=focal_modes,
            sampling="Read-only after real simulationStep, before the unchanged core hold callback for that step."))
    audit(label, time.perf_counter() - started)


def audit(label, elapsed):
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages
    out = ROOT / ("native-" + label)
    plan = json.loads((ROOT / "plan.json").read_bytes())
    network = CANDIDATE if label == "candidate" else SOURCE / "prepared/network.net.xml"
    paths = path_support(network, label == "candidate")
    histories = {job["vehicle_id"]: [] for job in plan["jobs"]}
    for _, step in ET.iterparse(out / "fcd.xml", events=("end",)):
        if step.tag == "timestep":
            for vehicle in step.findall("vehicle"):
                histories[vehicle.get("id")].append(dict(native_time_s=float(step.get("time")), lane=vehicle.get("lane")))
            step.clear()
    coverage = []
    for job in plan["jobs"]:
        history = histories[job["vehicle_id"]]
        actual = []
        for lane, path in paths.items():
            indices = [i for i, row in enumerate(history) if row["lane"] in path["via_lanes"]]
            if indices:
                receiving = next((r for r in history[max(indices) + 1:] if not r["lane"].startswith(":")), None)
                actual.append(dict(receiver_lane=int(lane), via_lanes=sorted({history[i]["lane"] for i in indices}),
                    first_via_native_s=history[min(indices)]["native_time_s"], first_receiving_sample=receiving))
        covered = any(r["receiver_lane"] == job["target_receiver_lane"] and r["first_receiving_sample"] and
            r["first_receiving_sample"]["lane"] == f"{RECEIVING}_{job['target_receiver_lane']}" for r in actual)
        coverage.append(dict(vehicle_id=job["vehicle_id"], desired_lane=job["target_receiver_lane"], actual_direct_movements=actual, requested_direct_movement_covered=covered))
    loops = [ET.parse(out / n).getroot() for n in ("instant.add.xml", "e1.add.xml")]
    mapping = {r.get("id"): next(p.get("id") for p in loops[1] if p.get("lane") == r.get("lane") and p.get("pos") == r.get("pos")) for r in loops[0]}
    events = read_contributing_e1_passages(instant_file=out / "instant-e1.xml", periodic_file=out / "field-counts.xml", detector_ids=mapping, step_length=.1)
    save(out / "contributing-passages.json", events)
    summary = ET.parse(out / "summary.xml").getroot().findall("step")[-1].attrib
    trips = ET.parse(out / "tripinfo.xml").getroot().findall("tripinfo")
    routes = ET.parse(out / "vehicle-routes.xml").getroot().findall("vehicle")
    monitor = json.loads((out / "stall-monitor.json").read_bytes())
    mode_report = json.loads((out / "lane-change-modes.json").read_bytes())
    requested = {job["vehicle_id"]: job for job in plan["jobs"]}
    checks = dict(all_three_inserted_arrived=all(int(summary[k]) == 3 for k in ("loaded", "inserted", "arrived")),
        zero_unfinished_unsafe=all(int(summary[k]) == 0 for k in ("running", "waiting", "collisions", "teleports", "discarded")) and not ET.parse(out / "collisions.xml").getroot().findall("collision"),
        complete_IDs_routes={r.get("id") for r in routes} == {r.get("id") for r in trips} == requested.keys() and all(float(r.get("arrival", "-1")) >= 0 and
            r.find("route").get("edges").split() == requested[r.get("id")]["complete_original_route"] for r in routes),
        unique_expected_fields=events["reconciled"] and Counter((r["vehicle_id"], r["detector_id"]) for r in events["passages"]) == Counter((r["vehicle_id"], r["source_field"]) for r in plan["jobs"]),
        monitor_completed=monitor["status"] == "completed" and monitor["library_completed"], speed_mode31=json.loads((out / "speed-modes.json").read_bytes()) == [31],
        original_LC_modes_only=set(mode_report["observed_modes"]) <= {1621, 512},
        focal_speed_mode31=bool(mode_report["focal_761_711_199_samples"]) and all(r["speed_mode"] == 31 for r in mode_report["focal_761_711_199_samples"]),
        actual_three_movements_covered=all(r["requested_direct_movement_covered"] for r in coverage) if label == "candidate" else True)
    check()
    save(out / "result.json", dict(schema="astra.hamburg.761-fanout-smoke/v1", status="pass" if all(checks.values()) else "review_required", label=label,
        native_runs=1, checks=checks, coverage=coverage, completion=summary, elapsed_s=elapsed, MAE=None, formal_result=False,
        network_sha256=sha(network), control_sha256=sha(SOURCE / "prepared/control.add.xml"),
        claim_boundary="Small ordinary-entry route/via support only. Source downstream lane changes are distinct from direct candidate fan-out. No capacity, full-traffic safety or count-fit claim."))
    print(json.dumps(checks))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare-only", action="store_true")
    action.add_argument("--bind-candidate", action="store_true")
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", choices=("source", "candidate"))
    args = parser.parse_args()
    if args.prepare_only:
        print(json.dumps(prepare()))
    elif args.bind_candidate:
        print(json.dumps(bind_candidate()))
    elif args.check_only:
        print(json.dumps(check()))
    else:
        run(args.run)
