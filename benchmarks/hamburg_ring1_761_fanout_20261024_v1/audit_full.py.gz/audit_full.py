"""Recheck one terminal fixed-demand761 comparison with existing raw evidence helpers."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stats(data):
    return {key: data[key] for key in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("retained8597", "restored8640"), required=True)
    args = parser.parse_args()
    case = (ROOT / "full" / args.case).resolve()
    assert case.parent == ROOT / "full" and (case / "verdict.json").exists(), "Wait for a terminal verdict."
    assert not (case / "independent.json").exists(), "Preserve the completed audit."
    verdict, plan, preflight = [load(case / name) for name in ("verdict.json", "measurement-plan.json", "preflight.json")]
    assert verdict["status"] == "diagnostic_measurement_complete"
    assert all(sha(path) == digest for path, digest in plan["source_hashes"].items())
    assert all(sha(case / "prepared" / name) == digest for name, digest in plan["prepared_hashes"].items())
    source_prepared = Path(plan["source_case"]) / "prepared"
    assert plan["demand_unchanged"] is True
    assert set(plan["prepared_hashes"]) == {path.name for path in source_prepared.iterdir()}
    assert all((case / "prepared" / name).read_bytes() == (source_prepared / name).read_bytes()
        for name in plan["prepared_hashes"] if name not in {"network.net.xml", "scenario.json"})
    assert sha(case / "prepared/network.net.xml") == "91f94db4dcef1201b4ccdaa03a2c1b3cfdac3072fdb7af947fa8b4f981a73697"

    for path, digest in plan["source_hashes"].items():
        if Path(path).suffix == ".py":
            assert sha(case / "measurement-implementation" / Path(path).name) == digest
    assert all(sha(case / "measurement-implementation" / name) == digest for name, digest in preflight["implementation_sha256"].items())
    runtime = preflight["runtime"]
    assert all(sha(path) == digest for path, digest in runtime["binaries"].items())
    for module in runtime["modules"].values():
        assert module["version"] == "1.27.1" and Path(module["path"]).resolve().is_relative_to(REPO / ".venv")
        assert sha(module["path"]) == module["sha256"]
    assert sha(runtime["native_library"]["path"]) == runtime["native_library"]["sha256"]
    sys.path.insert(0, str(HELPER.parent))
    sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
    tools = runpy.run_path(str(HELPER))
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages
    source, data, hashes = Path(plan["source_case"]), {}, dict(plan["source_hashes"])
    for label, folder in (("source", source), ("candidate", case)):
        vehicles = ET.parse(folder / "prepared/demand.rou.xml").getroot().findall("vehicle")
        count = len(vehicles)
        assert count == plan["source_N" if label == "source" else "candidate_N"]
        evidence = tools["evidence"](folder / "prepared", folder / "evaluation", folder / "evaluation/contributing-passages.json.gz", count)
        data[label] = evidence
        hashes.update(evidence["source_hashes"])
        if label == "candidate":
            assert count == plan["candidate_N"] == verdict["candidate_N"]
            native = load(folder / "evaluation/native/run.json")
            monitor = load(folder / "evaluation/native/stall-monitor.json")
            assert native["native_status"] == "pass" and not native["errors"] and native["inputs_unchanged"]
            assert native["vehicle_count"] == count and monitor["status"] == "completed" and monitor["library_completed"]
            assert monitor["simulation_time_s"] == 14400 and monitor["native_library"] == runtime["native_library"]
            assert Path(monitor["traci_module"]).resolve().is_relative_to(REPO / ".venv")
            raw = read_contributing_e1_passages(instant_file=folder / "evaluation/native/instant-e1.xml", periodic_file=folder / "evaluation/native/field-counts.xml",
                detector_ids=native["instant_to_periodic_ids"], step_length=.1)
            with gzip.open(folder / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
                assert raw == json.load(handle)
            fields = {row["vehicle_id"]: row["field_id"] for row in load(folder / "prepared/lane-intentions.json")["vehicles"]}
            requested = {row.get("id"): row.find("route").get("edges") for row in vehicles}
            routes = ET.parse(folder / "evaluation/native/vehicle-routes.xml").getroot().findall("vehicle")
            assert count == len(requested) == len(fields) == len(routes)
            assert requested.keys() == fields.keys() == evidence["tripinfo"].keys() == evidence["by_vehicle"].keys() == {row.get("id") for row in routes}
            assert all(len(rows) == 1 and rows[0]["detector_id"] == fields[identity] for identity, rows in evidence["by_vehicle"].items())
            assert all(float(row.get("arrival", "-1")) >= 0 and row.find("route").get("edges") == requested[row.get("id")] for row in routes)
    before, after = data["source"], data["candidate"]
    assert verdict["after"] == stats(after) and verdict["source_parent"] == stats(before)
    assert all(verdict["identity_checks"].values())
    expected_n, parent_tae = {"retained8597": (8597, 324), "restored8640": (8640, 365)}[args.case]
    assert plan["candidate_N"] == plan["source_N"] == expected_n and before["metrics130"]["TAE"] == parent_tae
    prefix = load(case / "evaluation/prefix-comparison.json")
    assert plan["prefix_end_s"] == prefix["end_s"] == 0 and prefix["rows"] == 0
    assert prefix["status"] == "not_applicable" and "all_native_attributes_identical" not in prefix
    assert verdict["prefix"] == prefix and verdict["demand_unchanged"] is True
    protected = [row for row in after["initial"] + after["main"] if row["detector_id"] in {
        "hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}]
    assert len(protected) == 56 and verdict["all53556"] == tools["metrics"](protected)
    for path in (Path(__file__), HELPER, HELPER.parent / "audit_scope.py", case / "verdict.json", case / "preflight.json", case / "measurement-plan.json",
        case / "evaluation/native/vehicle-routes.xml", case / "evaluation/native/sumo-errors.log"):
        hashes[str(path)] = sha(path)
    result = {"schema": "astra.hamburg.761-fixed-demand-independent/v1", "audit_status": "pass", "native_runs_by_audit": 0, "formal_result": False,
        "source_N": plan["source_N"], "candidate_N": plan["candidate_N"],
        "after": stats(after), "source": stats(before), "main130_TAE_delta": after["metrics130"]["TAE"] - before["metrics130"]["TAE"],
        "all53556": tools["metrics"](protected), "prefix": prefix, "all_IDs_routes_and_one_intended_event_each": True, "only_network_and_scenario_changed": True,
        "raw_instant_equals_compact": True, "runtime_and_snapshots_verified": True, "source_hashes": hashes,
        "claim_boundary": "Actual fixed-demand network comparison only. Each case is compared with its own already-measured parent. Prefix parity is not applicable because the network changes from time zero. Count response does not establish field topology, true OD or field SPaT. No simulation runs in this audit."}
    tools["save"](case / "independent.json", result)
    print(json.dumps({key: value for key, value in result.items() if key != "source_hashes"}))


if __name__ == "__main__":
    main()
