"""Audit the sealed spread once; check-only never reads active native XML."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import runpy
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
CASE = ROOT / "spread15"
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}
STAT_KEYS = ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check():
    history = CASE / "metadata-correction-history"
    old, new = load(history / "scenario.json"), load(CASE / "prepared/scenario.json")
    delta = {k: [old.get(k), new.get(k)] for k in old.keys() | new.keys() if old.get(k) != new.get(k)}
    assert set(delta) == {"demand_prior"}
    previous, scope = load(history / "scope-proof.json"), load(CASE / "scope-proof.json")
    assert all(value == scope["prepared_hashes"][name] for name, value in previous["prepared_hashes"].items() if name != "scenario.json")
    assert sha(CASE / "scope-proof.json") == "e03745b9cdbc77f1c1dd0cf9a2abd69c6439342d3865e5cd50874d249bb6feb0"
    assert all(sha(path) == value for path, value in scope["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in scope["prepared_hashes"].items())
    assert scope["actual_changes"]["depart_only_vehicles"] == 521 and scope["actual_changes"]["native_bin_crossings"] == 55
    plan, preflight = load(ROOT / "measurement-plan.json"), load(CASE / "preflight.json")
    assert all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert plan["prepared_hashes"] == scope["prepared_hashes"]
    assert preflight["scope_sha256"] == sha(CASE / "scope-proof.json") and preflight["measurement_plan_sha256"] == sha(ROOT / "measurement-plan.json")
    assert sha(CASE / "executed-driver.py") == sha(ROOT / "run_spread.py") == "22037d5d9a042295859499275915c4c5bd2bbcf68cb0a2d1cb3603936ead36b8"
    assert all(sha(CASE / "implementation" / n) == value for n, value in preflight["implementation_sha256"].items())
    assert all(sha(CASE / "measurement-implementation" / Path(path).name) == value for path, value in plan["source_hashes"].items() if Path(path).suffix == ".py")
    runtime = preflight["runtime"]
    assert all(sha(path) == value for path, value in runtime["binaries"].items())
    assert all(module["version"] == "1.27.1" and sha(module["path"]) == module["sha256"] and Path(module["path"]).resolve().is_relative_to(REPO / ".venv") for module in runtime["modules"].values())
    assert sha(runtime["native_library"]["path"]) == runtime["native_library"]["sha256"]
    gate = preflight["source_full_health_gate"]
    assert gate["sha256"] == sha(SOURCE / "verdict.json") and gate["parent_main130_MAE"] == 421 / 130
    assert load(SOURCE / "verdict.json")["after"]["metrics130"]["TAE"] == 421
    assert all((CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes() for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"))
    return {"status": "pass", "native_runs": 0, "metadata_delta": delta, "other_seven_prepared_hashes_unchanged": True, "scope_sha256": sha(CASE / "scope-proof.json"), "parent_main130_MAE": gate["parent_main130_MAE"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    checked = check()
    if args.check_only:
        print(json.dumps(checked, ensure_ascii=False))
        return
    assert (CASE / "verdict.json").is_file(), "Terminal verdict required; no active native XML is read."
    assert not (OUT / "summary.json").exists(), "Preserve the sealed independent result."
    verdict = load(CASE / "verdict.json")
    assert verdict["status"] == "diagnostic_measurement_complete", "Do not reinterpret invalid partial native output."
    sys.path.insert(0, str(HELPER.parent))
    tools = runpy.run_path(str(HELPER))
    data = {label: tools["evidence"](case / "prepared", case / "evaluation", case / "evaluation/contributing-passages.json.gz", 8640) for label, case in (("parent_209_full", SOURCE), ("spread15", CASE))}
    before, after = data["parent_209_full"], data["spread15"]
    assert before["metrics130"]["TAE"] == 421 and verdict["source_209_parent"] == {k: before[k] for k in STAT_KEYS}
    assert verdict["after"] == {k: after[k] for k in STAT_KEYS}
    run, monitor = load(CASE / "evaluation/native/run.json"), load(CASE / "evaluation/native/stall-monitor.json")
    assert not run["errors"] and run["native_status"] == "pass" and run["inputs_unchanged"]
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400 and monitor["library_completed"] is True and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"] and monitor["native_library"] == load(CASE / "preflight.json")["runtime"]["native_library"]
    assert all(Path(monitor[k]).resolve().is_relative_to(REPO / ".venv") for k in ("api_module", "traci_module"))
    vehicles = {v.get("id"): v for v in ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle")}
    fields = {r["vehicle_id"]: r["field_id"] for r in load(CASE / "prepared/lane-intentions.json")["vehicles"]}
    assert len(vehicles) == 8640 and fields.keys() == vehicles.keys()
    repeats = [{"vehicle_id": i, "field": field, "count": n} for i, events in after["by_vehicle"].items() for field, n in Counter(e["detector_id"] for e in events).items() if n > 1]
    outside = [{"vehicle_id": i, "actual_field": e["detector_id"], "intended_field": fields.get(i)} for i, events in after["by_vehicle"].items() for e in events if e["detector_id"] != fields.get(i)]
    unique = all(len(after["by_vehicle"].get(i, [])) == 1 and after["by_vehicle"][i][0]["detector_id"] == field for i, field in fields.items())
    assert repeats == verdict["repeated_vehicle_fields"] and outside == verdict["contributions_outside_prior_primary_intention"]
    assert verdict["unique_intended_fields"] == (unique and not repeats and not outside)
    protected = [r for r in after["initial"] + after["main"] if r["detector_id"] in FIELDS535]
    assert len(protected) == 56 and tools["metrics"](protected) == verdict["all53556"]
    rows = []
    for field in sorted(set(fields.values())):
        row = {"field": field}
        for label, measured in data.items():
            for region, source_rows in (("main", measured["main"]), ("initial", measured["initial"]), ("all182", measured["initial"] + measured["main"])):
                subset = [r for r in source_rows if r["detector_id"] == field]
                row.update({f"{label}_{region}_{k}": value for k, value in tools["metrics"](subset).items() if k in {"TAE", "SSE"}})
                row[f"{label}_{region}_signed"] = sum(int(r["diff_nVehContrib_minus_expected"]) for r in subset)
        rows.append(row)
    tools["table"](OUT / "field13.csv", rows)
    for name, source_rows in (("main130", after["main"]), ("initialization52", after["initial"]), ("all182", after["initial"] + after["main"]), ("station40", after["stations"]), ("native208", list(after["periodic"].values()))):
        tools["table"](OUT / (name + ".csv"), source_rows)
    terminal = []
    for i, vehicle in vehicles.items():
        trip = after["tripinfo"].get(i)
        if trip is None or float(trip["arrival"]) < 0:
            edges = vehicle.find("route").get("edges").split()
            terminal.append({"vehicle_id": i, "origin": edges[0], "destination": edges[-1], "field": fields[i], "requested_depart_s": vehicle.get("depart"), "status": "waiting" if trip is None else "running", "completed_fields": [e["detector_id"] for e in after["by_vehicle"].get(i, [])]})
    assert Counter(r["status"] for r in terminal) == Counter({k: after["completion"][k] for k in ("waiting", "running")})
    tools["table"](OUT / "terminal-vehicles.csv", terminal)
    result = {"schema": "astra.hamburg.209-Z5-spread-independent/v1", "audit_status": "pass", "raw_verdict": verdict["status"], "native_runs_by_audit": 0, "input_revision": checked,
        "before_parent_209": {k: before[k] for k in STAT_KEYS}, "after": {k: after[k] for k in STAT_KEYS}, "all53556": tools["metrics"](protected), "unique_contributing_vehicles": len(after["by_vehicle"]), "one_expected_event_per_request": unique,
        "repeated_vehicle_fields": repeats, "outside_primary": outside, "unknown_vehicle_ids": sorted(after["by_vehicle"].keys() - vehicles.keys()), "terminal_count": len(terminal),
        "claim_boundary": "A raw audit pass is not count-fit success. The parent is the209 full421/130 reference, not the older +15 response. No new SSE/all182 acceptance gate is imposed. Source concentration and toy saturation do not establish full-network capacity causation; actual new events are measured. Unfinished positions are not inferred from tripinfo."}
    tools["save"](OUT / "summary.json", result)
    paths = [Path(__file__), ROOT / "run_spread.py", ROOT / "measurement-plan.json", CASE / "scope-proof.json", CASE / "preflight.json", CASE / "metadata-revision.json", CASE / "verdict.json", HELPER]
    hashes = {str(p): sha(p) for p in paths}
    for measured in data.values():
        hashes.update(measured["source_hashes"])
    tools["save"](OUT / "source-hashes.json", hashes)
    tools["save"](OUT / "manifest.json", {"native_runs": 0, "files": [{"path": p.name, "sha256": sha(p), "size_bytes": p.stat().st_size} for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]})
    print(json.dumps({"audit_status": "pass", "after": result["after"], "parent_main130_MAE": before["metrics130"]["MAE"], "manifest_sha256": sha(OUT / "manifest.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
