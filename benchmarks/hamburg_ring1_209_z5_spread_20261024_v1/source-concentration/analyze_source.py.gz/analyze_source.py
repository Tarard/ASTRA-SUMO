"""Describe sealed Z5 departures and actual complete E1 events; no simulation."""

from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full"
FIELD = "hh_0119_Z_5_30494"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native_bin(value):
    return math.floor(float(value) * 1000 + .5) // 900000


def table(name, rows):
    with (OUT / name).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def quantiles(values):
    return dict(zip(("min", "median", "p90", "max"), map(float, np.quantile(values, [0, .5, .9, 1], method="linear")), strict=True))


def main():
    assert (SOURCE / "verdict.json").is_file()
    vehicles = {v.get("id"): v for v in ET.parse(SOURCE / "prepared/demand.rou.xml").getroot().findall("vehicle")}
    trips = {v.get("id"): v.attrib for v in ET.parse(SOURCE / "evaluation/native/tripinfo.xml").getroot().findall("tripinfo")}
    selected = [r["vehicle_id"] for r in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"] if r["field_id"] == FIELD]
    with gzip.open(SOURCE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        events = [r for r in json.load(handle)["passages"] if r["detector_id"] == FIELD]
    event_by_id = {r["vehicle_id"]: r for r in events}
    assert len(selected) == len(events) == len(event_by_id) == 623 and set(selected) == set(event_by_id)
    rows, groups = [], defaultdict(list)
    for identity in selected:
        vehicle, trip, event = vehicles[identity], trips[identity], event_by_id[identity]
        route = vehicle.find("route").get("edges").split()
        requested, inserted = float(vehicle.get("depart")), float(trip["depart"])
        assert float(trip["arrival"]) >= 0
        row = {"vehicle_id": identity, "origin": route[0], "destination": route[-1], "request_bin": native_bin(requested),
            "requested_depart_s": requested, "native_inserted_depart_s": inserted, "insertion_delay_s": inserted - requested,
            "E1_continuous_leave_s": event["time_s"], "E1_notification_s": event["notification_time_s"], "E1_bin": int(event["interval_begin_s"] / 900),
            "insert_to_E1_notification_lag_s": event["notification_time_s"] - inserted, "request_to_E1_notification_lag_s": event["notification_time_s"] - requested,
            "insert_to_E1_continuous_lag_s": event["time_s"] - inserted, "arrival_s": float(trip["arrival"]), "arrival_lane": trip["arrivalLane"]}
        rows.append(row)
        groups[row["request_bin"]].append(row)
    bins, crossing_rows = [], []
    for h, members in sorted(groups.items()):
        departures = [r["requested_depart_s"] for r in members]
        lo, hi = min(departures), max(departures)
        center, old_mean = (lo + hi) / 2, float(np.mean(departures))
        proposed = [center + 1.5 * (depart - center) if h >= 4 else depart for depart in departures]
        lag = quantiles([r["insert_to_E1_notification_lag_s"] for r in members])
        requested_lag = quantiles([r["request_to_E1_notification_lag_s"] for r in members])
        for row, new_depart in zip(members, proposed, strict=True):
            if native_bin(new_depart) != h:
                crossing_rows.append({"vehicle_id": row["vehicle_id"], "source_bin": h, "new_bin": native_bin(new_depart), "old_depart_s": row["requested_depart_s"], "raw_stretched_depart_s": new_depart})
        bins.append({"request_bin": h, "N": len(members), "source_min_s": lo, "source_max_s": hi, "source_span_s": hi - lo,
            "fixed_minmax_center_s": center, "source_sample_mean_s": old_mean, "raw_stretch_min_s": min(proposed), "raw_stretch_max_s": max(proposed),
            "raw_stretch_sample_mean_s": float(np.mean(proposed)), "sample_mean_delta_s": float(np.mean(proposed)) - old_mean,
            "raw_stretch_cross_bin_N": sum(native_bin(d) != h for d in proposed), "insert_to_E1_notification_lag": json.dumps(lag),
            "request_to_E1_notification_lag": json.dumps(requested_lag), "actual_E1_bins": json.dumps(dict(sorted(Counter(r["E1_bin"] for r in members).items())))})
    tail = [r for r in rows if r["E1_bin"] >= 14]
    assert len(tail) == 74 and sum(len(v) for h, v in groups.items() if h >= 4) == 521
    table("request-bin14.csv", bins)
    table("Z5-vehicles623.csv", rows)
    table("tail74.csv", tail)
    table("raw-stretch-crossings55.csv", crossing_rows)
    files = [SOURCE / n for n in ("verdict.json", "prepared/demand.rou.xml", "prepared/lane-intentions.json", "evaluation/native/tripinfo.xml", "evaluation/contributing-passages.json.gz", "evaluation/native/field-counts.xml")]
    save("source-hashes.json", {str(p.relative_to(REPO)): sha(p) for p in files})
    save("summary.json", {"schema": "astra.hamburg.Z5-departure-concentration-source/v1", "audit_status": "pass", "source_field": FIELD,
        "requests_total": 623, "main_request_cohort": 521, "actual_events": {"initial": sum(r["E1_bin"] < 4 for r in rows), "main": sum(4 <= r["E1_bin"] < 14 for r in rows), "tail": len(tail)},
        "tail74": {"request_bins": dict(Counter(r["request_bin"] for r in tail)), "origins": dict(Counter(r["origin"] for r in tail)), "destinations": dict(Counter(r["destination"] for r in tail)), "arrived": 74, "arrival_range_s": [min(r["arrival_s"] for r in tail), max(r["arrival_s"] for r in tail)], "insert_to_E1_notification_lag": quantiles([r["insert_to_E1_notification_lag_s"] for r in tail])},
        "pure_formula_scope": {"scale": 1.5, "center": "original min/max midpoint per native request bin", "selected_bins": list(range(4, 14)), "raw_crossings": len(crossing_rows), "main_to_initial_requests": sum(r["new_bin"] < 4 for r in crossing_rows), "crossings_by_source_bin": dict(Counter(r["source_bin"] for r in crossing_rows)), "range_blocker_if_same_bins_claimed": bool(crossing_rows), "midpoint_preserved_not_sample_mean": True},
        "native_runs_by_audit": 0, "claim_boundary": "Observed lag and departure concentration are descriptive. They do not prove a capacity cause or predict the new E1 bins. Tail events are delayed complete passages with all74 actual arrivals, not terminal backlog. Raw1.5 formula crosses55 prior native bins unless an explicit boundary operation is added; do not silently claim unchanged q or initialization requests. Count truth remains immutable."})
    save("manifest.json", {"files": [{"path": p.name, "size_bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"], "native_runs": 0})
    print(json.dumps({"audit_status": "pass", "crossings": len(crossing_rows), "tail": len(tail), "manifest_sha256": sha(OUT / "manifest.json")}))


if __name__ == "__main__":
    main()
