"""Check the saved spread against immutable explicit requests; no native run."""

from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASE = ROOT / "spread15"
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full/prepared"
FIELD = "hh_0119_Z_5_30494"
proof = json.loads((CASE / "scope-proof.json").read_bytes())
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in proof["source_hashes"].items())
assert all(hashlib.sha256((CASE / "prepared" / name).read_bytes()).hexdigest() == value for name, value in proof["prepared_hashes"].items())
for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
    assert (SOURCE / name).read_bytes() == (CASE / "prepared" / name).read_bytes()
before = {v.get("id"): v for v in ET.parse(SOURCE / "demand.rou.xml").getroot().findall("vehicle")}
after = {v.get("id"): v for v in ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle")}
intent = {row["vehicle_id"]: row for row in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
metadata = {row["vehicle_id"]: row for row in json.loads((CASE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}


def milliseconds(value):
    return int((Decimal(str(value)) * 1000).quantize(Decimal(1), rounding=ROUND_HALF_UP))


selected = {identity for identity, row in before.items() if intent[identity]["field_id"] == FIELD and 4 <= milliseconds(row.get("depart")) // 900000 <= 13}
assert len(selected) == 521 and before.keys() == after.keys() and len(after) == 8640
assert {identity for identity in before if milliseconds(before[identity].get("depart")) != milliseconds(after[identity].get("depart"))} == selected
for h in range(4, 14):
    ids = sorted((identity for identity in selected if milliseconds(before[identity].get("depart")) // 900000 == h), key=lambda identity: Decimal(before[identity].get("depart")))
    old = [Decimal(before[identity].get("depart")) for identity in ids]
    center = (min(old) + max(old)) / 2
    new = [Decimal(after[identity].get("depart")) for identity in ids]
    assert all(abs(actual - (center + Decimal("1.5") * (previous - center))) < Decimal("0.000000001") for previous, actual in zip(old, new, strict=True))
    assert all(a < b for a, b in zip(new, new[1:]))
for identity in before:
    assert before[identity].find("route").attrib == after[identity].find("route").attrib
    assert [ET.tostring(stop) for stop in before[identity].findall("stop")] == [ET.tostring(stop) for stop in after[identity].findall("stop")]
    if identity not in selected:
        assert intent[identity] == metadata[identity]
    else:
        assert metadata[identity]["field_id"] == FIELD
        assert milliseconds(metadata[identity]["depart_s"]) == milliseconds(after[identity].get("depart"))
raw = []
for path in (SOURCE / "demand.rou.xml", CASE / "prepared/demand.rou.xml"):
    raw.append({ET.fromstring(block).get("id"): block for block in re.findall(rb"<vehicle\b[\s\S]*?</vehicle>", path.read_bytes())})
assert all(raw[0][identity] == raw[1][identity] for identity in before.keys() - selected)
vector = json.loads((CASE / "od-vector.json").read_bytes())
q = [0] * 294
for identity, vehicle in after.items():
    edges = vehicle.find("route").get("edges").split()
    od = vector["od_pairs"].index([edges[0], edges[-1]])
    cell = (milliseconds(vehicle.get("depart")) // 900000) * 21 + od
    q[cell] += 1
    assert metadata[identity]["od_cell"] == cell
assert q == vector["values"] and sum(q[:84]) == 1956 and sum(q) == 8640
assert len(vector["metadata_cell_changes"]) == 55
report = {"status": "pass", "native_runs": 0, "selected_and_native_changed": 521, "unselected_raw_xml_identical": 8119,
    "five_protected_inputs_byte_identical": True, "formula_rank_and_metadata": True,
    "actual294_inventory_recomputed": True, "cross_bin_requests": 55, "additional_initialization_requests": 3}
(ROOT / "selfchecks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))
