"""Measure the single saved Z5 spread using the existing full measurement driver."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASE = ROOT / "spread15"
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full"
SHARED = SOURCE.parent / "run_full.py"
SHARED_SHA = "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    if path == CASE / "preflight.json":
        value["source_full_health_gate"] = value.pop("smoke")
        value["measurement_plan_sha256"] = sha(ROOT / "measurement-plan.json")
    if path == CASE / "verdict.json":
        value.update(study_role="one_saved_Z5_departure_spread", new_geometry_smoke_required=False,
            claim_boundary="Only521 source-main-Z5 departures use1.5x expansion around source-bin min/max midpoint.55 native-bin crossings are recorded. Routes, fields, controls and total8640 remain fixed.130/52/182/40/53556,unique events,safety and backlog are all retained. No automatic second round. Departure bins are not passage bins and this is not a hard-capacity or field-certified zero claim.")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


assert sha(SHARED) == SHARED_SHA
BASE = runpy.run_path(str(SHARED))
SHARED_RUN = BASE["run"]


def source_health():
    verdict = json.loads((SOURCE / "verdict.json").read_bytes())
    stats = verdict["after"]
    assert stats["healthy"] is True and stats["safe"] is True and verdict["unique_intended_fields"] is True
    assert stats["metrics130"]["TAE"] == 421 and stats["event_count"] == 8640
    return {"status": "pass", "role": "same_network_control_parent_full_native", "new_geometry_smoke_required": False,
        "path": str(SOURCE / "verdict.json"), "sha256": sha(SOURCE / "verdict.json"),
        "parent_main130_MAE": stats["metrics130"]["MAE"], "parent_healthy": True, "parent_safe": True}


def check():
    runpy.run_path(str(ROOT / "selfcheck.py"))
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    parent_runtime = json.loads((SOURCE / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent_runtime["modules"]
    assert runtime["native_library"] == parent_runtime["native_library"]
    assert all(sha(path) == value for path, value in parent_runtime["binaries"].items())
    runtime["binaries"] = parent_runtime["binaries"]
    for name in ("network.net.xml", "control.add.xml"):
        assert (CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    source_health()
    paths = [Path(__file__), SHARED, ROOT / "selfcheck.py", CASE / "scope-proof.json", SOURCE / "verdict.json", SOURCE / "preflight.json"]
    paths += list((SOURCE / "prepared").iterdir())
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "hamburg_od_spsa.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    paths += [BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"], BASE["AUDIT_HELPER"].parent / "audit_scope.py"]
    plan_path = ROOT / "measurement-plan.json"
    if not plan_path.exists():
        save(plan_path, {"formal_result": False, "source_hashes": {str(path): sha(path) for path in paths},
            "source_health": source_health(), "native_runs": 0,
            "prepared_hashes": json.loads((CASE / "scope-proof.json").read_bytes())["prepared_hashes"],
            "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo"})
    plan = json.loads(plan_path.read_bytes())
    assert all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in plan["prepared_hashes"].items())
    return {"status": "pass", "native_runs": 0, "runtime": runtime, "source_health": source_health()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    checked = check()
    if args.check_only:
        print(json.dumps({key: value for key, value in checked.items() if key != "runtime"}))
    else:
        assert not (CASE / "evaluation").exists() and not (CASE / "verdict.json").exists(), "Preserve all existing and partial results."
        snapshots = CASE / "measurement-implementation"
        snapshots.mkdir(exist_ok=False)
        for path in json.loads((ROOT / "measurement-plan.json").read_bytes())["source_hashes"]:
            path = Path(path)
            if path.suffix == ".py":
                shutil.copyfile(path, snapshots / path.name)
        # Reuse the completed parent's fixed-input measurement/report path, without its geometry-smoke gate.
        globals_ = SHARED_RUN.__globals__
        globals_.update(ROOT=ROOT, CASE=CASE, SOURCE=SOURCE, check=check, require_smoke=source_health, save=save, __file__=str(Path(__file__)))
        SHARED_RUN()
