"""Prepare one1.5x Z5 departure-range sensitivity; never start SUMO."""

from collections import defaultdict
from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full"
CASE = ROOT / "spread15"
FIELD = "hh_0119_Z_5_30494"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "lane-intentions.json", "field-loops.add.xml",
    "expected-counts.csv", "initialization-counts.csv", "scenario.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def native_ms(value):
    return int((Decimal(str(value)) * 1000).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def prepare():
    sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
    from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming

    source = SOURCE / "prepared"
    root = ET.parse(source / "demand.rou.xml").getroot()
    vehicles = {vehicle.get("id"): vehicle for vehicle in root.findall("vehicle")}
    meta = json.loads((source / "lane-intentions.json").read_bytes())
    intentions = {row["vehicle_id"]: row for row in meta["vehicles"]}
    assert len(vehicles) == len(intentions) == 8640 and vehicles.keys() == intentions.keys()
    groups = defaultdict(list)
    for identity, vehicle in vehicles.items():
        depart = Decimal(vehicle.get("depart"))
        h = native_ms(depart) // 900000
        if intentions[identity]["field_id"] == FIELD and 4 <= h <= 13:
            groups[h].append((identity, depart))
    assert sum(map(len, groups.values())) == 521 and set(groups) == set(range(4, 14))
    assert sum(row["field_id"] == FIELD for row in intentions.values()) == 623
    proposals, bin_stats = [], []
    for h, rows in sorted(groups.items()):
        rows.sort(key=lambda row: (row[1], row[0]))
        old = [row[1] for row in rows]
        center = (min(old) + max(old)) / 2
        ideal = [center + Decimal("1.5") * (value - center) for value in old]
        applied = [Decimal(f"{float(value):.9f}") for value in ideal]
        assert all(value >= 0 for value in applied)
        assert all(first < last for first, last in zip(applied, applied[1:]))
        for (identity, previous), target, actual in zip(rows, ideal, applied, strict=True):
            new_bin = native_ms(actual) // 900000
            assert new_bin in (h - 1, h)
            proposals.append({"vehicle_id": identity, "source_depart_s": float(previous), "proposed_depart_s": float(target),
                "applied_xml_depart_s": str(actual), "field_id": FIELD, "source_bin": h, "target_bin": new_bin,
                "ideal_decimal_depart_s": str(target), "shift_s": float(actual - previous),
                "ideal_to_xml_error_s": float(actual - target), "native_requested_depart_s": native_ms(actual) / 1000})
        bin_stats.append({"source_bin": h, "vehicles": len(rows), "old_min_s": float(min(old)), "old_max_s": float(max(old)),
            "new_min_s": float(min(applied)), "new_max_s": float(max(applied)), "old_midpoint_s": float(center),
            "new_midpoint_s": float((min(applied) + max(applied)) / 2), "old_arithmetic_mean_s": float(sum(old) / len(old)),
            "new_arithmetic_mean_s": float(sum(applied) / len(applied)), "arithmetic_mean_change_s": float(sum(applied) / len(applied) - sum(old) / len(old)),
            "native_old_midpoint_s": (min(map(native_ms, old)) + max(map(native_ms, old))) / 2000,
            "native_new_midpoint_s": (min(map(native_ms, applied)) + max(map(native_ms, applied))) / 2000,
            "native_old_mean_s": statistics.mean(map(native_ms, old)) / 1000,
            "native_new_mean_s": statistics.mean(map(native_ms, applied)) / 1000,
            "cross_to_previous_bin": sum(native_ms(value) // 900000 == h - 1 for value in applied)})
    candidate = apply_native_count_retiming(root, proposals)
    modified = {vehicle.get("id"): vehicle for vehicle in candidate.findall("vehicle")}
    selected = {row["vehicle_id"] for row in proposals}
    assert len(selected) == 521 and len(modified) == 8640
    assert [row.get("id") for row in root.findall("vehicle") if row.get("id") not in selected] == [row.get("id") for row in candidate.findall("vehicle") if row.get("id") not in selected]
    for identity, before in vehicles.items():
        after = modified[identity]
        if identity not in selected:
            assert ET.tostring(before) == ET.tostring(after)
        else:
            expected = deepcopy(before)
            expected.set("depart", after.get("depart"))
            assert ET.tostring(expected) == ET.tostring(after)
    pairs = sorted({(v.find("route").get("edges").split()[0], v.find("route").get("edges").split()[-1]) for v in vehicles.values()})
    assert len(pairs) == 21
    old_q, new_q = [0] * 294, [0] * 294
    new_meta = deepcopy(meta)
    lookup = {row["vehicle_id"]: row for row in new_meta["vehicles"]}
    changed_cells = []
    for identity, before in vehicles.items():
        edges = before.find("route").get("edges").split()
        od = pairs.index((edges[0], edges[-1]))
        old_cell = (native_ms(before.get("depart")) // 900000) * 21 + od
        new_cell = (native_ms(modified[identity].get("depart")) // 900000) * 21 + od
        assert intentions[identity]["od_cell"] == old_cell
        old_q[old_cell] += 1
        new_q[new_cell] += 1
        if identity in selected:
            lookup[identity]["depart_s"] = float(modified[identity].get("depart"))
            lookup[identity]["od_cell"] = new_cell
        if old_cell != new_cell:
            changed_cells.append({"vehicle_id": identity, "old_cell": old_cell, "new_cell": new_cell})
    assert sum(new_q) == sum(old_q) == 8640 and len(changed_cells) == 55
    assert [sum(old_q[h * 21 + i] for h in range(14)) for i in range(21)] == [sum(new_q[h * 21 + i] for h in range(14)) for i in range(21)]
    prepared = CASE / "prepared"
    prepared.mkdir(parents=True, exist_ok=False)
    for name in NAMES:
        shutil.copyfile(source / name, prepared / name)
    ET.ElementTree(candidate).write(prepared / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    save(prepared / "lane-intentions.json", new_meta)
    raw_before, raw_after = [(p / "demand.rou.xml").read_bytes() for p in (source, prepared)]
    def blocks(raw):
        return {ET.fromstring(block).get("id"): block for block in re.findall(rb"<vehicle\b[\s\S]*?</vehicle>", raw)}
    first_blocks, last_blocks = blocks(raw_before), blocks(raw_after)
    assert len(first_blocks) == len(last_blocks) == 8640
    assert all(first_blocks[identity] == last_blocks[identity] for identity in vehicles.keys() - selected)
    assert re.findall(rb"<vType\b[^>]*?/>", raw_before) == re.findall(rb"<vType\b[^>]*?/>", raw_after)
    scenario = json.loads((prepared / "scenario.json").read_bytes())
    scenario.update(demand_sha256=sha(prepared / "demand.rou.xml"), initialization_vehicles=sum(new_q[:84]),
        main_vehicles=sum(new_q[84:]), formal_result=False, exact_count_fit=False,
        time_prior="Only521 source-main-Z5 requests:1.5x spread about each source-bin min/max midpoint, no clamp or added shift.55 cross to the previous bin;3 cross3600. Native count response unmeasured.")
    save(prepared / "scenario.json", scenario)
    save(CASE / "departure-proposals.json", proposals)
    save(CASE / "bin-spread-statistics.json", bin_stats)
    save(CASE / "od-vector.json", {"values": new_q, "source_values": old_q, "od_pairs": pairs,
        "coordinate_order": "native900s bin-major,21 lexicographic actual route endpoints", "metadata_cell_changes": changed_cells,
        "claim": "Actual explicit request inventory, not a new OD model or passage prediction."})
    stocks = []
    for h in range(14):
        stocks.append({"departure_bin": h, "source_Z5": sum(intentions[i]["field_id"] == FIELD and native_ms(v.get("depart")) // 900000 == h for i, v in vehicles.items()),
            "candidate_Z5": sum(intentions[i]["field_id"] == FIELD and native_ms(v.get("depart")) // 900000 == h for i, v in modified.items())})
    save(CASE / "z5-departure-stocks.json", stocks)
    native_rows = [row for row in ET.parse(SOURCE / "evaluation/native/field-counts.xml").getroot() if row.get("id") == FIELD]
    source_passages = {"initialization_0_3600": sum(int(row.get("nVehContrib")) for row in native_rows if float(row.get("end")) <= 3600),
        "main_3600_12600": sum(int(row.get("nVehContrib")) for row in native_rows if 3600 <= float(row.get("begin")) < 12600),
        "tail_12600_14400": sum(int(row.get("nVehContrib")) for row in native_rows if float(row.get("begin")) >= 12600)}
    assert source_passages == {"initialization_0_3600": 90, "main_3600_12600": 459, "tail_12600_14400": 74}
    request = json.loads((SOURCE / "evaluation/native/native-request.json").read_bytes())
    paths = [source / name for name in NAMES] + [SOURCE / "verdict.json", SOURCE / "evaluation/native/native-request.json", SOURCE / "evaluation/native/field-counts.xml", Path(__file__),
        REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_departure_probe.py"]
    paths += [CASE / name for name in ("departure-proposals.json", "bin-spread-statistics.json", "od-vector.json", "z5-departure-stocks.json")]
    proof = {"status": "pass", "formal_result": False, "native_runs": 0, "N": 8640,
        "source_hashes": {str(path): sha(path) for path in paths}, "prepared_hashes": {name: sha(prepared / name) for name in NAMES},
        "original_driver_scope": {**{key: request[key] for key in ("backend", "junction_body_hold", "junction_body_hold_nodes", "all_stopped_timeout_s", "monitor_interval_s")},
            "end_s": 14400, "step_length_s": .1, "seed": 104, "precision": 12},
        "actual_changes": {"depart_only_vehicles": 521, "unchanged_vehicle_xml_blocks": 8119, "routes": 0, "stops": 0,
            "fields": 0, "IDs": 0, "od_cell_changes": 55, "selected_depart_metadata_rows": 521,
            "initialization_requests": [sum(old_q[:84]), sum(new_q[:84])], "main_requests": [sum(old_q[84:]), sum(new_q[84:])],
            "max_abs_shift_s": max(abs(row["shift_s"]) for row in proposals), "median_abs_shift_s": statistics.median(abs(row["shift_s"]) for row in proposals),
            "max_ideal_to_9decimal_error_s": max(abs(row["ideal_to_xml_error_s"]) for row in proposals),
            "max_ideal_to_native_ms_error_s": max(abs(native_ms(row["applied_xml_depart_s"]) / 1000 - float(row["ideal_decimal_depart_s"])) for row in proposals),
            "native_bin_crossings": 55, "native_rounding_changes_due_xml_precision": sum(native_ms(row["applied_xml_depart_s"]) != native_ms(row["ideal_decimal_depart_s"]) for row in proposals)},
        "rules": {"scale": 1.5, "center": "Source min/max midpoint, not sample mean", "clamp": False,
            "uniform_center_shift": False, "per_bin_rank_preserved": True, "all21OD_totals_and13field_totals_preserved": True},
        "source_actual_Z5_passages": source_passages,
        "conditional_boundary": "Z5 planned total remains623 against real initialization102+main522=624. If initialization were also forced exact102 and each vehicle contributed at most once, main total could not exceed521. Current reference initialization is90, not102, leaving a main upper bound533; this is not a user-main130 infeasibility proof. Initialization is reported and may change.",
        "claim_boundary": "One timing-prior sensitivity only. Departure bins are not passage bins. Midpoints stay fixed before rounding; sample means need not. Neither concentrated source timing nor8/green tiny service proves a full-network cause or hard capacity. New native130/52/182/40/53556/safety/completion measurement required."}
    save(CASE / "scope-proof.json", proof)
    print(json.dumps({"status": "pass", "native_runs": 0, "prepared": str(prepared), "actual_changes": proof["actual_changes"]}))


if __name__ == "__main__":
    prepare()
