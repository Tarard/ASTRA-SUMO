# 119 exit-prior support check

This read-only check found six structural alternatives for the original Z4/Z5 route prefixes. It does not support an exit change yet. No demand, network, permissions, or control changed. No native run occurred.

The current network declares 39 exit edges. Only 17 are terminal in the loaded passenger graph after the existing route-pool rule excludes U-turns. A declared exit is not sufficient evidence of a real external destination. This check leaves all native U-turn permissions intact.

`ports-lane-detour.csv` has 54 rows: nine original Z4/Z5 prefixes and six tested terminal edges. `lane-paths.json` contains each full edge prefix, ordinary lane choice, connection, and internal lane chain. Every reported chain permits passenger traffic. The two Z15 prefixes found only the current exit, `199500676`, under these search rules.

| Alternate terminal edge | Additional possible field after the target |
| --- | --- |
| `19728446#0` | None |
| `551303415#0` | None |
| `28665128#0` | 535 Z4 |
| `142944318` | 535 Z4 |
| `142944477` | None |
| `142944538` | None |

For every alternative, the natural shortest route from the same origin avoids the target detector edge, `24483344#1`. Keeping the original detector prefix adds 319.868–320.507 m. No independent destination or route-choice evidence supports that detour. These are structural possibilities, not proposed demand routes.

The length metric includes ordinary roads and complete internal transition lengths. It uses the minimum internal cost for each edge pair. The concrete lane witness has separate length and nominal free-flow time. It is not a claim of a globally shortest lane path. Its permitted lane changes have no gap or timing guarantee.

The repeated-road and physical-junction checks pass for the reported paths. Those checks alone cannot exclude a geographical detour. The search uses existing forward route-pool rules and does not prove global absence of every longer legal route. Boundary and original-OSM endpoint validity remain separate source questions. A `scope_cut` label alone neither accepts nor rejects an exit.

All 13 field signatures remain in the route checks. Additional fields are not removed or used to synthesize counts. Route permission does not establish observed route shares, traffic capacity, or field correctness. This result does not establish excess demand or infeasibility of the calibration task.

Run `audit_exits.py` with the project Python and `PYTHONPATH=plugins/astra-sumo/src` to repeat this static check. It writes only this output directory. `summary.json` binds the input files by SHA-256.
