"""Measure a declared ordinary-road exit alternative; smoke is route support only."""

import argparse
from collections import Counter
import gzip
from importlib.metadata import version
import json
from pathlib import Path
import runpy
import shutil
import sys
import time
import traceback

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"
BEST = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def check(case):
    proof = json.loads((case / "scope-proof.json").read_bytes())
    assert proof["status"] == "pass" and proof["N"] in {4, 8640}
    assert all(sha(Path(p)) == h for p, h in proof["source_hashes"].items())
    assert all(sha(case / "prepared" / n) == h for n, h in proof["prepared_hashes"].items())
    driver = proof["original_driver_scope"]
    assert tuple(driver["junction_body_hold_nodes"]) == _body_hold_nodes(case / "prepared")
    assert driver["backend"] == "libsumo" and driver["end_s"] == 14400 and driver["junction_body_hold"]
    assert float(driver["step_length_s"]) == .1 and int(driver["seed"]) == 104
    assert driver["all_stopped_timeout_s"] == 300 and int(driver["precision"]) == 12
    return proof


def run(case):
    proof = check(case)
    prepared, evaluation = case / "prepared", case / "evaluation"
    assert not evaluation.exists() and not (case / "verdict.json").exists(), "Preserve existing results."
    assert Path(sys.executable).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    versions = {n: version(n) for n in ("eclipse-sumo", "libsumo", "traci", "sumolib")}
    assert set(versions.values()) == {"1.27.1"}
    evaluation.mkdir()
    for name in ("demand.rou.xml", "lane-intentions.json"):
        shutil.copyfile(prepared / name, evaluation / name)
    shutil.copyfile(case / "od-vector.json", evaluation / "od-vector.json")
    shutil.copyfile(__file__, case / "executed-driver.py")
    implementation = case / "implementation"
    implementation.mkdir(exist_ok=True)
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core"
    for frozen in (SOURCE / "implementation").glob("*.py"):
        assert (core / frozen.name).read_bytes() == frozen.read_bytes(), frozen.name
        if (implementation / frozen.name).exists():
            assert (implementation / frozen.name).read_bytes() == frozen.read_bytes()
        else:
            shutil.copyfile(frozen, implementation / frozen.name)
    binaries = [REPO / ".venv/Scripts/python.exe", REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe"]
    binaries += list((REPO / ".venv/Lib/site-packages/libsumo").glob("*.pyd"))
    assert len(binaries) >= 3
    save(case / "preflight.json", dict(formal_result=False, versions=versions, backend="libsumo",
         python=sys.executable, binaries={str(p): sha(p) for p in binaries},
         source_proof_sha256=sha(case / "scope-proof.json"), helper_sha256=sha(HELPER),
         search_reference_verdict_sha256=sha(SOURCE / "verdict.json"), global_best_verdict_sha256=sha(BEST / "verdict.json"),
         helper_scope_sha256=sha(HELPER.parent / "audit_scope.py"),
         executed_driver_sha256=sha(case / "executed-driver.py"),
         implementation_sha256={p.name: sha(p) for p in implementation.iterdir()},
         prepared_hashes=proof["prepared_hashes"], demand_generation_changes=proof["actual_changes"]))
    started = time.perf_counter()
    try:
        native = run_point_detector_demand(
            net_file=prepared / "network.net.xml", route_file=prepared / "demand.rou.xml",
            e1_additional_file=prepared / "field-loops.add.xml", expected_counts_csv=prepared / "expected-counts.csv",
            output_dir=evaluation / "native", end_s=14400, timeout_seconds=4800, step_length=.1, seed=104,
            backend="libsumo", sumo_binary=str(binaries[1]), signal_program_file=prepared / "control.add.xml",
            lane_intentions_file=prepared / "lane-intentions.json", junction_body_hold=True,
            junction_body_hold_nodes=_body_hold_nodes(prepared))
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        events = read_contributing_e1_passages(
            instant_file=evaluation / "native/instant-e1.xml", periodic_file=evaluation / "native/field-counts.xml",
            detector_ids=native["instant_to_periodic_ids"], step_length=.1)
        assert events["reconciled"]
        compact = evaluation / "contributing-passages.json.gz"
        compact.write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        sys.path.insert(0, str(HELPER.parent))
        tools = runpy.run_path(str(HELPER))
        measured = tools["evidence"](prepared, evaluation, compact, proof["N"])
        fields = {r["vehicle_id"]: r["field_id"] for r in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
        assert set(measured["by_vehicle"]) <= fields.keys()
        repeated = [dict(vehicle_id=i, field=f, count=n) for i, events in measured["by_vehicle"].items()
                    for f, n in Counter(e["detector_id"] for e in events).items() if n > 1]
        extra = [dict(vehicle_id=i, actual_field=e["detector_id"], intended_field=fields[i])
                 for i, events in measured["by_vehicle"].items() for e in events if e["detector_id"] != fields[i]]
        for name, rows in (("initialization52", measured["initial"]),
                           ("all182", measured["initial"] + measured["main"]),
                           ("native208", list(measured["periodic"].values()))):
            tools["table"](evaluation / f"{name}-comparison.csv", rows)
        source_verdict = json.loads((SOURCE / "verdict.json").read_bytes())["after"]
        fields535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}
        rows535 = [r for r in measured["initial"] + measured["main"] if r["detector_id"] in fields535]
        assert len(rows535) == 56
        tools["table"](evaluation / "535-all56.csv", rows535)
        stats535 = tools["metrics"](rows535)
        stats = {k: measured[k] for k in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}
        gates = dict(safe=measured["safe"], healthy=measured["healthy"], all53556_zero=stats535["TAE"] == 0,
                     no_repeated_vehicle_fields=not repeated, no_contributions_outside_primary_intention=not extra,
                     main130_MAE_improves=stats["metrics130"]["MAE"] < source_verdict["metrics130"]["MAE"],
                     main130_SSE_not_worse=stats["metrics130"]["SSE"] <= source_verdict["metrics130"]["SSE"],
                     all182_TAE_not_worse=stats["metrics182"]["TAE"] <= source_verdict["metrics182"]["TAE"])
        best = json.loads((BEST / "verdict.json").read_bytes())["candidate"]
        best_gates = {**gates,
            "main130_MAE_improves": stats["metrics130"]["MAE"] < best["metrics130"]["MAE"],
            "main130_SSE_not_worse": stats["metrics130"]["SSE"] <= best["metrics130"]["SSE"],
            "all182_TAE_not_worse": stats["metrics182"]["TAE"] <= best["metrics182"]["TAE"]}
        status = ("working_best_improved_candidate" if all(best_gates.values()) else
                  "search_reference_improved_candidate" if all(gates.values()) else "rejected")
        affected = [r["vehicle_id"] for r in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]
                    if r["field_id"] in {"hh_0535_Z_4_33055", "hh_0535_Z_9_29038", "hh_0535_Z_14_31892"}]
        endpoint_arrivals = {i: measured["tripinfo"].get(i, {}) for i in affected}
        realized = {i: measured["by_vehicle"].get(i, []) for i in affected}
        route_support = dict(safe=measured["safe"], healthy=measured["healthy"],
            one_expected_field_per_changed_vehicle=all(len(realized[i]) == 1 and realized[i][0]["detector_id"] == fields[i] for i in affected),
            all_changed_vehicles_arrive_at_declared_road_cut=all(float(t.get("arrival", -1)) >= 0 and
                t.get("arrivalLane", "").startswith("142944318_") and not t.get("vaporized", "") for t in endpoint_arrivals.values()),
            no_extra_or_repeated_fields=not repeated and not extra)
        assert len(affected) == (4 if case.name == "smoke" else 882)
        if not all(route_support.values()):
            status = "rejected"
        if case.name == "smoke":
            status = "route_support_pass" if all(route_support.values()) else "route_support_failed"
        save(case / "changed-route-native.json", dict(actual_changed_vehicles=len(affected),
             route_support_gates=route_support, arrivals=endpoint_arrivals, passages=realized))
        verdict = dict(status=status, formal_result=False, global_best=best,
                       global_best_gates=best_gates, search_reference=str(SOURCE), route_support_gates=route_support,
                       study_role="route_support_smoke" if case.name == "smoke" else "full_destination_prior_comparison",
                       calibration_selection_applicable=case.name == "full",

                       before=source_verdict, after=stats, all53556=stats535, gates=gates,
                       repeated_vehicle_fields=repeated, contributions_outside_prior_primary_intention=extra,
                       native_response_measured=True, exact130=stats["metrics130"]["TAE"] == 0,
                       claim_boundary="Declared ordinary-through destination sensitivity. The existing paired road-cut142944318 is not a demonstrated real-world trip endpoint. No parking activity counts establish the true share. IDs/departures/stops/fields are retained for full traffic; only882 route tails and derived OD metadata change. Four-car smoke evaluates route execution only, not calibration against the retained real observations.")
    except Exception as error:
        verdict = dict(status="invalid", formal_result=False, error=f"{type(error).__name__}: {error}",
                       partial_outputs_preserved=True)
        (case / "failure.log").write_text(traceback.format_exc(), encoding="utf-8")
    verdict["elapsed_s"] = time.perf_counter() - started
    save(case / "verdict.json", verdict)
    print(json.dumps(verdict, ensure_ascii=False), flush=True)
    if verdict["status"] == "invalid":
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("smoke", "full"), required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    target = ROOT / args.case
    if args.check_only:
        print(json.dumps(dict(status="pass", native_runs=0, proof=check(target)), ensure_ascii=False))
    else:
        run(target)
