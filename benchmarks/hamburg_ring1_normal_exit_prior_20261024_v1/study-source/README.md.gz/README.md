# Ordinary-road exit prior sensitivity

These inputs test a 100% through-destination prior for the existing 882 parking-ending requests. They do not identify a real through share or parking activity.

The source is the healthy one-share input. Its planned field totals include 760 requests for119 Z4 and624 for Z5. The earlier best reference remains separate. This preparation makes no claim of lower native count error.

The full candidate replaces only the final `28665128#0` road with `186821028 186821026 142944318`. The original prefix through each detector remains. All8640 IDs, request times, vehicle attributes, stops, and field intentions remain. The other7758 complete vehicle XML elements are unchanged. Reversing the882 exact tail-string replacements restores the complete original demand bytes.

`142944318` is an existing paired road scope cut. It is not a proven real road end. The existing lane2 straight movement uses197 link7, not U-turn link9. The source-bound static support is preserved under `source-snapshot/`.

Actual OD destinations change for882 requests. `cells294.json` declares14 native-millisecond departure bins and21 newly sorted actual OD pairs. `od-vector.json` counts the saved explicit vehicles in those coordinates. The preparation does not regenerate vehicles from the old empirical model.

The new ordering changes332 `od_cell` indices. Of these,251 requests also change their route tail. Another81 unchanged routes to `199500676` receive only a new index. `metadata-index-changes.csv` separates them. `od-coordinate-map.json` keeps both coordinate systems. Numeric vector equality is not claimed.

The smoke input contains one existing main-period ID from each of the four complete prefixes. It retains each original departure, all13 real loops, and all130 main plus52 initialization targets. The smoke checks actual intended-field passages, exit arrivals, and native safety. Its four-car count errors have no calibration meaning. `smoke-plan.json` lists the expected fields and exact request times.

The network, control, permissions, road lengths, observations, and four-node body-hold scope remain unchanged. `scope-proof.json` binds each input set. `selfchecks.json` records the preparation checks. `prepare-manifest.json` covers preparation artifacts only. It does not certify any later simulation result.

`preparation-notes/` retains an initial smoke-description correction. No prepared simulation input changed during that correction. No native run occurred in this preparation task.
