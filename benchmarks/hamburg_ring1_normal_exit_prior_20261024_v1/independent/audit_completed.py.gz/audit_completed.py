"""Audit sealed route smoke or full endpoint sensitivity, without a new run."""

import argparse
from collections import Counter
import gzip
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from inspect_inputs import OUT, REPO, SOURCE, STUDY, digest, inspect

HELPERS=REPO/"outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0,str(HELPERS))
import audit_response as audit  # noqa: E402
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages  # noqa: E402

BEST=REPO/"outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
FIELDS={"hh_0535_Z_4_33055","hh_0535_Z_9_29038","hh_0535_Z_14_31892"}
PROTECTED={"hh_0535_Z_5_30894","hh_0535_Z_6_33855","hh_0535_Z_7_29316","hh_0535_Z_8_34287"}


def measure(folder,n):
    return audit.evidence(folder/"prepared",folder/"evaluation",folder/"evaluation/contributing-passages.json.gz",n)


def compare_gates(actual,reference,zero,repeat,outside):
    return dict(safe=actual["safe"],healthy=actual["healthy"],all53556_zero=zero,
        no_repeated_vehicle_fields=not repeat,no_contributions_outside_primary_intention=not outside,
        main130_MAE_improves=actual["metrics130"]["MAE"]<reference["metrics130"]["MAE"],
        main130_SSE_not_worse=actual["metrics130"]["SSE"]<=reference["metrics130"]["SSE"],
        all182_TAE_not_worse=actual["metrics182"]["TAE"]<=reference["metrics182"]["TAE"])


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--case",choices=["smoke","full"],required=True)
    label=parser.parse_args().case
    case=STUDY/label
    assert (case/"verdict.json").exists(),"Read only sealed native results."
    verdict=json.loads((case/"verdict.json").read_bytes())
    assert verdict["native_response_measured"] and verdict["status"]!="invalid"
    input_scope=inspect()
    target=OUT/label
    target.mkdir(exist_ok=True)
    proof=json.loads((case/"scope-proof.json").read_bytes())
    preflight=json.loads((case/"preflight.json").read_bytes())
    assert preflight["source_proof_sha256"]==digest(case/"scope-proof.json")
    assert preflight["search_reference_verdict_sha256"]==digest(SOURCE/"verdict.json") and preflight["global_best_verdict_sha256"]==digest(BEST/"verdict.json")
    assert set(preflight["versions"].values())=={"1.27.1"} and preflight["backend"]=="libsumo"
    assert digest(case/"executed-driver.py")==preflight["executed_driver_sha256"] and (case/"executed-driver.py").read_bytes()==(STUDY/"run_candidate.py").read_bytes()
    for path,h in preflight["binaries"].items():
        assert digest(Path(path))==h
    for name,h in preflight["implementation_sha256"].items():
        assert digest(case/"implementation"/name)==h
        assert (case/"implementation"/name).read_bytes()==(SOURCE/"implementation"/name).read_bytes()
    assert preflight["prepared_hashes"]==proof["prepared_hashes"]
    assert digest(HELPERS/"audit_response.py")==preflight["helper_sha256"] and digest(HELPERS/"audit_scope.py")==preflight["helper_scope_sha256"]
    reference,best,actual=measure(SOURCE,8640),measure(BEST,8640),measure(case,proof["N"])
    native=case/"evaluation/native"
    run=json.loads((native/"run.json").read_bytes())
    raw=read_contributing_e1_passages(instant_file=native/"instant-e1.xml",periodic_file=native/"field-counts.xml",detector_ids=run["instant_to_periodic_ids"],step_length=.1)
    with gzip.open(case/"evaluation/contributing-passages.json.gz","rt",encoding="utf-8") as handle:
        assert raw==json.load(handle) and raw["reconciled"]
    requests=[json.loads((folder/"evaluation/native/native-request.json").read_bytes()) for folder in [SOURCE,case]]
    normalized=[json.dumps(r,sort_keys=True).replace(str(folder).replace("\\","\\\\"),"{case}") for r,folder in zip(requests,[SOURCE,case])]
    assert normalized[0]==normalized[1]
    monitor=json.loads((native/"stall-monitor.json").read_bytes())
    assert monitor["library_completed"] and monitor["native_returncode"] is None and monitor["native_version"]==[22,"SUMO 1.27.1"]
    assert digest(Path(monitor["native_library"]["path"]))==monitor["native_library"]["sha256"]
    for measured,key in [(reference,"before"),(best,"global_best"),(actual,"after")]:
        assert all(measured[k]==verdict[key][k] for k in verdict[key])
    for name,rows in [("130",actual["main"]),("52",actual["initial"]),("182",actual["initial"]+actual["main"]),("40",actual["stations"])]:
        audit.table(target/(name+".csv"),rows)
    metadata={r["vehicle_id"]:r for r in json.loads((case/"prepared/lane-intentions.json").read_bytes())["vehicles"]}
    vehicles={v.get("id"):v for v in ET.parse(case/"prepared/demand.rou.xml").getroot().findall("vehicle")}
    affected={i for i,r in metadata.items() if r["field_id"] in FIELDS}
    assert len(affected)==(4 if label=="smoke" else 882)
    repeat=[(i,f,n) for i,events in actual["by_vehicle"].items() for f,n in Counter(e["detector_id"] for e in events).items() if n>1]
    outside=[(i,e["detector_id"]) for i,events in actual["by_vehicle"].items() for e in events if e["detector_id"]!=metadata[i]["field_id"]]
    protected=[r for r in actual["initial"]+actual["main"] if r["detector_id"] in PROTECTED]
    assert len(protected)==56
    gates=compare_gates(actual,reference,audit.metrics(protected)["TAE"]==0,repeat,outside)
    global_gates=compare_gates(actual,best,audit.metrics(protected)["TAE"]==0,repeat,outside)
    assert gates==verdict["gates"] and global_gates==verdict["global_best_gates"]
    route_gates=dict(safe=actual["safe"],healthy=actual["healthy"],one_expected_field_per_changed_vehicle=all(len(actual["by_vehicle"].get(i,[]))==1 and actual["by_vehicle"][i][0]["detector_id"]==metadata[i]["field_id"] for i in affected),
        all_changed_vehicles_arrive_at_declared_road_cut=all(float(actual["tripinfo"].get(i,{}).get("arrival",-1))>=0 and actual["tripinfo"][i].get("arrivalLane","").startswith("142944318_") and not actual["tripinfo"][i].get("vaporized","") for i in affected),
        no_extra_or_repeated_fields=not repeat and not outside)
    assert route_gates==verdict["route_support_gates"]
    selection="working_best_improved_candidate" if all(global_gates.values()) else "search_reference_improved_candidate" if all(gates.values()) else "rejected"
    if not all(route_gates.values()):
        selection="rejected"
    if label=="smoke":
        selection="route_support_pass" if all(route_gates.values()) else "route_support_failed"
    assert selection==verdict["status"] and verdict["calibration_selection_applicable"]==(label=="full")
    route_rows=ET.parse(native/"vehicle-routes.xml").getroot().findall("vehicle")
    arrived={i for i,t in actual["tripinfo"].items() if float(t["arrival"])>=0}
    assert len(route_rows)==len(arrived)==actual["completion"]["arrived"] and {r.get("id") for r in route_rows}==arrived
    assert all(r.find("route").get("edges")==vehicles[r.get("id")].find("route").get("edges") for r in route_rows)
    lanes={lane.get("id"):lane for edge in ET.parse(case/"prepared/network.net.xml").getroot().findall("edge") for lane in edge.findall("lane")}
    affected_rows=[]
    for identity in sorted(affected):
        trip=actual["tripinfo"].get(identity,{})
        lane=trip.get("arrivalLane")
        at_end=float(trip.get("arrival",-1))>=0 and lane in lanes and abs(float(trip["arrivalPos"])-float(lanes[lane].get("length")))<1e-6
        affected_rows.append(dict(vehicle_id=identity,field=metadata[identity]["field_id"],requested_depart_s=vehicles[identity].get("depart"),actual_arrival_s=trip.get("arrival"),arrival_lane=lane,arrival_position_m=trip.get("arrivalPos"),normal_arrival_at_lane_end=at_end,
            before_events=audit.event_view(reference["by_vehicle"].get(identity,[])),after_events=audit.event_view(actual["by_vehicle"].get(identity,[]))))
    audit.table(target/"changed-route-actual-events-and-arrivals.csv",affected_rows)
    terminal=[]
    for identity in sorted(set(vehicles)-arrived):
        trip=actual["tripinfo"].get(identity)
        path=vehicles[identity].find("route").get("edges").split()
        terminal.append(dict(vehicle_id=identity,origin=path[0],destination=path[-1],field=metadata[identity]["field_id"],state="not_inserted" if trip is None or float(trip["depart"])<0 else "inserted_unfinished",events=audit.event_view(actual["by_vehicle"].get(identity,[]))))
    assert len(terminal)==actual["completion"]["running"]+actual["completion"]["waiting"]
    audit.table(target/"terminal-unfinished-inputs-and-events.csv",terminal)
    field_rows=[]
    for field in sorted({k[0] for k in actual["periodic"]}):
        a,b,c=[audit.metrics([r for r in d["main"] if r["detector_id"]==field]) for d in [reference,actual,best]]
        field_rows.append(dict(field=field,reference_TAE=a["TAE"],after_TAE=b["TAE"],delta_TAE=b["TAE"]-a["TAE"],reference_SSE=a["SSE"],after_SSE=b["SSE"],delta_SSE=b["SSE"]-a["SSE"],global_best_TAE=c["TAE"],delta_TAE_vs_best=b["TAE"]-c["TAE"],global_best_SSE=c["SSE"],delta_SSE_vs_best=b["SSE"]-c["SSE"]))
    audit.table(target/"field13-response.csv",field_rows)
    cohort_response=None
    if label=="full":
        cohorts={"changed882":affected,"unmodified7758":set(vehicles)-affected}
        counts={name:[audit.counts(d["by_vehicle"],ids) for d in [reference,actual]] for name,ids in cohorts.items()}
        cohort_response={}
        for name,ids in cohorts.items():
            def signature(data,identity):
                return [(e["detector_id"],e["interval_begin_s"],e["interval_end_s"]) for e in data["by_vehicle"].get(identity,[])]
            cohort_response[name]=dict(IDs=len(ids),before_events=sum(len(reference["by_vehicle"].get(i,[])) for i in ids),after_events=sum(len(actual["by_vehicle"].get(i,[])) for i in ids),field_or_bin_or_event_presence_changed=sum(signature(reference,i)!=signature(actual,i) for i in ids))
        response=[]
        for key in sorted(reference["periodic"]):
            a,b=[int(d["periodic"][key]["nVehContrib"]) for d in [reference,actual]]
            row=dict(field=key[0],begin_s=key[1],end_s=key[2],reference=a,after=b,delta=b-a)
            row.update({name+"_delta":c[1][key]-c[0][key] for name,c in counts.items()})
            assert row["changed882_delta"]+row["unmodified7758_delta"]==b-a
            response.append(row)
        audit.table(target/"native208-cohort-accounting.csv",response)
        if terminal:
            last_steps=[]
            for _,element in ET.iterparse(native/"summary.xml",events=("end",)):
                if element.tag=="step" and float(element.get("time"))>=14399.7:
                    last_steps.append(dict(element.attrib))
                element.clear()
            queue_context=[]
            for _,element in ET.iterparse(native/"queues.xml",events=("end",)):
                if element.tag=="data":
                    if float(element.get("timestep"))>=14395:
                        queue_context.append(dict(time=element.get("timestep"),lanes=[dict(row.attrib) for row in element.iter("lane")]))
                    element.clear()
            terminal_context=[]
            for row in terminal:
                identity=row["vehicle_id"]
                terminal_context.append(dict(vehicle_id=identity,input_edges=vehicles[identity].find("route").get("edges").split(),requested_depart_s=vehicles[identity].get("depart"),
                    source_tripinfo=reference["tripinfo"].get(identity),candidate_tripinfo=actual["tripinfo"].get(identity),actual_complete_events=actual["by_vehicle"].get(identity,[]),
                    detector_hold_events=[e for e in monitor["lane_section_hold"]["events"] if e["vehicle_id"]==identity],
                    body_hold_events=[e for e in monitor["lane_section_hold"].get("junction_body_hold",{}).get("events",[]) if e["vehicle_id"]==identity]))
            audit.save(target/"terminal-state-context.json",dict(schema="astra.hamburg.normal-exit-terminal-context/v1",status="measured",native_runs=0,vehicles=terminal_context,
                last_native_summary_steps=last_steps,last_aggregate_queue_frames=queue_context,detector_still_held=monitor["lane_section_hold"]["still_held"],junction_still_held=monitor["lane_section_hold"].get("junction_body_hold",{}).get("still_held"),
                saved_states=run.get("state_snapshots"),queue_sha256=digest(native/"queues.xml"),
                claim_boundary="The final aggregate summary reports moving vehicles, not a deadlock. Empty unfinished arrivalLane and routeLength do not identify an exact current lane or position. Queue frames have no vehicle IDs. Actual final individual lane, speed, leader and TLS state were not saved. A horizon-end unfinished record is not evidence of manual early removal."))
    initial_keys=[(r["detector_id"],float(r["begin"]),float(r["end"])) for r in reference["initial"]]
    report=dict(schema="astra.hamburg.normal-exit-endpoint-independent/v1",audit_status="pass",case=label,native_runs_by_audit=0,input_scope_status=input_scope["status"],selection=selection,calibration_selection_applicable=label=="full",
        reference={k:reference[k] for k in verdict["before"]},global_best={k:best[k] for k in verdict["global_best"]},after={k:actual[k] for k in verdict["after"]},
        route_support_gates=route_gates,search_reference_gates=gates,global_best_gates=global_gates,all_changed_arrivals_at_lane_end=all(r["normal_arrival_at_lane_end"] for r in affected_rows),
        changed_vehicle_count=len(affected),changed_arrived_count=sum(float(actual["tripinfo"].get(i,{}).get("arrival",-1))>=0 for i in affected),changed_arrived_at_lane_end_count=sum(r["normal_arrival_at_lane_end"] for r in affected_rows),
        unique_complete_vehicles=len(actual["by_vehicle"]),repeat=repeat,outside=outside,all53556=audit.metrics(protected),station40_max=max(abs(r["residual"]) for r in actual["stations"]),field_rows=field_rows,
        initial52_count_rows_exact=all(reference["periodic"][key]["nVehContrib"]==actual["periodic"][key]["nVehContrib"] for key in initial_keys),
        cohort_response=cohort_response,
        terminal_count=len(terminal),terminal_by_origin=dict(Counter(r["origin"] for r in terminal)),terminal_by_field=dict(Counter(r["field"] for r in terminal)),
        raw_source_hashes=actual["source_hashes"],binding_hashes={str(p):digest(p) for p in [case/"preflight.json",case/"verdict.json",case/"executed-driver.py",case/"changed-route-native.json",native/"vehicle-routes.xml"]},
        claim_boundary="A100percent through-exit sensitivity at an existing paired road graph cut, not measured destination choice. Smoke is execution support only, never calibration acceptance against the retained real observations. Full errors, initialization, health and every field are remeasured. Neither native arrival nor improved fit establishes field OD, geographic domain or control truth.")
    audit.save(target/"summary.json",report)
    print(json.dumps(dict(case=label,audit_status="pass",selection=selection,completion=actual["completion"],route_support_gates=route_gates,all_changed_arrivals_at_lane_end=report["all_changed_arrivals_at_lane_end"],metrics130=actual["metrics130"] if label=="full" else "not_used_for_smoke_calibration")))


if __name__=="__main__":
    main()
