"""Check the one endpoint-prior sensitivity and its four-route smoke subset."""

from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
STUDY=OUT.parent
REPO=STUDY.parents[1]
SOURCE=REPO/"outputs/hamburg-z5-single-share-20261024-v1/one-share"
OLD=b"186821029#1 28665128#0"
NEW=b"186821029#1 186821028 186821026 142944318"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cell_key(vehicle):
    edges=vehicle.find("route").get("edges").split()
    return edges[0],edges[-1],math.floor(float(vehicle.get("depart"))*1000+.5)//900000


def inspect():
    source_raw=(SOURCE/"prepared/demand.rou.xml").read_bytes()
    full_raw=(STUDY/"full/prepared/demand.rou.xml").read_bytes()
    assert source_raw.count(OLD)==882 and source_raw.count(NEW)==0
    assert full_raw.count(NEW)==882 and full_raw.replace(NEW,OLD)==source_raw
    roots=[ET.fromstring(raw) for raw in [source_raw,full_raw]]
    vehicles=[{v.get("id"):v for v in root.findall("vehicle")} for root in roots]
    assert len(vehicles[0])==len(vehicles[1])==8640 and list(vehicles[0])==list(vehicles[1])
    assert [ET.tostring(r) for r in roots[0] if r.tag!="vehicle"]==[ET.tostring(r) for r in roots[1] if r.tag!="vehicle"]
    meta_top=[json.loads((folder/"prepared/lane-intentions.json").read_bytes()) for folder in [SOURCE,STUDY/"full"]]
    metadata=[{r["vehicle_id"]:r for r in d["vehicles"]} for d in meta_top]
    assert list(metadata[0])==list(metadata[1]) and len(metadata[0])==8640
    old_pairs=sorted({cell_key(v)[:2] for v in vehicles[0].values()})
    new_pairs=sorted({cell_key(v)[:2] for v in vehicles[1].values()})
    assert len(old_pairs)==len(new_pairs)==21
    assert len(set(old_pairs)-set(new_pairs))==len(set(new_pairs)-set(old_pairs))==4
    cells=json.loads((STUDY/"full/cells294.json").read_bytes())["cells"]
    expected=[dict(index=21*h+j,origin=o,destination=d,begin_s=900*h,end_s=900*(h+1)) for h in range(14) for j,(o,d) in enumerate(new_pairs)]
    assert cells==expected
    changed=[]
    pure_reindex=[]
    q=[Counter(),Counter()]
    entry_bin=[Counter(),Counter()]
    field_bin=[Counter(),Counter()]
    for identity in vehicles[0]:
        a,b=[d[identity] for d in vehicles]
        assert a.attrib==b.attrib
        restored=deepcopy(b)
        if a.find("route").get("edges")!=b.find("route").get("edges"):
            old=a.find("route").get("edges").split()
            new=b.find("route").get("edges").split()
            assert old[-2:]==["186821029#1","28665128#0"] and new==old[:-1]+["186821028","186821026","142944318"]
            restored.find("route").set("edges",a.find("route").get("edges"))
            changed.append(identity)
        assert ET.tostring(restored)==ET.tostring(a)
        assert {k:v for k,v in metadata[0][identity].items() if k!="od_cell"}=={k:v for k,v in metadata[1][identity].items() if k!="od_cell"}
        for side,pairs in [(0,old_pairs),(1,new_pairs)]:
            key=cell_key(vehicles[side][identity])
            index=21*key[2]+pairs.index(key[:2])
            assert metadata[side][identity]["od_cell"]==index
            q[side][index]+=1
            entry_bin[side][key[0],key[2]]+=1
            field_bin[side][metadata[side][identity]["field_id"],key[2]]+=1
        if metadata[0][identity]["od_cell"]!=metadata[1][identity]["od_cell"] and identity not in changed:
            pure_reindex.append(identity)
    assert len(changed)==882 and len(pure_reindex)==81
    assert sum(metadata[0][i]["od_cell"]!=metadata[1][i]["od_cell"] for i in vehicles[0])==332
    assert entry_bin[0]==entry_bin[1] and field_bin[0]==field_bin[1]
    assert {k:v for k,v in meta_top[0].items() if k!="vehicles"}=={k:v for k,v in meta_top[1].items() if k!="vehicles"}
    vector=json.loads((STUDY/"full/od-vector.json").read_bytes())
    assert vector["values"]==[q[1][i] for i in range(294)] and vector["vehicle_count"]==8640
    coordinate_map=json.loads((STUDY/"full/od-coordinate-map.json").read_bytes())
    assert coordinate_map["old_pairs"]==[list(p) for p in old_pairs] and coordinate_map["new_pairs"]==[list(p) for p in new_pairs]
    assert coordinate_map["old_vector"]==[q[0][i] for i in range(294)] and coordinate_map["new_vector"]==vector["values"]
    for old in old_pairs:
        new=(old[0],"142944318" if old[1]=="28665128#0" else old[1])
        assert all(q[0][21*h+old_pairs.index(old)]==q[1][21*h+new_pairs.index(new)] for h in range(14))
    fixed=["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]
    for label in ["full","smoke"]:
        case=STUDY/label
        proof=json.loads((case/"scope-proof.json").read_bytes())
        assert proof["status"]=="pass" and all(proof["checks"].values())
        assert all(digest(Path(p))==h for p,h in proof["source_hashes"].items())
        assert all(digest(case/"prepared"/n)==h for n,h in proof["prepared_hashes"].items())
        assert all((SOURCE/"prepared"/name).read_bytes()==(case/"prepared"/name).read_bytes() for name in fixed)
        assert (case/"cells294.json").read_bytes()==(STUDY/"full/cells294.json").read_bytes()
    for name in [*fixed,"demand.rou.xml","lane-intentions.json","scenario.json"]:
        assert gzip.decompress((STUDY/"source-snapshot"/(name+".gz")).read_bytes())==(SOURCE/"prepared"/name).read_bytes()
    donor="od_0209_v00026"
    assert metadata[1][donor]["field_id"]=="hh_0119_Z_5_30494" and vehicles[1][donor].find("stop").get("lane")=="24483344#1_1"
    smoke_root=ET.parse(STUDY/"smoke/prepared/demand.rou.xml").getroot()
    smoke={v.get("id"):v for v in smoke_root.findall("vehicle")}
    smoke_meta={r["vehicle_id"]:r for r in json.loads((STUDY/"smoke/prepared/lane-intentions.json").read_bytes())["vehicles"]}
    plan=json.loads((STUDY/"smoke/smoke-plan.json").read_bytes())
    assert len(smoke)==len(smoke_root.findall("vehicle"))==len(plan["expected_fields_by_vehicle"])==4
    assert smoke.keys()==plan["expected_fields_by_vehicle"].keys()
    assert smoke_meta.keys()==smoke.keys() and all(smoke_meta[i]==metadata[1][i] for i in smoke)
    assert len({vehicles[0][i].find("route").get("edges") for i in smoke})==4
    assert all(ET.tostring(v)==ET.tostring(vehicles[1][i]) and cell_key(v)[2]>=4 for i,v in smoke.items())
    assert plan["expected_exit"]=="142944318" and all(plan["expected_fields_by_vehicle"][i]==metadata[0][i]["field_id"] for i in smoke)
    smoke_q=Counter(21*cell_key(v)[2]+new_pairs.index(cell_key(v)[:2]) for v in smoke.values())
    assert json.loads((STUDY/"smoke/od-vector.json").read_bytes())["values"]==[smoke_q[i] for i in range(294)]
    initial_changed=sum(cell_key(vehicles[0][i])[2]<4 for i in changed)
    report=dict(schema="astra.hamburg.normal-exit-input-independent/v1",status="pass",native_runs_by_audit=0,
        full_N=8640,route_tail_changes=882,other7758_vehicle_XML_exact=True,inverse_raw_substitution_restores_source_bytes=True,
        all_IDs_departures_vehicle_attributes_stops_fields_types_order_fixed=True,entry_period_inventory_fixed=True,field_period_intended_inventory_fixed=True,
        old_OD_pairs=21,new_OD_pairs=21,four_destination_groups_redefined=True,OD_counts_preserved_only_under_declared_coordinate_mapping=True,
        metadata_indices_changed=332,unchanged_route_metadata_only=81,new_actual_cells294_and_vector_exact=True,
        initial_route_tail_changes=initial_changed,initial_requests_not_retimed=True,initial52_observations_fixed=True,
        v26_Z5_not_reset=True,smoke4_original_main_requests_and_fields=True,smoke_observations_not_synthesized=True,
        source_hashes={str(p):digest(p) for p in [STUDY/"full/scope-proof.json",STUDY/"smoke/scope-proof.json",STUDY/"full/cells294.json",STUDY/"full/od-vector.json",STUDY/"full/od-coordinate-map.json",STUDY/"smoke/smoke-plan.json"]},
        claim_boundary="100percent through-exit sensitivity, not observed OD. Four destinations change to a pre-existing paired road graph cut; original OD labels are not retained. No network, control, field, request time or synthetic observation changes. The new full native response and health remain unmeasured.")
    (OUT/"input-scope.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:report[k] for k in ["status","full_N","route_tail_changes","metadata_indices_changed","initial_route_tail_changes"]}))
    return report


if __name__=="__main__":
    inspect()
