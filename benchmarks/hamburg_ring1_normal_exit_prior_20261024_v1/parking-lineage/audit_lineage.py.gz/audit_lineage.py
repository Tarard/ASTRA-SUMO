"""Read the frozen parking-endpoint selection chain without generating demand."""

import ast
from collections import Counter
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

import numpy as np


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
BENCH = REPO / "benchmarks"
PARK = "28665128#0"
PROFILES = (34, 86, 111, 281)
SOURCES = {}


def read(path):
    if not path.exists():
        path = path.with_name(path.name + ".gz")
    stored = path.read_bytes()
    raw = gzip.decompress(stored) if path.suffix == ".gz" else stored
    SOURCES[str(path)] = {"stored_sha256": hashlib.sha256(stored).hexdigest(),
                          "raw_sha256": hashlib.sha256(raw).hexdigest()}
    return raw


def load(path):
    return json.loads(read(path))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def inventory(label, folder):
    raw = read(folder / "demand.rou.xml")
    intents = {r["vehicle_id"]: r for r in load(folder / "lane-intentions.json")["vehicles"]}
    vehicles = ET.fromstring(raw).findall("vehicle")
    selected = [v for v in vehicles if v.find("route").get("edges").split()[-1] == PARK]
    fields = Counter(intents[v.get("id")]["field_id"] for v in selected)
    profiles = Counter(intents[v.get("id")].get("profile_index") for v in selected)
    return {"stage": label, "N": len(vehicles), "parking_requests": len(selected),
            "field_totals": dict(fields), "profile_totals": {str(k): n for k, n in profiles.items()},
            "demand_raw_sha256": hashlib.sha256(raw).hexdigest()}, selected, intents


def frozen_function(package, filename, commit, function):
    manifest = load(BENCH / package / "manifest.json")
    path = "plugins/astra-sumo/src/astra_sumo/core/" + filename
    expected = next(r["sha256"] for r in manifest["implementation_files"] if r["path"] == path)
    raw = subprocess.check_output(["git", "show", commit + ":" + path], cwd=REPO)
    assert hashlib.sha256(raw).hexdigest() == expected
    node = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == function)
    lines = raw.decode("utf-8").splitlines()
    return {"commit": commit, "path": path, "sha256": expected, "function": function,
            "first_line": node.lineno, "last_line": node.end_lineno,
            "source": "\n".join(lines[node.lineno - 1:node.end_lineno])}, node


def main():
    base = BENCH / "hamburg_ring1_m1_2_demand_pool_20261021_v1/base"
    profiles = load(base / "ideal-lane-profiles.json")["profiles"]
    profiles = [{**p, "field_offsets_s": {int(k): v for k, v in p["field_offsets_s"].items()}} for p in profiles]
    source, node = frozen_function(base.parent.name, "hamburg_readme_demand.py",
        "3f00255f73d6daceaf04f90d1a07cd35a5a85ddd", "timed_columns")
    namespace = {"math": math}
    exec(compile(ast.Module(body=[node], type_ignores=[]), "frozen-timed-columns", "exec"), namespace)
    timed = namespace["timed_columns"]
    kwargs = dict(begin=3600, interval=900, bins=10, end=14400, step=.1)
    columns = timed(profiles, 13, **kwargs)
    assert columns == load(base / "columns.json")["columns"]
    competitions = []
    for index in PROFILES:
        chosen = next(c for c in columns if c["profile_index"] == index)
        key = chosen["entry"], chosen["departure_bin"], chosen["field_rows"]
        matches = []
        for other, profile in enumerate(profiles):
            for column in timed([profile], 13, **kwargs):
                if (column["entry"], column["departure_bin"], column["field_rows"]) == key:
                    matches.append({"profile": other, "exit": profile["edges"][-1], "distance_m": profile["distance_m"]})
        matches.sort(key=lambda r: r["distance_m"])
        assert matches[0]["profile"] == index and len(matches) == 2
        competitions.append({"selected_profile": index, "entry": key[0], "departure_bin": key[1],
            "field_rows": key[2], "candidates": matches,
            "through_distance_penalty_m": matches[1]["distance_m"] - matches[0]["distance_m"]})
    end = BENCH / "hamburg_ring1_end_to_end_20261021_v1/inputs"
    end_columns = load(end / "columns.json")["columns"]
    solution = load(end / "integer-proposal.json")
    with np.load(end / "system.npz") as system:
        read(end / "system.npz")
        assert np.array_equal(system["solution"], solution["solution"])
        assert np.array_equal(system["response"] @ system["solution"], system["observations"])
    assert solution["objective"] == "minimum_route_cost"
    weighted = sum(c["distance_km"] * n for c, n in zip(end_columns, solution["solution"]))
    assert math.isclose(weighted, solution["objective_value"], abs_tol=1e-8)
    selected = Counter()
    for column, count in zip(end_columns, solution["solution"]):
        if profiles[column["profile_index"]]["edges"][-1] == PARK:
            selected[column["profile_index"]] += int(count)
    stages = []
    current_selected = None
    for label, folder in [
        ("end_to_end_main", end),
        ("initialization", BENCH / "hamburg_ring1_initialization_population_20261021_v1/inputs"),
        ("primary_entry", BENCH / "hamburg_ring1_primary_entry_full_20261022_v1/inputs"),
        ("munich_refit", BENCH / "hamburg_ring1_munich_corridor_20261022_v1/inputs"),
        ("original_seed_restored", REPO / "outputs/hamburg-directed-backlog-20261023-v1/original-seed-restored-prepared"),
        ("classical_minus1", REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation"),
        ("healthy_full_priority", REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/prepared"),
        ("one_share", REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share/prepared"),
    ]:
        row, vehicles, intents = inventory(label, folder)
        stages.append(row)
        if label == "end_to_end_main":
            assert selected == Counter(intents[v.get("id")]["profile_index"] for v in vehicles)
        if label == "healthy_full_priority":
            current_selected = {v.get("id"): ET.tostring(v) for v in vehicles}
        if label == "one_share":
            assert current_selected == {v.get("id"): ET.tostring(v) for v in vehicles}
    assert stages[3]["demand_raw_sha256"] == stages[4]["demand_raw_sha256"]
    assert stages[5]["demand_raw_sha256"] == stages[6]["demand_raw_sha256"]
    assert all(r["parking_requests"] == 882 for r in stages[1:])
    initial = load(BENCH / "hamburg_ring1_initialization_population_20261021_v1/inputs/initialization-allocation.json")
    initial_counts = Counter()
    for row in initial["rows"]:
        if row["profile_index"] in PROFILES:
            initial_counts[row["detector_id"]] += row["vehicles"]
    seed = load(BENCH / "hamburg_ring1_munich_corridor_20261022_v1/inputs/corridor-demand-seed.json")
    assert sum(r["vehicles"] for r in seed["allocations"] if r["profile_index"] in PROFILES) == 882
    boundary = load(base / "boundary-declarations.json")
    parking_boundary = next(r for r in boundary["zones"] if PARK in r["exit_edges"])
    assert parking_boundary["basis"] == ["scope_cut"]
    pipeline, _ = frozen_function("hamburg_ring1_end_to_end_20261021_v1", "hamburg_readme_pipeline.py",
        "a5c3dc3e005f09a70802cf2d66d961fb9ce55685", "prepare_hamburg_readme_run")
    current_code = {str(REPO / "plugins/astra-sumo/src/astra_sumo/core" / name): read(REPO / "plugins/astra-sumo/src/astra_sumo/core" / name).decode("utf-8")
                    for name in ("hamburg_initialization.py", "hamburg_corridor_pruning.py", "hamburg_od_spsa.py")}
    claims = {str(BENCH / "hamburg_ring1_munich_corridor_20261022_v1/inputs/scenario.json"):
              load(BENCH / "hamburg_ring1_munich_corridor_20261022_v1/inputs/scenario.json")["demand_prior"]}
    assert "not measured OD" in claims[next(iter(claims))]
    with (OUT / "stages.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(stages[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v) if isinstance(v, dict) else v for k, v in r.items()} for r in stages)
    save("lineage.json", {"status": "pass", "formal_result": False, "native_runs": 0,
        "parking_boundary": parking_boundary, "frozen_760_columns_reconstructed_exactly": True,
        "profile_competitions": competitions, "end_to_end_objective": solution["objective"],
        "end_to_end_vehicle_km": weighted, "main_parking_by_profile": dict(selected),
        "initial_parking_by_field": dict(initial_counts), "stages": stages,
        "munich_refit_rule": "Native-completed templates only. Road-class entry ceilings set prior weights; retained exit templates at each entry share those weights equally. The solver minimizes L1 change from that prior, subject to field totals and entry ceilings.",
        "current_882_vehicle_xml_identical_between_healthy_and_one_share": True,
        "explicit_parking_activity_counts_in_audited_inputs": False,
        "declared_claims": claims,
        "conclusion": "The parking endpoint is an inherited scope-port and route-cost/model-share prior, not an observed parking-activity destination. The earliest audited main population already selected 710 parking-ending requests; inherited initialization adds 172. Later corridor refitting retains 882 but changes their entry shares. No field, route, control or demand correction follows from this trace alone.",
        "claim_boundary": "Absence of parking-activity input is limited to the audited construction chain. Endpoint OSM continuation and external-domain validity are separate evidence. This is not a SUMO counting bug or an explanation of every residual.",
        "source_hashes": SOURCES})
    save("frozen-source-evidence.json", {"historical_functions": [source, pipeline],
        "current_claim_code_files": list(current_code), "note": "Historical function bytes match their frozen implementation manifest hashes. No historical execution or native run was repeated."})
    print(json.dumps({"status": "pass", "parking": 882, "through_penalty_m": competitions[0]["through_distance_penalty_m"], "sources": len(SOURCES)}))


if __name__ == "__main__":
    main()
