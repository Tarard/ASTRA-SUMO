# Parking-endpoint prior lineage and one straight-tail check

The 882 requests to `28665128#0` inherit a model-port and route-cost prior. The audited construction chain has no parking-activity count input.

The M1.2 boundary declaration marks this edge as `scope_cut`, with omitted continuation `28665128#1`. The frozen `timed_columns` function uses `(source, departure bin, field rows)` as its key. It does not include destination. It retains the shorter profile at each key. Repeating that pure function from the manifest-matched historical Git blob reproduces all 760 frozen columns exactly.

For the four relevant profiles, the parking ending is 37.739349 m shorter than the paired straight ending at `142944318`. The pairs are 34/33, 86/85, 111/110, and 281/280. The longer straight columns were removed before the later integer assignment.

The frozen end-to-end solution reports `minimum_route_cost`. Its 430-column response and solution satisfy the frozen equations. Its weighted route cost independently recomputes to 4893.006520102 vehicle-km. The selected main-window parking population is 710: 390 for 535 Z4, 255 for Z9, and 65 for Z14. Initialization inherits the main-window profile shares and adds 172: 105, 58, and 9, respectively.

The later Munich preparation retains 882 requests, using only previously completed native field templates. It sets route shares from road-class entry ceilings, then minimizes L1 change from that prior. It does not solve a new minimum-distance objective at that stage. Its declared claim explicitly says these shares are not measured OD or native capacity.

`stages.csv` records the subsequent inheritance. The restored original demand equals the frozen Munich demand by raw SHA-256. The current healthy demand equals the classical minus1 demand by raw SHA-256. All 882 parking-ending vehicle XML elements remain identical in the one-share input. IDs changed earlier during OD materialization, so the table does not claim byte equality across every stage.

This trace does not establish an implementation defect in the stated static cost objective. Destination-sensitive columns alone would not remove a minimum-distance preference for the parking ending. Static field signatures and route cost do not establish equivalent native responses or true destination shares.

`straight-tail-check.csv` checks one specific existing alternative for the same 882 requests. All four different prefixes retain the original detector and LSA535 route. They use the existing lane2 chain through `186821028`, `186821026`, and `142944318`. The first new turn is straight197 link7, not U-turn link9. Every ordinary and internal lane in the selected witness permits passenger traffic.

All four complete edge paths equal their natural shortest origin-to-`142944318` paths under the stated ordinary-plus-internal distance metric. They have no repeated roads or physical-junction groups. Their field signatures contain only the original field. This specific straight tail adds 37.739348 m to the current parking ending. Permitted lane changes do not certify available gaps or time.

The endpoint audit is separate. A model cut is not evidence that the real road ends there. These results do not establish that all 882 requests should continue straight. They do not predict better counts or identify real OD. No candidate, core change, demand change, or native run occurred.

`lineage.json` and `straight-tail-check.json` bind all read inputs and current helpers by SHA-256. Compressed inputs have both stored and decompressed hashes. `frozen-source-evidence.json` records exact historical source bytes, commits, and function line ranges.
