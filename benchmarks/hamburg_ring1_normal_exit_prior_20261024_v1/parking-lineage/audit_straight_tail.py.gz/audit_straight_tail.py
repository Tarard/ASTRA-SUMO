"""Check one existing straight exit suffix without emitting candidate vehicles."""

from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.demand_route_pool import ideal_lane_profiles, junction_visit_audit
from astra_sumo.core.detector_demand import read_net
from astra_sumo.core.local_network_conversion import loaded_turn_permissions
from astra_sumo.core.osm_access import _permission_set
from astra_sumo.core.road_hierarchy import _internal_transition_lengths, _network, _path, _paths


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority/prepared"
TAIL = ["186821029#1", "186821028", "186821026", "142944318"]


def main():
    net = ET.parse(SOURCE / "network.net.xml").getroot()
    _, graph, lengths = _network(net, "passenger")
    edges, connections = read_net(SOURCE / "network.net.xml")
    turns = loaded_turn_permissions(net)
    transition = _internal_transition_lengths(net, "passenger")
    uturns = {(c.get("from"), c.get("to")) for c in net.findall("connection") if c.get("dir") in {"t", "T"}}
    graph = {a: {b for b in bs if (a, b) not in uturns} for a, bs in graph.items()}
    native = {(c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))): c for c in net.findall("connection")}
    lane_xml = {lane.get("id"): lane for edge in net.findall("edge") for lane in edge.findall("lane")}
    lanes = defaultdict(list)
    for edge in net.findall("edge"):
        if edge.get("id") not in edges:
            continue
        for lane in edge.findall("lane"):
            if "passenger" in _permission_set(lane.attrib, network_version=net.get("version")):
                lanes[edge.get("id")].append({"id": lane.get("id"), "index": int(lane.get("index")),
                    "change_left": sorted(_permission_set({"allow": lane.get("changeLeft", "all")}, network_version=net.get("version"))),
                    "change_right": sorted(_permission_set({"allow": lane.get("changeRight", "all")}, network_version=net.get("version")))})
    lane_connections = defaultdict(set)
    for (a, la, b, lb), allowed in turns.items():
        if "passenger" in allowed:
            lane_connections[a, la, b].add(lb)
    loops = list(ET.parse(SOURCE / "field-loops.add.xml").getroot())
    fields = [{"field_index": i, "lane_id": loop.get("lane")} for i, loop in enumerate(loops)]
    field_index = {loop.get("id"): i for i, loop in enumerate(loops)}
    owners = {j.get("id"): j.get("id").split("_part")[0] for j in net.findall("junction") if j.get("id", "").startswith("LSA")}
    intents = {r["vehicle_id"]: r for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    originals = Counter()
    for vehicle in ET.parse(SOURCE / "demand.rou.xml").getroot().findall("vehicle"):
        route = tuple(vehicle.find("route").get("edges").split())
        if route[-1] == "28665128#0":
            assert route[-2] == TAIL[0]
            originals[intents[vehicle.get("id")]["field_id"], route] += 1
    details, rows = [], []
    def metric(route):
        return sum(lengths[e] for e in route) + sum(transition[a, b] for a, b in zip(route, route[1:]))
    for (field, original), count in originals.items():
        route = list(original[:-2]) + TAIL
        visit = junction_visit_audit(route, edges, connections, owners)
        assert visit["allowed"]
        profiles = ideal_lane_profiles(route, lanes, lane_connections, fields)
        profiles = [p for p in profiles if p["field_mask"] & (1 << field_index[field])
                    and all(p["entry_lanes"][i] == p["exit_lanes"][i] == 2 for i in range(len(route) - 4, len(route)))]
        assert profiles
        profile = profiles[0]
        chain_rows = []
        for i, (a, b) in enumerate(zip(route, route[1:])):
            key = a, profile["exit_lanes"][i], b, profile["entry_lanes"][i + 1]
            assert "passenger" in turns[key]
            connection = native[key]
            via, chain = connection.get("via"), []
            while via:
                assert via not in chain
                assert "passenger" in _permission_set(lane_xml[via].attrib, network_version=net.get("version"))
                chain.append(via)
                via_edge, via_index = via.rsplit("_", 1)
                via = native[via_edge, int(via_index), b, key[3]].get("via")
            chain_rows.append({"key": list(key), "connection": dict(connection.attrib), "complete_internal_chain": chain})
        distance, previous = _paths(graph, lengths, route[0], set(graph), transition_costs=transition)
        natural = _path(previous, route[0], route[-1])
        assert natural == route
        field_sets = [[loops[i].get("id") for i in range(len(loops)) if p["field_mask"] & (1 << i)] for p in profiles]
        assert field_sets == [[field]]
        row = {"field_id": field, "origin": route[0], "requests": count,
               "original_exit": original[-1], "tested_exit": route[-1],
               "no_repeated_road_or_physical_group": visit["allowed"], "lane2_complete_tail_supported": True,
               "natural_shortest_edge_route_identical": natural == route,
               "original_metric_m": metric(original), "straight_metric_m": metric(route),
               "extra_metric_m": metric(route) - metric(original), "forced_detour_m": metric(route) - distance[route[-1]],
               "field_signatures": field_sets,
               "status": "structurally_supported_destination_share_unidentified"}
        rows.append(row)
        details.append({"summary": row, "original_edges": original, "tested_edges": route,
                        "natural_edges": natural, "lane_witness": profile, "turns": chain_rows,
                        "tail_keys": [r["key"] for r in chain_rows[-3:]]})
    assert len(rows) == 4 and sum(r["requests"] for r in rows) == 882
    with (OUT / "straight-tail-check.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v) if isinstance(v, list) else v for k, v in row.items()} for row in rows)
    sources = [SOURCE / name for name in ("network.net.xml", "control.add.xml", "demand.rou.xml", "lane-intentions.json", "field-loops.add.xml")]
    sources += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / (name + ".py") for name in
                ("demand_route_pool", "detector_demand", "local_network_conversion", "osm_access", "road_hierarchy")]
    report = {"status": "review_required", "native_runs": 0, "candidates_generated": 0, "requests": 882,
              "distinct_original_prefixes": 4, "details": details,
              "source_hashes": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
              "claim_boundary": "Every tested prefix retains its detector and has a loaded passenger lane witness. The new tail uses existing straight197 link7, not Uturn9, and adds no field. All four edge paths equal their natural shortest origin-to142944318 path. Permitted lane changes do not certify gap/time availability. Endpoint external-domain validity and the fraction of through destinations remain independent questions. No claim that all882 should continue, no prediction of improved counts, and no candidate or native run."}
    (OUT / "straight-tail-check.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"requests": 882, "prefixes": 4, "natural_routes_identical": True,
                      "extra_length_range_m": [min(r["extra_metric_m"] for r in rows), max(r["extra_metric_m"] for r in rows)]}))


if __name__ == "__main__":
    main()
