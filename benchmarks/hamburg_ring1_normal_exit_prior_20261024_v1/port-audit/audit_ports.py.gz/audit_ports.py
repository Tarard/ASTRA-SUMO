"""Inspect actual model ports and one named comparison against frozen sources."""

import csv
import gzip
import hashlib
import heapq
import itertools
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from pyproj import Transformer

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[1]
CURRENT=REPO/"outputs/hamburg-z5-single-share-20261024-v1/one-share/prepared/network.net.xml"
FULL=REPO/"benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml"
OSM=REPO/"benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz"
OLD_OSM=REPO/"benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/ring1-full_filtered.osm.xml.gz"
DECL=REPO/"benchmarks/hamburg_ring1_munich_corridor_20261022_v1/boundaries.json"
OLD_DECL=REPO/"benchmarks/hamburg_ring1_m1_2_demand_pool_20261021_v1/base/boundary-declarations.json"
FRAME=REPO/"benchmarks/hamburg_ring1_end_to_end_20261021_v1/figure-sources/source.json"
DEMAND=CURRENT.parent/"demand.rou.xml"
INTENTS=CURRENT.parent/"lane-intentions.json"
LOOPS=CURRENT.parent/"field-loops.add.xml"
BINDINGS=REPO/"benchmarks/hamburg_ring1_m2_control_20261021_v1/link-bindings.json.gz"
NATIVE_ROUTES=CURRENT.parent.parent/"evaluation/native/vehicle-routes.xml"
LINEAGE=REPO/"outputs/hamburg-parking-exit-prior-lineage-20261024-v1"


def movement(net, connection):
    lanes={lane.get("id"):lane for edge in net.findall("edge") for lane in edge.findall("lane")}
    chain=[]
    via=connection.get("via")
    seen=set()
    permitted_connections=permitted(connection)
    while via:
        assert via not in seen
        seen.add(via)
        chain.append(via)
        road,index=via.rsplit("_",1)
        following=[q for q in net.findall("connection") if q.get("from")==road and q.get("fromLane")==index and q.get("to")==connection.get("to") and q.get("toLane")==connection.get("toLane")]
        assert len(following)==1
        permitted_connections=permitted_connections and permitted(following[0])
        via=following[0].get("via")
    endpoints=[f"{connection.get('from')}_{connection.get('fromLane')}",f"{connection.get('to')}_{connection.get('toLane')}"]
    keep=["from","fromLane","to","toLane","via","dir","tl","linkIndex","allow","disallow","state"]
    return dict(connection={k:connection.get(k) for k in keep if connection.get(k) is not None},internal_lanes=chain,
        internal_length_m=sum(float(lanes[lane].get("length")) for lane in chain),
        passenger_allowed=permitted_connections and all(permitted(lanes[lane]) for lane in endpoints+chain))


def bounded_reentry(full,current,start):
    """One local existing-source witness, with no lane change or U-turn."""
    retained={edge.get("id") for edge in current.findall("edge") if not edge.get("function")}
    edges={edge.get("id"):edge for edge in full.findall("edge") if not edge.get("function")}
    connections=full.findall("connection")
    serial=itertools.count()
    heap=[]
    for lane in edges[start].findall("lane"):
        if permitted(lane):
            heapq.heappush(heap,(0.,next(serial),start,lane.get("index"),[start],[]))
    seen=set()
    while heap:
        distance,_,edge,index,path,moves=heapq.heappop(heap)
        if (edge,index) in seen:
            continue
        seen.add((edge,index))
        if edge!=start and edge in retained:
            return dict(status="source_lane_witness_found",roads=path,movements=moves,
                omitted_roads=path[1:-1],reentry_road=edge,reentry_node=edges[edge].get("from"),
                post_port_to_reentry_lane_start_distance_m=distance,ordinary_lane_changes=0,Uturns=0)
        if len(path)>7 or distance>600:
            continue
        for connection in connections:
            following=connection.get("to")
            if connection.get("from")!=edge or connection.get("fromLane")!=index or following not in edges or following in path or connection.get("dir") in {"t","T"}:
                continue
            info=movement(full,connection)
            if not info["passenger_allowed"]:
                continue
            next_distance=distance+info["internal_length_m"]
            if following not in retained:
                lane=next(lane for lane in edges[following].findall("lane") if lane.get("index")==connection.get("toLane"))
                next_distance+=float(lane.get("length"))
            if next_distance<=600:
                heapq.heappush(heap,(next_distance,next(serial),following,connection.get("toLane"),path+[following],moves+[info]))
    return dict(status="no_witness_within_declared_search",maximum_omitted_roads=6,maximum_distance_m=600,ordinary_lane_changes=0,Uturns=0)


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def tags(e):
    return {t.get("k"):t.get("v") for t in e.findall("tag")}


def permitted(lane):
    allow,deny=lane.get("allow"," ").split(),lane.get("disallow","").split()
    return (not allow or "all" in allow or "passenger" in allow) and "all" not in deny and "passenger" not in deny


def main():
    nets=[ET.parse(p).getroot() for p in [CURRENT,FULL]]
    roots=[ET.fromstring(gzip.decompress(p.read_bytes())) for p in [OSM,OLD_OSM]]
    nodes={n.get("id"):n for n in roots[0].findall("node")}
    ways={w.get("id"):w for w in roots[0].findall("way")}
    declarations=[json.loads(p.read_bytes())["zones"] for p in [DECL,OLD_DECL]]
    frame=json.loads(FRAME.read_bytes())["bounds_epsg25832"]
    transform=Transformer.from_crs(4326,25832,always_xy=True)
    vehicles={v.get("id"):v for v in ET.parse(DEMAND).getroot().findall("vehicle")}
    intents={r["vehicle_id"]:r for r in json.loads(INTENTS.read_bytes())["vehicles"]}
    demand_by_destination={}
    for identity,vehicle in vehicles.items():
        end=vehicle.find("route").get("edges").split()[-1]
        demand_by_destination.setdefault(end,{})
        field=intents[identity]["field_id"]
        demand_by_destination[end][field]=demand_by_destination[end].get(field,0)+1
    assert len(demand_by_destination)==8 and sum(sum(fields.values()) for fields in demand_by_destination.values())==8640
    native_vehicles={v.get("id"):v for v in ET.parse(NATIVE_ROUTES).getroot().findall("vehicle")}
    assert len(native_vehicles)==8640 and native_vehicles.keys()==vehicles.keys()
    assert all(native_vehicles[i].find("route").get("edges")==v.find("route").get("edges") for i,v in vehicles.items())
    records=[]
    for identity in sorted(demand_by_destination)+["142944318"]:
        edge=nets[0].find(f"edge[@id='{identity}']")
        source_edge=nets[1].find(f"edge[@id='{identity}']")
        endpoint=edge.get("to")
        way=ways[identity.split("#")[0]]
        refs=[r.get("ref") for r in way.findall("nd")]
        at=refs.index(endpoint)
        old_way=roots[1].find(f"way[@id='{way.get('id')}']")
        assert old_way is not None and refs==[r.get("ref") for r in old_way.findall("nd")] and tags(way)==tags(old_way)
        node=nodes[endpoint]
        point=transform.transform(float(node.get("lon")),float(node.get("lat")))
        all_out=[]
        for net in nets:
            turns=[]
            for c in net.findall("connection"):
                if c.get("from")!=identity or c.get("to","").startswith(":") or c.get("dir") in {"t","T"}:
                    continue
                turns.append(movement(net,c))
            all_out.append(turns)
        assert not any(t["passenger_allowed"] for t in all_out[0])
        current_declarations=[z for z in declarations[0] if identity in z.get("exit_edges",[])]
        old_declarations=[z for z in declarations[1] if identity in z.get("exit_edges",[])]
        assert current_declarations and old_declarations
        original_continues=any(t["passenger_allowed"] for t in all_out[1])
        record=dict(edge_id=identity,classification="declared_graph_scope_cut_with_original_passenger_continuation" if original_continues else "inherited_source_terminal_external_continuation_unknown",
            current_edge=dict(edge.attrib),source_edge=dict(source_edge.attrib),current_declarations=current_declarations,earlier_declarations=old_declarations,
            current_forward_passenger_turns=all_out[0],original_forward_turns=all_out[1],
            original_way_id=way.get("id"),original_way_tags=tags(way),original_way_refs=refs,endpoint_ref_index_zero_based=at,
            endpoint_node=dict(node.attrib),endpoint_node_tags=tags(node),
            downstream_same_way_nodes=[dict(nodes[i].attrib) for i in refs[at+1:]],
            incident_OSM_ways=[dict(id=w.get("id"),refs=[n.get("ref") for n in w.findall("nd")],tags=tags(w)) for w in ways.values() if any(n.get("ref")==endpoint for n in w.findall("nd"))],
            endpoint_epsg25832=list(point),inside_fixed_display_frame=frame[0]<=point[0]<=frame[2] and frame[1]<=point[1]<=frame[3],display_frame_is_model_domain_proof=False,
            original_same_way_edges=[dict(e.attrib) for e in nets[1].findall("edge") if not e.get("function") and e.get("id").split("#")[0]==way.get("id")],
            no_physical_external_domain_crossing_proven=True)
        planned=demand_by_destination.get(identity,{})
        record.update(actual_planned_requests=sum(planned.values()),is_actual_destination=identity in demand_by_destination,actual_fields=planned,local_reentry_witness=bounded_reentry(nets[1],nets[0],identity))
        witness=record["local_reentry_witness"]
        if witness["status"]=="source_lane_witness_found":
            reentry=nodes[witness["reentry_node"]]
            reentry_xy=transform.transform(float(reentry.get("lon")),float(reentry.get("lat")))
            witness.update(reentry_node_osm=dict(reentry.attrib),cut_to_reentry_node_straight_distance_m=((point[0]-reentry_xy[0])**2+(point[1]-reentry_xy[1])**2)**.5,same_source_junction_id=witness["reentry_node"]==endpoint,physical_junction_grouping="not_established_by_distance_or_node_ID")
        if identity=="28665128#0":
            assert tags(way)["service"]=="parking_aisle"
            downstream=[dict(c.attrib) for c in nets[1].findall("connection") if c.get("from")=="28665128#3" and c.get("to") in {"186821026","-186821028"}]
            assert downstream and all(nets[0].find(f"edge[@id='{c['to']}']") is not None for c in downstream)
            record.update(classification="truncated_parking_aisle_access_not_generic_external_outlet",source_downstream_rejoins_retained_roads=downstream,
                general_through_destination_support="review_required: a parking destination needs an explicit parking-activity assumption; a6.76m entrance is not evidence of an external city outlet")
        records.append(record)
    field_bindings=json.loads(gzip.decompress(BINDINGS.read_bytes()))["rows"]
    loops={r.get("id"):r for r in ET.parse(LOOPS).getroot()}
    affected_fields=demand_by_destination["28665128#0"]
    field_choices=[]
    for field in sorted(affected_fields):
        field_edge,field_lane=loops[field].get("lane").rsplit("_",1)
        connection=next(c for c in nets[0].findall("connection") if c.get("from")==field_edge and c.get("fromLane")==field_lane and c.get("to")=="186821029#1" and c.get("toLane")=="2")
        info=movement(nets[0],connection)
        assert info["passenger_allowed"]
        key=[field_edge,int(field_lane),"186821029#1",2]
        official=[r for r in field_bindings if r["physical_key"]==key]
        assert official and official[0]["official_movements"]
        field_choices.append(dict(field=field,requests=affected_fields[field],detector=dict(loops[field].attrib),permitted_after_detector_movement=info,existing_official_535_binding=official))
    branch_choices=[]
    for target,lane in [("28665128#0","0"),("186821028","2")]:
        connection=next(c for c in nets[0].findall("connection") if c.get("from")=="186821029#1" and c.get("fromLane")=="2" and c.get("to")==target and c.get("toLane")==lane)
        info=movement(nets[0],connection)
        assert info["passenger_allowed"]
        branch_choices.append(info)
    continuation=[]
    for start,target in [("186821028","186821026"),("186821026","142944318")]:
        connection=next(c for c in nets[0].findall("connection") if c.get("from")==start and c.get("fromLane")=="2" and c.get("to")==target and c.get("toLane")=="2")
        info=movement(nets[0],connection)
        assert info["passenger_allowed"] and connection.get("dir")=="s"
        continuation.append(info)
    comparison=next(r for r in records if r["edge_id"]=="142944318")
    records=[r for r in records if r["is_actual_destination"]]
    reverse=nets[0].find("edge[@id='-142944318']")
    assert reverse.get("from")==comparison["current_edge"]["to"]
    assert any("-142944318" in z["entry_edges"] for z in comparison["current_declarations"])
    tail_edges=["186821029#1","186821028","186821026","142944318"]
    tail_lane_lengths=[float(nets[0].find(f"edge[@id='{edge}']/lane[@index='2']").get("length")) for edge in tail_edges]
    straight_movement=branch_choices[1]
    tail_internal=straight_movement["internal_length_m"]+sum(m["internal_length_m"] for m in continuation)
    straight_tail_length=sum(tail_lane_lengths)+tail_internal
    parking_tail_length=tail_lane_lengths[0]+branch_choices[0]["internal_length_m"]+float(nets[0].find("edge[@id='28665128#0']/lane[@index='0']").get("length"))
    assert not any(loop.get("lane").rsplit("_",1)[0] in tail_edges for loop in loops.values())
    comparison.update(shared_existing_reverse_entry=dict(reverse.attrib),current_complete_lane2_chain=tail_edges,
        current_complete_turn_support=[straight_movement]+continuation,all_passenger_allowed=True,no_Uturn_or_repeated_tail_edge=True,
        extra_declared_field_detectors_on_tail=[],ordinary_lane_lengths_m=tail_lane_lengths,internal_lengths_total_m=tail_internal,
        full_current_tail_from_186821029_start_to_exit_end_m=straight_tail_length,
        parking_tail_from_same_start_m=parking_tail_length,distance_added_vs_parking_m=straight_tail_length-parking_tail_length,
        conclusion="Existing paired road graph-scope cut, not a terminal of the full original source. It is not a new sink, but a geographic external boundary and real destination shares remain unproved.")
    affected=dict(requests=882,fields=affected_fields,field_specific_support=field_choices,same_lane2_branch_choices=branch_choices,current_straight_continuation=continuation,
        all882_routes_choose_parking=True,parking_is_not_only_passenger_continuation=True,
        destination_186821027_requires_Uturn_from_this_approach=True,
        official_scope="The frozen535 binding supports movements onto186821029#1. The197 onward branches are native/source model support; independent field control and real destination shares are not established.",
        parking_activity_declaration="No parking-activity allocation or facility-capacity claim was found in the inspected scenario and boundary declarations. OSM parking_aisle alone is not observed parking OD.")
    policy=REPO/"plugins/astra-sumo/src/astra_sumo/core/road_hierarchy.py"
    od_policy=REPO/"plugins/astra-sumo/src/astra_sumo/core/hamburg_od_definition.py"
    related={}
    for name,expected in [("manifest.json","36d29ece667c57e1fb7d67aa8aa3e00ae34a1a8f4044736cef0e85fbecf7d022"),("lineage.json","333a61b739f5185e9fa44c0d6b11b334aca9b6833e2865c9bf4a7efb529caa4c"),("straight-tail-check.json","3b803718a97b84f488788bef2fe423f2778f17a0db496a10cffaba9f45c895c8")]:
        assert digest(LINEAGE/name)==expected
        related[name]=dict(path=str(LINEAGE/name),sha256=expected)
    result=dict(schema="astra.hamburg.named-port-boundary-independent/v1",status="review_required",native_runs=0,candidates_created=0,
        named_ports=records,actual_destination_count=8,native8640_arrived_route_endpoints_equal_explicit_requests=True,destination_field_inventory=demand_by_destination,parking_endpoint_affected_demand=affected,
        additional_endpoint142944318=comparison,display_frame_epsg25832=frame,
        evidence_rules=[
            "Current leaf status means no retained forward passenger continuation. It does not prove a physical road end or an external-domain exit.",
            "An existing declared graph-scope cut may be a model port while located inside a display frame. It remains an OD modeling hypothesis, not observed destination demand.",
            "A source-forward permitted connection and original OSM continuation prove that downstream roads were omitted from the selected graph. They do not alone prove a geographic study-domain crossing.",
            "A geographic external-outlet claim needs an explicit study-domain definition and a source-backed outward continuation across it. The aerial review bbox is not such a definition.",
            "Keep each detector prefix and full route to an approved interface. Do not replace a post-detector internal road with a sink or use a shorter destination solely to delete traffic.",
            "Parking access is a facility hypothesis, not a generic city outlet. Legal access and native completion do not establish parking demand, storage or through-traffic diversion."],
        declaration_basis_drift_fact="1257937836#0,551303415#0,28665128#0 and the comparison142944318 are scope_cut in the earlier list but source_model_boundary in the later list; original forward passenger connections remain documented.",
        interpretation="road_hierarchy._boundaries labels source_model_boundary when the supplied graph has no neighbor, so a prior cut can lose its provenance if a pruned graph is reused. This is a code-based explanation, not a traced execution cause of this particular later list.",
        related_parking_choice_lineage_audit=related,related_audit_usage="Hashes and declared scope checked. This endpoint audit does not repeat the other audit's historical760-column reconstruction.",
        unknowns=["Physical external study-domain boundary for these ports", "Real destination shares for the119 streams and882 parking-ended requests", "Whether the frozen OSM terminal199500676 reflects data scope or a physical terminus", "Complete generation call chain behind the changed later declaration labels"],
        source_hashes={str(p):digest(p) for p in [CURRENT,FULL,OSM,OLD_OSM,DECL,OLD_DECL,FRAME,DEMAND,INTENTS,LOOPS,CURRENT.parent/"scenario.json",NATIVE_ROUTES,BINDINGS,policy,od_policy]},
        claim_boundary="Only the eight actual destinations, one named existing comparison port, bounded source continuations and affected535 movements were inspected. No new demand route, sink, destination allocation, native run, control change, demand excess claim or field-OD inference is supplied.")
    (OUT/"evidence.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (OUT/"142944318-check.json").write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    with (OUT/"named-ports.csv").open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=["edge_id","requests","fields","current_length_m","later_basis","earlier_basis","original_forward_passenger_targets","OSM_end_is_way_terminal","source_OSM_remaining_nodes","parking_aisle","inside_display_frame","first_source_reentry_road","full_native_distance_to_reentry_lane_start_m","classification"])
        writer.writeheader()
        for r in records:
            writer.writerow(dict(edge_id=r["edge_id"],requests=r["actual_planned_requests"],fields=json.dumps(r["actual_fields"]),current_length_m=r["current_edge"].get("length"),later_basis=json.dumps(r["current_declarations"][0]["basis"]),earlier_basis=json.dumps(r["earlier_declarations"][0]["basis"]),original_forward_passenger_targets=json.dumps(sorted({t["connection"]["to"] for t in r["original_forward_turns"] if t["passenger_allowed"]})),OSM_end_is_way_terminal=r["endpoint_ref_index_zero_based"]==len(r["original_way_refs"])-1,source_OSM_remaining_nodes=len(r["downstream_same_way_nodes"]),parking_aisle=r["original_way_tags"].get("service")=="parking_aisle",inside_display_frame=r["inside_fixed_display_frame"],first_source_reentry_road=r["local_reentry_witness"].get("reentry_road"),full_native_distance_to_reentry_lane_start_m=r["local_reentry_witness"].get("post_port_to_reentry_lane_start_distance_m"),classification=r["classification"]))
    print(json.dumps(dict(status=result["status"],ports=len(records),native_runs=0)))


if __name__=="__main__":
    main()
