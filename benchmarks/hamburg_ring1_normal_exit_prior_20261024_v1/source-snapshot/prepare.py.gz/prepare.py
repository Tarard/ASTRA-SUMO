"""Prepare one fixed exit-prior sensitivity and four existing-route smoke vehicles."""

from collections import Counter, defaultdict
from copy import deepcopy
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share/prepared"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
         "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json")
OLD = b"186821029#1 28665128#0"
NEW = b"186821029#1 186821028 186821026 142944318"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def native_bin(vehicle):
    return int(math.floor(float(vehicle.get("depart")) * 1000 + .5)) // 900000


def inventory(vehicles, pairs):
    counts = [0] * 294
    cells = {}
    for vehicle in vehicles:
        route = vehicle.find("route").get("edges").split()
        index = native_bin(vehicle) * 21 + pairs.index((route[0], route[-1]))
        assert 0 <= index < 294
        cells[vehicle.get("id")] = index
        counts[index] += 1
    return counts, cells


def main():
    for name in ("full", "smoke", "source-snapshot"):
        assert not (OUT / name).exists(), "Keep any prior preparation unchanged."
    source_raw = {name: (SOURCE / name).read_bytes() for name in NAMES}
    source_root = ET.fromstring(source_raw["demand.rou.xml"])
    old_vehicles = {v.get("id"): v for v in source_root.findall("vehicle")}
    old_intent = json.loads(source_raw["lane-intentions.json"])
    old_rows = {r["vehicle_id"]: r for r in old_intent["vehicles"]}
    assert len(old_vehicles) == len(old_rows) == 8640 and old_vehicles.keys() == old_rows.keys()
    assert source_raw["demand.rou.xml"].count(OLD) == 882 and NEW not in source_raw["demand.rou.xml"]
    full_raw = source_raw["demand.rou.xml"].replace(OLD, NEW)
    assert full_raw.replace(NEW, OLD) == source_raw["demand.rou.xml"]
    full_root = ET.fromstring(full_raw)
    vehicles = full_root.findall("vehicle")
    current = {v.get("id"): v for v in vehicles}
    assert list(current) == list(old_vehicles)
    old_pairs = sorted({(v.find("route").get("edges").split()[0], v.find("route").get("edges").split()[-1]) for v in old_vehicles.values()})
    pairs = sorted({(v.find("route").get("edges").split()[0], v.find("route").get("edges").split()[-1]) for v in vehicles})
    assert len(old_pairs) == len(pairs) == 21
    old_q, old_cells = inventory(old_vehicles.values(), old_pairs)
    q, cells = inventory(vehicles, pairs)
    assert all(old_rows[identity]["od_cell"] == value for identity, value in old_cells.items())
    assert sum(q) == 8640 and min(q) > 0
    changed, metadata, by_prefix = [], [], defaultdict(list)
    for identity, vehicle in current.items():
        previous = old_vehicles[identity]
        assert vehicle.attrib == previous.attrib
        assert [ET.tostring(c) for c in vehicle if c.tag != "route"] == [ET.tostring(c) for c in previous if c.tag != "route"]
        old_route = previous.find("route").get("edges").split()
        new_route = vehicle.find("route").get("edges").split()
        different = old_route != new_route
        if different:
            assert old_route[-2:] == ["186821029#1", "28665128#0"]
            assert new_route == old_route[:-1] + ["186821028", "186821026", "142944318"]
            assert previous.find("route").attrib.keys() == vehicle.find("route").attrib.keys()
            assert len(new_route) == len(set(new_route))
            by_prefix[tuple(old_route)].append(identity)
            changed.append({"vehicle_id": identity, "field_id": old_rows[identity]["field_id"],
                            "depart": vehicle.get("depart"), "old_od_cell": old_cells[identity],
                            "new_od_cell": cells[identity], "old_destination": "28665128#0", "new_destination": "142944318"})
        else:
            assert ET.tostring(previous) == ET.tostring(vehicle)
        if cells[identity] != old_cells[identity]:
            metadata.append({"vehicle_id": identity, "old_od_cell": old_cells[identity],
                             "new_od_cell": cells[identity], "route_changed": different})
    assert len(changed) == 882 and len(by_prefix) == 4
    assert sum(not r["route_changed"] for r in metadata) == 81
    assert old_rows["od_0209_v00026"]["field_id"] == "hh_0119_Z_5_30494"
    assert current["od_0209_v00026"].find("stop").get("lane") == "24483344#1_1"
    full_intent = deepcopy(old_intent)
    for row in full_intent["vehicles"]:
        row["od_cell"] = cells[row["vehicle_id"]]
        assert {k: v for k, v in row.items() if k != "od_cell"} == {k: v for k, v in old_rows[row["vehicle_id"]].items() if k != "od_cell"}
    selected = []
    for identities in by_prefix.values():
        eligible = [identity for identity in identities if native_bin(current[identity]) >= 4]
        selected.append(min(eligible, key=lambda identity: (float(current[identity].get("depart")), identity)))
    selected.sort(key=lambda identity: (float(current[identity].get("depart")), identity))
    assert len(set(selected)) == 4
    smoke_root = ET.Element(source_root.tag, source_root.attrib)
    smoke_root.extend(deepcopy(row) for row in source_root if row.tag != "vehicle")
    smoke_root.extend(deepcopy(current[identity]) for identity in selected)
    smoke_intent = deepcopy(full_intent)
    smoke_intent["vehicles"] = [deepcopy(r) for r in full_intent["vehicles"] if r["vehicle_id"] in selected]
    smoke_q, _ = inventory(smoke_root.findall("vehicle"), pairs)
    scenario = json.loads(source_raw["scenario.json"])
    request_path = SOURCE.parent / "evaluation/native/native-request.json"
    request = json.loads(request_path.read_bytes())
    driver_scope = {key: request[key] for key in ("backend", "end_s", "all_stopped_timeout_s", "junction_body_hold", "junction_body_hold_nodes")}
    command = request["command"]
    driver_scope.update({key: command[command.index(flag) + 1] for key, flag in
                         (("step_length_s", "--step-length"), ("seed", "--seed"), ("precision", "--precision"))})
    source_hashes = {str(SOURCE / name): sha(raw) for name, raw in source_raw.items()}
    source_hashes[str(request_path)] = sha(request_path.read_bytes())
    source_hashes[str(Path(__file__).resolve())] = sha(Path(__file__).read_bytes())
    evidence_paths = [REPO / "outputs/hamburg-parking-exit-prior-lineage-20261024-v1" / name for name in
                      ("manifest.json", "lineage.json", "straight-tail-check.json")]
    evidence_paths += [REPO / "outputs/hamburg-route-port-boundary-audit-20261024-v1" / name for name in
                       ("manifest.json", "142944318-check.json")]
    for path in evidence_paths:
        source_hashes[str(path)] = sha(path.read_bytes())
    snapshot = OUT / "source-snapshot"
    snapshot.mkdir()
    for name, raw in source_raw.items():
        (snapshot / (name + ".gz")).write_bytes(gzip.compress(raw, mtime=0))
    (snapshot / "prepare.py").write_bytes(Path(__file__).read_bytes())
    (snapshot / "native-request.json.gz").write_bytes(gzip.compress(request_path.read_bytes(), mtime=0))
    for path in evidence_paths:
        label = path.parent.name + "--" + path.name + ".gz"
        (snapshot / label).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    cells_rows = [{"index": h * 21 + j, "origin": origin, "destination": destination,
                   "begin_s": h * 900, "end_s": (h + 1) * 900}
                  for h in range(14) for j, (origin, destination) in enumerate(pairs)]
    full_scope = None
    for label, demand, intent, vector in (("full", full_raw, full_intent, q),
                                        ("smoke", ET.tostring(smoke_root, encoding="utf-8", xml_declaration=True), smoke_intent, smoke_q)):
        case = OUT / label
        prepared = case / "prepared"
        prepared.mkdir(parents=True)
        for name, raw in source_raw.items():
            (prepared / name).write_bytes(raw)
        (prepared / "demand.rou.xml").write_bytes(demand)
        write_json(prepared / "lane-intentions.json", intent)
        declared = deepcopy(scenario)
        declared.update(status="diagnostic_exit_prior_candidate" if label == "full" else "route_support_smoke_only",
                        vehicles=sum(vector), main_vehicles=6687 if label == "full" else 4,
                        initialization_vehicles=1953 if label == "full" else 0,
                        demand_sha256=sha(demand), formal_result=False, exact_count_fit=False,
                        demand_prior="100% through-destination sensitivity for the existing882 parking-ending requests. Replace only the final parking road by existing186821028/186821026/142944318. No observed parking activity or identified through share is supplied. The existing paired ordinary-road scope cut is not a proven real road end.",
                        exit_prior_source="healthy one-share8640 explicit input, not the previous best3.715 reference")
        if label == "smoke":
            declared.update(profiles_used=4, claim_boundary="Four unchanged main-period request IDs/times and intended fields from four complete prefixes. Only check actual legal field/port arrivals and native safety. All13 real loops and182 real target rows remain, but smoke count errors are not calibration results.")
        write_json(prepared / "scenario.json", declared)
        write_json(case / "od-vector.json", {"values": vector, "vehicle_count": sum(vector),
                   "ordering": "native-millisecond departure bin, then lexicographic actual origin and destination",
                   "cells_file": "cells294.json", "actual_destinations_changed": True})
        write_json(case / "cells294.json", {"cells": cells_rows, "empirical_generation": False,
                   "note": "Coordinates describe the saved explicit XML. Never regenerate from the old model."})
        prepared_hashes = {name: sha((prepared / name).read_bytes()) for name in NAMES}
        assert all(prepared_hashes[name] == sha(source_raw[name]) for name in
                   ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"))
        scope = {"status": "pass", "formal_result": False, "native_runs": 0, "N": sum(vector),
                 "source_hashes": source_hashes, "prepared_hashes": prepared_hashes,
                 "original_driver_scope": driver_scope,
                 "actual_changes": {"route_tail_changes": 882 if label == "full" else 4,
                    "request_ids_changed": 0, "request_departures_changed": 0, "vehicle_attributes_changed": 0,
                    "stops_changed": 0, "field_intentions_changed": 0,
                    "metadata_od_cell_index_changes_full": len(metadata),
                    "unchanged_route_rows_with_reindexed_od_cell_full": 81,
                    "old_actual_OD_pairs": 21, "new_actual_OD_pairs": 21,
                    "actual_destination_requests_changed": 882 if label == "full" else 4},
                 "checks": {"all_ids_unique": True, "all_request_attributes_and_nonroute_children_preserved": True,
                            "source_one_share_Z5_donor_preserved": True, "network_control_targets_rawbytes_identical": True,
                            "metadata_matches_new_actual_OD_native_bin": True, "request_count_matches_case": sum(vector) == (8640 if label == "full" else 4),
                            "real130_main_and52_initial_targets_unmodified": True},
                 "claim_boundary": "Preparation only.100% through sensitivity is not measured destination choice. No native outcome or count improvement is claimed. Smoke only checks4 existing IDs, fields, ports and safety, not calibration."}
        write_json(case / "scope-proof.json", scope)
        if label == "full":
            full_scope = scope
    write_csv(OUT / "full/route-changes.csv", changed)
    write_csv(OUT / "full/metadata-index-changes.csv", metadata)
    write_json(OUT / "full/od-coordinate-map.json", {"old_pairs": old_pairs, "new_pairs": pairs,
               "old_vector": old_q, "new_vector": q,
               "mapping": [{"old_pair_index": j, "new_pair_index": pairs.index((origin, "142944318" if destination == "28665128#0" else destination)),
                            "origin": origin, "old_destination": destination,
                            "new_destination": "142944318" if destination == "28665128#0" else destination}
                           for j, (origin, destination) in enumerate(old_pairs)],
               "note": "Actual four OD destinations change. Re-sorting also reindexes unchanged -983227468#1→199500676 requests. Numeric vector equality is not asserted."})
    write_json(OUT / "smoke/smoke-plan.json", {"status": "prepared_not_run", "expected_fields_by_vehicle": {i: old_rows[i]["field_id"] for i in selected},
               "expected_exit": "142944318", "vehicle_departures": {i: current[i].get("depart") for i in selected},
               "expected_no_unsafe_events": True, "must_all_arrive": True,
               "observations": "Original13 loops and130+52 targets unchanged. No calibration interpretation of four-car counts."})
    write_json(OUT / "selfchecks.json", {"status": "pass", "native_runs": 0, "source_N": 8640, "full_N": 8640,
               "route_tail_changes": 882, "other_whole_vehicle_XML_unchanged": 7758,
               "metadata_indices_changed": len(metadata), "unchanged_route_metadata_only": 81,
               "old_q_sum": sum(old_q), "new_q_sum": sum(q), "numeric_q_L1_due_to_coordinate_reordering": sum(abs(a-b) for a,b in zip(old_q,q)),
               "field_totals_preserved": dict(Counter(r["field_id"] for r in old_rows.values())),
               "smoke_IDs": selected, "prepared_hashes": full_scope["prepared_hashes"]})
    print(json.dumps({"status": "pass", "full_prepared": str(OUT / "full/prepared"), "smoke_prepared": str(OUT / "smoke/prepared"),
                      "metadata_reindexed": len(metadata), "smoke_IDs": selected}))


if __name__ == "__main__":
    main()
