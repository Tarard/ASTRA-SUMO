"""Test two declared boundary routes; this is not a count calibration run."""
import copy
import json
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

from astra_sumo.core.candidate_contracts import file_sha256
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages


def main():
    out = Path(__file__).resolve().parent
    root = out.parents[1]
    prepared = root / "outputs/hamburg-joint-od-spsa-20261023-v1/prepared"
    witness_path = root / "outputs/hamburg-joint-od-spsa-20261023-v1/support-audit/multi-field-witnesses.json"
    witnesses = json.loads(witness_path.read_bytes())
    loops = {r.get("id"): r for r in ET.parse(prepared / "field-loops.add.xml").getroot()}
    lanes = {r.get("id"): r for r in ET.parse(prepared / "network.net.xml").getroot().iter("lane")}
    source_demand = ET.parse(prepared / "demand.rou.xml").getroot()
    demand = ET.Element("routes")
    for vtype in source_demand.findall("vType"):
        demand.append(copy.deepcopy(vtype))
    intentions = []
    expected_signatures = {}
    for index, witness in enumerate(witnesses):
        edges, fields = witness["edges"], witness["fields"]
        assert len(edges) == len(set(edges)) and len(fields) == 2
        assert witness["junction_audit"]["allowed"] and not witness["uturn_connections"]
        assert edges[0] == witness["origin"] and edges[-1] == witness["destination"]
        identity = witness["id"]
        vehicle = ET.SubElement(demand, "vehicle", id=identity, type="readme_lane_intent",
                                depart=str(index * 900 + 10), departLane="best", departPos="5.1", departSpeed="max")
        ET.SubElement(vehicle, "route", edges=" ".join(edges))
        for field in fields:
            lane = loops[field].get("lane")
            length = float(lanes[lane].get("length"))
            assert length > 7.5 and lane.rsplit("_", 1)[0] in edges
            ET.SubElement(vehicle, "stop", lane=lane, endPos=f"{length - 7.5:.6f}", speed="13.888889")
        intentions.append({"vehicle_id": identity, "field_id": fields[0]})
        expected_signatures[identity] = fields
    ET.ElementTree(demand).write(out / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    (out / "lane-intentions.json").write_text(json.dumps({"mechanism": "Two native moving lane waypoints per route; existing rear-clear hold only at the first field.", "vehicles": intentions}, indent=2), encoding="utf-8")
    inputs = [prepared / name for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv")]
    inputs += [witness_path, out / "demand.rou.xml", out / "lane-intentions.json", Path(__file__).resolve()]
    provenance = {str(path): file_sha256(path) for path in inputs}
    protocol = {"claim": "Tiny native route-support test only. Real counts remain unmodified; its field-comparison is not a calibration result.", "expected_signatures": expected_signatures, "inputs": provenance,
                "python": sys.executable, "network_change": False, "control_change": False, "end_s": 14400, "step_s": .1, "seed": 104}
    (out / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    native = run_point_detector_demand(net_file=prepared / "network.net.xml", route_file=out / "demand.rou.xml",
        e1_additional_file=prepared / "field-loops.add.xml", expected_counts_csv=prepared / "expected-counts.csv",
        output_dir=out / "native", end_s=14400, sumo_binary=str(root / ".venv/Lib/site-packages/sumo/bin/sumo.exe"),
        timeout_seconds=300, signal_program_file=prepared / "control.add.xml", lane_intentions_file=out / "lane-intentions.json",
        junction_body_hold=True, junction_body_hold_nodes=("14398547", "205069138", "18653534", "LSA104_part0"),
        backend="libsumo", seed=104)
    passages = read_contributing_e1_passages(instant_file=out / "native/instant-e1.xml", periodic_file=out / "native/field-counts.xml",
        detector_ids=native["instant_to_periodic_ids"], step_length=.1)
    actual = defaultdict(list)
    for event in sorted(passages["passages"], key=lambda row: row["time_s"]):
        actual[event["vehicle_id"]].append(event["detector_id"])
    result = {"status": "pass" if native["healthy"] and passages["reconciled"] and dict(actual) == expected_signatures else "review_required",
              "formal_count_calibration": False, "healthy": native["healthy"], "completion": native["completion"],
              "expected_signatures": expected_signatures, "actual_signatures": dict(actual), "passages": passages,
              "inputs_unchanged": all(file_sha256(Path(path)) == value for path, value in provenance.items()),
              "claim_boundary": "Two isolated trips under the declared driver and control. No real OD share, congested capacity, or 130-field exact fit is established."}
    assert result["inputs_unchanged"]
    (out / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "passages"}, indent=2))


if __name__ == "__main__":
    main()
