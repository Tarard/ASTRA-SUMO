"""Measure a fixed list of paired lane-intention changes with native E1 counts."""
import argparse
from collections import Counter
import hashlib
import gzip
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.lane_section_hold import read_lane_intentions
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = ROOT.parent / 'hamburg-classical-od-calibration-20261023-v1'
FIELDS = ('hh_0119_Z_5_30494', 'hh_0119_Z_4_29437')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--pairs', type=int, choices=(1, 5), required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    assert Path(sys.executable).resolve() == (REPO / '.venv/Scripts/python.exe').resolve()
    assert {version(n) for n in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')} == {'1.27.1'}
    plan = json.loads(args.plan.read_bytes())
    pairs = plan['pairs'][:args.pairs]
    assert len(pairs) == args.pairs
    original = SOURCE / 'probe-minus1/evaluation'
    base = SOURCE / 'prepared'
    source_files = [base / n for n in ('network.net.xml', 'control.add.xml', 'field-loops.add.xml',
        'expected-counts.csv', 'initialization-counts.csv', 'scenario.json', 'od-model.json')]
    source_files += [original / n for n in ('demand.rou.xml', 'lane-intentions.json', 'od-vector.json', 'evaluation.json')]
    source_files.append(args.plan.resolve())
    source_hashes = {str(p): sha(p) for p in source_files}
    tree = ET.parse(original / 'demand.rou.xml')
    vehicles = {v.get('id'): v for v in tree.getroot().findall('vehicle')}
    intentions = json.loads((original / 'lane-intentions.json').read_bytes())
    assigned = {r['vehicle_id']: r for r in intentions['vehicles']}
    assert len(vehicles) == len(assigned) == 8640 and vehicles.keys() == assigned.keys()
    before_xml = {i: ET.tostring(v) for i, v in vehicles.items()}
    before_fields = {i: r['field_id'] for i, r in assigned.items()}
    inventory = Counter((int(float(vehicles[i].get('depart')) // 900), f) for i, f in before_fields.items())
    changed = []
    for pair in pairs:
        ids = [pair['z5_vehicle_id'], pair['z4_vehicle_id']]
        assert len(set(ids)) == 2 and not set(ids) & set(changed)
        assert [before_fields[i] for i in ids] == list(FIELDS)
        assert len({int(float(vehicles[i].get('depart')) // 900) for i in ids}) == 1
        stops = []
        for identity, lane in zip(ids, ('24483344#1_1', '24483344#1_0')):
            assert vehicles[identity].find('route').get('edges').split().count('24483344#1') == 1
            rows = [r for r in vehicles[identity].findall('stop') if r.get('lane') == lane]
            assert len(rows) == 1 and rows[0].get('endPos') == '87.630000'
            stops.append(rows[0])
        assert {k: v for k, v in stops[0].attrib.items() if k != 'lane'} == {k: v for k, v in stops[1].attrib.items() if k != 'lane'}
        for identity, stop, lane, field in zip(ids, stops, ('24483344#1_0', '24483344#1_1'), reversed(FIELDS)):
            stop.set('lane', lane)
            assigned[identity]['field_id'] = field
        changed.extend(ids)
    assert inventory == Counter((int(float(vehicles[i].get('depart')) // 900), r['field_id']) for i, r in assigned.items())
    for identity, v in vehicles.items():
        restored = ET.fromstring(ET.tostring(v))
        if identity in changed:
            stop = next(r for r in restored.findall('stop') if r.get('lane', '').startswith('24483344#1_'))
            stop.set('lane', '24483344#1_1' if before_fields[identity] == FIELDS[0] else '24483344#1_0')
        assert ET.tostring(restored) == before_xml[identity]
    out = ROOT / f'{"offline-" if args.prepare_only else ""}lane-swap-{args.pairs}pair'
    out.mkdir(exist_ok=False)
    prepared, evaluation = out / 'prepared', out / 'evaluation'
    prepared.mkdir()
    evaluation.mkdir()
    for path in source_files[:6]:
        shutil.copyfile(path, prepared / path.name)
    tree.write(prepared / 'demand.rou.xml', encoding='utf-8', xml_declaration=True)
    save(prepared / 'lane-intentions.json', intentions)
    read_lane_intentions(prepared / 'lane-intentions.json', prepared / 'field-loops.add.xml', vehicles)
    scenario = json.loads((prepared / 'scenario.json').read_bytes())
    scenario.update(demand_sha256=sha(prepared / 'demand.rou.xml'),
        lane_prior_treatment='Explicit paired Z4/Z5 moving-stop lane and intention swaps. OD, routes, departures and field totals per departure period are unchanged. Not a quantile OD update.')
    save(prepared / 'scenario.json', scenario)
    for name in ('demand.rou.xml', 'lane-intentions.json'):
        shutil.copyfile(prepared / name, evaluation / name)
    vector = json.loads((original / 'od-vector.json').read_bytes())
    vector['prior_od_model_sha256'] = vector.pop('source_model_sha256')
    vector.update(generation='Explicit lane-prior transform after the unchanged selected OD vector; the original model alone does not generate this demand.',
                  source_vector_sha256=sha(original / 'od-vector.json'), paired_vehicle_ids=changed)
    save(evaluation / 'od-vector.json', vector)
    shutil.copyfile(__file__, out / 'executed-driver.py')
    save(out / 'preflight.json', {'source_hashes': source_hashes, 'pairs': pairs, 'changed_vehicle_ids': changed,
        'input_sha256': {p.name: sha(p) for p in prepared.iterdir()},
        'implementation_sha256': {n: sha(REPO / 'plugins/astra-sumo/src/astra_sumo/core' / n) for n in
            ('detector_demand_replay.py', 'simulation_stall.py', 'lane_section_hold.py', 'hamburg_od_spsa.py')},
        'driver_sha256': sha(Path(__file__)), 'field_inventory_by_departure_period_identical': True,
        'all_routes_departures_other_attributes_identical': True, 'formal_result': False})
    if args.prepare_only:
        print(json.dumps({'prepared_only': True, 'changed_vehicle_ids': changed}), flush=True)
        return
    started = time.perf_counter()
    native = run_point_detector_demand(net_file=prepared / 'network.net.xml', route_file=prepared / 'demand.rou.xml',
        e1_additional_file=prepared / 'field-loops.add.xml', expected_counts_csv=prepared / 'expected-counts.csv',
        output_dir=evaluation / 'native', end_s=14400, timeout_seconds=4800, seed=104, backend='libsumo',
        sumo_binary=str(REPO / '.venv/Lib/site-packages/sumo/bin/sumo.exe'), signal_program_file=prepared / 'control.add.xml',
        lane_intentions_file=prepared / 'lane-intentions.json', junction_body_hold=True,
        junction_body_hold_nodes=_body_hold_nodes(prepared))
    measured = summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
    full = audit_expected_to_e1_strict(read_csv_rows(prepared / 'initialization-counts.csv') + read_csv_rows(prepared / 'expected-counts.csv'), evaluation / 'native/field-counts.xml')
    assert len(full) == 182 and all(r['measured_nVehContrib'] is not None for r in full)
    write_csv(evaluation / 'all182-comparison.csv', full, list(full[0]))
    baseline_full = audit_expected_to_e1_strict(read_csv_rows(prepared / 'initialization-counts.csv') + read_csv_rows(prepared / 'expected-counts.csv'), original / 'native/field-counts.xml')
    unchanged_before = min(float(vehicles[i].get('depart')) for i in changed)
    prefix = [(a, b) for a, b in zip(full, baseline_full, strict=True) if float(a['end']) <= unchanged_before]
    assert prefix and all(a == b for a, b in prefix)
    passages = read_contributing_e1_passages(instant_file=evaluation / 'native/instant-e1.xml',
        periodic_file=evaluation / 'native/field-counts.xml', detector_ids=native['instant_to_periodic_ids'], step_length=.1)
    assert passages['reconciled']
    (evaluation / 'contributing-passages.json.gz').write_bytes(gzip.compress(json.dumps(passages).encode('utf-8'), mtime=0))
    repeated = [key for key, n in Counter((r['vehicle_id'], r['detector_id']) for r in passages['passages']).items() if n > 1]
    wrong = [r for r in passages['passages'] if r['detector_id'] != assigned[r['vehicle_id']]['field_id']]
    baseline = json.loads((original / 'evaluation.json').read_bytes())
    safe = not any(measured['completion'][k] for k in ('collisions', 'teleports', 'discarded'))
    backlog = sum(measured['completion'][k] for k in ('waiting', 'running'))
    accepted = safe and not repeated and not wrong and measured['MAE'] < baseline['MAE'] and measured['loss'] < baseline['loss'] and backlog <= 21 and measured['completion']['waiting'] <= 7
    assert all(sha(Path(p)) == h for p, h in source_hashes.items())
    result = {'status': 'diagnostic_candidate' if accepted else 'rejected', 'before': baseline, 'after': measured,
        'all182_TAE': sum(abs(r['diff_nVehContrib_minus_expected']) for r in full),
        'elapsed_seconds': time.perf_counter() - started, 'source_inputs_unchanged': True,
        'unchanged_prefix_rows': len(prefix), 'repeated_vehicle_field': repeated, 'wrong_field_contributions': wrong,
        'formal_result': False, 'new_native_run': True, 'claim_boundary': scenario['lane_prior_treatment']}
    save(out / 'verdict.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
