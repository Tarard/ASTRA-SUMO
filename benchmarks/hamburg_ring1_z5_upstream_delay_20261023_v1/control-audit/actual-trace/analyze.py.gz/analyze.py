"""Read the completed TLS recording and compare it with declared static programs."""

from bisect import bisect_right
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / "trace/baseline"
LINKS = {"LSA104_part0": [23, 24, 25], "LSA118_part0": [39, 40, 41]}


def compare(phases, program, events, steps):
    cycle = [(i, state) for i, (duration, state) in enumerate(phases) for _ in range(duration)]
    assert events and events[0]["step"] == 0
    assert all(a["step"] < b["step"] for a, b in zip(events, events[1:]))
    errors, phase_errors, missing, cursor = [], [], 0, 0
    event_steps = {r["step"] for r in events}
    for event in events:
        phase, state = cycle[event["step"] % len(cycle)]
        if int(event["phase"]) != phase or event["state"] != state:
            phase_errors.append(event)
    for step in range(steps):
        if cursor + 1 < len(events) and events[cursor + 1]["step"] <= step:
            cursor += 1
        phase, expected = cycle[step % len(cycle)]
        event = events[cursor]
        if (event["state"], event["programID"]) != (expected, program):
            errors.append({"step": step, "expected": expected, "actual": event["state"]})
        if step and phase != cycle[(step-1) % len(cycle)][0] and expected == cycle[(step-1) % len(cycle)][1]:
            missing += step not in event_steps
    return {"steps_checked": steps, "switch_events": len(events), "state_or_program_mismatches": errors,
            "event_phase_mismatches": phase_errors, "same_state_phase_boundaries_without_events": missing}


def main():
    record = json.loads((SOURCE / "record-result.json").read_bytes())
    assert record["status"] == "pass" and all(record["checks"].values()) and len(record["checks"]) == 12
    statefile = SOURCE / "tls-switch-states.xml"
    assert hashlib.sha256(statefile.read_bytes()).hexdigest() == record["state_log"]["sha256"]
    controlfile = SOURCE / "signal-programs.add.xml"
    assert hashlib.sha256(controlfile.read_bytes()).hexdigest() == record["source_hashes"]["signal-programs.add.xml"]
    events = {tls: [] for tls in LINKS}
    for _, row in ET.iterparse(statefile, events=("end",)):
        if row.tag == "tlsState" and row.get("id") in events:
            tick = Decimal(row.get("time")) * 10
            assert tick == int(tick)
            events[row.get("id")].append({**row.attrib, "step": int(tick)})
        row.clear()
    checks = {}
    for logic in ET.parse(controlfile).getroot().findall("tlLogic"):
        tls = logic.get("id")
        if tls in LINKS:
            assert logic.get("type") == "static" and logic.get("offset") == "0"
            phases = [(int(Decimal(p.get("duration"))*10), p.get("state")) for p in logic.findall("phase")]
            assert sum(d for d, _ in phases) == 900
            checks[tls] = compare(phases, logic.get("programID"), events[tls], 144000)
            assert not checks[tls]["state_or_program_mismatches"] and not checks[tls]["event_phase_mismatches"]
    windows = {"queue_overlap": (131900, 132450), "focus_delay": (116700, 138492)}
    rows, summaries = [], {}
    for name, (begin, end) in windows.items():
        released = {}
        for tls, timeline in events.items():
            released[tls] = 0
            for i, event in enumerate(timeline):
                a, b = max(begin, event["step"]), min(end, timeline[i+1]["step"] if i+1 < len(timeline) else 144000)
                if a >= b:
                    continue
                states = "".join(event["state"][k] for k in LINKS[tls])
                if set(states) <= set("Gg"):
                    released[tls] += b-a
                rows.append({"window": name, "tls": tls, "begin_s": a/10, "end_s": b/10,
                             "target_links": ",".join(map(str, LINKS[tls])), "target_states": states,
                             "source_event_time_s": event["step"]/10, "phase_at_source_event_only": event["phase"]})
        times = sorted({begin, end} | {r["step"] for t in events.values() for r in t if begin < r["step"] < end})
        shared = 0
        for a, b in zip(times, times[1:]):
            current = {tls: timeline[bisect_right([r["step"] for r in timeline], a)-1]
                       for tls, timeline in events.items()}
            if all(current[tls]["state"][k] in "Gg" for tls in LINKS for k in LINKS[tls]):
                shared += b-a
        summaries[name] = {"begin_s": begin/10, "end_s": end/10,
                           "actual_target_release_seconds": {k: v/10 for k, v in released.items()},
                           "simultaneous_release_seconds": shared/10}
    with (ROOT / "actual-target-state-windows.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    files = [statefile, controlfile, SOURCE / "record-result.json", Path(__file__)]
    result = {"status": "pass", "formal_result": False, "new_native_runs": 0, "parity_checks_passed": 12,
              "checks": checks, "windows": summaries,
              "source_hashes": [{"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],
              "claim_boundary": "Actual selected-demand model replay after exact native-output parity, not field SPaT. Switch logs omit same-state phase boundaries. Event phase is checked only at emitted events. Target release does not prove available receiving space or absence of leaders."}
    (ROOT / "audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "windows": summaries}, indent=2))


if __name__ == "__main__":
    main()
