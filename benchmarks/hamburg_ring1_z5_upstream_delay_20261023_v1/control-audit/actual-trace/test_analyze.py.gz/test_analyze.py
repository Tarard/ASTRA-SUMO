"""Same-state phase changes need no switch event; this is not a mismatch."""

import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location("actual_control", Path(__file__).with_name("analyze.py"))
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def test_cycle_wrap_with_identical_state_does_not_require_phase_event():
    phases = [(90, "G"), (480, "r"), (330, "G")]
    events = [{"step": 0, "state": "G", "phase": "0", "programID": "p"},
              {"step": 90, "state": "r", "phase": "1", "programID": "p"},
              {"step": 570, "state": "G", "phase": "2", "programID": "p"},
              {"step": 990, "state": "r", "phase": "1", "programID": "p"}]
    result = audit.compare(phases, "p", events, 1080)
    assert not result["state_or_program_mismatches"]
    assert not result["event_phase_mismatches"]
    assert result["same_state_phase_boundaries_without_events"] == 1
