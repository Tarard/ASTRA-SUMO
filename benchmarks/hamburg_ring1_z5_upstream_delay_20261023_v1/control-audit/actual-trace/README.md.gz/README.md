# 104—118实际回放状态与声明对账

状态：`pass`，`formal_result=false`。本次只读取已完成的观察回放，没有新增原生运行。该回放与selected-minus1的208项原生E1、144000步Summary、235802个instant事件及8619条完成路线逐项一致，记录者的12项检查全部通过。本报告核对的是该模型回放，不能当作现场SPaT。

实际状态源为`trace/baseline/tls-switch-states.xml`，SHA-256为`fcb3c95f81b96e9c58203a5d6ac53aa63cffc2ac13ce949437c563610c92ebc8`。完整来源哈希与结果见[audit.json](audit.json)，目标状态区间见[CSV](actual-target-state-windows.csv)。

## 完整时窗核对

对104、118分别按事件重构[0,14400)的144000个0.1秒时步。完整状态字符串与当前cc7程序、offset=0、90秒周期完全一致。记录中的programID均为`readme_fixed_A`，每个已输出事件的phase索引也与声明相符。

| 控制器 | 重构时步 | 实际切换事件 | 状态/程序不符 | 事件phase不符 | 未另记的同态相位边界 |
| --- | ---: | ---: | ---: | ---: | ---: |
| LSA104_part0 | 144000 | 1281 | 0 | 0 | 159 |
| LSA118_part0 | 144000 | 2721 | 0 | 0 | 159 |

`SaveTLSSwitchStates`只在状态变化时输出。本例末相位与下一周期phase0状态相同，因此90秒及其后同类边界没有事件。例如13230秒没有新事件，不能把上一事件的phase8或phase17一直当作实际当前phase索引。CSV的`phase_at_source_event_only`只表示源事件时刻的索引，状态值可以延续到下一状态事件。

## 13190—13245秒的实际状态

| 目标连接 | 实际状态区间 |
| --- | --- |
| 104 links23/24/25 | 13190—13196为`r/r/r`，13196—13197为`u/u/u`，13197—13239为`g/g/g`，13239—13242为`y/y/y`，13242—13245为`r/r/r` |
| 118 links39/40/41 | 13190—13210为`r/r/r`，13210—13211为`u/u/u`，13211—13239为`g/G/G`，13239—13242为`y/y/y`，13242—13245为`r/r/r` |

该55秒窗口内，104目标释放42秒，118目标释放28秒，共同释放28秒。这确认了此前队列核查使用的窗口。释放状态本身不证明目标车道有接收空间，也不证明车辆前方没有leader或冲突约束。

## 焦点车长延误窗口

在[11670,13849.2)这一2179.2秒窗口内，104目标连接实际释放1027.2秒，118目标连接实际释放680.2秒，共同释放680.2秒。队列按1秒时点采样得到1028与681个释放样本，与连续时长不同，两者不应混写。

该车在104的body hold为11670.1—11677.4，进入234车道2后已有无需换道的主路路径。这些记录一起排除了“整个长延误窗口目标灯一直不放行”及“104 body hold一直未解除”的描述。排队溢出、leader、接收空间及实际换道仍由同一观察回放中的FCD、lanechange和既有queues核对。

104 link14与535 link5缺绿警告继续保留，本次目标连接核对没有处理这些警告。没有据本次结果修改相位、偏移、转向权限或需求。

离线重算与同态相位边界测试：

```powershell
.venv/Scripts/python.exe outputs/hamburg-z5-upstream-delay-20261023-v1/control-audit/actual-trace/analyze.py
.venv/Scripts/python.exe -m pytest outputs/hamburg-z5-upstream-delay-20261023-v1/control-audit/actual-trace/test_analyze.py -q
```
