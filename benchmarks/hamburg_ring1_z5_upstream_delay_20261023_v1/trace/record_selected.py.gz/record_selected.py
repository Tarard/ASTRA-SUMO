"""Record native TLS events with the original monitor and driver in one process."""
import argparse
import csv
from decimal import Decimal
import hashlib
import itertools
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import libsumo

from astra_sumo.core.simulation_stall import monitor_sumo


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CASES = {'baseline': ('C:/Users/Danial/.codex/worktrees/hamburg-reproduction/Torii/outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1', 14400)}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def elements(path, tag):
    for _, row in ET.iterparse(path, events=('end',)):
        if row.tag == tag:
            yield row
            row.clear()


def main(variant):
    label, end = CASES[variant]
    source = ROOT.parent/label/'evaluation/native'
    out = ROOT/variant
    out.mkdir(exist_ok=False)
    assert Path(sys.executable).resolve() == (REPO/'.venv/Scripts/python.exe').resolve()
    assert libsumo.__version__ == '1.27.1'
    names = ['network.net.xml', 'demand.rou.xml', 'signal-programs.add.xml', 'lane-intentions.json',
             'source-e1.add.xml', 'expected-counts.csv', 'e1.add.xml', 'instant.add.xml', 'native-request.json']
    hashes = {name: digest(source/name) for name in names}
    for name in names:
        shutil.copyfile(source/name, out/name)
    shutil.copyfile(Path(__file__), out/'record_tls.snapshot.py')
    for name in ('e1.add.xml', 'instant.add.xml'):
        tree = ET.parse(out/name)
        for row in tree.getroot():
            row.set('file', str(out/Path(row.get('file')).name))
            if row.tag == 'inductionLoop':
                row.set('end', str(end))
        tree.write(out/name, encoding='utf-8', xml_declaration=True)
    observer = ET.Element('additional')
    ET.SubElement(observer, 'timedEvent', type='SaveTLSSwitchStates', dest=str(out/'tls-switch-states.xml'))
    if variant == 'baseline':
        ET.SubElement(observer, 'timedEvent', type='SaveTLSProgram', dest=str(out/'tls-recorded-programs.add.xml'))
    ET.ElementTree(observer).write(out/'tls-observer.add.xml', encoding='utf-8', xml_declaration=True)
    request = json.loads((source/'native-request.json').read_bytes())
    command = [part.replace(str(source), str(out)) for part in request['command']]
    command[command.index('--end')+1] = str(end)
    position = command.index('--additional-files')+1
    command[position] += ','+str(out/'tls-observer.add.xml')
    cohort_file = REPO/'outputs/hamburg-classical-od-calibration-20261023-v1/selected-next-diagnosis/z5-tail115-vehicles.csv'
    with cohort_file.open(encoding='utf-8', newline='') as stream:
        cohort = sorted(row['vehicle_id'] for row in csv.DictReader(stream))
    assert len(cohort) == len(set(cohort)) == 115
    (out/'observed-vehicle-ids.json').write_text(json.dumps({'source': str(cohort_file), 'sha256': digest(cohort_file), 'vehicles': cohort}, indent=2)+'\n', encoding='utf-8')
    command.extend(['--fcd-output', str(out/'cohort-fcd.xml'), '--device.fcd.probability', '0',
        '--device.fcd.explicit', ','.join(cohort), '--device.fcd.period', '1',
        '--fcd-output.max-leader-distance', '200', '--lanechange-output', str(out/'lanechanges.xml')])
    request.update(command=command, end_s=end, monitor_file=str(out/'stall-monitor.json'))
    for key in ('lane_intentions_file', 'route_file', 'e1_file'):
        request[key] = request[key].replace(str(source), str(out))
    assert request['backend'] == 'libsumo' and request['monitor_interval_s'] is None
    assert command[command.index('--step-length')+1] == '0.1'
    (out/'native-request.json').write_text(json.dumps(request, indent=2)+'\n', encoding='utf-8')
    preflight = {'variant': variant, 'source': str(source), 'end_s': end, 'source_hashes': hashes,
        'script_sha256': digest(out/'record_tls.snapshot.py'),
        'driver_hashes': {name: digest(REPO/'plugins/astra-sumo/src/astra_sumo/core'/name)
                         for name in ('simulation_stall.py', 'lane_section_hold.py')},
        'observer_sha256': digest(out/'tls-observer.add.xml'), 'formal_result': False}
    (out/'preflight.json').write_text(json.dumps(preflight, indent=2)+'\n', encoding='utf-8')
    start = time.perf_counter()
    monitor_sumo(request)
    elapsed = time.perf_counter()-start
    checks = {'source_inputs_unchanged': hashes == {name: digest(source/name) for name in names},
        'network_demand_control_intentions_identical': all((out/name).read_bytes() == (source/name).read_bytes()
            for name in ('network.net.xml', 'demand.rou.xml', 'signal-programs.add.xml', 'lane-intentions.json', 'source-e1.add.xml'))}
    reference_counts = {(r.get('id'), r.get('begin'), r.get('end')): r.attrib
        for r in elements(source/'field-counts.xml', 'interval') if Decimal(r.get('end')) <= end}
    actual_counts = {(r.get('id'), r.get('begin'), r.get('end')): r.attrib
        for r in elements(out/'field-counts.xml', 'interval') if Decimal(r.get('begin')) < Decimal(r.get('end'))}
    checks['all_closed_e1_attributes_identical'] = actual_counts == reference_counts
    checks['expected_closed_e1_count'] = len(actual_counts) == (208 if variant == 'baseline' else 78)
    summary_differences, last_summary, step_count = [], None, 0
    reference_steps = (r for r in elements(source/'summary.xml', 'step') if Decimal(r.get('time')) < end)
    for original, current in itertools.zip_longest(reference_steps, elements(out/'summary.xml', 'step')):
        if original is None or current is None:
            summary_differences.append({'reason': 'step count differs'})
            break
        before = {k: v for k, v in original.attrib.items() if k != 'duration'}
        after = {k: v for k, v in current.attrib.items() if k != 'duration'}
        step_count += 1
        last_summary = dict(current.attrib)
        if before != after and len(summary_differences) < 10:
            summary_differences.append({'reference': before, 'recording': after})
    checks['all_prefix_traffic_summary_attributes_identical'] = not summary_differences
    checks['expected_native_step_count'] = step_count == end*10
    instant_differences, instant_count = [], 0
    reference_events = (r for r in elements(source/'instant-e1.xml', 'instantOut') if Decimal(r.get('time')) < end)
    actual_events = (r for r in elements(out/'instant-e1.xml', 'instantOut') if Decimal(r.get('time')) < end)
    for original, current in itertools.zip_longest(reference_events, actual_events):
        if original is None or current is None:
            instant_differences.append({'reason': 'event count differs'})
            break
        instant_count += 1
        if original.attrib != current.attrib and len(instant_differences) < 10:
            instant_differences.append({'reference': dict(original.attrib), 'recording': dict(current.attrib)})
    checks['all_prefix_instant_e1_attributes_identical'] = not instant_differences
    reference_vehicles = {v.get('id'): ET.canonicalize(ET.tostring(v, encoding='unicode'), strip_text=True)
        for v in elements(source/'vehicle-routes.xml', 'vehicle') if Decimal(v.get('arrival')) <= end}
    actual_vehicles = {v.get('id'): ET.canonicalize(ET.tostring(v, encoding='unicode'), strip_text=True)
        for v in elements(out/'vehicle-routes.xml', 'vehicle')}
    checks['all_arrived_prefix_vehicle_routes_and_exit_times_identical'] = actual_vehicles == reference_vehicles
    checks['zero_collisions'] = not ET.parse(out/'collisions.xml').getroot().findall('collision')
    monitor = json.loads((out/'stall-monitor.json').read_bytes())
    checks['monitor_completed'] = monitor['status'] == 'completed' and monitor['simulation_time_s'] == end
    programs = ET.parse(source/'signal-programs.add.xml').getroot().findall('tlLogic')
    kinds = {r.get('id'): r.get('type') for r in programs}
    initial = {r.get('id'): dict(r.attrib) for r in elements(out/'tls-switch-states.xml', 'tlsState') if Decimal(r.get('time')) == 0}
    checks['all_51_tls_initialized_at_zero'] = initial.keys() == kinds.keys() and len(initial) == 51
    exported = None
    if variant == 'baseline':
        exported_root = ET.parse(out/'tls-recorded-programs.add.xml').getroot()
        exported = exported_root.findall('tlLogic')
        checks['native_program_export_complete'] = exported_root.tag == 'additional' and len(exported) == 51 and {
            r.get('id') for r in exported} == kinds.keys() and all(r.get('type') == 'static' and sum(
                Decimal(p.get('duration')) for p in r.findall('phase')) == end for r in exported)
    result = {'status': 'pass' if all(checks.values()) else 'blocked', 'variant': variant, 'end_s': end,
        'elapsed_seconds': elapsed, 'formal_result': False, 'checks': checks,
        'closed_e1_rows': len(actual_counts), 'summary_steps_checked': step_count,
        'instant_e1_events_checked': instant_count, 'arrived_routes_checked': len(actual_vehicles),
        'completion': last_summary, 'tls_types': kinds, 'summary_differences': summary_differences,
        'instant_e1_differences': instant_differences, 'source_hashes': hashes,
        'state_log': {'path': str(out/'tls-switch-states.xml'), 'sha256': digest(out/'tls-switch-states.xml')},
        'program_export': {'path': str(out/'tls-recorded-programs.add.xml'),
                           'sha256': digest(out/'tls-recorded-programs.add.xml')} if exported is not None else None,
        'claim_boundary': 'Read-only native TLS, 115-vehicle FCD and lane-change recording of probe-minus1. Same demand and driving model; verify all native outputs against the selected source. No controller treatment was performed.'}
    (out/'record-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'variant': variant, 'elapsed_seconds': elapsed, 'checks': checks}), flush=True)
    assert all(checks.values()), checks


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant', choices=CASES, required=True)
    main(parser.parse_args().variant)
