"""Read selected and canonical native evidence; never run or change simulation."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path
from statistics import median
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
CASES = {'selected': ROOT / 'probe-minus1/evaluation',
         'canonical': ROOT.parent / 'hamburg-z5-native-feedback-20261023-v1/z15-half-unsplit-full/evaluation'}
Z5 = 'hh_0119_Z_5_30494'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stats(values):
    return {'n': len(values), 'min': min(values), 'median': median(values), 'max': max(values)} if values else {'n': 0}


def read_case(path):
    native = path / 'native'
    run = json.loads((native / 'run.json').read_bytes())
    vehicles = {v.get('id'): v for v in ET.parse(path / 'demand.rou.xml').getroot().findall('vehicle')}
    intent = {r['vehicle_id']: r for r in json.loads((path / 'lane-intentions.json').read_bytes())['vehicles']}
    trips = {t.get('id'): dict(t.attrib) for t in ET.parse(native / 'tripinfo.xml').getroot().findall('tripinfo')}
    passage = read_contributing_e1_passages(instant_file=native / 'instant-e1.xml', periodic_file=native / 'field-counts.xml',
        detector_ids=run['instant_to_periodic_ids'], step_length=.1)
    assert passage['reconciled'] and len(passage['interval_comparisons']) == 208
    by_vehicle = defaultdict(list)
    for event in passage['passages']:
        by_vehicle[event['vehicle_id']].append(event)
    status = {i: 'not_inserted' if i not in trips else 'running' if float(trips[i]['arrival']) < 0 else 'arrived' for i in vehicles}
    assert Counter(status.values()) == {'not_inserted': run['completion']['waiting'],
        'running': run['completion']['running'], 'arrived': run['completion']['arrived']}
    last = None
    for _, row in ET.iterparse(native / 'summary.xml', events=('end',)):
        if row.tag == 'step':
            last = dict(row.attrib)
            row.clear()
    assert all(int(last[key]) == value for key, value in run['completion'].items())
    return dict(path=path, native=native, run=run, vehicles=vehicles, intent=intent, trips=trips,
        passage=passage, by_vehicle=by_vehicle, status=status, final_summary=last)


def main():
    prepared = ROOT / 'prepared'
    main_expected = read_csv_rows(prepared / 'expected-counts.csv')
    init_expected = read_csv_rows(prepared / 'initialization-counts.csv')
    metadata = {r['detector_id']: r for r in main_expected}
    target = {(r['detector_id'], float(r['begin']), float(r['end'])): int(r['expected_total']) for r in main_expected + init_expected}
    cases = {label: read_case(path) for label, path in CASES.items()}
    per_field = defaultdict(dict)
    for label, data in cases.items():
        rows = audit_expected_to_e1_strict(main_expected, data['native'] / 'field-counts.xml', count_attribute='nVehContrib')
        assert len(rows) == 130 and all(r['measured_nVehContrib'] is not None for r in rows)
        for field in metadata:
            selected = [r for r in rows if r['detector_id'] == field]
            residuals = [int(r['diff_nVehContrib_minus_expected']) for r in selected]
            per_field[field][label] = {'TAE': sum(map(abs, residuals)), 'SSE': sum(r * r for r in residuals),
                'expected': sum(int(r['expected_total']) for r in selected),
                'measured': sum(int(r['measured_nVehContrib']) for r in selected), 'max_abs': max(map(abs, residuals))}
    fields = [{'field': field, 'node': metadata[field]['node_id'], 'asset': metadata[field]['asset_id'],
        'direction': metadata[field]['direction'], **{label + '_' + k: v for label, values in data.items() for k, v in values.items()},
        'TAE_change': data['selected']['TAE'] - data['canonical']['TAE']} for field, data in per_field.items()]
    fields.sort(key=lambda r: (-r['selected_TAE'], r['field']))
    write_csv(OUT / 'field-summary13.csv', fields, list(fields[0]))
    directions = []
    for node, direction in sorted({(r['node'], r['direction']) for r in fields}):
        group = [r for r in fields if (r['node'], r['direction']) == (node, direction)]
        directions.append({'node': node, 'direction': direction, 'fields': len(group),
            **{label + '_' + metric: sum(r[label + '_' + metric] for r in group)
               for label in ('selected', 'canonical') for metric in ('expected', 'measured', 'TAE', 'SSE')}})
    directions.sort(key=lambda r: -r['selected_TAE'])
    assert sum(r['selected_TAE'] for r in directions) == 662
    assert sum(r['canonical_TAE'] for r in directions) == 775
    write_csv(OUT / 'direction-summary.csv', directions, list(directions[0]))
    periodic = {label: {(r['detector_id'], r['begin_s'], r['end_s']): r['periodic_nVehContrib']
        for r in data['passage']['interval_comparisons']} for label, data in cases.items()}
    bins = []
    for key, count in sorted(periodic['selected'].items()):
        baseline = periodic['canonical'][key]
        bins.append({'field': key[0], 'begin_s': key[1], 'end_s': key[2],
            'scope': 'initial52' if key[1] < 3600 else 'main130' if key[1] < 12600 else 'tail_without_target',
            'expected': target.get(key, ''), 'canonical': baseline, 'selected': count,
            'canonical_residual': baseline - target[key] if key in target else '',
            'selected_residual': count - target[key] if key in target else '', 'count_change': count - baseline})
    write_csv(OUT / 'field-bins208.csv', bins, list(bins[0]))
    selected = cases['selected']
    reusable = {**selected['passage'], 'source_context': {
        'new_native_runs': 0, 'native_run': str(selected['native'] / 'run.json'),
        'native_run_sha256': digest(selected['native'] / 'run.json'),
        'selected_vector': str(selected['path'] / 'od-vector.json'),
        'selected_vector_sha256': digest(selected['path'] / 'od-vector.json'),
        'demand_sha256': digest(selected['path'] / 'demand.rou.xml'),
        'intentions_sha256': digest(selected['path'] / 'lane-intentions.json'),
        'od_model_sha256': digest(prepared / 'od-model.json'),
        'instant_to_periodic_ids': selected['run']['instant_to_periodic_ids'],
        'helper_source_sha256': digest(Path(__file__).parents[3] / 'plugins/astra-sumo/src/astra_sumo/core/route_sensor_matrix.py')}}
    packed = gzip.compress(json.dumps(reusable, ensure_ascii=False, separators=(',', ':')).encode('utf-8'), mtime=0)
    packed_path = OUT / 'selected-contributing-passages.json.gz'
    packed_path.write_bytes(packed)
    assert json.loads(gzip.decompress(packed)) == reusable
    terminal_ids = {i for i, status in selected['status'].items() if status != 'arrived'}
    last_events = {}
    for _, row in ET.iterparse(selected['native'] / 'instant-e1.xml', events=('end',)):
        if row.tag == 'instantOut':
            if row.get('vehID') in terminal_ids:
                last_events[row.get('vehID')] = dict(row.attrib)
            row.clear()
    loops = {r.get('id'): dict(r.attrib) for r in ET.parse(prepared / 'field-loops.add.xml').getroot()}
    terminal = []
    for identity in sorted(terminal_ids):
        vehicle, trip = selected['vehicles'][identity], selected['trips'].get(identity, {})
        intention = selected['intent'][identity]
        field, route = intention['field_id'], vehicle.find('route').get('edges').split()
        event = last_events.get(identity, {})
        last_field = selected['run']['instant_to_periodic_ids'].get(event.get('id'))
        own = [e for e in selected['by_vehicle'][identity] if e['detector_id'] == field]
        terminal.append({'vehicle_id': identity, 'status': selected['status'][identity], 'od_cell': intention['od_cell'],
            'field': field, 'direction': metadata[field]['direction'], 'requested_depart_s': vehicle.get('depart'),
            'origin': route[0], 'destination': route[-1], 'route': ' '.join(route),
            'actual_depart_s': trip.get('depart', ''), 'insertion_delay_s': trip.get('departDelay', ''),
            'tripinfo_routeLength_m': trip.get('routeLength', ''), 'tripinfo_waitingTime_s': trip.get('waitingTime', ''),
            'depart_lane': trip.get('departLane', ''), 'final_lane_known': False, 'final_lane': '',
            'final_lane_status': 'not_in_network' if not trip else 'unknown_running_vehicle',
            'last_instant_time_s': event.get('time', ''), 'last_instant_state': event.get('state', ''),
            'last_instant_field': last_field or '', 'last_instant_lane': loops[last_field]['lane'] if last_field else '',
            'last_own_completed_passage_s': max((e['notification_time_s'] for e in own), default=''),
            'canonical_same_id_status': cases['canonical']['status'].get(identity, 'not_in_canonical_requests')})
    assert Counter(r['status'] for r in terminal) == {'running': 14, 'not_inserted': 7}
    assert {r['origin'] for r in terminal} == {'-142944318'}
    write_csv(OUT / 'terminal21-vehicles.csv', terminal, list(terminal[0]))
    z5 = {}
    for label, data in cases.items():
        ids = {i for i, r in data['intent'].items() if r['field_id'] == Z5}
        own = [e for e in data['passage']['passages'] if e['vehicle_id'] in ids and e['detector_id'] == Z5]
        complete = {e['vehicle_id'] for e in own}
        z5[label] = {'assigned_requests': len(ids), 'completed_own_field': len(complete),
            'initial': sum(e['notification_time_s'] < 3600 for e in own),
            'main': sum(3600 <= e['notification_time_s'] < 12600 for e in own),
            'tail': sum(e['notification_time_s'] >= 12600 for e in own),
            'no_complete_own_field_by_end': len(ids - complete),
            'uncompleted_statuses': dict(Counter(data['status'][i] for i in ids - complete)),
            'other_field_completed_events': sum(e['vehicle_id'] in ids and e['detector_id'] != Z5 for e in data['passage']['passages'])}
    tail_rows = []
    for event in selected['passage']['passages']:
        identity = event['vehicle_id']
        if event['detector_id'] != Z5 or event['notification_time_s'] < 12600:
            continue
        assert selected['intent'][identity]['field_id'] == Z5
        vehicle, trip = selected['vehicles'][identity], selected['trips'][identity]
        requested = math.floor(float(vehicle.get('depart')) * 1000 + .5) / 1000
        depart = float(trip['depart'])
        tail_rows.append({'vehicle_id': identity, 'od_cell': selected['intent'][identity]['od_cell'],
            'requested_depart_s': requested, 'actual_depart_s': depart, 'passage_notification_s': event['notification_time_s'],
            'insertion_delay_s': depart - requested, 'inserted_to_passage_s': event['notification_time_s'] - depart,
            'requested_to_passage_s': event['notification_time_s'] - requested,
            'arrival_s': trip['arrival'], 'canonical_same_id_status': cases['canonical']['status'].get(identity, 'absent')})
    assert len(tail_rows) == z5['selected']['tail'] == 115
    write_csv(OUT / 'z5-tail115-vehicles.csv', tail_rows, list(tail_rows[0]))
    cohort_rows = []
    for cell in sorted({r['od_cell'] for r in tail_rows}):
        group = [r for r in tail_rows if r['od_cell'] == cell]
        cohort_rows.append({'od_cell': cell, 'departure_begin_s': (cell // 21) * 900,
            'tail_vehicles': len(group), **{k + '_' + metric: value for k in
                ('insertion_delay_s', 'inserted_to_passage_s', 'requested_to_passage_s')
                for metric, value in stats([r[k] for r in group]).items() if metric != 'n'}})
    write_csv(OUT / 'z5-tail-cohorts.csv', cohort_rows, list(cohort_rows[0]))
    end_queues = []
    for label, data in cases.items():
        last = None
        for _, row in ET.iterparse(data['native'] / 'queues.xml', events=('end',)):
            if row.tag == 'data':
                last = (row.get('timestep'), [dict(lane.attrib) for lane in row.findall('lanes/lane')])
                row.clear()
        end_queues += [{'case': label, 'sample_time_s': last[0], **lane} for lane in last[1]]
    write_csv(OUT / 'last-queue-samples.csv', end_queues, list(end_queues[0]))
    used = [Path(__file__).resolve(), prepared / 'od-model.json', prepared / 'expected-counts.csv',
            prepared / 'initialization-counts.csv', prepared / 'field-loops.add.xml']
    for data in cases.values():
        used += [data['path'] / n for n in ('od-vector.json', 'demand.rou.xml', 'lane-intentions.json')]
        used += [data['native'] / n for n in ('run.json', 'field-counts.xml', 'summary.xml', 'tripinfo.xml', 'instant-e1.xml', 'queues.xml')]
    report = {'status': 'measured', 'new_native_runs': 0, 'selected_search_center': str(CASES['selected'] / 'od-vector.json'),
        'model_rebuilt': False, 'largest_remaining_field': fields[0], 'z5_full_horizon_accounting': z5,
        'direction_summary': directions,
        'z5_tail_cohorts': cohort_rows, 'z5_tail_delay_s': {key: stats([r[key] for r in tail_rows]) for key in
            ('insertion_delay_s', 'inserted_to_passage_s', 'requested_to_passage_s')},
        'terminal_group_counts': dict(Counter(r['status'] + ':' + r['field'] for r in terminal)),
        'running_final_lane_unknown': 14, 'uninserted_not_in_network': 7,
        'terminal_counts_by_field': {k: dict(Counter(v['status'][i] + ':' + v['intent'][i]['field_id']
            for i in v['status'] if v['status'][i] != 'arrived')) for k, v in cases.items()},
        'completion': {k: v['run']['completion'] for k, v in cases.items()},
        'same_replay_E1_reconciliation': {k: {'reconciled': v['passage']['reconciled'], 'intervals': 208} for k, v in cases.items()},
        'reusable_passages': {'path': str(packed_path), 'sha256': digest(packed_path),
            'bytes': packed_path.stat().st_size, 'complete_passages': len(selected['passage']['passages']),
            'unique_vehicles': len({e['vehicle_id'] for e in selected['passage']['passages']}),
            'periodic_sum': sum(r['periodic_nVehContrib'] for r in selected['passage']['interval_comparisons'])},
        'next_question': 'For selected Z5, identify how the 115 complete contributions after 12600 s arise from requested departure cohorts and insertion versus in-network delay. Do not conflate this window mismatch with the separate 535-direction terminal backlog.',
        'claim_boundary': 'Observed offline accounting only. The 115 tail contributions are not all proven to belong in the measured main window. Tripinfo has no final lane for the running vehicles; queue output has no vehicle identities. No new algorithm or lane/control change is selected.',
        'source_sha256': {str(p): digest(p) for p in used}}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('largest_remaining_field', 'z5_full_horizon_accounting', 'z5_tail_cohorts', 'z5_tail_delay_s', 'terminal_group_counts')}, indent=2))


if __name__ == '__main__':
    main()
