"""Locate Z5 tail-cohort time in recorded ordinary-edge exit intervals only."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import lane_allows_passenger, read_csv_rows, read_net, write_csv


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SELECTED = ROOT / 'probe-minus1/evaluation'
CANONICAL = ROOT.parent / 'hamburg-z5-native-feedback-20261023-v1/z15-half-unsplit-full/evaluation'
DETECTOR_EDGE = '24483344#1'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def routes(path, wanted):
    result = {}
    for _, vehicle in ET.iterparse(path, events=('end',)):
        if vehicle.tag == 'vehicle':
            if vehicle.get('id') in wanted:
                route = vehicle.find('route')
                edges, times = route.get('edges').split(), list(map(float, route.get('exitTimes').split()))
                assert len(edges) == len(times) and all(a <= b for a, b in zip(times, times[1:]))
                result[vehicle.get('id')] = {'edges': edges, 'times': times, 'depart': float(vehicle.get('depart'))}
            vehicle.clear()
    return result


def main():
    tail = read_csv_rows(OUT / 'z5-tail115-vehicles.csv')
    wanted = {r['vehicle_id'] for r in tail}
    assert len(wanted) == 115
    network_path = SELECTED / 'native/network.net.xml'
    network = ET.parse(network_path).getroot()
    edge_xml = {e.get('id'): e for e in network.findall('edge') if not e.get('id').startswith(':')}
    edges, connections = read_net(network_path)
    recorded = {k: routes(path / 'native/vehicle-routes.xml', wanted) for k, path in
                [('selected', SELECTED), ('canonical', CANONICAL)]}
    assert recorded['selected'].keys() == wanted
    inputs = {k: {v.get('id'): v for v in ET.parse(path / 'demand.rou.xml').getroot().findall('vehicle') if v.get('id') in wanted}
              for k, path in [('selected', SELECTED), ('canonical', CANONICAL)]}
    assert all(ET.canonicalize(ET.tostring(inputs['selected'][i], encoding='unicode'), strip_text=True) ==
               ET.canonicalize(ET.tostring(inputs['canonical'][i], encoding='unicode'), strip_text=True) for i in wanted)
    assert network_path.read_bytes() == (CANONICAL / 'native/network.net.xml').read_bytes()
    assert (SELECTED / 'native/signal-programs.add.xml').read_bytes() == (CANONICAL / 'native/signal-programs.add.xml').read_bytes()
    rows, clear_rows = [], []
    for row in tail:
        identity = row['vehicle_id']
        current = recorded['selected'][identity]
        route, exit_times = current['edges'], current['times']
        stop = route.index(DETECTOR_EDGE)
        assert all(e in edges and edges[e].allows_passenger for e in route)
        assert all(b in connections.get(a, ()) for a, b in zip(route, route[1:]))
        elapsed_sum = 0
        for index, edge in enumerate(route[:stop + 1]):
            begin = current['depart'] if index == 0 else exit_times[index - 1]
            elapsed = exit_times[index] - begin
            lanes = [lane for lane in edge_xml[edge].findall('lane') if lane_allows_passenger(lane)]
            depart_pos = float(inputs['selected'][identity].get('departPos')) if index == 0 else 0
            nominal = min(max(0, float(lane.get('length')) - depart_pos) / float(lane.get('speed')) for lane in lanes)
            original = recorded['canonical'].get(identity)
            old_elapsed = ''
            if original is not None:
                assert original['edges'] == route
                old_begin = original['depart'] if index == 0 else original['times'][index - 1]
                old_elapsed = original['times'][index] - old_begin
            rows.append({'vehicle_id': identity, 'od_cell': row['od_cell'], 'origin': route[0], 'edge_index': index,
                'edge': edge, 'previous_edge': route[index - 1] if index else '',
                'interval_begin_s': begin, 'edge_exit_s': exit_times[index], 'elapsed_s': elapsed,
                'ordinary_only_nominal_freeflow_s': nominal, 'signed_difference_from_ordinary_nominal_s': elapsed - nominal,
                'canonical_elapsed_s_if_arrived': old_elapsed,
                'elapsed_change_if_paired_s': elapsed - old_elapsed if old_elapsed != '' else '',
                'includes_preceding_internal': index > 0})
            elapsed_sum += elapsed
        remainder = float(row['passage_notification_s']) - exit_times[stop]
        assert abs(elapsed_sum + remainder - float(row['inserted_to_passage_s'])) < 1e-7
        clear_rows.append({'vehicle_id': identity, 'od_cell': row['od_cell'], 'origin': route[0],
            'detector_edge_exit_s': exit_times[stop], 'full_E1_notification_s': row['passage_notification_s'],
            'E1_notification_minus_edge_exit_s': remainder, 'canonical_arrived_route_available': identity in recorded['canonical']})
    write_csv(OUT / 'z5-upstream-edge-intervals.csv', rows, list(rows[0]))
    write_csv(OUT / 'z5-detector-edge-exit-to-complete.csv', clear_rows, list(clear_rows[0]))
    aggregates = []
    for scope, chosen in [('all115', rows), ('origin963_105', [r for r in rows if r['origin'] == '963776077#0'])]:
        for edge in sorted({r['edge'] for r in chosen}):
            group = [r for r in chosen if r['edge'] == edge]
            paired = [r for r in group if r['canonical_elapsed_s_if_arrived'] != '']
            aggregates.append({'scope': scope, 'edge': edge, 'vehicles': len(group),
                'elapsed_total_s': sum(r['elapsed_s'] for r in group), 'elapsed_median_s': median(r['elapsed_s'] for r in group),
                'elapsed_max_s': max(r['elapsed_s'] for r in group),
                'ordinary_nominal_total_s': sum(r['ordinary_only_nominal_freeflow_s'] for r in group),
                'signed_difference_from_nominal_total_s': sum(r['signed_difference_from_ordinary_nominal_s'] for r in group),
                'canonical_arrived_pairs': len(paired),
                'paired_elapsed_change_median_s': median(r['elapsed_change_if_paired_s'] for r in paired) if paired else ''})
    aggregates.sort(key=lambda r: (r['scope'], -r['elapsed_total_s']))
    write_csv(OUT / 'z5-edge-time-aggregate.csv', aggregates, list(aggregates[0]))
    longest = sorted(rows, key=lambda r: -r['elapsed_s'])[:30]
    write_csv(OUT / 'z5-longest-edge-instances30.csv', longest, list(longest[0]))
    focus = ['963776077#0', '234423652#1', '538341584', '51214742#1', '37693933#0', '37693933#1',
             '24483344#0', '24483344#1', '79014037#1', '186713429']
    permission_rows = []
    for edge in focus:
        row = edge_xml[edge]
        lanes = [lane for lane in row.findall('lane') if lane_allows_passenger(lane)]
        outgoing = [c for c in network.findall('connection') if c.get('from') == edge and not c.get('to').startswith(':')]
        permission_rows.append({'edge': edge, 'from_node': row.get('from'), 'to_node': row.get('to'),
            'passenger_lanes': ' '.join(lane.get('id') for lane in lanes), 'lengths_m': ' '.join(lane.get('length') for lane in lanes),
            'speeds_m_s': ' '.join(lane.get('speed') for lane in lanes),
            'legal_passenger_successors': ' '.join(sorted(connections.get(edge, ()))),
            'outgoing_TLS_ids': ' '.join(sorted({c.get('tl') for c in outgoing if c.get('tl')}))})
    write_csv(OUT / 'approach-road-permissions.csv', permission_rows, list(permission_rows[0]))
    chosen = [r for r in aggregates if r['scope'] == 'origin963_105']
    assert len({r['vehicle_id'] for r in rows if r['origin'] == '963776077#0'}) == 105
    total = sum(r['elapsed_total_s'] for r in chosen)
    first_two = sum(r['elapsed_total_s'] for r in chosen if r['edge'] in {'963776077#0', '234423652#1'})
    report = {'status': 'measured', 'new_native_runs': 0, 'vehicles': 115, 'origin_counts': dict(Counter(r['origin'] for r in clear_rows)),
        'source_requests_and_routes_unchanged_between_runs_for_these115': True, 'network_permissions_rawbytes_identical': True,
        'control_programs_rawbytes_identical': True, 'actual_TLS_history_equality_established': False,
        'origin963_105_upstream_ordinary_exit_interval_total_s': total,
        'origin963_105_first_two_intervals_total_s': first_two,
        'origin963_105_first_two_share_of_exit_interval_time': first_two / total,
        'canonical_arrived_route_pairs_available': len(recorded['canonical']),
        'origin963_105_edge_summary': chosen, 'top_edge_instances': longest[:5],
        'E1_notification_minus_detector_edge_exit_s': {'min': min(r['E1_notification_minus_edge_exit_s'] for r in clear_rows),
            'median': median(r['E1_notification_minus_edge_exit_s'] for r in clear_rows),
            'max': max(r['E1_notification_minus_edge_exit_s'] for r in clear_rows)},
        'claim_boundary': 'Each interval ends at an ordinary edge exitTime and starts at the preceding ordinary edge exitTime; it includes the connecting internal path. First-edge time starts at actual departure. Nominal freeflow uses only ordinary-lane length/speed (first edge minus departure position), excludes internals/acceleration/control, and is diagnostic, not causal delay. Missing canonical unfinished routes are not imputed. Tail membership is not proof of true desired main-window passages.',
        'source_sha256': {str(p): digest(p) for p in [Path(__file__).resolve(), OUT / 'z5-tail115-vehicles.csv', network_path,
            SELECTED / 'native/vehicle-routes.xml', CANONICAL / 'native/vehicle-routes.xml',
            SELECTED / 'demand.rou.xml', CANONICAL / 'demand.rou.xml',
            SELECTED / 'native/signal-programs.add.xml', CANONICAL / 'native/signal-programs.add.xml']}}
    (OUT / 'exit-time-analysis.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('origin_counts', 'canonical_arrived_route_pairs_available',
        'origin963_105_edge_summary', 'E1_notification_minus_detector_edge_exit_s', 'top_edge_instances')}, indent=2))


if __name__ == '__main__':
    main()
