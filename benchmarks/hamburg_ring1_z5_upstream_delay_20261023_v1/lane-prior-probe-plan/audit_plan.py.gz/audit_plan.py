"""Audit explicit lane-intention pair proposals. Never write candidate demand."""

from collections import Counter
import csv
import heapq
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.junction_split_fanout import _internal_path
from astra_sumo.core.local_network_conversion import loaded_turn_permissions
from astra_sumo.core.osm_access import _permission_set
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages


ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
NATIVE = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"
FIELD4, FIELD5 = "hh_0119_Z_4_29437", "hh_0119_Z_5_30494"
FIELD_EDGE = "24483344#1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


network = ET.parse(NATIVE / "network.net.xml").getroot()
edges = {e.get("id"): e for e in network.findall("edge")}
lanes = {lane.get("id"): lane for edge in edges.values() for lane in edge.findall("lane")}
allowed = {road: {int(lane.get("index")) for lane in edge.findall("lane")
                  if "passenger" in _permission_set(lane.attrib, network_version=network.get("version"))}
           for road, edge in edges.items()}
permissions = loaded_turn_permissions(network)
connections = {(c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))): c
               for c in network.findall("connection")}
requests = {v.get("id"): v for v in ET.parse(NATIVE / "demand.rou.xml").getroot().findall("vehicle")}
intentions = {v["vehicle_id"]: v for v in json.loads((NATIVE / "lane-intentions.json").read_bytes())["vehicles"]}
trips = {v.get("id"): dict(v.attrib) for _, v in ET.iterparse(NATIVE / "tripinfo.xml") if v.tag == "tripinfo"}
run = json.loads((NATIVE / "run.json").read_bytes())
passages = read_contributing_e1_passages(instant_file=NATIVE / "instant-e1.xml", periodic_file=NATIVE / "field-counts.xml",
                                       detector_ids=run["instant_to_periodic_ids"], step_length=.1)
assert passages["reconciled"] and passages["inputs_unchanged"]
passed = {v["vehicle_id"]: v for v in passages["passages"]}
assert len(passed) == len(passages["passages"])
source_paths = [NATIVE / name for name in ["network.net.xml", "demand.rou.xml", "lane-intentions.json", "tripinfo.xml",
    "source-e1.add.xml", "instant-e1.xml", "field-counts.xml", "run.json"]]
source_paths += [OUT / "one-pair.json", OUT / "five-pairs.json", Path(__file__).resolve()]
source_paths += [NATIVE.parent / "od-vector.json", NATIVE.parents[1] / "source/prepared/od-model.json"]
sources = [dict(path=str(p.relative_to(ROOT)), sha256=sha(p)) for p in source_paths]
selected_vector = json.loads((NATIVE.parent / "od-vector.json").read_bytes())
actual_cells = Counter(row["od_cell"] for row in intentions.values())
assert [actual_cells[column] for column in range(294)] == selected_vector["integer_counts"]


def route_for(identity):
    return requests[identity].find("route").get("edges").split()


def lane_name(road, lane):
    return edges[road].findall("lane")[lane].get("id")


def fixed_prefix(route, target):
    prefix = route[:route.index(FIELD_EDGE) + 1]
    states = {lane: [lane_name(route[0], lane)] for lane in allowed[route[0]]}
    for first, last in zip(prefix, prefix[1:]):
        future = {}
        for (origin, a, destination, b), modes in permissions.items():
            if origin == first and destination == last and a in states and "passenger" in modes:
                future[b] = states[a] + [lane_name(last, b)]
        states = future
    return states.get(target)


def prefix_length(prefix):
    length = float(lanes[prefix[0]].get("length")) - 5.1
    internal = []
    for first, last in zip(prefix, prefix[1:]):
        a, b = first.rsplit("_", 1), last.rsplit("_", 1)
        connection = connections[a[0], int(a[1]), b[0], int(b[1])]
        middle = _internal_path(network, connection)
        internal.extend(lane.get("id") for lane in middle)
        length += sum(float(lane.get("length")) for lane in middle)
        length += 95.03 if b[0] == FIELD_EDGE else float(lanes[last].get("length"))
    return dict(front_path_to_e1_m=length, internal_lanes=internal,
                boundary="One legal fixed-lane geometric witness to the vehicle front at E1; not an observed path length or passage forecast")


def suffix_path(route, target):
    start = route.index(FIELD_EDGE)
    states = {target: (0.0, [lane_name(FIELD_EDGE, target)], [])}
    for index in range(start, len(route) - 1):
        first, last = route[index:index + 2]
        # The field lane stays fixed until its outgoing connection. Later road
        # changes require native gaps; this is only structural permission.
        if index > start:
            assert not any("changeLeft" in lane.attrib or "changeRight" in lane.attrib for lane in edges[first].findall("lane"))
            pending = [(cost, lane) for lane, (cost, _, _) in states.items()]
            heapq.heapify(pending)
            while pending:
                cost, lane = heapq.heappop(pending)
                if cost != states[lane][0]:
                    continue
                for adjacent in [lane - 1, lane + 1]:
                    if adjacent not in allowed[first]:
                        continue
                    old = states[lane]
                    proposed = cost + 1 + 1 / float(lanes[lane_name(first, lane)].get("length"))
                    if adjacent not in states or proposed < states[adjacent][0]:
                        change = dict(road=first, from_lane=lane_name(first, lane), to_lane=lane_name(first, adjacent),
                                      road_length_m=float(lanes[lane_name(first, lane)].get("length")))
                        states[adjacent] = (proposed, old[1] + [lane_name(first, adjacent)], old[2] + [change])
                        heapq.heappush(pending, (proposed, adjacent))
        future = {}
        for (origin, a, destination, b), modes in permissions.items():
            if origin == first and destination == last and a in states and "passenger" in modes:
                old = states[a]
                if b not in future or old[0] < future[b][0]:
                    future[b] = (old[0], old[1] + [lane_name(last, b)], old[2])
        states = future
        if not states:
            return None
    best = min(states.values(), key=lambda row: row[0])
    return dict(ordinary_lane_sequence=best[1], ordinary_lane_changes=best[2],
                boundary="Passenger permission witness on unchanged road sequence. It does not establish a safe gap at a given traffic time.")


def detail(identity, new_field):
    vehicle = requests[identity]
    route = route_for(identity)
    event = passed[identity]
    target = 0 if new_field == FIELD4 else 1
    prefix = fixed_prefix(route, target)
    suffix = suffix_path(route, target)
    assert prefix and suffix
    same_route_witness = next(i for i in requests if route_for(i) == route and intentions[i]["field_id"] == new_field
                              and i in passed and passed[i]["detector_id"] == new_field
                              and i in trips and float(trips[i]["arrival"]) >= 0)
    assert event["detector_id"] == intentions[identity]["field_id"]
    return dict(vehicle_id=identity, od_cell=intentions[identity]["od_cell"], origin=route[0], destination=route[-1], route_edges=route,
        departure_bin=int(float(vehicle.get("depart")) // 900), requested_depart_s=float(vehicle.get("depart")),
        actual_depart_s=float(trips[identity]["depart"]), insertion_delay_s=float(trips[identity]["departDelay"]),
        complete_passage_notification_s=event["notification_time_s"], complete_passage_bin_begin_s=event["interval_begin_s"],
        requested_to_complete_passage_s=event["notification_time_s"] - float(vehicle.get("depart")),
        inserted_to_complete_passage_s=event["notification_time_s"] - float(trips[identity]["depart"]),
        actual_arrival_s=float(trips[identity]["arrival"]), observed_full_trip_route_length_m=float(trips[identity]["routeLength"]),
        ordinary_road_length_sum_m=sum(float(edges[road].find("lane").get("length")) for road in route),
        ordinary_length_boundary="Ordinary roads only, excluding native internal junction paths",
        old_field=intentions[identity]["field_id"], proposed_field=new_field,
        original_moving_stop=dict(vehicle.find("stop").attrib), proposed_stop_lane=lane_name(FIELD_EDGE, target),
        alternative_prefix_no_lateral_change=prefix, alternative_prefix_geometry=prefix_length(prefix),
        alternative_suffix=suffix, same_route_native_opposite_field_witness=dict(vehicle_id=same_route_witness,
            complete_passage=passed[same_route_witness], arrival_s=float(trips[same_route_witness]["arrival"])))


pairs = json.loads((OUT / "five-pairs.json").read_bytes())["pairs"]
assert len(pairs) == 5 and json.loads((OUT / "one-pair.json").read_bytes())["pairs"] == pairs[:1]
assert len({identity for pair in pairs for identity in pair.values()}) == 10
details = []
inventory_delta = Counter()
for pair in pairs:
    z5, z4 = pair["z5_vehicle_id"], pair["z4_vehicle_id"]
    a, b = detail(z5, FIELD4), detail(z4, FIELD5)
    assert a["origin"] == "963776077#0" and b["origin"] == "31106387"
    assert a["old_field"] == FIELD5 and b["old_field"] == FIELD4
    assert a["departure_bin"] == b["departure_bin"]
    assert a["complete_passage_bin_begin_s"] >= 12600
    assert b["complete_passage_bin_begin_s"] == b["departure_bin"] * 900 and 3600 <= b["complete_passage_bin_begin_s"] < 12600
    assert {k: v for k, v in a["original_moving_stop"].items() if k != "lane"} == {
        k: v for k, v in b["original_moving_stop"].items() if k != "lane"}
    details.append(dict(pair=pair, z5_to_z4=a, z4_to_z5=b))
    for row in [a, b]:
        inventory_delta[row["departure_bin"], row["old_field"]] -= 1
        inventory_delta[row["departure_bin"], row["proposed_field"]] += 1
assert not any(inventory_delta.values())
flat = [dict(pair=i + 1, role=role, vehicle_id=row["vehicle_id"], origin=row["origin"], departure_bin=row["departure_bin"],
    requested_depart_s=row["requested_depart_s"], complete_passage_notification_s=row["complete_passage_notification_s"],
    inserted_to_complete_passage_s=row["inserted_to_complete_passage_s"],
    observed_full_trip_route_length_m=row["observed_full_trip_route_length_m"], old_field=row["old_field"], new_field=row["proposed_field"])
    for i, pair in enumerate(details) for role, row in [("z5_to_z4", pair["z5_to_z4"]), ("z4_to_z5", pair["z4_to_z5"])]]
with (OUT / "pair-baseline-comparison.csv").open("w", encoding="utf-8", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(flat[0]))
    writer.writeheader()
    writer.writerows(flat)
save_json("pair-audit.json", dict(source_case=str(NATIVE.relative_to(ROOT)), source_hashes=sources,
    source_vector_semantics="Selected minus1 explicit counts are preserved. This proposal does not regenerate the 294-cell model or alter its OD flows.",
    pairs=details, input_invariants=dict(same_900s_departure_bin_each_pair=True, field_inventory_each_departure_bin_preserved=True,
        all_294_od_flows_unchanged_by_declared_edit=True, routes_departures_vehicle_attributes_other_than_stop_lane_unchanged_by_declared_edit=True,
        only_declared_edits="Swap the two field_id values and the two existing moving-stop lane attributes. No regeneration or timing edit.",
        native_candidate_generated=False, simulation_executed=False),
    actual_passages_reconciled=passages["reconciled"],
    claim_boundary="A bounded lane-prior hypothesis test plan. Existing passage times and counts are baseline evidence only. No projected new count, proof of a prior bug, or new native safety claim.",
    source_inputs_unchanged=all(sha(ROOT / row["path"]) == row["sha256"] for row in sources)))
print(json.dumps(flat, indent=2))
