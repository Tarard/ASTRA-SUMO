"""Read sparse one-second queues and declared static states; never run SUMO."""
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
from statistics import median
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import connection_allows_passenger, lane_allows_passenger, read_csv_rows, write_csv


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
CASE = REPO / 'outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native'
DIAG = REPO / 'outputs/hamburg-classical-od-calibration-20261023-v1/selected-next-diagnosis'
BEGIN, END = 11670, 13849.2
IDENTITY = 'od_0272_v00002'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def runs(times):
    result = []
    for time in sorted(times):
        if not result or time > result[-1][1]:
            result.append([time, time + 1])
        else:
            result[-1][1] = time + 1
    return result


def main():
    net = ET.parse(CASE / 'network.net.xml').getroot()
    lane_elements = {lane.get('id'): lane for edge in net.findall('edge') for lane in edge.findall('lane')}
    lanes = {identity: dict(lane.attrib) for identity, lane in lane_elements.items()}
    focus = [f'{edge}_{i}' for edge, indices in [
        ('963776077#0', (2, 3, 4)), ('234423652#1', (0, 1, 2)), ('538341584', (0, 1, 2)),
        ('51214742#1', (1, 2, 3)), ('24483344#0', (0, 1)), ('24483344#1', (0, 1)),
        ('37693933#0', (1, 2, 3)), ('37693933#1', (1, 2, 3)),
        (':LSA104_part0_23', (0, 1, 2)), (':LSA118_part0_38', (1, 2, 3))] for i in indices]
    lengths = {lane: float(lanes[lane]['length']) for lane in focus}
    programs = {r.get('id'): r for r in ET.parse(CASE / 'signal-programs.add.xml').getroot()}

    def state(identity, index, time):
        program = programs[identity]
        assert program.get('type') == 'static'
        phases = program.findall('phase')
        cycle = sum(float(p.get('duration')) for p in phases)
        assert cycle == 90 and float(program.get('offset')) == 0
        position = time % cycle
        for phase in phases:
            duration = float(phase.get('duration'))
            if position < duration:
                return phase.get('state')[index]
            position -= duration
        raise AssertionError('phase lookup failed')

    queues, recorded_times, internal_names = {}, [], set()
    for _, row in ET.iterparse(CASE / 'queues.xml', events=('end',)):
        if row.tag == 'data':
            time = int(float(row.get('timestep')))
            recorded_times.append(time)
            queues[time] = {}
            for lane in row.findall('lanes/lane'):
                identity = lane.get('id')
                if identity.startswith((':LSA104', ':LSA118')):
                    internal_names.add(identity)
                if identity in focus:
                    queues[time][identity] = {k: float(lane.get(k)) for k in
                        ('queueing_time', 'queueing_length', 'queueing_length_experimental')}
            row.clear()
    assert recorded_times == list(range(14400))

    def get(time, lane, key='queueing_length'):
        # An omitted record bounds both exported extents <=1 m; it does not show empty occupancy.
        return queues[time].get(lane, {}).get(key, 0.0)

    def near(time, lane):
        return get(time, lane) > 1 and lengths[lane] - get(time, lane) <= 7.5

    times = [t for t in recorded_times if BEGIN <= t < END]
    summaries, dense = [], []
    for lane in focus:
        length = lengths[lane]
        present = [t for t in times if lane in queues[t]]
        near_times = [t for t in times if near(t, lane)]
        extents = [get(t, lane) for t in times]
        intervals = runs(near_times)
        summaries.append({'lane': lane, 'length_m': length, 'samples': len(times), 'row_present_samples': len(present),
            'positive_stopped_extent_samples': sum(v > 1 for v in extents),
            'max_stopped_extent_m': max(extents), 'median_exported_extent_or_zero_m': median(extents),
            'max_waiting_seconds_exported': max(get(t, lane, 'queueing_time') for t in times),
            'stopped_rear_within_7_5m_of_lane_start_samples': len(near_times),
            'stopped_extent_exceeds_lane_length_samples': sum(v > length for v in extents),
            'max_extent_time_s': times[extents.index(max(extents))],
            'stopped_extent_at_least90pct_samples': sum(v >= .9 * length and v > 1 for v in extents),
            'longest_near_start_interval_s': max((b - a for a, b in intervals), default=0),
            'longest_near_start_begin_s': max(intervals, key=lambda r: r[1] - r[0])[0] if intervals else '',
            'longest_near_start_end_s': max(intervals, key=lambda r: r[1] - r[0])[1] if intervals else ''})
    for time in range(11500, 13900):
        for lane in focus:
            dense.append({'time_s': time, 'lane': lane, 'row_present': lane in queues[time], 'lane_length_m': lengths[lane],
                **{k: get(time, lane, k) for k in ('queueing_time', 'queueing_length', 'queueing_length_experimental')},
                'stopped_rear_clearance_from_start_m': lengths[lane] - get(time, lane) if get(time, lane) > 1 else '',
                'declared_104_link25': state('LSA104_part0', 25, time),
                'declared_118_link41': state('LSA118_part0', 41, time)})
    write_csv(OUT / 'lane-summary-exemplar-window.csv', summaries, list(summaries[0]))
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=list(dense[0]))
    writer.writeheader()
    writer.writerows(dense)
    (OUT / 'lane-time-series11500-13900.csv.gz').write_bytes(gzip.compress(stream.getvalue().encode('utf-8'), mtime=0))
    links = [('104', f'963776077#0_{i + 2}', f'234423652#1_{i}', 'LSA104_part0', 23 + i) for i in range(3)]
    links += [('priority', f'234423652#1_{i}', f'538341584_{i}', None, None) for i in range(3)]
    links += [('118', f'538341584_{i}', f'51214742#1_{i + 1}', 'LSA118_part0', 39 + i) for i in range(3)]
    overlap_rows = []
    for owner, supply, receiving, tls, link in links:
        green = [t for t in times if tls is None or state(tls, link, t) in 'gG']
        blocked = [t for t in green if near(t, receiving)]
        overlap_rows.append({'node': owner, 'supply_lane': supply, 'receiving_lane': receiving,
            'declared_green_or_uncontrolled_samples': len(green), 'receiving_near_start_during_these_samples': len(blocked),
            'supply_positive_stopped_extent_with_receiving_near_start': sum(get(t, supply) > 1 for t in blocked),
            'receiving_row_omitted_during_these_samples': sum(receiving not in queues[t] for t in green)})
    write_csv(OUT / 'supply-receiving-overlap.csv', overlap_rows, list(overlap_rows[0]))
    cycles = []
    for start in range(57, 14400, 90):
        if start < BEGIN or start + 42 > END:
            continue
        green = list(range(start, start + 42))
        both = [t for t in green if state('LSA118_part0', 41, t) in 'gG']
        cycles.append({'green104_begin_s': start, 'green104_end_s': start + 42,
            'shared_green_begin_s': both[0], 'shared_green_end_s': both[-1] + 1,
            'receiver234_lane2_near_start_green104_samples': sum(near(t, '234423652#1_2') for t in green),
            'supply963_lane4_stopped_green104_samples': sum(get(t, '963776077#0_4') > 1 for t in green),
            'receiver538_lane2_near_start_shared_green_samples': sum(near(t, '538341584_2') for t in both),
            'receiver512_lane3_near_start_shared_green_samples': sum(near(t, '51214742#1_3') for t in both),
            'receiver376_0_lane3_near_start_shared_green_samples': sum(near(t, '37693933#0_3') for t in both),
            'receiver376_1_lane3_near_start_shared_green_samples': sum(near(t, '37693933#1_3') for t in both),
            'receiver244_0_lane1_near_start_shared_green_samples': sum(near(t, '24483344#0_1') for t in both),
            'internal104_23_2_row_present_green_samples': sum(':LSA104_part0_23_2' in queues[t] for t in green),
            'max234_lane2_wait_s': max(get(t, '234423652#1_2', 'queueing_time') for t in green)})
    cycles.sort(key=lambda r: (-r['receiver234_lane2_near_start_green104_samples'],
        -r['receiver538_lane2_near_start_shared_green_samples'], -r['supply963_lane4_stopped_green104_samples'], r['green104_begin_s']))
    write_csv(OUT / 'declared-green-cycles.csv', cycles, list(cycles[0]))
    focus_edges = {lane.rsplit('_', 1)[0] for lane in focus if not lane.startswith(':')}
    connection_rows = []
    for link in net.findall('connection'):
        if link.get('from') not in focus_edges or link.get('to', '').startswith(':'):
            continue
        first, last = link.get('from') + '_' + link.get('fromLane'), link.get('to') + '_' + link.get('toLane')
        if lane_allows_passenger(lane_elements[first]) and lane_allows_passenger(lane_elements[last]) and connection_allows_passenger(link):
            connection_rows.append({key: link.get(key, '') for key in ('from', 'fromLane', 'to', 'toLane', 'via', 'tl', 'linkIndex', 'dir')})
    write_csv(OUT / 'passenger-lane-connections.csv', connection_rows, list(connection_rows[0]))
    chosen_rows = [r for r in dense if 13190 <= r['time_s'] < 13245]
    write_csv(OUT / 'read-window13190-13245.csv', chosen_rows, list(chosen_rows[0]))
    monitor = json.loads((CASE / 'stall-monitor.json').read_bytes())
    events = monitor['lane_section_hold']['junction_body_hold']['events']
    target_events = [e for e in events if e['vehicle_id'] == IDENTITY]
    exemplar = [r for r in read_csv_rows(DIAG / 'z5-upstream-edge-intervals.csv') if r['vehicle_id'] == IDENTITY]
    report = {'status': 'measured', 'new_native_runs': 0, 'identity': IDENTITY,
        'exemplar_exit_interval': [BEGIN, END], 'exemplar_input_and_exit_times': exemplar,
        'exemplar_existing_junction_body_hold_events': target_events,
        'follow_up_read_window_s': [13190, 13245],
        'queue_sample_period_s': 1, 'window_samples': len(times), 'lane_summary': summaries,
        'supply_receiving_overlap': overlap_rows, 'ranked_declared_green_cycles': cycles,
        'internal_lanes_ever_exported': sorted(internal_names),
        'claim_boundary': 'Queue rows have no vehicle identity and no contiguous-queue test. Extents reach the back of a stopped vehicle, not proof that the whole lane is occupied. Omitted rows are not empty lanes. Static greens are inferred from declared 90 s programs, not recorded actual TLS. The exemplar lane after departure and its internal/ordinary entry time are unknown.',
        'source_contract': {'url': 'https://raw.githubusercontent.com/eclipse-sumo/sumo/v1_27_1/src/microsim/output/MSQueueExport.cpp',
            'lines': '64-94', 'queueing_time': 'maximum getWaitingSeconds across on-road lane vehicles',
            'queueing_length': 'max(laneLength-position+vehicleLength) for vehicles with waitingSeconds>0; no continuous-queue check',
            'experimental': 'same extent for speed<5/3.6 and position>0.25*laneLength',
            'omitted_lane': 'both exported extents <=1 m, or no applicable on-road vehicles'},
        'source_sha256': {str(p): digest(p) for p in [Path(__file__).resolve(), CASE / 'queues.xml',
            CASE / 'network.net.xml', CASE / 'signal-programs.add.xml', CASE / 'vehicle-routes.xml',
            CASE / 'stall-monitor.json',
            DIAG / 'z5-upstream-edge-intervals.csv', DIAG / 'exit-time-analysis.json']}}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'lanes': [r for r in summaries if r['lane'].startswith(('963', '234', '538', ':LSA104'))],
        'overlaps': overlap_rows, 'top_cycles': cycles[:5]}, indent=2))


if __name__ == '__main__':
    main()
