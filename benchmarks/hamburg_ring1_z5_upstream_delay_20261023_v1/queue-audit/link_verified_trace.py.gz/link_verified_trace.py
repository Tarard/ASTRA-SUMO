"""Link the parity-checked native trace to the existing queue audit; no simulation."""
from bisect import bisect_right
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import read_csv_rows, write_csv


OUT = Path(__file__).resolve().parent
TRACE = OUT.parent / 'trace/baseline'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parity = json.loads((TRACE / 'record-result.json').read_bytes())
    assert parity['status'] == 'pass' and len(parity['checks']) == 12 and all(parity['checks'].values())
    events = {'LSA104_part0': [], 'LSA118_part0': []}
    for _, row in ET.iterparse(TRACE / 'tls-switch-states.xml', events=('end',)):
        if row.tag == 'tlsState':
            if row.get('id') in events:
                events[row.get('id')].append((float(row.get('time')), row.get('state')))
            row.clear()

    def state(identity, index, time):
        values = events[identity]
        offset = bisect_right([r[0] for r in values], time) - 1
        assert offset >= 0
        return values[offset][1][index]

    for identity, index, begin, end in [('LSA104_part0', 25, 13197, 13239), ('LSA118_part0', 41, 13211, 13239)]:
        assert state(identity, index, begin) in 'gG' and state(identity, index, begin - .1) not in 'gG'
        assert state(identity, index, end - .1) in 'gG' and state(identity, index, end) not in 'gG'

    queue = read_csv_rows(OUT / 'read-window13190-13245.csv')
    for row in queue:
        time = float(row['time_s'])
        for identity, indices, name in [('LSA104_part0', (23, 24, 25), '104'), ('LSA118_part0', (39, 40, 41), '118')]:
            for index in indices:
                row[f'actual_{name}_link{index}'] = state(identity, index, time)
        assert row['actual_104_link25'] == row['declared_104_link25']
        assert row['actual_118_link41'] == row['declared_118_link41']
    write_csv(OUT / 'queue-with-actual-tls13190-13245.csv', queue, list(queue[0]))
    fcd, time = [], None
    for event, row in ET.iterparse(TRACE / 'cohort-fcd.xml', events=('start', 'end')):
        if event == 'start' and row.tag == 'timestep':
            time = float(row.get('time'))
        elif event == 'end' and row.tag == 'vehicle':
            if row.get('id') == 'od_0272_v00002' and 13190 <= time <= 13245:
                fcd.append({'time_s': time, **dict(row.attrib)})
            row.clear()
        elif event == 'end' and row.tag == 'timestep':
            row.clear()
    assert len(fcd) == 56 and [r['time_s'] for r in fcd] == list(range(13190, 13246))
    assert {r['lane'] for r in fcd} == {'234423652#1_2'}
    assert {r['leaderID'] for r in fcd} == {'od_0251_v00075'}
    assert all(float(r['speed']) == float(r['leaderSpeed']) == 0 for r in fcd)
    assert len({r['pos'] for r in fcd}) == len({r['leaderGap'] for r in fcd}) == 1
    write_csv(OUT / 'target-fcd13190-13245.csv', fcd, list(fcd[0]))
    report = {'status': 'measured', 'new_native_runs': 0, 'trace_parity_passed': True, 'parity_checks': parity['checks'],
        'queue_read_window': '[13190,13245), 55 one-second samples per lane',
        'target_FCD_window': '[13190,13245], 56 samples including endpoint',
        'target_lane': fcd[0]['lane'], 'target_position_m': float(fcd[0]['pos']), 'target_speed_m_s': 0,
        'leader_id': fcd[0]['leaderID'], 'leader_speed_m_s': 0, 'native_leaderGap_m': float(fcd[0]['leaderGap']),
        'actual_104_g_window': [13197, 13239], 'actual_118_g_or_G_window': [13211, 13239],
        'actual_state_matches_declared_for_every_queue_sample': True,
        'claim_boundary': 'FCD establishes this vehicle lane and recorded leader only in this window. It does not assign other anonymous queue tails to this vehicle or identify the root constraint beyond its leader. A continuous legal lane path exists; the lane split is not by itself a cause. No new native treatment was performed.',
        'source_sha256': {str(p): digest(p) for p in [Path(__file__).resolve(), TRACE / 'record-result.json',
            TRACE / 'tls-switch-states.xml', TRACE / 'cohort-fcd.xml', OUT / 'read-window13190-13245.csv']}}
    (OUT / 'actual-trace-link.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('target_lane', 'target_position_m', 'leader_id',
        'native_leaderGap_m', 'actual_104_g_window', 'actual_118_g_or_G_window')}, indent=2))


if __name__ == '__main__':
    main()
