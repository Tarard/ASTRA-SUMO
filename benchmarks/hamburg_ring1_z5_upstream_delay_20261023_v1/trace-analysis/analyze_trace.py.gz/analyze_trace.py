"""Read a parity-checked trace. Sample counts are not exact stopped durations."""

from bisect import bisect_right
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
TRACE = OUT.parent / "trace/baseline"
SELECTED = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"
STOP_SPEED = .1
NEAR_GAP = 10.0
FOCUS_ROADS = {"963776077#0", "234423652#1", "538341584"}
REPRESENTATIVES = {"od_0272_v00002", "od_0272_v00061", "od_0251_v00029", "od_0251_v00075"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def save_csv(name, rows):
    with (OUT / name).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def stopped_class(row):
    if row["speed"] > STOP_SPEED:
        return "moving"
    if not row["leader_id"] or row["leader_gap"] < 0:
        return "stopped_leader_not_reported"
    if row["leader_gap"] > NEAR_GAP:
        return "stopped_reported_leader_far"
    if row["leader_speed"] <= STOP_SPEED:
        return "stopped_near_stopped_leader"
    return "stopped_near_moving_leader"


OUT.mkdir(parents=True, exist_ok=True)
record = json.loads((TRACE / "record-result.json").read_bytes())
assert record["status"] == "pass" and len(record["checks"]) == 12 and all(record["checks"].values())
cohort = json.loads((TRACE / "observed-vehicle-ids.json").read_bytes())
ids = set(cohort["vehicles"])
assert len(ids) == len(cohort["vehicles"]) == 115
assert sha(Path(cohort["source"])) == cohort["sha256"]
source_paths = [TRACE / name for name in ["record-result.json", "observed-vehicle-ids.json", "cohort-fcd.xml",
    "lanechanges.xml", "stall-monitor.json", "network.net.xml", "tls-switch-states.xml", "demand.rou.xml"]]
source_paths += [SELECTED / "stall-monitor.json", Path(__file__).resolve()]
sources = [dict(path=str(path.relative_to(ROOT)), sha256=sha(path)) for path in source_paths]
requests = {e.get("id"): e for e in ET.parse(TRACE / "demand.rou.xml").getroot().findall("vehicle")}
origins = {identity: requests[identity].find("route").get("edges").split()[0] for identity in ids}
samples = defaultdict(list)
by_time = defaultdict(dict)
now = None
for event, element in ET.iterparse(TRACE / "cohort-fcd.xml", events=("start", "end")):
    if event == "start" and element.tag == "timestep":
        now = float(element.get("time"))
    elif event == "end" and element.tag == "vehicle":
        identity = element.get("id")
        assert identity in ids
        row = dict(vehicle_id=identity, time=now, lane=element.get("lane"), pos=float(element.get("pos")),
            speed=float(element.get("speed")), leader_id=element.get("leaderID", ""),
            leader_gap=float(element.get("leaderGap", "-1")), leader_speed=float(element.get("leaderSpeed", "-1")))
        row["road"] = row["lane"].rsplit("_", 1)[0]
        row["classification"] = stopped_class(row)
        samples[identity].append(row)
        by_time[now][identity] = row
        element.clear()
    elif event == "end" and element.tag == "timestep":
        element.clear()
assert set(samples) == ids
for rows in samples.values():
    assert all(b["time"] - a["time"] == 1 for a, b in zip(rows, rows[1:]))
hold = json.loads((TRACE / "stall-monitor.json").read_bytes())["lane_section_hold"]
original_hold = json.loads((SELECTED / "stall-monitor.json").read_bytes())["lane_section_hold"]
hold_intervals = defaultdict(list)
for kind, events in [("detector", hold["events"]), ("body", hold["junction_body_hold"]["events"])]:
    pending = {}
    for event in events:
        identity = event["vehicle_id"]
        if identity not in ids:
            continue
        if event["event"] == "held":
            pending[identity] = event
        elif identity in pending:
            start = pending.pop(identity)
            hold_intervals[identity].append(dict(kind=kind, lane=start["lane"], begin=start["time_s"], end=event["time_s"]))
lane_counts = defaultdict(Counter)
lane_vehicles = defaultdict(set)
vehicle_lane_counts = defaultdict(Counter)
for identity, rows in samples.items():
    for row in rows:
        if row["road"] not in FOCUS_ROADS:
            continue
        lane = row["lane"]
        lane_counts[lane]["sample_count"] += 1
        lane_counts[lane][row["classification"]] += 1
        lane_vehicles[lane].add(identity)
        vehicle_lane_counts[identity, lane][row["classification"]] += 1
        vehicle_lane_counts[identity, lane]["sample_count"] += 1
save_csv("lane-sample-summary.csv", [dict(lane=lane, distinct_vehicles=len(lane_vehicles[lane]),
    **{key: counts[key] for key in ["sample_count", "moving", "stopped_near_stopped_leader",
       "stopped_near_moving_leader", "stopped_reported_leader_far", "stopped_leader_not_reported"]})
    for lane, counts in sorted(lane_counts.items())])
save_csv("vehicle-lane-summary.csv", [dict(vehicle_id=identity, origin=origins[identity], lane=lane,
    **{key: counts[key] for key in ["sample_count", "moving", "stopped_near_stopped_leader",
       "stopped_near_moving_leader", "stopped_reported_leader_far", "stopped_leader_not_reported"]})
    for (identity, lane), counts in sorted(vehicle_lane_counts.items())])
segments, stops = [], []
for identity, rows in samples.items():
    start = 0
    for index in range(1, len(rows) + 1):
        if index < len(rows) and rows[index]["lane"] == rows[start]["lane"]:
            continue
        part = rows[start:index]
        if part[0]["road"] in FOCUS_ROADS:
            segments.append(dict(vehicle_id=identity, lane=part[0]["lane"], first_sample_s=part[0]["time"],
                last_sample_s=part[-1]["time"], sample_count=len(part), first_pos_m=part[0]["pos"], last_pos_m=part[-1]["pos"],
                stopped_samples=sum(r["speed"] <= STOP_SPEED for r in part),
                leader_classes=dict(Counter(r["classification"] for r in part))))
        start = index
    start = None
    for index in range(len(rows) + 1):
        stopped = index < len(rows) and rows[index]["road"] in FOCUS_ROADS and rows[index]["speed"] <= STOP_SPEED
        if start is not None and (not stopped or rows[index]["lane"] != rows[start]["lane"]
                                  or rows[index]["classification"] != rows[start]["classification"]
                                  or rows[index]["leader_id"] != rows[start]["leader_id"]):
            part = rows[start:index]
            stops.append(dict(vehicle_id=identity, lane=part[0]["lane"], classification=part[0]["classification"],
                leader_id=part[0]["leader_id"], first_sample_s=part[0]["time"], last_sample_s=part[-1]["time"],
                sample_count=len(part), first_pos_m=part[0]["pos"], last_pos_m=part[-1]["pos"],
                min_leader_gap_m=min(r["leader_gap"] for r in part), max_leader_gap_m=max(r["leader_gap"] for r in part)))
            start = None
        if stopped and start is None:
            start = index
save_csv("lane-stay-segments.csv", sorted(segments, key=lambda row: (row["vehicle_id"], row["first_sample_s"])))
save_csv("stopped-segments.csv", sorted(stops, key=lambda row: -row["sample_count"]))
changes = []
for _, element in ET.iterparse(TRACE / "lanechanges.xml"):
    if element.tag in {"change", "changeStarted", "changeEnded"} and element.get("id") in ids:
        row = dict(element.attrib)
        now = float(row["time"])
        row["overlapping_hold_events"] = [h for h in hold_intervals[row["id"]] if h["begin"] <= now < h["end"]]
        changes.append(row)
    element.clear()
save_json("cohort-lanechanges.json", changes)
states = defaultdict(list)
for _, element in ET.iterparse(TRACE / "tls-switch-states.xml"):
    if element.tag == "tlsState" and element.get("id") in {"LSA104_part0", "LSA118_part0"}:
        states[element.get("id")].append(dict(time=float(element.get("time")), state=element.get("state"), phase=element.get("phase")))
    element.clear()
state_times = {identity: [r["time"] for r in rows] for identity, rows in states.items()}


def scene(identity, time):
    row = dict(by_time[time][identity])
    leader = by_time[time].get(row["leader_id"])
    row["leader_sample_same_time"] = dict(leader) if leader else None
    row["hold_intervals_overlapping"] = [h for h in hold_intervals[identity] if h["begin"] <= time < h["end"]]
    row["tls_states"] = {tls: entries[bisect_right(state_times[tls], time) - 1] for tls, entries in states.items()}
    row["tls_link_bits"] = {tls: {str(i): row["tls_states"][tls]["state"][i] for i in indices}
                            for tls, indices in [("LSA104_part0", [23, 24, 25]), ("LSA118_part0", [38, 39, 40, 41])]}
    chain, current, seen = [], row, {identity}
    while current["leader_id"] and current["leader_id"] not in seen and len(chain) < 20:
        leader_id = current["leader_id"]
        following = by_time[time].get(leader_id)
        chain.append(dict(vehicle_id=leader_id, reported_gap_m=current["leader_gap"],
            reported_speed_m_s=current["leader_speed"], recorded_sample=dict(following) if following else None))
        if following is None:
            break
        seen.add(leader_id)
        current = following
    row["leader_chain_within_recorded_cohort"] = chain
    return row


scene_rows = [scene("od_0272_v00002", t) for t in [11677., 11678., 13190., 13215., 13245.]]
scene_rows += [scene(identity, time) for identity, time in [
    ("od_0293_v00053", 13190.), ("od_0251_v00032", 12520.),
    ("od_0272_v00039", 12000.), ("od_0251_v00045", 12085.), ("od_0293_v00041", 13215.),
    ("od_0272_v00061", 11735.)]]
for identity in ["od_0272_v00002", "od_0272_v00061"]:
    for category in ["stopped_near_stopped_leader", "stopped_reported_leader_far", "stopped_leader_not_reported"]:
        relevant = [r for r in stops if r["vehicle_id"] == identity and r["classification"] == category]
        if relevant:
            longest = max(relevant, key=lambda r: r["sample_count"])
            scene_rows.append(scene(identity, longest["first_sample_s"]))
            scene_rows.append(scene(identity, (longest["first_sample_s"] + longest["last_sample_s"]) // 2))
save_json("representative-scenes.json", scene_rows)
save_csv("representative-samples.csv", [row for identity in sorted(REPRESENTATIVES) for row in samples.get(identity, [])])
report = dict(recording_parity=record["checks"], source_hashes=sources,
    definitions=dict(stopped_speed_m_s=STOP_SPEED, near_reported_leader_gap_m=NEAR_GAP, configured_leader_search_distance_m=200,
        units="Counts of 1-second native FCD samples, not exact continuous durations",
        missing_leader="No leader reported by native route-sensitive FCD search; no free-downstream inference",
        reported_gap_boundary="Native reports are retained even if a reported gap exceeds the configured search distance; no range clipping or inferred leader location"),
    declared_vehicles=len(ids), actual_fcd_vehicles=len(samples), declared_and_actual_ids_identical=set(samples) == ids,
    origin_counts=dict(Counter(origins.values())), sample_count=sum(len(rows) for rows in samples.values()),
    hold_event_parity_with_selected=hold == original_hold,
    recorded_cohort_lane_change_count=len(changes),
    recorded_lane_changes_overlapping_hold_intervals=sum(bool(row["overlapping_hold_events"]) for row in changes),
    lane_summaries=[dict(lane=lane, vehicles=len(lane_vehicles[lane]), counts=dict(counts)) for lane, counts in sorted(lane_counts.items())],
    representative_lane_stays=[row for row in segments if row["vehicle_id"] in REPRESENTATIVES],
    representative_lane_changes=[row for row in changes if row["id"] in REPRESENTATIVES],
    longest_stops=sorted(stops, key=lambda row: -row["sample_count"])[:20],
    longest_far_leader_stops=sorted([row for row in stops if row["classification"] == "stopped_reported_leader_far"], key=lambda row: -row["sample_count"])[:20],
    claim_boundary="Observed lanes, speeds and native leader reports only. No inferred unobserved leader position, desire to change lanes, or causal hold/controller contribution.",
    source_inputs_unchanged=all(sha(ROOT / row["path"]) == row["sha256"] for row in sources))
assert report["source_inputs_unchanged"]
save_json("trace-analysis.json", report)
print(json.dumps({k: report[k] for k in ["declared_vehicles", "actual_fcd_vehicles", "origin_counts", "sample_count", "hold_event_parity_with_selected", "lane_summaries"]}, indent=2))
print("representative lanes", json.dumps(report["representative_lane_stays"], indent=2))
print("far leader", json.dumps(report["longest_far_leader_stops"][:5], indent=2))
