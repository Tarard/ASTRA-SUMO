"""Read selected-run hold events and completed route exit times. No SUMO call."""

from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.junction_split_fanout import _curve, _key

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
NATIVE = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def save_csv(name, rows):
    with (OUT / name).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def stats(values):
    return dict(n=len(values), **{key: float(np.percentile(values, percentile)) for key, percentile in
                [("minimum", 0), ("median", 50), ("p90", 90), ("maximum", 100)]}) if values else dict(n=0)


OUT.mkdir(parents=True, exist_ok=True)
paths = [NATIVE / name for name in ["demand.rou.xml", "lane-intentions.json", "source-e1.add.xml",
    "network.net.xml", "run.json", "native-request.json", "stall-monitor.json", "tripinfo.xml", "vehicle-routes.xml"]]
paths += [ROOT / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
          ["lane_section_hold.py", "simulation_stall.py", "detector_demand_replay.py"]]
executed = NATIVE.parents[1] / "implementation/astra_sumo/core"
paths += [executed / name for name in ["lane_section_hold.py", "simulation_stall.py", "detector_demand_replay.py"]]
paths.append(Path(__file__).resolve())
sources = [dict(path=str(p.relative_to(ROOT)), sha256=sha(p)) for p in paths]
requests = {v.get("id"): v for v in ET.parse(NATIVE / "demand.rou.xml").getroot().findall("vehicle")}
identities = {identity for identity, v in requests.items() if v.find("route").get("edges").split()[0] == "963776077#0"}
trip = {v.get("id"): dict(v.attrib) for _, v in ET.iterparse(NATIVE / "tripinfo.xml") if v.tag == "tripinfo"}
monitor = json.loads((NATIVE / "stall-monitor.json").read_bytes())
hold = monitor["lane_section_hold"]
intervals = defaultdict(list)
for kind, events in [("detector", hold["events"]), ("body", hold["junction_body_hold"]["events"])]:
    pending = {}
    for event in events:
        identity = event["vehicle_id"]
        if identity not in identities:
            continue
        if event["event"] == "held":
            pending[identity] = event
        elif event["event"] in {"released", "left_before_release"} and identity in pending:
            start = pending.pop(identity)
            intervals[identity].append(dict(kind=kind, lane=start["lane"], begin_s=start["time_s"],
                end_s=event["time_s"], duration_s=event["time_s"] - start["time_s"],
                end_event=event["event"], previous_mode=start.get("previous_mode"),
                restored_mode=event.get("restored_mode")))
    assert not pending
records = []
for _, vehicle in ET.iterparse(NATIVE / "vehicle-routes.xml"):
    if vehicle.tag != "vehicle" or vehicle.get("id") not in identities:
        continue
    identity = vehicle.get("id")
    route = vehicle.find("route")
    roads, times = route.get("edges").split(), [float(t) for t in route.get("exitTimes").split()]
    assert len(roads) == len(times) and times[-1] >= 0
    exits = dict(zip(roads, times))
    body = [r for r in intervals[identity] if r["kind"] == "body" and r["lane"].startswith(":LSA104_part0_")]
    detector = [r for r in intervals[identity] if r["kind"] == "detector"]
    assert len(body) == len(detector) == 1
    b, d = body[0], detector[0]
    records.append(dict(vehicle_id=identity, request_depart_s=float(requests[identity].get("depart")),
        actual_depart_s=float(trip[identity]["depart"]), depart_delay_s=float(trip[identity]["departDelay"]),
        exit_963_s=exits["963776077#0"], exit_234_s=exits["234423652#1"],
        exit_538_s=exits["538341584"], exit_512_s=exits["51214742#1"],
        on_963_s=exits["963776077#0"] - float(trip[identity]["depart"]),
        from_exit963_to_exit234_s=exits["234423652#1"] - exits["963776077#0"],
        from_exit234_to_exit538_s=exits["538341584"] - exits["234423652#1"],
        from_exit538_to_exit512_s=exits["51214742#1"] - exits["538341584"],
        body_lane=b["lane"], body_begin_s=b["begin_s"], body_end_s=b["end_s"], body_duration_s=b["duration_s"],
        after_body_release_to_exit234_s=exits["234423652#1"] - b["end_s"],
        detector_lane=d["lane"], detector_begin_s=d["begin_s"], detector_end_s=d["end_s"],
        detector_duration_s=d["duration_s"], detector_previous_mode=d["previous_mode"], detector_restored_mode=d["restored_mode"]))
save_csv("963-completed-exit-hold-alignment.csv", records)
flat = [dict(vehicle_id=identity, **row) for identity, rows in intervals.items() for row in rows]
save_csv("963-hold-intervals.csv", flat)
net = ET.parse(NATIVE / "network.net.xml").getroot()
body_nodes = json.loads((NATIVE / "run.json").read_bytes())["junction_body_hold_nodes"]
scoped = [dict(edge=e.get("id"), lane=lane.get("id"), length_m=float(lane.get("length")))
          for e in net.findall("edge") if e.get("function") == "internal"
          and any(e.get("id").startswith(":" + node + "_") for node in body_nodes)
          for lane in e.findall("lane")]
save_csv("body-scope-internal-lanes.csv", scoped)
historical = ROOT / "outputs/lsa104-collision-diagnosis-20261023"
old = ET.parse(historical / "full-window-candidate/candidate.net.xml").getroot()
old_edges = {e.get("id"): e for e in old.findall("edge")}
new_edges = {e.get("id"): e for e in net.findall("edge")}
old_connections = {_key(c): c for c in old.findall("connection") if c.get("from") in old_edges
                   and old_edges[c.get("from")].get("to") == "LSA104_part0"
                   and c.get("to") in old_edges and not old_edges[c.get("to")].get("function")}
new_connections = {_key(c): c for c in net.findall("connection") if c.get("from") in new_edges
                   and new_edges[c.get("from")].get("to") == "LSA104_part0"
                   and c.get("to") in new_edges and not new_edges[c.get("to")].get("function")}
assert old_connections.keys() == new_connections.keys()
curve_offsets = [dict(connection=list(key), maximum_offset_m=_curve(old, old_connections[key]).hausdorff_distance(
    _curve(net, new_connections[key]))) for key in sorted(old_connections)]
history = dict(original_small_probe=json.loads((ROOT / "outputs/lsa104-portable-probe-20261023/evidence.json").read_bytes()),
    source_candidate_sha256=sha(historical / "full-window-candidate/candidate.net.xml"),
    current_vs_historical_104_candidate=dict(connection_count=len(curve_offsets), curves=curve_offsets,
        maximum_curve_offset_m=max(r["maximum_offset_m"] for r in curve_offsets)), full_window_cases={})
for label in ["full-window-native", "104-body-full-native"]:
    path = historical / label
    old_run = json.loads((path / "run.json").read_bytes())
    history["full_window_cases"][label] = dict(run_sha256=sha(path / "run.json"),
        body_nodes=old_run["junction_body_hold_nodes"], completion=old_run["completion"],
        collisions=[dict(e.attrib) for e in ET.parse(path / "collisions.xml").getroot()])
history["comparison_boundary"] = "8622 historical requests, not the current 8640 minus1 input. It is an LSA104-body-scope comparison, not an all-holds-off comparison."
save_json("historical-104-evidence.json", history)
matches = []
for scope in [ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1", OUT.parent]:
    for path in scope.rglob("native-request.json"):
        request = json.loads(path.read_bytes())
        route_path = Path(request.get("route_file", ""))
        if not route_path.is_file() or route_path.stat().st_size != (NATIVE / "demand.rou.xml").stat().st_size:
            continue
        if sha(route_path) != sha(NATIVE / "demand.rou.xml"):
            continue
        command = request["command"]
        network_path = Path(command[command.index("--net-file") + 1])
        if sha(network_path) != sha(NATIVE / "network.net.xml"):
            continue
        matches.append(dict(request_path=str(path.relative_to(ROOT)),
            junction_body_hold=request.get("junction_body_hold", False),
            body_nodes=request.get("junction_body_hold_nodes"),
            end_s=request["end_s"], request_sha256=sha(path)))
save_json("current-matching-demand-scopes.json", dict(
    searched_roots=["outputs/hamburg-classical-od-calibration-20261023-v1", str(OUT.parent.relative_to(ROOT))],
    route_sha256=sha(NATIVE / "demand.rou.xml"), network_sha256=sha(NATIVE / "network.net.xml"), matches=matches,
    boundary="Static input matches only. This search does not certify completion of another ongoing recording."))
report = dict(source_case=str(NATIVE.relative_to(ROOT)), sources=sources, body_nodes=body_nodes,
    request_count=len(identities), arrived_exit_record_count=len(records),
    source_vehicle_status=dict(Counter("missing_trip" if i not in trip else "running" if float(trip[i]["arrival"]) < 0 else "arrived"
                                      for i in identities)),
    route_exit_time_boundary="Consecutive ordinary-edge exits include the intervening native internal junction; they are not full lane trajectories.",
    statistics={key: stats([r[key] for r in records]) for key in ["on_963_s", "from_exit963_to_exit234_s",
        "from_exit234_to_exit538_s", "from_exit538_to_exit512_s", "body_duration_s",
        "after_body_release_to_exit234_s", "detector_duration_s"]},
    all_completed_body_releases_before_exit234=all(r["body_end_s"] <= r["exit_234_s"] for r in records),
    longest_234_intervals=sorted(records, key=lambda r: -r["from_exit963_to_exit234_s"])[:10],
    longest_body_holds=sorted(records, key=lambda r: -r["body_duration_s"])[:10],
    body_lanes=dict(Counter(r["lane"] for rows in intervals.values() for r in rows if r["kind"] == "body")),
    executed_driver_files_match_current={name: sha(executed / name) == sha(ROOT / "plugins/astra-sumo/src/astra_sumo/core" / name)
        for name in ["lane_section_hold.py", "simulation_stall.py", "detector_demand_replay.py"]},
    actual_lane_change_trace_available=False,
    claim_boundary="Hold event times establish when the driver requested mode 512. Existing records do not show whether a desired lane change was blocked, or its causal delay.",
    source_inputs_unchanged=all(sha(ROOT / r["path"]) == r["sha256"] for r in sources))
assert report["source_inputs_unchanged"]
save_json("driver-audit.json", report)
print(json.dumps({k: report[k] for k in ["request_count", "arrived_exit_record_count", "source_vehicle_status", "statistics",
                 "all_completed_body_releases_before_exit234"]}, indent=2))
print("largest", json.dumps(report["longest_234_intervals"][:2], indent=2))
