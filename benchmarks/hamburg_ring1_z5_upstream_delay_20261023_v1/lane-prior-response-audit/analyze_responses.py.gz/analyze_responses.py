"""Reconcile completed lane swaps. No simulation or input mutation."""

from collections import Counter
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np


ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
UPSTREAM = OUT.parent
SELECTED = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation"
BASE_PASSAGES = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/selected-next-diagnosis/selected-contributing-passages.json.gz"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def save_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def canonical(element):
    return ET.canonicalize(ET.tostring(element, encoding="unicode"), strip_text=True)


def requests(path):
    return {e.get("id"): e for e in ET.parse(path).getroot().findall("vehicle")}


def intentions(path):
    return {row["vehicle_id"]: row for row in load_json(path)["vehicles"]}


def periodic(path):
    return {(e.get("id"), float(e.get("begin")), float(e.get("end"))): dict(e.attrib)
            for _, e in ET.iterparse(path) if e.tag == "interval"}


def compact(path, native):
    data = load_json(path)
    assert data["reconciled"] and data["inputs_unchanged"] and data["measurement_attribute"] == "nVehContrib"
    assert not data["outside_periodic_intervals"]
    for row in data["inputs"]:
        assert sha(Path(row["path"])) == row["sha256"]
    counts = Counter((r["detector_id"], r["interval_begin_s"], r["interval_end_s"]) for r in data["passages"])
    raw = periodic(native / "field-counts.xml")
    assert len(raw) == len(data["interval_comparisons"]) == 208
    assert all(counts[key] == int(row["nVehContrib"]) for key, row in raw.items())
    by_id = {r["vehicle_id"]: r for r in data["passages"]}
    assert len(by_id) == len(data["passages"])
    return data, counts, by_id, raw


def exits(path):
    result = {}
    for _, vehicle in ET.iterparse(path):
        if vehicle.tag != "vehicle":
            continue
        route = vehicle.find("route")
        roads = route.get("edges").split()
        times = [float(v) for v in route.get("exitTimes").split()]
        assert len(roads) == len(times)
        result[vehicle.get("id")] = (roads, times)
    return result


def trip_rows(path):
    return {e.get("id"): dict(e.attrib) for _, e in ET.iterparse(path) if e.tag == "tripinfo"}


def signature(event):
    return (event["detector_id"], event["interval_begin_s"]) if event else None


OUT.mkdir(parents=True, exist_ok=True)
source_requests = requests(SELECTED / "demand.rou.xml")
source_intentions = intentions(SELECTED / "lane-intentions.json")
base_data, base_counts, base_events, base_raw = compact(BASE_PASSAGES, SELECTED / "native")
base_routes = exits(SELECTED / "native/vehicle-routes.xml")
base_trips = trip_rows(SELECTED / "native/tripinfo.xml")
base_run = load_json(SELECTED / "native/run.json")
base_evaluation = load_json(SELECTED / "evaluation.json")
keys = sorted(base_raw)
key_index = {key: index for index, key in enumerate(keys)}
targets = {}
for filename in ["expected-counts.csv", "initialization-counts.csv"]:
    path = UPSTREAM / "lane-swap-1pair/prepared" / filename
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            targets[row["detector_id"], float(row["begin"]), float(row["end"])] = int(row["expected_total"])
assert len(targets) == 182
main = np.array([key in targets and key[1] >= 3600 for key in keys])
all182 = np.array([key in targets for key in keys])
target_array = np.array([targets.get(key, 0) for key in keys], dtype=int)
y0 = np.array([base_counts[key] for key in keys], dtype=int)
assert abs((y0 - target_array)[main]).sum() == 662
assert ((y0 - target_array)[main] ** 2).sum() == 6898
source_files = [BASE_PASSAGES, Path(__file__).resolve()] + [SELECTED / name for name in [
    "demand.rou.xml", "lane-intentions.json", "od-vector.json", "evaluation.json", "native/vehicle-routes.xml",
    "native/tripinfo.xml", "native/run.json", "native/field-counts.xml"]]
reports = {}
for case, expected_changed in [("lane-swap-1pair", 2), ("lane-swap-5pair", 10)]:
    folder = UPSTREAM / case
    output = OUT / case
    output.mkdir(exist_ok=True)
    native = folder / "evaluation/native"
    for name in ["network.net.xml", "signal-programs.add.xml", "source-e1.add.xml", "expected-counts.csv"]:
        assert sha(native / name) == sha(SELECTED / "native" / name)
    verdict = load_json(folder / "verdict.json")
    preflight = load_json(folder / "preflight.json")
    changed = set(preflight["changed_vehicle_ids"])
    assert len(changed) == expected_changed
    current_requests = requests(native / "demand.rou.xml")
    current_intentions = intentions(native / "lane-intentions.json")
    old_vector, current_vector = load_json(SELECTED / "od-vector.json"), load_json(folder / "evaluation/od-vector.json")
    assert current_vector["integer_counts"] == old_vector["integer_counts"]
    assert current_vector["values"] == old_vector["values"]
    assert current_vector["source_vector_sha256"] == sha(SELECTED / "od-vector.json")
    assert source_requests.keys() == current_requests.keys() == source_intentions.keys() == current_intentions.keys()
    inventory0, inventory1 = Counter(), Counter()
    for identity, before in source_requests.items():
        after = current_requests[identity]
        assert before.attrib == after.attrib
        restored = copy.deepcopy(after)
        if identity in changed:
            assert before.find("stop").get("lane") != after.find("stop").get("lane")
            restored.find("stop").set("lane", before.find("stop").get("lane"))
            assert source_intentions[identity]["field_id"] != current_intentions[identity]["field_id"]
        else:
            assert source_intentions[identity] == current_intentions[identity]
        assert canonical(before) == canonical(restored)
        assert {k: v for k, v in source_intentions[identity].items() if k != "field_id"} == {
            k: v for k, v in current_intentions[identity].items() if k != "field_id"}
        period = int(float(before.get("depart")) // 900)
        inventory0[period, source_intentions[identity]["field_id"]] += 1
        inventory1[period, current_intentions[identity]["field_id"]] += 1
    assert inventory0 == inventory1
    data, current_counts, events, raw = compact(folder / "evaluation/contributing-passages.json.gz", native)
    assert set(raw) == set(base_raw)
    earliest_depart = min(float(source_requests[i].get("depart")) for i in changed)
    prefix = [key for key in keys if key in targets and key[2] <= earliest_depart]
    assert len(prefix) == verdict["unchanged_prefix_rows"] and all(base_raw[key] == raw[key] for key in prefix)
    wrong = [row for row in data["passages"] if row["detector_id"] != current_intentions[row["vehicle_id"]]["field_id"]]
    repeated = [key for key, n in Counter((r["vehicle_id"], r["detector_id"]) for r in data["passages"]).items() if n > 1]
    assert wrong == verdict["wrong_field_contributions"] == [] and repeated == verdict["repeated_vehicle_field"] == []
    y = np.array([current_counts[key] for key in keys], dtype=int)
    r0, residual = y0 - target_array, y - target_array
    tae, sse = int(abs(residual[main]).sum()), int((residual[main] ** 2).sum())
    assert tae == round(verdict["after"]["MAE"] * 130) and sse == verdict["after"]["loss"]
    assert int(abs(residual[all182]).sum()) == verdict["all182_TAE"]
    current_routes, current_trips = exits(native / "vehicle-routes.xml"), trip_rows(native / "tripinfo.xml")
    outcome_rows, edge_rows = [], []
    for identity in sorted(changed):
        old_event, event = base_events.get(identity), events.get(identity)
        old_trip, trip = base_trips.get(identity), current_trips.get(identity)
        row = dict(vehicle_id=identity, origin=source_requests[identity].find("route").get("edges").split()[0],
            requested_depart_s=float(source_requests[identity].get("depart")),
            old_intended_field=source_intentions[identity]["field_id"], new_intended_field=current_intentions[identity]["field_id"],
            source_actual_field=old_event["detector_id"] if old_event else None,
            candidate_actual_field=event["detector_id"] if event else None,
            source_passage_s=old_event["notification_time_s"] if old_event else None,
            candidate_passage_s=event["notification_time_s"] if event else None,
            passage_time_change_s=event["notification_time_s"] - old_event["notification_time_s"] if event and old_event else None,
            source_passage_bin_s=old_event["interval_begin_s"] if old_event else None,
            candidate_passage_bin_s=event["interval_begin_s"] if event else None,
            source_actual_depart_s=float(old_trip["depart"]) if old_trip else None,
            candidate_actual_depart_s=float(trip["depart"]) if trip else None,
            source_actual_depart_lane=old_trip["departLane"] if old_trip else None,
            candidate_actual_depart_lane=trip["departLane"] if trip else None,
            source_arrival_s=float(old_trip["arrival"]) if old_trip else None,
            candidate_arrival_s=float(trip["arrival"]) if trip else None,
            source_arrived_route_record=identity in base_routes, candidate_arrived_route_record=identity in current_routes)
        outcome_rows.append(row)
        if identity in base_routes and identity in current_routes:
            roads, old_times = base_routes[identity]
            new_roads, times = current_routes[identity]
            assert roads == new_roads == source_requests[identity].find("route").get("edges").split()
            for index, (road, old_time, time) in enumerate(zip(roads, old_times, times)):
                old_start = old_times[index - 1] if index else float(old_trip["depart"])
                start = times[index - 1] if index else float(trip["depart"])
                edge_rows.append(dict(vehicle_id=identity, edge_index=index, edge=road, source_exit_s=old_time,
                    candidate_exit_s=time, exit_change_s=time - old_time, source_previous_exit_or_depart_s=old_start,
                    candidate_previous_exit_or_depart_s=start, source_interval_s=old_time - old_start,
                    candidate_interval_s=time - start, interval_change_s=(time - start) - (old_time - old_start)))
    save_csv(output / "modified-vehicle-outcomes.csv", outcome_rows)
    save_csv(output / "modified-edge-exits.csv", edge_rows)
    old_changed = Counter((r["detector_id"], r["interval_begin_s"], r["interval_end_s"]) for i, r in base_events.items() if i in changed)
    new_changed = Counter((r["detector_id"], r["interval_begin_s"], r["interval_end_s"]) for i, r in events.items() if i in changed)
    c0, c1 = [np.array([counts[key] for key in keys], dtype=int) for counts in [old_changed, new_changed]]
    u0, u1 = y0 - c0, y - c1
    delta_c, delta_u = c1 - c0, u1 - u0
    assert np.array_equal(y - y0, delta_c + delta_u)
    delta_rows = [dict(field=key[0], begin_s=key[1], end_s=key[2],
        scope="main" if main[i] else "initialization" if all182[i] else "tail_no_target",
        target=targets.get(key), source_measured=int(y0[i]), candidate_measured=int(y[i]),
        source_residual=int(r0[i]) if all182[i] else None, candidate_residual=int(residual[i]) if all182[i] else None,
        source_modified_cohort=int(c0[i]), candidate_modified_cohort=int(c1[i]), modified_delta=int(delta_c[i]),
        source_unmodified_cohort=int(u0[i]), candidate_unmodified_cohort=int(u1[i]), unmodified_delta=int(delta_u[i]))
        for i, key in enumerate(keys)]
    save_csv(output / "contribution-deltas-208.csv", delta_rows)
    transfers = []
    same_bin_different_time = 0
    for identity in sorted(source_requests.keys() - changed):
        before, after = base_events.get(identity), events.get(identity)
        if signature(before) == signature(after):
            same_bin_different_time += bool(before and after and before["notification_time_s"] != after["notification_time_s"])
            continue
        transfers.append(dict(vehicle_id=identity, source_field=before["detector_id"] if before else None,
            candidate_field=after["detector_id"] if after else None,
            source_passage_s=before["notification_time_s"] if before else None,
            candidate_passage_s=after["notification_time_s"] if after else None,
            source_bin_s=before["interval_begin_s"] if before else None,
            candidate_bin_s=after["interval_begin_s"] if after else None,
            kind="cross_bin" if before and after else "new_complete_passage" if after else "no_longer_complete"))
    if transfers:
        save_csv(output / "unmodified-vehicle-transfers.csv", transfers)
    field_rows = []
    for field in sorted({key[0] for key in keys}):
        mask = main & np.array([key[0] == field for key in keys])
        field_rows.append(dict(field=field, source_TAE=int(abs(r0[mask]).sum()), candidate_TAE=int(abs(residual[mask]).sum()),
            source_SSE=int((r0[mask] ** 2).sum()), candidate_SSE=int((residual[mask] ** 2).sum()),
            source_measured=int(y0[mask].sum()), candidate_measured=int(y[mask].sum()),
            modified_signed_delta=int(delta_c[mask].sum()), unmodified_signed_delta=int(delta_u[mask].sum()),
            modified_L1_delta=int(abs(delta_c[mask]).sum()), unmodified_L1_delta=int(abs(delta_u[mask]).sum())))
    save_csv(output / "field-main-summary.csv", field_rows)
    native_run = load_json(native / "run.json")
    assert all(native_run[k] == base_run[k] for k in ["seed", "step_length_s", "end_s", "backend", "junction_body_hold_nodes"])
    completion = native_run["completion"]
    assert completion == verdict["after"]["completion"]
    safe = not any(completion[k] for k in ["collisions", "teleports", "discarded"])
    assert not ET.parse(native / "collisions.xml").getroot().findall("collision")
    gates = dict(safe=safe, wrong_and_repeated_zero=not wrong and not repeated,
        MAE_improves=tae < 662, SSE_improves=sse < 6898,
        waiting_not_above_selected=completion["waiting"] <= 7,
        unfinished_not_above_selected=completion["waiting"] + completion["running"] <= 21)
    assert not all(gates.values()) and verdict["status"] == "rejected"
    reports[case] = dict(raw_verdict_status=verdict["status"], gates=gates,
        main_TAE=tae, main_SSE=sse, main_MAE=tae / 130, all182_TAE=verdict["all182_TAE"], completion=completion,
        changed_vehicle_count=len(changed), prefix_rows_identical=len(prefix), modified_vehicles=outcome_rows,
        explicit_input_checks=dict(only_declared_stop_lanes_and_fields_changed=True, OD_integer_counts_and_values_unchanged=True,
            native_network_control_detectors_targets_unchanged=True, all_run_treatment_settings_unchanged=True,
            field_inventory_each_departure_bin_unchanged=inventory0 == inventory1),
        main_contribution_bookkeeping=dict(source_modified_total=int(c0[main].sum()), candidate_modified_total=int(c1[main].sum()),
            modified_delta=int(delta_c[main].sum()), unmodified_delta=int(delta_u[main].sum()),
            modified_L1_delta=int(abs(delta_c[main]).sum()), unmodified_L1_delta=int(abs(delta_u[main]).sum()),
            rows_with_unmodified_delta=int(np.count_nonzero(delta_u[main]))),
        unmodified_transfer_kinds=dict(Counter(row["kind"] for row in transfers)),
        unmodified_same_bin_time_changed=same_bin_different_time,
        field_main_summary=field_rows,
        claim_boundary="Changed/unmodified groups decompose observed contributions arithmetically. They are not separate causal effects, and no old contribution has been relabeled.")
    source_files += [folder / name for name in ["verdict.json", "preflight.json", "executed-driver.py",
        "prepared/expected-counts.csv", "prepared/initialization-counts.csv", "evaluation/contributing-passages.json.gz",
        "evaluation/od-vector.json", "evaluation/native/demand.rou.xml", "evaluation/native/lane-intentions.json",
        "evaluation/native/vehicle-routes.xml", "evaluation/native/tripinfo.xml", "evaluation/native/run.json",
        "evaluation/native/field-counts.xml", "evaluation/native/collisions.xml"]]
source_hashes = [dict(path=str(path.relative_to(ROOT)), sha256=sha(path)) for path in source_files]
report = dict(source_reference=str(SELECTED.relative_to(ROOT)), source_hashes=source_hashes,
    baseline=dict(main_TAE=662, main_SSE=6898, main_MAE=base_evaluation["MAE"], completion=base_run["completion"]),
    cases=reports, edge_interval_boundary="Ordinary-edge exit-to-exit intervals include the intervening internal junction; arrived route records are not complete step trajectories.",
    outcome_boundary="Only new compact complete passages and new route exits support candidate outcomes. No projection or old-field relabeling.",
    no_simulation_executed=True, source_inputs_unchanged=all(sha(ROOT / row["path"]) == row["sha256"] for row in source_hashes))
assert report["source_inputs_unchanged"]
save_json(OUT / "response-audit.json", report)
print(json.dumps({case: {key: value[key] for key in ["gates", "main_TAE", "main_SSE", "completion", "main_contribution_bookkeeping", "unmodified_transfer_kinds"]}
                  for case, value in reports.items()}, indent=2))
