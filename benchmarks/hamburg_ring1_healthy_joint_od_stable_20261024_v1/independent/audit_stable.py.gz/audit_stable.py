"""Read sealed inputs and, only after a verdict, the completed native response."""

from collections import Counter
from copy import deepcopy
import gzip
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
CASE = STUDY / "stable-64"
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
MODEL = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json"
QUANTILE = REPO / "outputs/hamburg-healthy-joint-od-feedback-20261024-v1"
TARGET = REPO / "outputs/hamburg-healthy-joint-od-audit-20261024-v1/bounded-128/proposal.json"
HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPERS))
import audit_response as audit  # noqa: E402
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages  # noqa: E402

FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def native_ms(value):
    return math.floor(float(value) * 1000 + .5)


def inspect_inputs():
    proof = json.loads((CASE / "scope-proof.json").read_bytes())
    preflight = json.loads((CASE / "preflight.json").read_bytes())
    proposal = json.loads((CASE / "proposal.json").read_bytes())
    assert proof["status"] == "pass" and proof["N"] == 8640
    assert preflight["source_proof_sha256"] == audit.digest(CASE / "scope-proof.json")
    mapping = {r["original_path"]: r for r in proof["source_snapshot_mapping"]}
    bindings = []
    for original, expected in proof["source_hashes"].items():
        resolved = Path(mapping[original]["snapshot_path"]) if original in mapping else Path(original)
        assert audit.digest(resolved) == expected
        if original in mapping:
            assert mapping[original]["sha256"] == expected
        bindings.append(dict(declared_path=original, audited_path=str(resolved), sha256=expected))
    assert set(preflight["versions"].values()) == {"1.27.1"} and preflight["backend"] == "libsumo"
    assert preflight["prepared_hashes"] == proof["prepared_hashes"]
    for name, expected in proof["prepared_hashes"].items():
        assert audit.digest(CASE / "prepared" / name) == expected
    for name, expected in preflight["implementation_sha256"].items():
        assert audit.digest(CASE / "implementation" / name) == expected
        if (SOURCE / "implementation" / name).exists():
            assert (CASE / "implementation" / name).read_bytes() == (SOURCE / "implementation" / name).read_bytes()
    for path, expected in preflight["binaries"].items():
        assert audit.digest(Path(path)) == expected
    assert audit.digest(CASE / "executed-driver.py") == preflight["executed_driver_sha256"]
    assert (CASE / "executed-driver.py").read_bytes() == (STUDY / "run_candidate.py").read_bytes()
    assert audit.digest(HELPERS / "audit_response.py") == preflight["helper_sha256"]
    assert audit.digest(HELPERS / "audit_scope.py") == preflight["helper_scope_sha256"]
    folders = [SOURCE / "prepared", CASE / "prepared"]
    for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]:
        assert (folders[0] / name).read_bytes() == (folders[1] / name).read_bytes()
    roots = [ET.parse(folder / "demand.rou.xml").getroot() for folder in folders]
    rows = [{r.get("id"): r for r in root.findall("vehicle")} for root in roots]
    assert rows[0].keys() == rows[1].keys() and len(rows[0]) == len(rows[1]) == 8640
    assert all(len(root.findall("vehicle")) == 8640 for root in roots)
    assert [ET.tostring(v) for v in roots[0] if v.tag != "vehicle"] == [ET.tostring(v) for v in roots[1] if v.tag != "vehicle"]
    selected = {r["vehicle_id"]: r for r in proposal["proposals"]}
    assert len(selected) == len(proposal["proposals"]) == proposal["changed_vehicles"] == 64
    assert proposal["l1_cell_change"] == 128 and not proposal["initial_requests_changed"]
    metadata_top = [json.loads((folder / "lane-intentions.json").read_bytes()) for folder in folders]
    metadata = [{r["vehicle_id"]: r for r in d["vehicles"]} for d in metadata_top]
    assert [k for k in metadata_top[0] if k != "vehicles" and metadata_top[0][k] != metadata_top[1][k]] == ["mechanism"]
    cells = json.loads(MODEL.read_bytes())["cells"]
    keys = [(r["origin"], r["destination"], int(r["begin_s"])) for r in cells]
    assert len(keys) == len(set(keys)) == 294
    indices = {key: i for i, key in enumerate(keys)}
    inventories = [Counter(), Counter()]
    field_inventories = [Counter(), Counter()]
    shifts, changed, initial = [], [], []
    for identity in rows[0]:
        old, new = [r[identity] for r in rows]
        restored = deepcopy(new)
        restored.set("depart", old.get("depart"))
        assert ET.tostring(restored) == ET.tostring(old)
        for side in (0, 1):
            row = rows[side][identity]
            edges = row.find("route").get("edges").split()
            native = native_ms(row.get("depart"))
            index = indices[edges[0], edges[-1], native // 900000 * 900]
            assert metadata[side][identity]["od_cell"] == index
            inventories[side][index] += 1
            field_inventories[side][native // 900000, metadata[side][identity]["field_id"]] += 1
        if native_ms(old.get("depart")) < 3600000:
            assert ET.tostring(old) == ET.tostring(new)
            initial.append(identity)
        if identity in selected:
            p = selected[identity]
            assert float(old.get("depart")) == p["source_depart_s"] and float(new.get("depart")) == p["proposed_depart_s"]
            assert native_ms(old.get("depart")) != native_ms(new.get("depart"))
            source_cell, target_cell = p["source_cell"], p["target_cell"]
            assert keys[source_cell][:2] == keys[target_cell][:2]
            assert cells[source_cell]["begin_s"] >= 3600 and cells[target_cell]["begin_s"] >= 3600
            assert metadata[0][identity]["od_cell"] == source_cell and metadata[1][identity]["od_cell"] == target_cell
            m = dict(metadata[1][identity])
            assert m.pop("depart_s") == float(new.get("depart"))
            m["od_cell"] = source_cell
            assert m == metadata[0][identity]
            shifts.append(abs(native_ms(new.get("depart"))-native_ms(old.get("depart"))) / 1000)
            changed.append(dict(vehicle_id=identity, source_cell=source_cell, target_cell=target_cell, origin=keys[source_cell][0], destination=keys[source_cell][1], field=m["field_id"], old_requested_s=old.get("depart"), new_requested_s=new.get("depart"), native_shift_s=(native_ms(new.get("depart"))-native_ms(old.get("depart"))) / 1000))
        else:
            assert ET.tostring(old) == ET.tostring(new) and metadata[0][identity] == metadata[1][identity]
    assert [i for i in rows[0] if i not in selected] == [i for i in rows[1] if i not in selected]
    assert len(initial) == 1953
    target = json.loads(TARGET.read_bytes())["solution"]
    vectors = [[d[i] for i in range(294)] for d in inventories]
    assert vectors[0] == proposal["prior"] and vectors[1] == proposal["target"] == target
    saved = json.loads((CASE / "od-vector.json").read_bytes())
    assert saved["integer_counts"] == saved["values"] == target and saved["vehicle_count"] == 8640
    assert saved["source_model_sha256"] == audit.digest(MODEL) and not saved["demand_generated_by_original_model"]
    assert vectors[0][:84] == vectors[1][:84]
    for od in {k[:2] for k in keys}:
        assert sum(vectors[0][i] for i,k in enumerate(keys) if k[:2] == od) == sum(vectors[1][i] for i,k in enumerate(keys) if k[:2] == od)
    audit.table(OUT / "selected64-input-changes.csv", changed)
    audit.table(OUT / "all294-cell-inventory.csv", [dict(index=i, origin=k[0], destination=k[1], begin_s=k[2], before=vectors[0][i], after=vectors[1][i], delta=vectors[1][i]-vectors[0][i]) for i,k in enumerate(keys)])
    audit.table(OUT / "all14bin-field-intended-inventory.csv", [dict(departure_bin=k[0], field=k[1], before=field_inventories[0][k], after=field_inventories[1][k], delta=field_inventories[1][k]-field_inventories[0][k]) for k in sorted(field_inventories[0].keys() | field_inventories[1].keys())])
    report = dict(schema="astra.hamburg.stable-od-input-independent/v1", status="pass", native_runs_by_audit=0,
        N=8640, same_IDs_routes_stops_fields_vtypes=True, exactly64_departures_changed=True,
        unmodified8576_XML_and_intent_rows_exact=True, unmodified_relative_input_order_exact=True,
        selected64_depart_s_target_od_cell_exact=True, same294_target_as_quantile=True, all21_OD_totals_exact=True,
        initial84_cells_frozen=True, initial1953_XML_exact=True, source_bindings=bindings,
        max_native_shift_s=max(shifts), median_native_shift_s=sum(sorted(shifts)[31:33]) / 2,
        scope_hashes={str(p):audit.digest(p) for p in [CASE / "scope-proof.json", CASE / "preflight.json", CASE / "proposal.json", CASE / "od-vector.json", CASE / "executed-driver.py"]},
        claim_boundary="Only64 existing departures change; their matching metadata changes are explicit. Same OD-period counts do not establish the same traffic response or verify the previous C/q prediction. All control, network and measured-target bytes are fixed.")
    audit.save(OUT / "input-scope.json", report)
    return report, rows, metadata, selected


def main():
    scope, rows, metadata, selected = inspect_inputs()
    if not (CASE / "verdict.json").exists():
        print(json.dumps(dict(status="input_scope_pass", terminal_native_analysis="not_started", native_runs=0)))
        return
    verdict = json.loads((CASE / "verdict.json").read_bytes())
    assert verdict["native_response_measured"] and verdict["status"] != "invalid"
    data = [audit.evidence(folder / "prepared", folder / "evaluation", folder / "evaluation/contributing-passages.json.gz", 8640) for folder in [SOURCE, CASE]]
    native = CASE / "evaluation/native"
    run = json.loads((native / "run.json").read_bytes())
    raw = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=run["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(CASE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        assert raw == json.load(handle) and raw["reconciled"]
    requests = [json.loads((folder / "evaluation/native/native-request.json").read_bytes()) for folder in [SOURCE, CASE]]
    normalized = [json.dumps(r, sort_keys=True).replace(str(folder).replace("\\", "\\\\"), "{case}") for r,folder in zip(requests,[SOURCE,CASE])]
    assert normalized[0] == normalized[1]
    monitor = json.loads((native / "stall-monitor.json").read_bytes())
    assert monitor["library_completed"] and monitor["native_returncode"] is None and monitor["native_version"] == [22, "SUMO 1.27.1"]
    assert audit.digest(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    before, after = data
    initial_keys = [(r["detector_id"], float(r["begin"]), float(r["end"])) for r in before["initial"]]
    initial52_count_rows_exact = all(before["periodic"][k]["nVehContrib"] == after["periodic"][k]["nVehContrib"] for k in initial_keys)
    for label, measured in zip(["before", "after"], data):
        assert all(measured[k] == verdict[label][k] for k in verdict[label])
        for name, values in [("130",measured["main"]),("52",measured["initial"]),("182",measured["initial"]+measured["main"]),("40",measured["stations"])]:
            audit.table(OUT / f"{label}-{name}.csv",values)
    fields = sorted({k[0] for k in before["periodic"]})
    field_rows = []
    for field in fields:
        a,b = [audit.metrics([r for r in d["main"] if r["detector_id"] == field]) for d in data]
        field_rows.append(dict(field=field,before_TAE=a["TAE"],after_TAE=b["TAE"],delta_TAE=b["TAE"]-a["TAE"],before_SSE=a["SSE"],after_SSE=b["SSE"],delta_SSE=b["SSE"]-a["SSE"]))
    audit.table(OUT / "field13-response.csv",field_rows)
    cohort_sets = {"selected64":set(selected),"unmodified8576":set(rows[0])-set(selected)}
    cohort_counts = {name:[audit.counts(d["by_vehicle"],ids) for d in data] for name,ids in cohort_sets.items()}
    cohort_response = {}
    for name, ids in cohort_sets.items():
        def signature(measured, identity):
            return [(e["detector_id"],e["interval_begin_s"],e["interval_end_s"]) for e in measured["by_vehicle"].get(identity,[])]
        cohort_response[name] = dict(IDs=len(ids),before_events=sum(len(before["by_vehicle"].get(i,[])) for i in ids),after_events=sum(len(after["by_vehicle"].get(i,[])) for i in ids),field_or_bin_or_event_presence_changed=sum(signature(before,i)!=signature(after,i) for i in ids))
    response=[]
    for k in sorted(before["periodic"]):
        a,b=[int(d["periodic"][k]["nVehContrib"]) for d in data]
        row=dict(field=k[0],begin_s=k[1],end_s=k[2],before=a,after=b,delta=b-a)
        row.update({name+"_delta":c[1][k]-c[0][k] for name,c in cohort_counts.items()})
        assert sum(row[name+"_delta"] for name in cohort_sets)==b-a
        response.append(row)
    audit.table(OUT / "native208-cohort-accounting.csv",response)
    audit.table(OUT / "selected64-actual-events.csv",[dict(vehicle_id=i,old_requested_s=rows[0][i].get("depart"),new_requested_s=rows[1][i].get("depart"),old_actual_depart_s=before["tripinfo"].get(i,{}).get("depart"),new_actual_depart_s=after["tripinfo"].get(i,{}).get("depart"),before_events=audit.event_view(before["by_vehicle"].get(i,[])),after_events=audit.event_view(after["by_vehicle"].get(i,[]))) for i in selected])
    repeat=[(i,f,n) for i,es in after["by_vehicle"].items() for f,n in Counter(e["detector_id"] for e in es).items() if n>1]
    outside=[(i,e["detector_id"]) for i,es in after["by_vehicle"].items() for e in es if e["detector_id"]!=metadata[1][i]["field_id"]]
    assert not repeat and not outside
    rows535=[r for r in after["initial"]+after["main"] if r["detector_id"] in FIELDS535]
    assert len(rows535)==56 and audit.metrics(rows535)["TAE"]==0
    arrived={i for i,t in after["tripinfo"].items() if float(t["arrival"])>=0}
    route_rows=ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle")
    assert {r.get("id") for r in route_rows}==arrived and len(route_rows)==len(arrived)==after["completion"]["arrived"]
    assert all(r.find("route").get("edges")==rows[1][r.get("id")].find("route").get("edges") for r in route_rows)
    terminal=[]
    for identity in sorted(set(rows[1])-arrived):
        trip=after["tripinfo"].get(identity)
        edges=rows[1][identity].find("route").get("edges").split()
        terminal.append(dict(vehicle_id=identity,origin=edges[0],destination=edges[-1],field=metadata[1][identity]["field_id"],od_cell=metadata[1][identity]["od_cell"],state="not_inserted" if trip is None or float(trip["depart"])<0 else "inserted_unfinished",before_events=audit.event_view(before["by_vehicle"].get(identity,[])),after_events=audit.event_view(after["by_vehicle"].get(identity,[]))))
    assert len(terminal)==after["completion"]["waiting"]+after["completion"]["running"]
    audit.table(OUT / "terminal-unfinished-inputs-and-events.csv",terminal)
    gates=dict(safe=after["safe"],healthy=after["healthy"],all53556_zero=audit.metrics(rows535)["TAE"]==0,no_repeated_vehicle_fields=not repeat,no_contributions_outside_primary_intention=not outside,
        main130_MAE_improves=after["metrics130"]["MAE"]<before["metrics130"]["MAE"],main130_SSE_not_worse=after["metrics130"]["SSE"]<=before["metrics130"]["SSE"],all182_TAE_not_worse=after["metrics182"]["TAE"]<=before["metrics182"]["TAE"])
    assert gates==verdict["gates"] and verdict["status"]==("diagnostic_candidate" if all(gates.values()) else "rejected")
    quantile_path=QUANTILE / "independent/summary.json"
    quantile=json.loads(quantile_path.read_bytes())
    z5="hh_0119_Z_5_30494"
    fixed_total=sum(r["field_id"]==z5 for r in metadata[0].values())
    fixed_initial=sum(int(r["measured_nVehContrib"]) for r in before["initial"] if r["detector_id"]==z5)
    main_target=sum(int(r["expected_total"]) for r in before["main"] if r["detector_id"]==z5)
    assert (fixed_total,fixed_initial,main_target)==(623,102,522)
    result=dict(schema="astra.hamburg.stable-od-independent/v1",audit_status="pass",native_runs_by_audit=0,selection=verdict["status"],gates=gates,
        before={k:before[k] for k in verdict["before"]},after={k:after[k] for k in verdict["after"]},station40_max=max(abs(r["residual"]) for r in after["stations"]),
        input_scope=scope,field_rows=field_rows,all53556=audit.metrics(rows535),unique_complete_contributing_vehicles=len(after["by_vehicle"]),repeated=repeat,outside=outside,
        initial52_count_rows_exact=initial52_count_rows_exact,cohort_response=cohort_response,
        conditional_Z5_capacity=dict(global_fixed_intended_vehicles=fixed_total,fixed_initial_complete_events=fixed_initial,main_maximum_if_at_most_one_intended_contribution=fixed_total-fixed_initial,main_target_total=main_target,applies_only_with_fixed_initial_and_no_extra_or_repeated_contributions=True,does_not_restrict_legal_field_share_changes=True),
        same_q_quantile_reference=dict(path=str(quantile_path),sha256=audit.digest(quantile_path),after=quantile["after"]),
        terminal_count=len(terminal),terminal_by_origin=dict(Counter(r["origin"] for r in terminal)),terminal_by_field=dict(Counter(r["field"] for r in terminal)),
        source_raw_hashes=before["source_hashes"],candidate_raw_hashes=after["source_hashes"],verdict_sha256=audit.digest(CASE / "verdict.json"),
        claim_boundary="Same294 OD-period vector as quantile candidate, with64 explicit departures and corresponding metadata changed. Realization and endogenous control response can differ. Native counts and health are measured anew. Cohort accounting is not causal separation or proof of trueOD, fieldSPaT or zero-fit feasibility.")
    audit.save(OUT / "summary.json",result)
    print(json.dumps({k:result[k] for k in ["audit_status","selection","before","after","terminal_by_origin","terminal_by_field"]}))


if __name__=="__main__":
    main()
