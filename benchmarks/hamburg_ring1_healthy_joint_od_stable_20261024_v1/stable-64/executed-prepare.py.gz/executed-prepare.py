"""Realize the saved22-cell target with exactly64 preserved requests retimed."""

import copy
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming
from astra_sumo.core.od_stable_realization import propose_stable_od_retiming

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
PREVIOUS = REPO / "outputs/hamburg-healthy-joint-od-audit-20261024-v1/bounded-128"
MODEL = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json"
CASE = ROOT / "stable-64"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    assert not CASE.exists(), "Preserve all existing candidates."
    CASE.mkdir()
    source = SOURCE / "prepared"
    model = json.loads(MODEL.read_bytes())
    target = json.loads((PREVIOUS / "proposal.json").read_bytes())["solution"]
    before = ET.parse(source / "demand.rou.xml").getroot()
    old = {r.get("id"): r for r in before.findall("vehicle")}
    metadata = json.loads((source / "lane-intentions.json").read_bytes())
    old_intent = {r["vehicle_id"]: r for r in metadata["vehicles"]}
    requests = [dict(vehicle_id=i, od_cell=old_intent[i]["od_cell"], requested_depart_s=float(v.get("depart")))
                for i, v in old.items()]
    proposal = propose_stable_od_retiming(requests=requests, cells=model["cells"], target=target)
    assert proposal["changed_vehicles"] == 64 and proposal["l1_cell_change"] == 128
    assert not proposal["initial_requests_changed"] and proposal["vehicle_count"] == 8640
    save(CASE / "proposal.json", proposal)
    after = apply_native_count_retiming(before, proposal["proposals"])
    new = {r.get("id"): r for r in after.findall("vehicle")}
    selected = {r["vehicle_id"]: r for r in proposal["proposals"]}
    assert len(new) == len(old) == 8640 and old.keys() == new.keys()
    for identity, original in old.items():
        check = copy.deepcopy(new[identity])
        if identity not in selected:
            assert ET.tostring(check) == ET.tostring(original), identity
        check.set("depart", original.get("depart"))
        assert ET.tostring(check) == ET.tostring(original), identity
    assert [ET.tostring(r) for r in before if r.tag != "vehicle"] == [ET.tostring(r) for r in after if r.tag != "vehicle"]
    prepared = CASE / "prepared"
    shutil.copytree(source, prepared)
    ET.ElementTree(after).write(prepared / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    new_counts = [0] * len(model["cells"])
    keys = {(c["origin"], c["destination"], c["begin_s"]): i for i, c in enumerate(model["cells"])}
    for row in metadata["vehicles"]:
        identity = row["vehicle_id"]
        depart = float(new[identity].get("depart"))
        native_depart = math.floor(depart*1000+.5)/1000
        edges = new[identity].find("route").get("edges").split()
        cell = keys[edges[0], edges[-1], math.floor(native_depart/900)*900]
        new_counts[cell] += 1
        if identity in selected:
            assert cell == selected[identity]["target_cell"]
            row.update(od_cell=cell, depart_s=depart)
        else:
            assert row == old_intent[identity] and row["od_cell"] == cell
        assert row["field_id"] == old_intent[identity]["field_id"]
    assert new_counts == target
    metadata["mechanism"] += " Same saved OD-period target as the quantile candidate, with only64 existing requests retimed. IDs/routes/stops/fields retained; empirical realization differs."
    save(prepared / "lane-intentions.json", metadata)
    scenario = json.loads((source / "scenario.json").read_bytes())
    scenario.update(demand_sha256=sha(prepared / "demand.rou.xml"), formal_result=False,
        demand_prior="All original8640 IDs/routes/stops/vTypes/fields preserved. Only64 explicit requests cross departure cells to the saved joint128 count vector.",
        time_prior="Deterministic donor empirical ranks, receiver empirical time quantiles, same-OD sorted pairing. No900s shift cap. This differs from joint cell-quantile regeneration.")
    save(prepared / "scenario.json", scenario)
    vector = json.loads((PREVIOUS / "generated/od-vector.json").read_bytes())
    assert vector["integer_counts"] == target and vector["vehicle_count"] == 8640
    vector.update(generation="Same saved22-cell target, stable64 explicit-request retiming. Original model supplies count-coordinate lineage only.",
                  demand_generated_by_original_model=False)
    save(CASE / "od-vector.json", vector)
    fixed = ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv")
    assert all((source / n).read_bytes() == (prepared / n).read_bytes() for n in fixed)
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core"
    implementation = CASE / "implementation"
    implementation.mkdir()
    mapping = []
    for name in ("od_stable_realization.py", "hamburg_departure_probe.py", "route_sensor_matrix.py"):
        original, snapshot = core / name, implementation / name
        shutil.copyfile(original, snapshot)
        assert original.read_bytes() == snapshot.read_bytes()
        mapping.append(dict(original_path=str(original), snapshot_path=str(snapshot), sha256=sha(snapshot),
                            policy="Original source hash retained; archived raw bytes resolve historical provenance after later live-source edits."))
    save(CASE / "source-snapshot-mapping.json", mapping)
    shutil.copyfile(__file__, CASE / "executed-prepare.py")
    bound = [*source.iterdir(), MODEL, PREVIOUS / "proposal.json", PREVIOUS / "generated/od-vector.json",
             Path(__file__), CASE / "executed-prepare.py", CASE / "source-snapshot-mapping.json"]
    bound += [Path(r["original_path"]) for r in mapping] + [Path(r["snapshot_path"]) for r in mapping]
    shifts = [abs(math.floor(float(new[i].get("depart"))*1000+.5)-math.floor(float(old[i].get("depart"))*1000+.5))/1000 for i in selected]
    stats = dict(common_IDs=8640, added_IDs=0, removed_IDs=0, common_request_changed=64,
                 common_native_millisecond_departure_changed=64, common_non_depart_attributes_changed=0,
                 common_route_changed=0, common_stop_changed=0, common_field_intention_changed=0,
                 other8576_vehicle_XML_exact=True, other8576_intent_rows_exact=True,
                 vtypes_and_all_nonvehicle_XML_exact=True, native_max_absolute_shift_s=max(shifts),
                 native_median_absolute_shift_s=float(np.median(shifts)))
    save(CASE / "scope-proof.json", dict(status="pass", native_runs=0, formal_result=False, N=8640,
         actual_changes=64, demand_generation_changes=stats, unchanged_requests=8576,
         original_driver_scope=scenario["junction_body_hold_nodes"], target_counts_exact=True,
         target_vector_source=str(PREVIOUS / "proposal.json"), no_departure_shift_cap=True,
         source_hashes={str(p.resolve()): sha(p) for p in bound},
         prepared_hashes={p.name: sha(p) for p in prepared.iterdir()}, source_snapshot_mapping=mapping,
         claim_boundary="Same OD-period integer vector, different empirical realization from cell-quantile resampling. All IDs/routes/stops/field intentions retained. Prior C/q predictions do not transfer as verified native response."))
    save(CASE / "generation-audit.json", dict(status="pass", native_runs=0, formal_result=False,
         N=8640, demand_generation_changes=stats, changes=proposal["proposals"],
         original_OD_totals=proposal["od_totals"], first84_departure_cells_frozen=True,
         all1953_initial_requests_XML_unchanged=all(ET.tostring(old[i]) == ET.tostring(new[i]) for i in old if float(old[i].get("depart")) < 3600),
         source_model_sha256=sha(MODEL), source_target_sha256=sha(PREVIOUS / "proposal.json")))
    print(json.dumps(dict(status="prepared", native_runs=0, case=str(CASE), changes=64, stats=stats), ensure_ascii=False))


if __name__ == "__main__":
    main()
