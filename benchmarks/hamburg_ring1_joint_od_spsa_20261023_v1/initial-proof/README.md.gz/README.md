# selected初值复用证明

参考为 `hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation`，主窗MAE为5.09230769。原模型字节未重建，SHA-256为 `256472ed0c48f759787e3b76dd58317a4efb0cc965ca27e45ede250cbe244c7f`。

已用原 `write_hamburg_od_demand`、该模型和selected vector的294项values，生成本目录的需求、意向和向量。三份文件与selected原始字节完全相同：

| 文件 | SHA-256 |
|---|---|
| demand.rou.xml | `7f521b4614df86f7c9968969b30bbbb2aad81c980e04407b17795acd4df79440` |
| lane-intentions.json | `c7014d5659ffc75655e4a50c93548ff54e245574a3de60cc0c1accedc0c52f39` |
| od-vector.json | `de93ac09f4564481e0febe3644cfa8c2c88123eb59eb040e474bab044d29b893` |

从原生E1重算130项主窗：SSE6898、TAE662、MAE5.09230769、最大误差27。40项派生站点逐项核平，站点MAE14.8、最大误差48。52项初始化逐项核平，TAE82；全部182项TAE744。重算文件保存在本目录，40项合计未增加独立损失。

实际设置为Libsumo、SUMO/TraCI/sumolib/libsumo均1.27.1、步长0.1秒、seed104、终点14400秒。四个body节点为 `14398547/205069138/18653534/LSA104_part0`。六份原生输入的当前字节、原始input hash和native snapshot hash逐项一致。

Python可执行文件、SUMO binary及Libsumo `.pyd` 均与原execution相同。SUMO SHA为 `e39d9f60e2494570bc826d29ac0a22c3fe311c2b222469cb5063591b4574d05c`，`.pyd` SHA为 `b7fec284bf60e07fd6b10d2b58547530f13a83e34ff39aa0facb20a4bad6036e`。

`proof.json`记录原执行包382个文件的完整hash清单及证明执行时的工作区对照。初次检查时9个原生、生成与统计相关模块raw SHA均相同，优化器 `spsa.py` 单列为差异；该优化器未由本次固定向量核对执行。随后复用助手的兼容修复及workflow变更由新API调用证据单列，未改写原执行包。

## 真实布局与复用前提

原execution实际在 `probe-minus1/execution.json`，implementation在同一父目录的 `implementation/`。原monitor使用Libsumo完成语义：command与request完全相同，`native_returncode=None`，`library_completed=True`。没有创建旧布局的execution记录。

旧prepared初值与selected在cell125、146不同。后续starting prepared须保留同一模型和输入字节，仅在声明的 `initial-od-vector.json` 中使用selected values。proposal须与cached vector一致，六份输入、四个body节点、原生设置及实现仍需核验。调用方若选择其他backend，应在开始测量前拒绝与缓存backend不一致的复用。

兼容后的 `reuse_hamburg_od_initial` 保持原三个参数。已对实际新的joint prepared、本目录proposal和selected缓存执行一次只读API核验，返回loss6898和相同全部指标，见 `reuse-api-proof.json`。旧TraCI布局和新parent布局均有聚焦测试，错误完成语义、版本、库hash、实现及初值会被拒绝。

本目录的pass表示生成字节、来源及重算损失闭合。原运行仍为7辆未入网、14辆在途、`healthy=false`，无collision/teleport/discard。它不是新原生运行、独立验证或零残差完成证明。源文件未改，未制造旧cache metadata。
