"""Audit an already regenerated selected reference without running SUMO."""

import ast
from collections import defaultdict
from importlib.metadata import version
import json
import hashlib
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import libsumo
from libsumo import _libsumo
import sumo

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
from astra_sumo.core.hamburg_readme_results import STATIONS


ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
CASE = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1"
PREPARED = CASE / "prepared"
REFERENCE = CASE / "probe-minus1/evaluation"
NATIVE = REFERENCE / "native"
EXECUTION = REFERENCE.parent / "execution.json"
IMPLEMENTATION = REFERENCE.parent / "implementation"
CORE = ROOT / "plugins/astra-sumo/src/astra_sumo/core"
EXPECTED_MODEL_SHA = "256472ed0c48f759787e3b76dd58317a4efb0cc965ca27e45ede250cbe244c7f"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def function_ast(path, name):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return ast.dump(next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


execution = load(EXECUTION)
run, monitor, request = [load(NATIVE / name) for name in ["run.json", "stall-monitor.json", "native-request.json"]]
original_eval = load(REFERENCE / "evaluation.json")
source_paths = [EXECUTION, REFERENCE.parent / "measure_probe.snapshot.py", PREPARED / "od-model.json",
    PREPARED / "initial-od-vector.json", PREPARED / "initialization-counts.csv", PREPARED / "scenario.json"]
source_paths += [REFERENCE / name for name in ["demand.rou.xml", "lane-intentions.json", "od-vector.json",
    "evaluation.json", "station-comparison.csv", "all182-comparison.csv"]]
source_paths += [NATIVE / name for name in ["run.json", "command.json", "native-request.json", "stall-monitor.json",
    "network.net.xml", "demand.rou.xml", "source-e1.add.xml", "expected-counts.csv", "signal-programs.add.xml",
    "lane-intentions.json", "field-counts.xml", "field-comparison.csv", "summary.xml", "tripinfo.xml", "collisions.xml"]]
source_paths += [Path(path) for path in execution["source_hashes"]]
source_hashes = [dict(path=str(path.resolve()), sha256=sha(path)) for path in dict.fromkeys(source_paths)]
assert all(sha(Path(path)) == digest for path, digest in execution["source_hashes"].items())
assert sha(REFERENCE.parent / "measure_probe.snapshot.py") == execution["script_sha256"]
assert execution["completed"] and execution["new_native_run"] and execution["backend"] == "libsumo"
assert sha(PREPARED / "od-model.json") == EXPECTED_MODEL_SHA
vector = load(REFERENCE / "od-vector.json")
assert vector["source_model_sha256"] == EXPECTED_MODEL_SHA
assert len(vector["values"]) == len(vector["integer_counts"]) == 294
assert vector["integer_counts"] == [math.floor(v + .5) for v in vector["values"]]
assert sum(vector["integer_counts"]) == vector["vehicle_count"] == 8640
generated_matches = {}
for name in ["demand.rou.xml", "lane-intentions.json", "od-vector.json"]:
    generated_matches[name] = dict(generated_sha256=sha(OUT / name), selected_sha256=sha(REFERENCE / name),
                                   rawbytes_identical=(OUT / name).read_bytes() == (REFERENCE / name).read_bytes())
assert all(row["rawbytes_identical"] for row in generated_matches.values())
initial = load(PREPARED / "initial-od-vector.json")
initial_differences = [i for i, (a, b) in enumerate(zip(initial["values"], vector["values"])) if a != b]
assert initial_differences == [125, 146]
pairs = [(PREPARED / "network.net.xml", "network.net.xml"), (OUT / "demand.rou.xml", "demand.rou.xml"),
    (PREPARED / "field-loops.add.xml", "source-e1.add.xml"), (PREPARED / "expected-counts.csv", "expected-counts.csv"),
    (PREPARED / "control.add.xml", "signal-programs.add.xml"), (OUT / "lane-intentions.json", "lane-intentions.json")]
assert len(run["inputs"]) == len(run["snapshots"]) == 6
input_bindings = []
for (path, name), recorded, snapshot in zip(pairs, run["inputs"], run["snapshots"]):
    digest = sha(path)
    assert digest == recorded["sha256"] == snapshot["sha256"] == sha(NATIVE / name)
    input_bindings.append(dict(current_input=str(path), native_snapshot=str(NATIVE / name), sha256=digest,
                               recorded_source=recorded, recorded_snapshot=snapshot))
body_nodes = list(_body_hold_nodes(PREPARED))
assert body_nodes == ["14398547", "205069138", "18653534", "LSA104_part0"]
expected_settings = dict(seed=104, step_length_s=.1, end_s=14400, backend="libsumo",
    driver_treatment="local_observation_and_junction_body_hold", signal_treatment="declared_additional_programs",
    measurement_attribute="nVehContrib", junction_body_hold_nodes=body_nodes, state_times_s=[])
assert all(run[name] == value for name, value in expected_settings.items())
assert run["native_status"] == "pass" and run["native_returncode"] == 0 and run["observer_complete"]
assert run["expected_field_bins"] == 130 and run["missing_field_bins"] == 0 and run["inputs_unchanged"]
assert load(NATIVE / "command.json")["status"] == "pass"
assert request["backend"] == "libsumo" and request["end_s"] == 14400 and request["all_stopped_timeout_s"] == 300
assert request.get("monitor_interval_s") is None and request["junction_body_hold"] is True
assert request["junction_body_hold_nodes"] == body_nodes
for flag, expected in [("--seed", "104"), ("--step-length", "0.1"), ("--end", "14400"), ("--precision", "12"),
    ("--time-to-teleport", "-1"), ("--collision.check-junctions", "true"),
    ("--tripinfo-output.write-unfinished", "true"), ("--vehroute-output.exit-times", "true")]:
    command = request["command"]
    assert command.count(flag) == 1 and command[command.index(flag) + 1] == expected
assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400
assert monitor["command"] == request["command"] and monitor["backend"] == "libsumo"
assert monitor["native_returncode"] is None and monitor["library_completed"] is True
assert monitor["native_version"] == [22, "SUMO 1.27.1"]
assert Path(sys.executable).resolve() == (ROOT / ".venv/Scripts/python.exe").resolve()
binary = Path(sumo.__file__).parent / "bin/sumo.exe"
library = Path(_libsumo.__file__).resolve()
assert library.is_relative_to(Path(sys.prefix).resolve())
assert sha(Path(sys.executable)) == execution["python_sha256"]
assert sha(binary) == execution["sumo_sha256"] == sha(Path(request["command"][0]))
assert sha(library) == execution["libsumo_sha256"] == monitor["native_library"]["sha256"]
runtime_versions = {name: version(name) for name in ["eclipse-sumo", "sumolib", "traci", "libsumo"]}
assert runtime_versions == execution["versions"] == {name: "1.27.1" for name in runtime_versions}
assert version("numpy") == execution["numpy_version"]
frozen_manifest = []
current_package_differences = []
for relative, digest in execution["implementation_sha256"].items():
    relative = relative.replace("\\", "/")
    frozen = IMPLEMENTATION / relative
    assert sha(frozen) == digest
    current = ROOT / "plugins/astra-sumo/src" / relative
    matches = current.is_file() and sha(current) == digest
    frozen_manifest.append(dict(path=str(frozen), sha256=digest, current_package_raw_sha_matches=matches,
                                current_package_sha256=sha(current) if current.is_file() else None))
    if not matches:
        current_package_differences.append(relative)
native_modules = ["artifact_io.py", "candidate_contracts.py", "command_runner.py", "detector_demand.py",
    "detector_demand_replay.py", "lane_section_hold.py", "simulation_stall.py", "hamburg_od_spsa.py", "hamburg_readme_results.py"]
native_implementation = []
for name in native_modules:
    current, frozen = CORE / name, IMPLEMENTATION / "astra_sumo/core" / name
    assert sha(current) == sha(frozen)
    native_implementation.append(dict(name=name, current_path=str(current), frozen_path=str(frozen), sha256=sha(frozen)))
od_functions = ["write_hamburg_od_demand", "measure_hamburg_od", "summarize_hamburg_od_measurement", "_body_hold_nodes"]
assert all(function_ast(CORE / "hamburg_od_spsa.py", name) == function_ast(IMPLEMENTATION / "astra_sumo/core/hamburg_od_spsa.py", name)
           for name in od_functions)
expected, initialization = [read_csv_rows(PREPARED / name) for name in ["expected-counts.csv", "initialization-counts.csv"]]
main_rows = audit_expected_to_e1_strict(expected, NATIVE / "field-counts.xml", count_attribute="nVehContrib")
init_rows = audit_expected_to_e1_strict(initialization, NATIVE / "field-counts.xml", count_attribute="nVehContrib")
assert len(main_rows) == 130 and len(init_rows) == 52
assert all(row["measured_nVehContrib"] is not None for row in main_rows + init_rows)
groups = defaultdict(list)
for metadata, row in zip(expected, main_rows, strict=True):
    for station, (node, assets) in STATIONS.items():
        if metadata["node_id"] == node and metadata["asset_id"] in assets:
            groups[station, float(row["begin"]), float(row["end"])].append(row)
assert len(groups) == 40 and all(len(rows) == len(STATIONS[key[0]][1]) for key, rows in groups.items())
stations = [dict(station_stream_id=station, begin=begin, end=end,
    expected_total=sum(int(r["expected_total"]) for r in rows),
    measured_nVehContrib=sum(int(r["measured_nVehContrib"]) for r in rows),
    residual=sum(int(r["diff_nVehContrib_minus_expected"]) for r in rows), independent_evidence=False)
    for (station, begin, end), rows in sorted(groups.items())]
source_stations = {(r["station_stream_id"], float(r["begin"]), float(r["end"])): r
                   for r in read_csv_rows(REFERENCE / "station-comparison.csv")}
assert len(source_stations) == 40
for row in stations:
    old = source_stations[row["station_stream_id"], row["begin"], row["end"]]
    assert all(row[k] == int(old[k]) for k in ["expected_total", "measured_nVehContrib", "residual"])
existing_all182 = {(r["detector_id"], float(r["begin"]), float(r["end"])): r
                   for r in read_csv_rows(REFERENCE / "all182-comparison.csv")}
assert len(existing_all182) == 182
for row in main_rows + init_rows:
    old = existing_all182[row["detector_id"], float(row["begin"]), float(row["end"])]
    assert all(int(row[k]) == int(old[k]) for k in ["expected_total", "measured_nVehContrib", "diff_nVehContrib_minus_expected"])
residuals = [int(row["diff_nVehContrib_minus_expected"]) for row in main_rows]
init_residuals = [int(row["diff_nVehContrib_minus_expected"]) for row in init_rows]
final = ET.parse(NATIVE / "summary.xml").getroot()[-1]
completion = {name: int(final.get(name, "0")) for name in ["loaded", "inserted", "arrived", "running", "waiting", "teleports", "collisions", "discarded"]}
assert completion == run["completion"] == original_eval["completion"]
safe = not any(completion[name] for name in ["collisions", "teleports", "discarded"])
assert safe and not ET.parse(NATIVE / "collisions.xml").getroot().findall("collision")
evaluation = dict(loss=sum(r * r for r in residuals), MAE=sum(map(abs, residuals)) / 130,
    max_abs_error=max(map(abs, residuals)), healthy=run["healthy"],
    station_MAE=sum(abs(r["residual"]) for r in stations) / 40,
    station_max_abs_error=max(abs(r["residual"]) for r in stations), completion=completion,
    exact_count_fit=run["healthy"] and not any(residuals), count_source="Native E1 nVehContrib only",
    field_rows=130, derived_station_rows=40)
assert evaluation == original_eval and evaluation["loss"] == 6898
assert sum(map(abs, residuals)) == 662 and sum(map(abs, init_residuals)) == 82
assert len(ET.parse(OUT / "demand.rou.xml").getroot().findall("vehicle")) == 8640
for name, rows in [("field130-recomputed.csv", main_rows), ("initialization52-recomputed.csv", init_rows), ("station40-recomputed.csv", stations)]:
    write_csv(OUT / name, rows, list(rows[0]))
save("evaluation-recomputed.json", evaluation)
proof = dict(status="pass", reusable_as_same_declared_initial_reference=True,
    reference_evaluation=str(REFERENCE), initial_values_source=str(REFERENCE / "od-vector.json"),
    model=dict(path=str(PREPARED / "od-model.json"), sha256=EXPECTED_MODEL_SHA, rebuilt=False),
    generation=dict(function="astra_sumo.core.hamburg_od_spsa.write_hamburg_od_demand",
        values="Selected vector values, not prepared initial-od-vector.json", byte_checks=generated_matches,
        declared_prepared_initial_differs_at_cells=initial_differences, new_native_run=False),
    actual_execution_layout=dict(execution=str(EXECUTION), implementation=str(IMPLEMENTATION),
        old_layout_metadata_created=False, legacy_reuse_helper_invoked=False),
    native_settings=expected_settings, monitor_libsumo_completion=dict(native_returncode=None, library_completed=True,
        command_identical_to_request=True, simulation_time_s=14400), six_native_input_bindings=input_bindings,
    runtime=dict(python=sys.version, executable=sys.executable, python_sha256=sha(Path(sys.executable)),
        versions=runtime_versions, numpy_version=version("numpy"), sumo_binary=str(binary), sumo_sha256=sha(binary),
        libsumo_version=libsumo.__version__, native_library=str(library), libsumo_sha256=sha(library)),
    native_implementation=native_implementation, all_recorded_implementation_files=frozen_manifest,
    recorded_implementation_file_count=len(frozen_manifest), current_package_differences=current_package_differences,
    implementation_scope="All recorded snapshots verify. Nine native, generator and metric modules have identical current raw SHA. Changed SPSA optimizer orchestration is not executed by this fixed-vector proof.",
    recomputed_rows_match_existing=dict(all_130_fields=True, all_40_derived_stations=True, all_52_initialization=True),
    proof_procedure_sha256=sha(Path(__file__)),
    OD_functions_AST_identical=od_functions, evaluation=evaluation,
    main_TAE=662, initialization_rows=52, initialization_TAE=82, all182_TAE=744,
    safe=safe, unfinished=completion["waiting"] + completion["running"],
    original_reference_healthy=run["healthy"], source_hashes=source_hashes,
    source_inputs_unchanged=all(sha(Path(row["path"])) == row["sha256"] for row in source_hashes),
    claim_boundary="Proof of regenerated input bytes, existing native provenance and freshly recomputed loss only. No simulation was run. The selected reference remains unfinished and healthy=false; no field truth, independent validation, new cache metadata, or zero-fit completion is claimed.")
assert proof["source_inputs_unchanged"]
save("proof.json", proof)
print(json.dumps({key: proof[key] for key in ["status", "main_TAE", "all182_TAE", "safe", "unfinished", "recorded_implementation_file_count", "current_package_differences", "source_inputs_unchanged"]}, indent=2))
