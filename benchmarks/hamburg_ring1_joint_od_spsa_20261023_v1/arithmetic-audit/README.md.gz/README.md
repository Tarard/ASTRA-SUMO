# 已完成SPSA迭代的独立算术核验

本目录只读运行记录，不启动SUMO、不轮询进度，也不修改run。根任务通知第k轮完整结束后，显式指定k：

```powershell
.venv/Scripts/python.exe outputs/hamburg-joint-od-spsa-20261023-v1/arithmetic-audit/audit.py --iteration 1
```

工具读取1至k轮已完成记录，重建seed104的伯努利序列，核对θ连续性、ck、两侧投影、梯度、初始及持续a、ak和nextθ。公式使用声明的通用增益，不把某次已写出的SSE当作验证基准。

每侧SSE都从完整原生field-counts.xml独立重算，使用相同130项真实计数CSV。要求208项原生观测完整，缺测不补零。另核对固定256472模型的原始SHA、向量的half-up取整、实际294项车辆数，以及每辆车对应分位数模板、路线、停靠、请求时刻和字段意向。原生源文件与snapshot哈希也要对应。

数学浮点比较容差为rtol=atol=1e-12；整数向量、原生SSE及生成结果要求准确对应，避免浮点容差掩盖取整边界变化。输出`iteration-000k-audit.json`，已有核验记录不会被覆盖。工具不会读取k+1或等待新文件。

纯离线已知例子与篡改拒绝检查：

```powershell
.venv/Scripts/python.exe -m pytest outputs/hamburg-joint-od-spsa-20261023-v1/arithmetic-audit/test_audit.py -q
```

目前三个检查通过：已知首步增益与更新、错误原生SSE拒绝、错误nextθ拒绝。这只验证核验工具，不代替未完成的原生测量，也不证明优化收敛或真实OD。
