"""Independently check one declared completed SPSA iteration and its prefix; no SUMO."""

import argparse
from collections import Counter
import csv
import hashlib
from importlib.metadata import version
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
MODEL_SHA = "256472ed0c48f759787e3b76dd58317a4efb0cc965ca27e45ede250cbe244c7f"
EXPECTED_SHA = "a648d6ebc0d93920210662ced8f8e6ef9c46a04079a31a8faa1b7cea9232bb02"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def equal(actual, expected, label):
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    assert a.shape == b.shape and np.all(np.isfinite(a)) and np.all(np.isfinite(b)), label
    assert np.allclose(a, b, rtol=1e-12, atol=1e-12), label


def check_row(row, theta, delta, settings, gain, native_losses):
    k = row["iteration"]
    equal(row["theta"], theta, "theta chain mismatch")
    assert np.array_equal(row["delta"], delta), "seed sequence mismatch"
    ck = settings["c"] / k ** settings["gamma"]
    equal(row["ck"], ck, "ck mismatch")
    plus, minus = np.maximum(theta + ck*delta, 0), np.maximum(theta - ck*delta, 0)
    equal(row["plus"], plus, "projected plus mismatch")
    equal(row["minus"], minus, "projected minus mismatch")
    for actual, expected in ((row["plus"], plus), (row["minus"], minus)):
        assert [math.floor(v+.5) for v in actual] == [math.floor(v+.5) for v in expected], "projected integer mismatch"
    assert (row["loss_plus"], row["loss_minus"]) == tuple(native_losses), "raw native SSE mismatch"
    gradient = (native_losses[0] - native_losses[1]) / (2*ck) / delta
    equal(row["gradient"], gradient, "gradient mismatch")
    if gain is None:
        magnitude = max(map(abs, gradient))
        assert magnitude > 0, "a complete update cannot identify its gain from zero first gradient"
        gain = settings["initial_step"] * (settings["A"]+1) ** settings["alpha"] / magnitude
    ak = gain / (settings["A"]+k) ** settings["alpha"]
    equal(row["a"], gain, "persistent a mismatch")
    equal(row["ak"], ak, "ak mismatch")
    following = np.maximum(theta-ak*gradient, 0)
    equal(row["next_theta"], following, "next theta mismatch")
    assert [math.floor(v+.5) for v in row["next_theta"]] == [math.floor(v+.5) for v in following], "next integer mismatch"
    return gain, following


def canonical(row):
    return ET.canonicalize(ET.tostring(row, encoding="unicode"), strip_text=True)


def check_native(job, prepared, vector, model):
    native = job / "native"
    run, monitor = read(native / "run.json"), read(native / "stall-monitor.json")
    assert run["native_status"] == "pass" and run["observer_complete"] and run["missing_field_bins"] == 0
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400
    assert (run["seed"], run["step_length_s"], run["end_s"], run["backend"]) == (104, .1, 14400, "libsumo")
    metadata = read(job / "od-vector.json")
    assert np.array_equal(metadata["values"], vector)
    integer = [math.floor(float(v)+.5) for v in vector]
    assert metadata["integer_counts"] == integer and metadata["vehicle_count"] == sum(integer)
    assert metadata["source_model_sha256"] == MODEL_SHA == sha(prepared / "od-model.json")
    demand = ET.parse(job / "demand.rou.xml").getroot()
    requests = demand.findall("vehicle")
    vehicles = {v.get("id"): v for v in requests}
    intentions = read(job / "lane-intentions.json")["vehicles"]
    fields = {r["vehicle_id"]: r for r in intentions}
    assert len(vehicles) == len(requests) == sum(integer) and len(fields) == len(intentions) == len(vehicles)
    expected_ids = set()
    for column, (cell, count) in enumerate(zip(model["cells"], integer, strict=True)):
        templates = cell["templates"]
        positions = (np.arange(len(templates))+.5) / len(templates)
        for index in range(count):
            identity = f"od_{column:04d}_v{index:05d}"
            expected_ids.add(identity)
            actual = vehicles[identity]
            quantile = (index+.5) / count
            template = templates[min(len(templates)-1, int(quantile*len(templates)))]
            source = ET.fromstring(template["vehicle_xml"])
            depart = float(np.interp(quantile, positions, [r["prior_depart_s"] for r in templates]))
            assert actual.get("depart") == f"{depart:.12f}"
            assert {k: v for k, v in actual.attrib.items() if k not in {"id", "depart"}} == {
                k: v for k, v in source.attrib.items() if k not in {"id", "depart"}}
            assert [canonical(c) for c in actual] == [canonical(c) for c in source]
            assert fields[identity]["field_id"] == template["prior_field_intention"] and fields[identity]["od_cell"] == column
    assert expected_ids == vehicles.keys() == fields.keys()
    assert [canonical(x) for x in demand if x.tag != "vehicle"] == [canonical(ET.fromstring(x)) for x in model["type_definitions"]]
    actual_cells = Counter(int(v.get("id").split("_")[1]) for v in requests)
    assert [actual_cells[i] for i in range(294)] == integer
    assert len(run["inputs"]) == len(run["snapshots"]) == 6
    for source, snapshot in zip(run["inputs"], run["snapshots"]):
        assert sha(Path(source["path"])) == source["sha256"] == snapshot["sha256"] == sha(Path(snapshot["path"]))
    assert sha(native / "expected-counts.csv") == sha(prepared / "expected-counts.csv") == EXPECTED_SHA
    counts = {}
    for interval in ET.parse(native / "field-counts.xml").getroot().findall("interval"):
        key = interval.get("id"), float(interval.get("begin")), float(interval.get("end"))
        if key[1] == key[2]:
            continue
        assert key not in counts and key[1] < key[2], "duplicate native E1 interval"
        numeric = float(interval.get("nVehContrib"))
        assert numeric >= 0 and numeric.is_integer()
        counts[key] = int(numeric)
    assert len(counts) == 208, "the complete native observation horizon must be retained"
    with (prepared / "expected-counts.csv").open(encoding="utf-8-sig", newline="") as stream:
        targets = list(csv.DictReader(stream))
    keys = [(r["detector_id"], float(r["begin"]), float(r["end"])) for r in targets]
    assert len(targets) == len(set(keys)) == 130 and set(keys) <= counts.keys(), "missing native main observation"
    residuals = [counts[k] - int(r["expected_total"]) for k, r in zip(keys, targets, strict=True)]
    return {"SSE": sum(r*r for r in residuals), "TAE": sum(map(abs, residuals)), "MAE": sum(map(abs, residuals))/130,
            "requested_vehicles": sum(integer), "zero_cells": sum(v == 0 for v in integer),
            "model_sha256": MODEL_SHA, "source_hashes": [{"path": str(p), "sha256": sha(p)} for p in
                (job / "od-vector.json", job / "demand.rou.xml", job / "lane-intentions.json", native / "field-counts.xml", native / "run.json")]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iteration", type=int, required=True, help="One iteration already reported complete by the parent run.")
    parser.add_argument("--run-dir", type=Path, default=STUDY / "run")
    args = parser.parse_args()
    run = args.run_dir.resolve(strict=True)
    settings = read(run / "settings.json")
    assert 1 <= args.iteration <= settings["iterations"]
    prepared = STUDY / "prepared"
    assert sha(prepared / "od-model.json") == MODEL_SHA and sha(prepared / "expected-counts.csv") == EXPECTED_SHA
    model = read(prepared / "od-model.json")
    theta = np.asarray(read(prepared / "initial-od-vector.json")["values"], dtype=float)
    assert theta.shape == (294,) and np.all(theta >= 0)
    rng, gain, reports = np.random.default_rng(settings["seed"]), settings["a"], []
    for k in range(1, args.iteration+1):
        history = run / f"iteration-{k:04d}.json"
        row = read(history)
        assert row["iteration"] == k
        delta = rng.choice((-1, 1), size=294)
        plus = check_native(run / f"iteration-{k:04d}-plus", prepared, np.asarray(row["plus"]), model)
        minus = check_native(run / f"iteration-{k:04d}-minus", prepared, np.asarray(row["minus"]), model)
        gain, following = check_row(row, theta, delta, settings, gain, (plus["SSE"], minus["SSE"]))
        ck = settings["c"] / k**settings["gamma"]
        reports.append({"iteration": k, "status": "pass", "a": gain, "ak": row["ak"], "ck": ck,
                        "native_plus": plus, "native_minus": minus,
                        "strictly_clipped_plus": np.flatnonzero(theta+ck*delta < 0).tolist(),
                        "strictly_clipped_minus": np.flatnonzero(theta-ck*delta < 0).tolist(),
                        "history_sha256": sha(history), "next_integer_counts": [math.floor(v+.5) for v in following]})
        theta = following
    execution = run.with_name(run.name + "-execution") / "execution.json"
    assert read(execution)["numpy_version"] == version("numpy")
    result = {"status": "pass", "formal_result": False, "new_native_runs": 0,
              "requested_complete_iteration": args.iteration, "verified_prefix": reports,
              "source_model_sha256": MODEL_SHA, "expected_counts_sha256": EXPECTED_SHA,
              "settings_sha256": sha(run / "settings.json"), "execution_sha256": sha(execution),
              "auditor_sha256": sha(Path(__file__)),
              "tolerance": {"formula_rtol": 1e-12, "formula_atol": 1e-12, "native_SSE_and_integer_vectors": "exact"},
              "claim_boundary": "Independent arithmetic and fixed-generator/source correspondence for declared complete iterations only. Native SSE is recomputed from 130 complete observations. No polling, native execution, convergence or true-OD claim."}
    target = ROOT / f"iteration-{args.iteration:04d}-audit.json"
    assert not target.exists(), "Preserve existing audit evidence; do not overwrite it."
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "pass", "iteration": args.iteration, "a": gain,
                      "loss_plus": plus["SSE"], "loss_minus": minus["SSE"], "audit": str(target)}, indent=2))


if __name__ == "__main__":
    main()
