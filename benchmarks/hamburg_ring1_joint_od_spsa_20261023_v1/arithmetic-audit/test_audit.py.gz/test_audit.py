"""Known arithmetic and tampered native losses for the independent checker."""

import copy
import importlib.util
from pathlib import Path

import numpy as np
import pytest

spec = importlib.util.spec_from_file_location("arithmetic_audit", Path(__file__).with_name("audit.py"))
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def known_row():
    return {"iteration": 1, "theta": [4, 6], "delta": [1, 1], "plus": [5, 7], "minus": [3, 5],
            "loss_plus": 74, "loss_minus": 34, "a": .05, "ak": .05, "ck": 1,
            "gradient": [20, 20], "next_theta": [3, 5]}


def test_known_first_gain_and_update():
    settings = {"c": 1, "alpha": .602, "gamma": .101, "A": 0, "a": None, "initial_step": 1}
    gain, theta = audit.check_row(known_row(), np.array([4., 6.]), np.array([1, 1]), settings, None, (74, 34))
    assert gain == .05 and np.array_equal(theta, [3, 5])


@pytest.mark.parametrize("native_losses,wrong_next", [((75, 34), False), ((74, 34), True)])
def test_wrong_native_sse_or_update_is_rejected(native_losses, wrong_next):
    row = copy.deepcopy(known_row())
    if wrong_next:
        row["next_theta"] = [4, 6]
    settings = {"c": 1, "alpha": .602, "gamma": .101, "A": 0, "a": None, "initial_step": 1}
    with pytest.raises(AssertionError):
        audit.check_row(row, np.array([4., 6.]), np.array([1, 1]), settings, None, native_losses)
