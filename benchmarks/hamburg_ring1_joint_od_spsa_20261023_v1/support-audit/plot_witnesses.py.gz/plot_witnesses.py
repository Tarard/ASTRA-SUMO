"""Draw source road geometry; this is not a simulated vehicle trajectory."""

import json
from pathlib import Path
import xml.etree.ElementTree as ET

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402


OUT = Path(__file__).resolve().parent


def points(text):
    return np.array([[float(v) for v in p.split(",")[:2]] for p in text.split()])


def main():
    net = ET.parse(OUT.parent / "prepared/network.net.xml").getroot()
    edges = {e.get("id"): e for e in net.findall("edge") if not e.get("function")}
    shapes = {k: points(e.get("shape") or e.find("lane").get("shape")) for k, e in edges.items()}
    lanes = {lane.get("id"): lane for lane in net.iter("lane")}
    witnesses = json.loads((OUT / "multi-field-witnesses.json").read_bytes())
    report = json.loads((OUT / "report.json").read_bytes())
    all_points = np.concatenate(list(shapes.values()))
    lower, upper = all_points.min(axis=0) - 35, all_points.max(axis=0) + 35
    with plt.rc_context({"font.size": 9, "svg.fonttype": "none", "figure.facecolor": "white"}):
        fig, axs = plt.subplots(1, 2, figsize=(13, 5), layout="constrained")
        for ax, witness in zip(axs, witnesses, strict=True):
            for shape in shapes.values():
                ax.plot(shape[:, 0], shape[:, 1], color="#d0d0d0", linewidth=.6, zorder=0)
            for edge in witness["edges"]:
                shape = shapes[edge]
                ax.plot(shape[:, 0], shape[:, 1], color="#0072b2", linewidth=2.4, zorder=2)
            for field in report["detectors"]:
                if field["id"] not in witness["fields"]:
                    continue
                shape = points(lanes[field["lane_id"]].get("shape"))
                segment = np.linalg.norm(np.diff(shape, axis=0), axis=1)
                distance = np.r_[0, np.cumsum(segment)]
                offset = field["pos"] / field["length_m"] * distance[-1]
                xy = np.array([np.interp(offset, distance, shape[:, dimension]) for dimension in (0, 1)])
                label = "119 Z12: lane 0" if "0119" in field["id"] else "535 Z4: lane 5"
                ax.scatter(*xy, s=45, marker="s", facecolor="#d55e00", edgecolor="black", linewidth=.5, zorder=4)
                ax.annotate(label, xy, xytext=(-20, 18 if "0119" in field["id"] else -30), textcoords="offset points",
                            ha="right", arrowprops={"arrowstyle": "-", "color": "black"}, zorder=5)
            for edge, endpoint, marker, label, shift in [(witness["origin"], 0, "o", "Entry", (10, -20)),
                    (witness["destination"], -1, "^", "Exit", (-10, -20))]:
                xy = shapes[edge][endpoint]
                ax.scatter(*xy, s=65, marker=marker, facecolor="white", edgecolor="black", zorder=5)
                ax.annotate(label, xy, xytext=shift, textcoords="offset points",
                            ha="right" if label == "Exit" else "left", zorder=5)
            ax.plot([lower[0] + 45, lower[0] + 245], [lower[1] + 55] * 2, color="black", linewidth=2)
            ax.text(lower[0] + 145, lower[1] + 75, "200 m", ha="center")
            ax.set(xlim=(lower[0], upper[0]), ylim=(lower[1], upper[1]), aspect="equal",
                   xlabel="SUMO x (m)", ylabel="SUMO y (m)",
                   title=f"{witness['id']}: {witness['origin']} to {witness['destination']}\n"
                         f"{len(witness['edges'])} roads; {witness['ordinary_road_length_m']:.1f} m ordinary-road length")
        fig.suptitle("Two permitted 119 to 535 routes outside the fixed 21-OD support\n"
                     "Source road geometry; square = detector, circle = entry, triangle = exit. No native trip or demand inferred.")
        fig.savefig(OUT / "witnesses.png", dpi=180, facecolor="white")
        fig.savefig(OUT / "witnesses.svg", facecolor="white")
        plt.close(fig)


if __name__ == "__main__":
    main()
