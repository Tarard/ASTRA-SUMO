"""Read fixed Hamburg support and retain two static, permitted route witnesses."""

from collections import Counter, defaultdict
import csv
import gzip
from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.demand_route_pool import (
    boundary_route_pool,
    ideal_lane_profiles,
    junction_visit_audit,
)
from astra_sumo.core.detector_demand import read_declared_boundaries, read_net
from astra_sumo.core.local_network_conversion import loaded_turn_permissions
from astra_sumo.core.osm_access import _permission_set


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PREPARED = OUT.parent / "prepared"
SELECTED = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation"
COMPACT = SELECTED.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz"
BOUNDARIES = ROOT / "benchmarks/hamburg_ring1_munich_corridor_20261022_v1/boundaries.json"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write_json(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(name, rows):
    with (OUT / name).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                             for k, v in row.items()})


def main():
    core = ROOT / "plugins/astra-sumo/src/astra_sumo/core"
    inputs = [PREPARED / "od-model.json", PREPARED / "network.net.xml", PREPARED / "field-loops.add.xml",
              SELECTED / "demand.rou.xml", SELECTED / "lane-intentions.json", SELECTED / "od-vector.json",
              SELECTED / "native/field-counts.xml", SELECTED / "native/instant-e1.xml",
              SELECTED / "native/tripinfo.xml", COMPACT, BOUNDARIES]
    inputs += [core / name for name in ["detector_demand.py", "demand_route_pool.py", "osm_access.py",
                                       "local_network_conversion.py", "hamburg_od_spsa.py"]]
    hashes = {str(p): digest(p) for p in inputs}
    model = json.loads((PREPARED / "od-model.json").read_bytes())
    assert hashes[str(PREPARED / "od-model.json")] == "256472ed0c48f759787e3b76dd58317a4efb0cc965ca27e45ede250cbe244c7f"
    net = ET.parse(PREPARED / "network.net.xml").getroot()
    assert digest(PREPARED / "network.net.xml") == model["source_network_sha256"]
    edges, connections = read_net(PREPARED / "network.net.xml")
    version = net.get("version")
    lane_elements = {lane.get("id"): lane for lane in net.iter("lane")}
    lanes = defaultdict(list)
    for edge in net.findall("edge"):
        if edge.get("id") not in edges:
            continue
        for lane in edge.findall("lane"):
            if "passenger" not in _permission_set(lane.attrib, network_version=version):
                continue
            lanes[edge.get("id")].append({"id": lane.get("id"), "index": int(lane.get("index")),
                "change_left": sorted(_permission_set({"allow": lane.get("changeLeft", "all")}, network_version=version)),
                "change_right": sorted(_permission_set({"allow": lane.get("changeRight", "all")}, network_version=version))})
    loaded = loaded_turn_permissions(net)
    lane_connections = defaultdict(set)
    for (a, la, b, lb), modes in loaded.items():
        if "passenger" in modes:
            lane_connections[a, la, b].add(lb)
    fields = []
    for index, detector in enumerate(ET.parse(PREPARED / "field-loops.add.xml").getroot()):
        lane = lane_elements[detector.get("lane")]
        fields.append({"field_index": index, "id": detector.get("id"), "lane_id": lane.get("id"),
                       "edge_id": lane.get("id").rsplit("_", 1)[0], "pos": float(detector.get("pos")),
                       "length_m": float(lane.get("length")),
                       "end_margin_m": float(lane.get("length")) - float(detector.get("pos"))})
    field_roads = {f["edge_id"] for f in fields}

    def signature(profile):
        return [f["id"] for f in fields if profile["field_mask"] & (1 << f["field_index"])]

    templates = Counter()
    template_stop_counts = Counter()
    template_intents = defaultdict(Counter)
    for cell in model["cells"]:
        for template in cell["templates"]:
            vehicle = ET.fromstring(template["vehicle_xml"])
            template_stop_counts[len(vehicle.findall("stop"))] += 1
            route = tuple(vehicle.find("route").get("edges").split())
            assert (route[0], route[-1]) == (cell["origin"], cell["destination"])
            templates[route] += 1
            template_intents[route][template["prior_field_intention"]] += 1
    assert len(model["cells"]) == 294 and sum(templates.values()) == 8640
    pairs = sorted({(c["origin"], c["destination"]) for c in model["cells"]})
    assert len(pairs) == 21
    profiles_by_route = {route: ideal_lane_profiles(route, lanes, lane_connections, fields) for route in templates}
    assert max(p["field_mask"].bit_count() for profiles in profiles_by_route.values() for p in profiles) == 1
    route_ids = {route: f"template-{i:02d}" for i, route in enumerate(sorted(templates))}
    template_rows = [{"route_id": route_ids[route], "origin": route[0], "destination": route[-1],
        "model_templates": templates[route], "edge_count": len(route), "edges": list(route),
        "detector_roads": sorted(set(route) & field_roads), "intended_fields": dict(template_intents[route]),
        "static_exit_lane_field_sets": [signature(p) for p in profiles_by_route[route]]} for route in sorted(templates)]
    write_json("template-routes.json", template_rows)

    with gzip.open(COMPACT, "rt", encoding="utf-8") as handle:
        passage_data = json.load(handle)
    assert passage_data["reconciled"] and passage_data["measurement_attribute"] == "nVehContrib"
    assert passage_data["inputs_unchanged"] and not passage_data["outside_periodic_intervals"]
    for source in passage_data["inputs"]:
        assert hashes[source["path"]] == source["sha256"]
    periodic = {(r.get("id"), float(r.get("begin"))): int(r.get("nVehContrib"))
                for r in ET.parse(SELECTED / "native/field-counts.xml").getroot().findall("interval")}
    actual_bins = Counter((p["detector_id"], p["interval_begin_s"]) for p in passage_data["passages"])
    assert len(periodic) == 208 and all(actual_bins[k] == v for k, v in periodic.items())
    passages = defaultdict(list)
    for row in passage_data["passages"]:
        passages[row["vehicle_id"]].append(row)
    intentions = {r["vehicle_id"]: r["field_id"] for r in json.loads((SELECTED / "lane-intentions.json").read_bytes())["vehicles"]}
    trips = {r.get("id"): r.attrib for r in ET.parse(SELECTED / "native/tripinfo.xml").getroot().findall("tripinfo")}
    selected = ET.parse(SELECTED / "demand.rou.xml").getroot().findall("vehicle")
    selected_routes = Counter()
    od = defaultdict(lambda: {"requests": 0, "complete_event_count": 0, "no_complete_event": 0,
                              "actual_field_sets": Counter(), "intended_fields": Counter()})
    trip_rows = []
    event_regions = Counter()
    for vehicle in selected:
        identity = vehicle.get("id")
        path = tuple(vehicle.find("route").get("edges").split())
        assert path in templates
        selected_routes[path] += 1
        events = sorted(passages.get(identity, []), key=lambda r: r["notification_time_s"])
        field_set = tuple(sorted({r["detector_id"] for r in events}))
        trip = trips.get(identity)
        state = "not_inserted" if trip is None else "arrived" if float(trip["arrival"]) >= 0 else "running"
        for event in events:
            begin = event["interval_begin_s"]
            event_regions["initialization" if begin < 3600 else "main" if begin < 12600 else "tail"] += 1
        row = od[path[0], path[-1]]
        row["requests"] += 1
        row["complete_event_count"] += len(events)
        row["no_complete_event"] += not events
        row["actual_field_sets"][field_set] += 1
        row["intended_fields"][intentions[identity]] += 1
        trip_rows.append({"vehicle_id": identity, "origin": path[0], "destination": path[-1],
            "departure_period": int(float(vehicle.get("depart")) // 900), "route_id": route_ids[path],
            "intended_field": intentions[identity], "complete_fields": list(field_set), "event_count": len(events),
            "notification_times_s": [r["notification_time_s"] for r in events], "terminal_state": state})
    assert len(selected) == 8640 and set(passages) <= {v.get("id") for v in selected}
    assert len(passage_data["passages"]) == len(passages) == 8626
    assert all(len(r["complete_fields"]) <= 1 and r["event_count"] <= 1 for r in trip_rows)
    assert all(not r["complete_fields"] or r["complete_fields"] == [r["intended_field"]] for r in trip_rows)
    write_csv("selected-trip-fields8640.csv", trip_rows)
    for row in template_rows:
        row["selected_requests"] = selected_routes[tuple(row["edges"])]
    write_json("template-routes.json", template_rows)
    od_rows = [{"origin": a, "destination": b, **{k: v for k, v in row.items() if k not in {"actual_field_sets", "intended_fields"}},
                "intended_fields": dict(row["intended_fields"]),
                "actual_field_sets": [{"fields": list(key), "trips": value} for key, value in sorted(row["actual_field_sets"].items())]}
               for (a, b), row in sorted(od.items())]
    write_csv("selected-od21-summary.csv", od_rows)

    sources, sinks, boundary_audit = read_declared_boundaries(BOUNDARIES, edges)
    assert not boundary_audit["unresolved"]
    declared_sources, declared_sinks = set(sources), set(sinks)
    active = {e for e in edges if edges[e].allows_passenger}
    turns = {(r.get("from"), r.get("to")) for r in net.findall("connection") if r.get("dir") == "t"}
    graph = {e: {f for f in connections.get(e, set()) & active if (e, f) not in turns} for e in active}
    incoming = defaultdict(set)
    for a, bs in graph.items():
        for b in bs:
            incoming[b].add(a)
    sources, sinks = declared_sources | {e for e in graph if not incoming[e]}, declared_sinks | {e for e in graph if not graph[e]}
    groups = {j.get("id"): j.get("id").split("_")[0] for j in net.findall("junction")
              if j.get("id", "").startswith(("LSA104_", "LSA118_", "LSA119_", "LSA200_", "LSA535_"))}
    pool, excluded = boundary_route_pool(edges, graph, sources, sinks, field_roads, groups)
    witnesses = []
    for origin in ["44532531", "25866659#1"]:
        choices = []
        for route in pool:
            if route["source_edge"] != origin or route["sink_edge"] != "28665128#0":
                continue
            for profile in ideal_lane_profiles(route["edges"], lanes, lane_connections, fields):
                if signature(profile) == ["hh_0119_Z_12_31546", "hh_0535_Z_4_33055"]:
                    choices.append((route, profile))
        route, profile = min(choices, key=lambda r: (r[0]["distance_m"], r[0]["edges"]))
        path = route["edges"]
        assert route["source_edge"] in declared_sources and route["sink_edge"] in declared_sinks
        assert (path[0], path[-1]) not in pairs and not any((a, b) in turns for a, b in zip(path, path[1:]))
        audit = junction_visit_audit(path, edges, graph, groups)
        assert audit["allowed"]
        lane_rows, turn_rows = [], []
        for i, edge in enumerate(path):
            entry, exit_lane = profile["entry_lanes"][i], profile["exit_lanes"][i]
            lane_rows.append({"edge_index": i, "edge": edge, "from_node": edges[edge].from_node,
                "to_node": edges[edge].to_node, "entry_lane": entry, "exit_lane": exit_lane,
                "entry_lane_id": f"{edge}_{entry}", "exit_lane_id": f"{edge}_{exit_lane}",
                "ordinary_lane_length_m": float(lane_elements[f"{edge}_{exit_lane}"].get("length")),
                "ordinary_lane_change_required": entry != exit_lane})
            if i + 1 < len(path):
                key = (edge, exit_lane, path[i + 1], profile["entry_lanes"][i + 1])
                assert "passenger" in loaded[key]
                element = next(c for c in net.findall("connection") if (c.get("from"), int(c.get("fromLane")),
                    c.get("to"), int(c.get("toLane"))) == key)
                turn_rows.append({"from": key[0], "fromLane": key[1], "to": key[2], "toLane": key[3],
                    "connection_attributes": element.attrib, "loaded_permissions": sorted(loaded[key])})
        witness = {"id": f"witness-{len(witnesses) + 1}", "origin": path[0], "destination": path[-1],
            "in_current_21OD": False, "edges": list(path), "fields": signature(profile),
            "ordinary_road_length_m": route["distance_m"], "junction_audit": audit,
            "uturn_connections": 0, "lane_profile": profile, "lane_segments": lane_rows, "connections": turn_rows,
            "claim_boundary": "Static passenger permission witness with ordinary-road lane changes. No native trip, timing, capacity, gaps, natural lane choice or observed OD is established."}
        witnesses.append(witness)
        write_csv(f"{witness['id']}-lane-path.csv", lane_rows)
    write_json("multi-field-witnesses.json", witnesses)
    assert hashes == {str(p): digest(p) for p in inputs}
    report = {"status": "pass", "native_runs": 0, "model_sha256": digest(PREPARED / "od-model.json"),
        "network_sha256": digest(PREPARED / "network.net.xml"), "ordinary_roads": len(edges),
        "passenger_roads": len(active), "OD_pairs": len(pairs), "departure_cells": len(model["cells"]),
        "model_templates": sum(templates.values()), "distinct_template_routes": len(templates),
        "template_moving_stop_count_distribution": dict(template_stop_counts),
        "template_exit_lane_profile_max_fields": 1, "template_routes_crossing_two_detector_roads": sum(len(set(route) & field_roads) > 1 for route in templates),
        "selected_requests": len(selected), "selected_complete_events": len(passage_data["passages"]),
        "selected_unique_complete_vehicles": len(passages), "selected_field_set_sizes": dict(Counter(len(r["complete_fields"]) for r in trip_rows)),
        "selected_no_event_terminal_states": dict(Counter(r["terminal_state"] for r in trip_rows if not r["event_count"])),
        "selected_periodic_event_regions": dict(event_regions), "periodic208_reconciled": True,
        "selected_wrong_intended_fields": 0, "declared_entries": sorted(declared_sources), "declared_exits": sorted(declared_sinks),
        "boundary_audit": boundary_audit, "augmented_entries": sorted(sources), "augmented_exits": sorted(sinks),
        "finite_pool_routes_checked": len(pool), "finite_pool_excluded_repeated_junction_or_road": len(excluded),
        "multi_field_witness_count": len(witnesses), "detectors": fields,
        "inputs_unchanged": True, "source_hashes": hashes,
        "claim_boundary": "Current 21-OD support is a fixed empirical prior. Actual selected nVehContrib is at most one field per trip; this does not make field-count sums unique-vehicle counts. Static exit-lane signatures are not an exhaustive proof about transient lane changes. Two legal multi-field boundary routes outside the fixed support do not establish observed traffic or justify adding demand. No zero-fit feasibility or total-demand excess is inferred."}
    write_json("report.json", report)
    print(json.dumps({k: report[k] for k in ["status", "OD_pairs", "departure_cells", "distinct_template_routes", "selected_requests",
        "selected_complete_events", "selected_unique_complete_vehicles", "selected_field_set_sizes", "selected_no_event_terminal_states",
        "selected_periodic_event_regions", "multi_field_witness_count"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
