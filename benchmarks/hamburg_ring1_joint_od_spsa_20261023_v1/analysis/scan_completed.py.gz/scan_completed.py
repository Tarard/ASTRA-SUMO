"""Scan sealed SPSA evaluations once. Write analysis only; never run SUMO."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows
from astra_sumo.core.hamburg_readme_results import STATIONS


HERE = Path(__file__).resolve().parent
CASE = HERE.parent


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def periodic(path):
    rows = {}
    for _, row in ET.iterparse(path):
        if row.tag != "interval":
            continue
        key = row.get("id"), float(row.get("begin")), float(row.get("end"))
        if key in rows:
            raise ValueError("Repeated native field interval")
        rows[key] = dict(row.attrib)
        row.clear()
    return rows


def key(row):
    return row["detector_id"], float(row["begin"]), float(row["end"])


def rounding(values):
    return np.floor(np.asarray(values, dtype=float) + .5).astype(np.int64)


def objective(rows):
    residuals = [int(row["diff_nVehContrib_minus_expected"]) for row in rows]
    return dict(rows=len(rows), SSE=sum(r * r for r in residuals), TAE=sum(map(abs, residuals)),
                MAE=sum(map(abs, residuals)) / len(rows), max_abs_error=max(map(abs, residuals)),
                exact_rows=sum(r == 0 for r in residuals))


def center_for(name, initial, history):
    if name == "initial":
        return initial.copy(), None, None
    match = re.fullmatch(r"iteration-(\d{4})-(plus|minus)", name)
    if match:
        iteration, side = int(match[1]), match[2]
        if iteration in history:
            return np.asarray(history[iteration]["theta"]), iteration, side
        if iteration == 1:
            return initial.copy(), iteration, side
        if iteration - 1 in history:
            return np.asarray(history[iteration - 1]["next_theta"]), iteration, side
        return None, iteration, side
    if name == "final" and history:
        return np.asarray(history[max(history)]["theta"]), max(history), None
    return None, None, None


def inspect_evaluation(name, proposal, evidence, prepared, model, canonical_keys, sources):
    native = evidence / "native"
    sealed_paths = [evidence / "evaluation.json", evidence / "station-comparison.csv"]
    sealed_paths += [proposal / filename for filename in ["od-vector.json", "demand.rou.xml", "lane-intentions.json"]]
    sealed_paths += [native / filename for filename in ["run.json", "native-request.json", "field-counts.xml", "field-comparison.csv",
        "summary.xml", "tripinfo.xml", "collisions.xml", "stall-monitor.json"]]
    sealed_hashes = {path: sha(path) for path in sealed_paths}
    run, monitor, request, recorded = [load(path) for path in [native / "run.json", native / "stall-monitor.json",
        native / "native-request.json", evidence / "evaluation.json"]]
    if (run["native_status"] != "pass" or not run["observer_complete"] or run["missing_field_bins"] != 0
            or run["expected_field_bins"] != 130 or run["measurement_attribute"] != "nVehContrib"
            or recorded["field_rows"] != 130 or recorded["derived_station_rows"] != 40
            or monitor["status"] != "completed" or monitor["simulation_time_s"] != run["end_s"]):
        raise ValueError("A sealed evaluation does not confirm complete native execution and observation")
    vector = load(proposal / "od-vector.json")
    values = np.asarray(vector["values"], dtype=float)
    integer = rounding(values)
    if values.shape != (294,) or not np.all(np.isfinite(values)) or np.any(values < 0):
        raise ValueError("Invalid OD vector")
    if integer.tolist() != vector["integer_counts"] or int(integer.sum()) != vector["vehicle_count"]:
        raise ValueError("OD half-up rounding or vehicle total differs")
    if vector["source_model_sha256"] != sha(prepared / "od-model.json"):
        raise ValueError("The evaluation uses another OD model")
    vehicles = {e.get("id"): e for e in ET.parse(proposal / "demand.rou.xml").getroot().findall("vehicle")}
    intentions = {r["vehicle_id"]: r for r in load(proposal / "lane-intentions.json")["vehicles"]}
    if len(vehicles) != vector["vehicle_count"] or vehicles.keys() != intentions.keys():
        raise ValueError("Explicit requests, lane intentions and declared N differ")
    actual_cells, field_inventory = Counter(), Counter()
    for identity, vehicle in vehicles.items():
        cell = intentions[identity]["od_cell"]
        route = vehicle.find("route").get("edges").split()
        period = int(float(vehicle.get("depart")) // 900)
        declared = model["cells"][cell]
        if (route[0], route[-1], period) != (declared["origin"], declared["destination"], int(declared["begin_s"]) // 900):
            raise ValueError("A request differs from its OD/departure cell")
        actual_cells[cell] += 1
        field_inventory[period, intentions[identity]["field_id"]] += 1
    if [actual_cells[i] for i in range(294)] != integer.tolist():
        raise ValueError("Native request count per cell differs from rounded OD")
    bindings = [(prepared / "network.net.xml", "network.net.xml"), (proposal / "demand.rou.xml", "demand.rou.xml"),
        (prepared / "field-loops.add.xml", "source-e1.add.xml"), (prepared / "expected-counts.csv", "expected-counts.csv"),
        (prepared / "control.add.xml", "signal-programs.add.xml"), (proposal / "lane-intentions.json", "lane-intentions.json")]
    if len(run["inputs"]) != 6 or len(run["snapshots"]) != 6:
        raise ValueError("Missing six-input provenance")
    for (path, filename), source, snapshot in zip(bindings, run["inputs"], run["snapshots"], strict=True):
        digest = sha(path)
        if digest != source["sha256"] or digest != snapshot["sha256"] or digest != sha(native / filename):
            raise ValueError(f"Native input hash differs: {filename}")
    raw = periodic(native / "field-counts.xml")
    if len(raw) != 208 or (canonical_keys is not None and set(raw) != canonical_keys):
        raise ValueError("Expected all 208 native field intervals")
    main, initialization = [audit_expected_to_e1_strict(read_csv_rows(prepared / filename),
        native / "field-counts.xml", count_attribute="nVehContrib") for filename in ["expected-counts.csv", "initialization-counts.csv"]]
    if len(main) != 130 or len(initialization) != 52 or len({key(row) for row in main + initialization}) != 182:
        raise ValueError("All 130/52 distinct target intervals are required")
    if any(row["measured_nVehContrib"] is None for row in main + initialization):
        raise ValueError("A real observation has no native count")
    stored_main = {key(row): row for row in read_csv_rows(native / "field-comparison.csv")}
    if len(stored_main) != 130 or any(any(int(row[k]) != int(stored_main[key(row)][k]) for k in
            ["expected_total", "measured_nVehContrib", "diff_nVehContrib_minus_expected"]) for row in main):
        raise ValueError("Stored field rows differ from raw native E1")
    groups = defaultdict(list)
    for metadata, row in zip(read_csv_rows(prepared / "expected-counts.csv"), main, strict=True):
        for station, (node, assets) in STATIONS.items():
            if metadata["node_id"] == node and metadata["asset_id"] in assets:
                groups[station, float(row["begin"]), float(row["end"])].append(row)
    if len(groups) != 40 or any(len(rows) != len(STATIONS[k[0]][1]) for k, rows in groups.items()):
        raise ValueError("Derived stations do not retain all fields")
    stations = [dict(station_stream_id=station, begin=begin, end=end,
        expected_total=sum(int(r["expected_total"]) for r in rows),
        measured_nVehContrib=sum(int(r["measured_nVehContrib"]) for r in rows),
        residual=sum(int(r["diff_nVehContrib_minus_expected"]) for r in rows), independent_evidence=False)
        for (station, begin, end), rows in sorted(groups.items())]
    stored_stations = {(r["station_stream_id"], float(r["begin"]), float(r["end"])): r
                       for r in read_csv_rows(evidence / "station-comparison.csv")}
    if len(stored_stations) != 40:
        raise ValueError("Stored station table is incomplete")
    for row in stations:
        stored = stored_stations[row["station_stream_id"], row["begin"], row["end"]]
        if any(int(stored[k]) != row[k] for k in ["expected_total", "measured_nVehContrib", "residual"]):
            raise ValueError("Stored station table differs from raw E1")
    final, step_count = None, 0
    for _, element in ET.iterparse(native / "summary.xml"):
        if element.tag == "step":
            final, step_count = dict(element.attrib), step_count + 1
        element.clear()
    if final is None or step_count != round(run["end_s"] / run["step_length_s"]):
        raise ValueError("Native summary is incomplete")
    completion = {k: int(final.get(k, 0)) for k in ["loaded", "inserted", "arrived", "running", "waiting", "teleports", "collisions", "discarded"]}
    if completion != run["completion"] or completion != recorded["completion"] or completion["loaded"] != len(vehicles):
        raise ValueError("Native completion or N differs from sealed metrics")
    trips = [dict(e.attrib) for _, e in ET.iterparse(native / "tripinfo.xml") if e.tag == "tripinfo"]
    healthy = (all(completion[k] == len(vehicles) for k in ["loaded", "inserted", "arrived"])
        and not any(completion[k] for k in ["running", "waiting", "teleports", "collisions", "discarded"])
        and len(trips) == len(vehicles) and {r["id"] for r in trips} == set(vehicles)
        and all(not row.get("vaporized", "") for row in trips))
    collision_rows = len(ET.parse(native / "collisions.xml").getroot().findall("collision"))
    safe = not collision_rows and not any(completion[k] for k in ["collisions", "teleports", "discarded"])
    command = request["command"]
    native_seed = int(command[command.index("--seed") + 1])
    if native_seed != run["seed"] or request["backend"] != run["backend"]:
        raise ValueError("Recorded native settings differ from the command")
    if (float(command[command.index("--step-length") + 1]) != run["step_length_s"]
            or float(command[command.index("--end") + 1]) != run["end_s"]
            or request["junction_body_hold_nodes"] != run["junction_body_hold_nodes"]):
        raise ValueError("Native step, horizon or body scope differs from its request")
    metrics = objective(main)
    if (metrics["SSE"] != recorded["loss"] or metrics["MAE"] != recorded["MAE"]
            or metrics["max_abs_error"] != recorded["max_abs_error"] or healthy != recorded["healthy"] or healthy != run["healthy"]):
        raise ValueError("Sealed metrics differ from raw native E1 or completion")
    station_mae = sum(abs(r["residual"]) for r in stations) / 40
    if (station_mae != recorded["station_MAE"]
            or max(abs(r["residual"]) for r in stations) != recorded["station_max_abs_error"]
            or recorded["exact_count_fit"] != (healthy and metrics["TAE"] == 0)):
        raise ValueError("Derived station metric differs")
    if any(sha(path) != digest for path, digest in sealed_hashes.items()):
        raise ValueError("Sealed evidence changed during this offline read")
    sources.extend(sealed_paths)
    return dict(name=name, proposal_path=str(proposal), native_evidence_path=str(evidence), reused=name == "initial",
        values=values.tolist(), integer_counts=integer.tolist(), N=len(vehicles), real_flow_sum=float(values.sum()),
        rounding_N_minus_real_sum=float(integer.sum() - values.sum()), fractional_real_cells=int(np.count_nonzero(values != integer)),
        zero_integer_cells=int(np.count_nonzero(integer == 0)), source_model_sha256=vector["source_model_sha256"],
        metrics130=metrics, metrics52=objective(initialization), metrics182=objective(main + initialization),
        native208_rows=len(raw), summary_steps=step_count, station40_MAE=station_mae,
        completion=completion, safe=bool(safe), healthy=healthy, collision_xml_rows=collision_rows,
        native_seed=native_seed, backend=run["backend"], body_nodes=run["junction_body_hold_nodes"],
        step_length_s=run["step_length_s"], end_s=run["end_s"], sealed_inputs_unchanged_during_read=True,
        main_rows=main, initialization_rows=initialization, stations=stations, native208=raw,
        field_inventory=[dict(departure_period=h, field=field, count=n) for (h, field), n in sorted(field_inventory.items())])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=CASE / "run")
    parser.add_argument("--prepared-dir", type=Path, default=CASE / "prepared")
    parser.add_argument("--output-dir", type=Path, default=HERE / "latest")
    args = parser.parse_args()
    run_dir, prepared, output = args.run_dir.resolve(strict=True), args.prepared_dir.resolve(strict=True), args.output_dir.resolve()
    if not output.is_relative_to(HERE) or output.is_relative_to(run_dir):
        raise SystemExit("Write analysis only inside this tool's analysis directory.")
    output.mkdir(parents=True, exist_ok=True)
    settings, reuse = load(run_dir / "settings.json"), load(run_dir / "initial-reuse.json")
    cached = Path(reuse["cached_dir"]).resolve(strict=True)
    for filename in ["demand.rou.xml", "lane-intentions.json", "od-vector.json"]:
        if (run_dir / "initial" / filename).read_bytes() != (cached / filename).read_bytes():
            raise ValueError("Initial proposal differs from the declared reused source")
    model = load(prepared / "od-model.json")
    history = {int(path.stem.split("-")[1]): load(path) for path in sorted(run_dir.glob("iteration-????.json"))}
    sources = [Path(__file__).resolve(), run_dir / "settings.json", run_dir / "initial-reuse.json", prepared / "od-model.json",
               prepared / "expected-counts.csv", prepared / "initialization-counts.csv"] + sorted(run_dir.glob("iteration-????.json"))
    for filename in ["expected-counts.csv", "initialization-counts.csv"]:
        original = cached.parent / "source/prepared" / filename
        if not original.is_file() or sha(original) != sha(prepared / filename):
            raise ValueError("Joint targets differ from the selected source targets")
    evaluations, errors, skipped = {}, [], []
    initial = inspect_evaluation("initial", run_dir / "initial", cached, prepared, model, None, sources)
    evaluations["initial"] = initial
    canonical_keys = set(initial["native208"])
    for folder in sorted(run_dir.iterdir()):
        if not folder.is_dir() or folder.name == "initial":
            continue
        if not (folder.name == "final" or re.fullmatch(r"iteration-\d{4}-(plus|minus)", folder.name)):
            continue
        if not (folder / "evaluation.json").is_file():
            skipped.append(dict(name=folder.name, reason="No evaluation.json completion seal; native XML not read"))
            continue
        try:
            evaluations[folder.name] = inspect_evaluation(folder.name, folder, folder, prepared, model, canonical_keys, sources)
        except (OSError, ValueError, KeyError, AssertionError, ET.ParseError) as error:
            errors.append(dict(name=folder.name, error=f"{type(error).__name__}: {error}"))
    initial_values = np.asarray(initial["values"])
    rng = np.random.default_rng(settings["seed"])
    perturbations = {k: rng.choice((-1, 1), size=294) for k in range(1, settings["iterations"] + 1)}
    launch = load(CASE / "launch.json") if (CASE / "launch.json").is_file() else {}
    stop_on_unsafe = "--stop-on-unsafe" in launch.get("arguments", [])
    summaries = []
    for name, item in evaluations.items():
        prior, iteration, side = center_for(name, initial_values, history)
        values, integer = np.asarray(item["values"]), np.asarray(item["integer_counts"])
        prior_name = next((other_name for other_name, other in evaluations.items()
                           if prior is not None and np.array_equal(prior, other["values"])), None)
        prior_eval = evaluations.get(prior_name)
        parameter = dict(SPSA_rng_seed=settings["seed"], native_seed=item["native_seed"],
            native_seed_changed_from_initial=item["native_seed"] != initial["native_seed"],
            N_change_from_initial=item["N"] - initial["N"], integer_L1_change_from_initial=int(abs(integer - initial["integer_counts"]).sum()),
            integer_changed_cells_from_initial=int(np.count_nonzero(integer != initial["integer_counts"])),
            iteration=iteration, perturbation_side=side, prior_native_evaluation=prior_name,
            prior_metrics_measured=prior_eval is not None)
        clipped = np.zeros(294, dtype=bool)
        if iteration is not None and side is not None and prior is not None:
            ck = settings["c"] / iteration ** settings["gamma"]
            delta = perturbations[iteration]
            unconstrained = prior + (1 if side == "plus" else -1) * ck * delta
            proposed = np.maximum(unconstrained, 0)
            if not np.allclose(values, proposed, rtol=0, atol=1e-12):
                raise ValueError(f"{name}: vector differs from declared SPSA seed, center, c or clipping")
            clipped = unconstrained < 0
            parameter.update(ck=ck, lower_clip_cells=int(clipped.sum()), upper_bound="infinity",
                             RNG_delta_matches_history=iteration not in history or delta.tolist() == history[iteration]["delta"])
            if not parameter["RNG_delta_matches_history"]:
                raise ValueError(f"{name}: recorded perturbation differs from the declared SPSA seed")
        rows = []
        for column, cell in enumerate(model["cells"]):
            rows.append(dict(cell=column, origin=cell["origin"], destination=cell["destination"], begin_s=cell["begin_s"],
                initial_real=float(initial_values[column]), real_value=float(values[column]), integer_count=int(integer[column]),
                initial_integer_count=int(initial["integer_counts"][column]),
                prior_real=float(prior[column]) if prior is not None else None,
                prior_integer_count=int(rounding(prior)[column]) if prior is not None else None,
                clipped_at_zero=bool(clipped[column])))
        comparison_rows = []
        for row in item["main_rows"]:
            k = key(row)
            baseline = next(r for r in initial["main_rows"] if key(r) == k)
            prior_row = next((r for r in prior_eval["main_rows"] if key(r) == k), None) if prior_eval else None
            comparison_rows.append(dict(field=k[0], begin_s=k[1], end_s=k[2], target=int(row["expected_total"]),
                measured=int(row["measured_nVehContrib"]), residual=int(row["diff_nVehContrib_minus_expected"]),
                initial_residual=int(baseline["diff_nVehContrib_minus_expected"]),
                prior_residual=int(prior_row["diff_nVehContrib_minus_expected"]) if prior_row else None))
        fields = []
        for field in sorted({r["field"] for r in comparison_rows}):
            members = [r for r in comparison_rows if r["field"] == field]
            field_data = dict(field=field, SSE=sum(r["residual"] ** 2 for r in members), TAE=sum(abs(r["residual"]) for r in members),
                initial_SSE=sum(r["initial_residual"] ** 2 for r in members), initial_TAE=sum(abs(r["initial_residual"]) for r in members),
                prior_SSE=sum(r["prior_residual"] ** 2 for r in members) if prior_eval else None,
                prior_TAE=sum(abs(r["prior_residual"]) for r in members) if prior_eval else None)
            fields.append(field_data)
        target_dir = output / name
        target_dir.mkdir(exist_ok=True)
        table(target_dir / "od-cells294.csv", rows)
        table(target_dir / "residual130.csv", comparison_rows)
        table(target_dir / "field13-summary.csv", fields)
        table(target_dir / "initialization52.csv", item["initialization_rows"])
        table(target_dir / "station40.csv", item["stations"])
        table(target_dir / "native208.csv", [dict(field=k[0], begin_s=k[1], end_s=k[2], nVehContrib=int(v["nVehContrib"]))
                                              for k, v in sorted(item["native208"].items())])
        table(target_dir / "input-field-inventory.csv", item["field_inventory"])
        concise = {k: v for k, v in item.items() if k not in {"main_rows", "initialization_rows", "stations", "native208", "field_inventory"}}
        setting_changes = {k: dict(initial=initial[k], evaluation=item[k]) for k in
                           ["native_seed", "backend", "body_nodes", "step_length_s", "end_s"] if initial[k] != item[k]}
        concise.update(parameters=parameter, prior_metric_boundary="Only an exactly matching real vector with actual native evidence supplies prior metrics; unmeasured centers stay null.",
            delta_from_initial=dict(SSE=item["metrics130"]["SSE"] - initial["metrics130"]["SSE"],
                                    MAE=item["metrics130"]["MAE"] - initial["metrics130"]["MAE"]),
            delta_from_measured_prior=dict(SSE=item["metrics130"]["SSE"] - prior_eval["metrics130"]["SSE"],
                MAE=item["metrics130"]["MAE"] - prior_eval["metrics130"]["MAE"]) if prior_eval else None,
            guard=dict(stop_on_unsafe_requested=stop_on_unsafe, unsafe_stop_required=stop_on_unsafe and not item["safe"],
                healthy_native_zero=item["healthy"] and item["metrics130"]["TAE"] == 0,
                same_native_treatment_as_initial=not setting_changes,
                meets_declared_native_zero_guard=item["healthy"] and item["safe"] and item["metrics130"]["TAE"] == 0),
            native_setting_changes_from_initial=setting_changes)
        save(target_dir / "audit.json", concise)
        summaries.append(dict(name=name, N=item["N"], real_flow_sum=item["real_flow_sum"], SSE=item["metrics130"]["SSE"],
            TAE=item["metrics130"]["TAE"], MAE=item["metrics130"]["MAE"], initialization_TAE=item["metrics52"]["TAE"],
            all182_TAE=item["metrics182"]["TAE"], safe=item["safe"], healthy=item["healthy"],
            waiting=item["completion"]["waiting"], running=item["completion"]["running"], native_seed=item["native_seed"],
            SPSA_seed=settings["seed"], prior_native_evaluation=prior_name, lower_clip_cells=parameter.get("lower_clip_cells"),
            delta_initial_SSE=concise["delta_from_initial"]["SSE"], delta_initial_MAE=concise["delta_from_initial"]["MAE"]))
    hashes = [dict(path=str(path), sha256=sha(path)) for path in dict.fromkeys(sources)]
    result = dict(status="pass" if not errors else "review_required", complete_evaluations=summaries,
        source_commit=launch.get("source_commit"), analysis_numpy_version=np.__version__,
        declared_run_result=load(run_dir / "result.json") if (run_dir / "result.json").is_file() else None,
        declared_run_failure=load(run_dir / "failure.json") if (run_dir / "failure.json").is_file() else None,
        declared_pair_failure=load(run_dir / "pair-failure.json") if (run_dir / "pair-failure.json").is_file() else None,
        skipped_without_completion_seal=skipped, complete_evaluation_audit_errors=errors, source_hashes=hashes,
        no_native_runs=True, run_directory_unchanged_by_tool=True,
        claim_boundary="One offline scan of sealed evaluations. 40 stations are derived. No interpolation of unmeasured centers, prediction, fixed-N assumption or automatic candidate promotion.")
    save(output / "scan.json", result)
    table(output / "evaluations-summary.csv", summaries)
    manifest = [dict(path=str(path.relative_to(output)), sha256=sha(path), bytes=path.stat().st_size)
                for path in sorted(output.rglob("*")) if path.is_file() and path.name != "manifest.json"]
    save(output / "manifest.json", dict(scope="This single offline scan output", files=manifest))
    print(json.dumps({k: result[k] for k in ["status", "complete_evaluations", "skipped_without_completion_seal", "complete_evaluation_audit_errors"]}, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
