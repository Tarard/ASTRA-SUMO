# 联合K5的单次离线核对

在仓库根目录运行一次：

```powershell
$env:PYTHONUTF8 = '1'
$env:PYTHONPATH = "$PWD/plugins/astra-sumo/src"
.venv/Scripts/python.exe outputs/hamburg-joint-od-spsa-20261023-v1/analysis/scan_completed.py
```

工具没有等待或循环轮询。主任务可在每对完成后再调用一次。它只向本目录内的 `latest/` 写结果，不改 `run/`、prepared或原生证据；可用 `--output-dir` 另选本目录内的新位置保存某次扫描。

初值从 `run/initial-reuse.json` 指向的selected完整缓存读取，先核 `run/initial` 的三份proposal字节相同。它不会假设 `run/initial/native` 存在。其他评价只有在该目录已有 `evaluation.json` 时才读取原生输出。尚无完成封口的目录记为跳过，不解析正在写入的XML，也不补零。

每项完整评价核对130项主窗、40项派生站点、52项初始化和208行原生计数，重算SSE、MAE、TAE、逐字段残差及182项总量。它检查原生summary步数、completion、collision记录、六份输入hash及OD请求计数。unsafe评价仍保留实际诊断数值，并标出安全停止条件；没有自动接受候选或控制正在运行的任务。

`latest/evaluations-summary.csv` 给出本次所有已核完整评价。`latest/scan.json`记录被跳过的未封口目录、完整评价的核验错误及已有的run/result/failure声明。这里的pass指本次已封口数据核验通过，不表示K5已结束。各评价子目录含：

- `residual130.csv`：相对原生初值及已实测迭代中心的逐窗残差。
- `field13-summary.csv`：13字段的SSE、TAE及相对基准。
- `initialization52.csv`、`station40.csv`、`native208.csv`：全部附属对账；40项是合计，未加入独立损失。
- `od-cells294.csv`：真实值、整数请求数、初值、迭代中心和下界截断标记。
- `input-field-inventory.csv`：实际生成输入按出发窗与字段的车辆数。
- `audit.json`：完整性、安全、原生设置、总请求量、取整变化及seed记录。

工具按声明的SPSA seed复核Bernoulli方向、`c/k^gamma`、下界0截断和逐cell半向上取整。SPSA抽样seed与native seed分列。每次N都从该次vector和实际XML重算，不假设继续为8640，也不依据N单独判定需求过量。

迭代中心只有与某项已有原生实测的真实向量完全相同时，才提供该中心的SSE、MAE和逐字段残差。中心未实测时对应值为null，保留向量变化和截断信息，不插值、不使用分配表预测。final相对最后一次更新之前的中心比较。

首次基础核验已读selected初值，重算SSE6898、TAE662、初始化TAE82、182项TAE744，并正确跳过两个尚无evaluation封口的首对目录。工具后续增强已对同一sealed初值函数复核；未再次轮询运行进度。后续调用以该次 `scan.json` 的完整评价列表为准。
