"""Core helpers for ASTRA."""
