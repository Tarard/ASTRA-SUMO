# Hamburg ordinary SPSA

Accepted exact calibration: False.
Stopping reason: declared_iteration_count. Completed updates: 5.

Counts use native E1 nVehContrib. All 130 fields and 40 derived station rows are retained.
Unsafe results have diagnostic errors only. Fixed route/lane/time templates remain priors.

[Settings](settings.json), [evaluations](evaluations.json), [result](result.json).

Runner: plugins/astra-sumo/scripts/run_hamburg_od_spsa.py. Scenario: C:\Users\Danial\.codex\worktrees\hamburg-reproduction\Torii\outputs\hamburg-joint-od-spsa-20261023-v1\prepared.
Analysis: plugins/astra-sumo/src/astra_sumo/core/hamburg_od_spsa.py. Raw results: C:\Users\Danial\.codex\worktrees\hamburg-reproduction\Torii\outputs\hamburg-joint-od-spsa-20261023-v1\run.

| Evaluation | Diagnostic MAE | Max error | Collisions | Teleports | Waiting | In network | Healthy |
|---|---:|---:|---:|---:|---:|---:|---|
| initial | 5.092308 | 27 | 0 | 0 | 7 | 14 | False |
| iteration-0001-plus | 7.184615 | 34 | 0 | 0 | 82 | 80 | False |
| iteration-0001-minus | 7.661538 | 35 | 0 | 0 | 47 | 104 | False |
| iteration-0002-plus | 7.784615 | 31 | 0 | 0 | 113 | 69 | False |
| iteration-0002-minus | 6.507692 | 27 | 0 | 0 | 91 | 32 | False |
| iteration-0003-plus | 6.769231 | 28 | 0 | 0 | 33 | 33 | False |
| iteration-0003-minus | 6.746154 | 36 | 0 | 0 | 58 | 33 | False |
| iteration-0004-plus | 6.984615 | 38 | 0 | 0 | 84 | 59 | False |
| iteration-0004-minus | 7.315385 | 32 | 0 | 0 | 98 | 62 | False |
| iteration-0005-plus | 6.223077 | 27 | 0 | 0 | 48 | 18 | False |
| iteration-0005-minus | 6.630769 | 29 | 0 | 0 | 107 | 15 | False |
| final | 6.200000 | 29 | 0 | 0 | 45 | 19 | False |

Initial native evidence reused from: C:\Users\Danial\.codex\worktrees\hamburg-reproduction\Torii\outputs\hamburg-classical-od-calibration-20261023-v1\probe-minus1\evaluation.
[Input and native correspondence](initial-reuse.json).
