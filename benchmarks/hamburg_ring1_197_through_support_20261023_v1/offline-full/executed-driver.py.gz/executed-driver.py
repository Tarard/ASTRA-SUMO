"""Measure the scoped connection candidate with the unchanged selected demand."""
import argparse
from collections import Counter, defaultdict
import gzip
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    candidate = args.candidate.resolve(strict=True)
    source = repo / 'outputs/hamburg-classical-od-calibration-20261023-v1'
    base, reference = source / 'prepared', source / 'probe-minus1/evaluation'
    proof = json.loads((candidate / 'manifest.json').read_bytes())
    assert proof['status'] == 'review_required' and proof['checks'] and all(proof['checks'].values())
    assert sha(candidate / 'network.net.xml') == proof['candidate_sha256']
    assert sha(candidate / 'control.add.xml') == proof['control_sha256']
    assert Path(sys.executable).resolve() == (repo / '.venv/Scripts/python.exe').resolve()
    versions = {name: version(name) for name in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')}
    assert set(versions.values()) == {'1.27.1'}
    files = {name: base / name for name in ('field-loops.add.xml', 'expected-counts.csv', 'initialization-counts.csv', 'scenario.json')}
    files.update({name: reference / name for name in ('demand.rou.xml', 'lane-intentions.json')})
    files.update({name: candidate / name for name in ('network.net.xml', 'control.add.xml')})
    hashes = {str(p): sha(p) for p in [*files.values(), candidate / 'manifest.json', Path(__file__).resolve()]}
    out = root / ('offline-full' if args.prepare_only else 'full')
    out.mkdir(exist_ok=False)
    prepared, evaluation = out / 'prepared', out / 'evaluation'
    prepared.mkdir()
    evaluation.mkdir()
    for name, path in files.items():
        shutil.copyfile(path, prepared / name)
    scenario = json.loads((prepared / 'scenario.json').read_bytes())
    scenario.update(network_sha256=sha(prepared / 'network.net.xml'), control_sha256=sha(prepared / 'control.add.xml'),
        connection_candidate='Only -186821028 lane3 to 186821027#0 lane4 and lane4 to lane5 are added at1975693623; existing geometry, access and turns are preserved.',
        control_assumptions='Original phase parameters, types and old signal colors remain. New14/15 inherit old through1. Old Uturn9 phases0/1 and parking-left2 phase3 become permissive green to yield to the added straight movement. This declared priority adaptation is not field SPaT; actuated histories may change with traffic.',
        demand_prior='Exact unchanged selected8640 explicit requests, routes, departures, moving stops and field intentions. No OD regeneration or retiming.')
    save(prepared / 'scenario.json', scenario)
    for name in ('demand.rou.xml', 'lane-intentions.json'):
        shutil.copyfile(prepared / name, evaluation / name)
        assert sha(prepared / name) == sha(reference / name)
    assert len(ET.parse(prepared / 'demand.rou.xml').getroot().findall('vehicle')) == 8640
    implementation = out / 'implementation'
    implementation.mkdir()
    for name in ('hamburg_197_through_support.py', 'detector_demand_replay.py', 'simulation_stall.py', 'lane_section_hold.py', 'hamburg_od_spsa.py', 'detector_demand.py', 'route_sensor_matrix.py', 'artifact_io.py', 'candidate_contracts.py', 'command_runner.py'):
        shutil.copyfile(repo / 'plugins/astra-sumo/src/astra_sumo/core' / name, implementation / name)
    shutil.copyfile(__file__, out / 'executed-driver.py')
    save(out / 'preflight.json', {'source_hashes': hashes, 'candidate_manifest': str(candidate / 'manifest.json'),
        'prepared_hashes': {p.name: sha(p) for p in prepared.iterdir()}, 'python': sys.executable, 'versions': versions,
        'unchanged_demand_and_observations': True, 'formal_result': False,
        'selection_scope': 'Source-supported connectivity and native safety are assessed separately from fit. A nonzero fit is diagnostic. Formal acceptance still requires all130 exact native counts and healthy completion.'})
    if args.prepare_only:
        print(json.dumps({'status': 'prepared', 'N': 8640, 'native_runs': 0}), flush=True)
        return
    started = time.perf_counter()
    native = run_point_detector_demand(net_file=prepared / 'network.net.xml', route_file=prepared / 'demand.rou.xml',
        e1_additional_file=prepared / 'field-loops.add.xml', expected_counts_csv=prepared / 'expected-counts.csv',
        output_dir=evaluation / 'native', end_s=14400, timeout_seconds=4800, step_length=.1, seed=104, backend='libsumo',
        sumo_binary=str(repo / '.venv/Lib/site-packages/sumo/bin/sumo.exe'), signal_program_file=prepared / 'control.add.xml',
        lane_intentions_file=prepared / 'lane-intentions.json', junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared))
    result = summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
    rows = audit_expected_to_e1_strict(read_csv_rows(prepared / 'initialization-counts.csv') + read_csv_rows(prepared / 'expected-counts.csv'), evaluation / 'native/field-counts.xml')
    assert len(rows) == 182 and all(r['measured_nVehContrib'] is not None for r in rows)
    write_csv(evaluation / 'all182-comparison.csv', rows, list(rows[0]))
    passages = read_contributing_e1_passages(instant_file=evaluation / 'native/instant-e1.xml', periodic_file=evaluation / 'native/field-counts.xml', detector_ids=native['instant_to_periodic_ids'], step_length=.1)
    assert passages['reconciled']
    (evaluation / 'contributing-passages.json.gz').write_bytes(gzip.compress(json.dumps(passages).encode(), mtime=0))
    actual = defaultdict(list)
    for row in passages['passages']:
        actual[row['vehicle_id']].append(row['detector_id'])
    intentions = {r['vehicle_id']: r['field_id'] for r in json.loads((prepared / 'lane-intentions.json').read_bytes())['vehicles']}
    repeated = [key for key, n in Counter((r['vehicle_id'], r['detector_id']) for r in passages['passages']).items() if n > 1]
    extra = [r for r in passages['passages'] if r['detector_id'] != intentions[r['vehicle_id']]]
    assert all(sha(Path(p)) == h for p, h in hashes.items())
    safe = not any(result['completion'][k] for k in ('collisions', 'teleports', 'discarded'))
    verdict = {'status': 'diagnostic_candidate' if safe and not repeated else 'invalid', 'formal_result': result['exact_count_fit'],
        'before': json.loads((reference / 'evaluation.json').read_bytes()), 'after': result, 'all182_TAE': sum(abs(r['diff_nVehContrib_minus_expected']) for r in rows),
        'repeated_vehicle_fields': repeated, 'contributions_outside_prior_primary_intention': extra, 'contributing_vehicles': len(actual),
        'complete_contributions': len(passages['passages']), 'source_inputs_unchanged': True, 'elapsed_s': time.perf_counter() - started}
    save(out / 'verdict.json', verdict)
    print(json.dumps(verdict), flush=True)


if __name__ == '__main__':
    main()
