"""Check source directions and illustrate the pinned importer allocation offline."""

from hashlib import sha256
from importlib.metadata import distribution
import gzip
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.local_network_conversion import loaded_turn_permissions
from astra_sumo.core.osm_network import _netconvert_profile_options


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
OSM = ROOT / "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz"
CURRENT = ROOT / "outputs/hamburg-joint-od-spsa-20261023-v1/prepared/network.net.xml"
ORIGINAL = ROOT / "benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def movements(root):
    permissions = loaded_turn_permissions(root)
    return [dict(c.attrib) for c in root.findall("connection") if c.get("from") == "-186821028"
            and "passenger" in permissions.get((c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))), ())]


def main():
    sources = json.loads((OUT / "downloaded-primary-sources.json").read_bytes())
    assert all(digest(OUT / s["path"]) == s["sha256"] for s in sources)
    tag = json.loads((OUT / "official-version-tag.json").read_bytes())
    commit = tag["resolved_tag_object"]["object"]["sha"]
    assert commit == "7717f2379d9e314a0c81c5cec748444de06a2a91"
    for source in sources:
        source["immutable_url"] = source["url"].replace("/v1_27_1/", f"/{commit}/")
    importer = (OUT / "NIImporter_OpenStreetMap.cpp").read_text(encoding="utf-8")
    edge = (OUT / "NBEdge.cpp").read_text(encoding="utf-8")
    assert "applyTurnSigns(nbe, e->myTurnSignsBackward);\n        nbe->setTurnSignTarget(first->getID());" in importer
    assert "dirMap[signedDirs[i]] = targets[i];" in edge
    osm = ET.fromstring(gzip.decompress(OSM.read_bytes()))
    current, original = ET.parse(CURRENT).getroot(), ET.parse(ORIGINAL).getroot()
    way_records = []
    for identity, direction in [("186821028", "backward"), ("186821027", "forward")]:
        way = osm.find(f"way[@id='{identity}']")
        nodes = [nd.get("ref") for nd in way.findall("nd")]
        tags = {t.get("k"): t.get("v") for t in way.findall("tag")}
        token = tags["turn:lanes:backward" if direction == "backward" else "turn:lanes"]
        lane_count = len(token.split("|"))
        way_records.append({"way": identity, "direction": direction, "nodes": nodes, "tags": tags,
            "SUMO_turn_sign_target_original_node": nodes[0] if direction == "backward" else nodes[-1],
            "raw_left_to_right_signs": token.split("|"),
            "native_lane_signs_with_observed_two_nonmotor_lanes": {str(lane_count - 1 - i + 2): sign for i, sign in enumerate(token.split("|"))}})
    incoming = next(e for e in current.findall("edge") if e.get("id") == "-186821028")
    assert len(incoming.findall("lane")) == 5
    actual = movements(current)
    assert {(r["fromLane"], r["to"], r["toLane"], r["dir"]) for r in actual} == {
        ("2", "186821027#0", "2", "s"), ("3", "28665128#0", "0", "l"), ("4", "186821028", "3", "t")}
    assert {(r["fromLane"], r["to"], r["toLane"], r["dir"]) for r in actual} == {
        (r["fromLane"], r["to"], r["toLane"], r["dir"]) for r in movements(original)}
    # This is the equal-number rank branch, not a replacement network generator.
    signs_right_to_left = [("right", "2"), ("through", "3"), ("left", "4")]
    targets_right_to_left = [("186821027#0", "s"), ("28665128#0", "l"), ("186821028", "t")]
    conditional = [{"raw_arrow": sign, "native_incoming_lane": lane, "assigned_target": target,
                    "exported_geometric_direction": direction}
                   for (sign, lane), (target, direction) in zip(signs_right_to_left, targets_right_to_left, strict=True)]
    assert all(any(r["fromLane"] == c["native_incoming_lane"] and r["to"] == c["assigned_target"] for r in actual) for c in conditional)
    restrictions = [ET.tostring(r, encoding="unicode") for r in osm.findall("relation")
                    if any(m.get("type") == "way" and m.get("ref") in {"186821028", "186821027", "28665128"} for m in r.findall("member"))]
    configuration = re.search(r"(<netconvertConfiguration[\s\S]*?</netconvertConfiguration>)", ORIGINAL.read_text(encoding="utf-8")).group(1)
    conf = ET.fromstring(configuration)
    flags = {e.tag: e.get("value") for group in conf for e in group if e.tag in {"osm.turn-lanes", "tls.guess", "tls.guess-signals", "tls.default-type", "tls.join-dist"}}
    assert flags["osm.turn-lanes"] == "true"
    runtime = distribution("eclipse-sumo")
    binary = Path(runtime.locate_file("sumo/bin/netconvert.exe"))
    save("offline-check.json", {"status": "pass", "native_runs": 0, "netconvert_invoked": False,
        "installed_distribution_version": runtime.version, "installed_netconvert_file": str(binary), "installed_netconvert_sha256": digest(binary),
        "primary_source_commit": commit, "primary_sources": sources, "source_way_semantics": way_records,
        "current_passenger_connections": actual, "same_passenger_mapping_in_original_generated_network": True,
        "equal_target_count_conditional_allocation": conditional, "conditional_allocation_matches_exported_network": True,
        "OSM_relation_count_in_frozen_input": len(osm.findall("relation")), "relations_touching_relevant_ways": restrictions,
        "actual_original_conversion_flags": flags,
        "current_repository_visual_profile": _netconvert_profile_options("reference_visual_detail"),
        "current_repository_vehicle_core_profile": _netconvert_profile_options("vehicle_core"),
        "source_hashes": {str(p): digest(p) for p in [OSM, CURRENT, ORIGINAL, ROOT / "plugins/astra-sumo/src/astra_sumo/core/osm_network.py", ROOT / "plugins/astra-sumo/src/astra_sumo/core/osm_workflow.py"]},
        "claim_boundary": "The pinned source explains an allocation branch consistent with the exported mapping. No instrumented historical conversion, native build or simulation was run, so this does not prove that branch was executed or establish physical lane legality. Missing generated through links are not explicit restriction-relation evidence."})
    print(json.dumps({"status": "pass", "native_runs": 0, "primary_source_commit": commit, "conditional_mapping": conditional,
                      "related_restrictions_in_frozen_input": len(restrictions)}, indent=2))


if __name__ == "__main__":
    main()
