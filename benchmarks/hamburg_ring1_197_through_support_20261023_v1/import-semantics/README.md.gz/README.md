# 197进口转向支持的SUMO导入语义

发现一个由SUMO 1.27.1源码解释、且与现网一致的分配机制。它说明当前只保留lane2直行可能来自箭头与出口的推导匹配，不能当作现场禁止lane3/4直行的证明。本次没有调用netconvert、构网、仿真或更改输入。

## 箭头作用于哪个端点

安装的`eclipse-sumo`和`sumolib`均声明1.27.1。官方tag `v1_27_1`解析到commit `7717f2379d9e314a0c81c5cec748444de06a2a91`；下载的四份官方源码及安装版netconvert文件SHA见`offline-check.json`。这是版本源码审查，没有重新编译二进制。

[OSM导入器](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netimport/NIImporter_OpenStreetMap.cpp#L920-L1008)将forward箭头目标设为原way末节点，将backward箭头目标设为原way首节点。[应用前的检查](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBEdge.cpp#L2982-L2996)要求该目标等于当前出口节点。因此不是把整条route的最终目的地当成箭头目标。

| 原OSM way | 方向及标签 | 源码指定的箭头目标 |
|---|---|---|
| 186821028：197→315 | backward3车道，`left|through|right` | 1975693623 |
| 186821027：197→…→13879907 | oneway4车道，`left|through|right|right` | 13879907，即下游535端 |

原标签按驾驶方向从左到右排列。[导入器1563–1575](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netimport/NIImporter_OpenStreetMap.cpp#L1563-L1575)先按反向SUMO索引赋给机动车lane，之后才加自行车道和人行道。当前`-186821028`有lane0人行、lane1自行车、lane2–4机动车，对应关系是lane4=left、lane3=through、lane2=right。该步骤本身不是把through从中间lane误读到右侧lane。

## 为什么现网可能变成2直行、3停车、4掉头

[NBEdge::applyTurnSigns](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBEdge.cpp#L2725-L2818)先收集已有目标。若箭头种类与目标数量不同，会尝试按几何方向或权限筛选/报失败；**数量相等时直接按右到左的顺序配对**。该分支不再次要求箭头名称等于目标的几何方向。

本例三个签名按源码枚举排序为right、straight、left；三个机动车目标按右到左是535继续道路、停车左分支、掉头。条件分配为：

| 原箭头 | 进入lane | 排序对应目标 | 导出几何dir |
|---|---:|---|---|
| right | 2 | 186821027#0，继续535 | s |
| through | 3 | 28665128#0，停车支路 | l |
| left | 4 | 186821028，返回 | t |

离线代码只演示这个已有源码分支，并断言它与当前导出的三个passenger连接完全吻合。冻结的原始生成网络已经是同一映射，故该模式早于当前道路筛选和需求实验。lane1→lane1的另一个直行连接不允许passenger，不能算成第二条机动车通路。

[源码随后清除各有箭头lane的旧连接并按分配重建](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBEdge.cpp#L2867-L2949)。所以即使更早的几何推导曾提供其他直行连接，这个分支也可能不保留它们。但本次没有历史转换的中间状态或调用轨迹，不能声称已直接观察当次函数执行。也不能只凭这份代码判定源箭头究竟指停车节点还是实际下游路口；物理合法性由独立OSM/MAP/航片审查判断。

## 推导连接与显式禁转不同

官方[选项说明](https://sumo.dlr.de/docs/netconvert.html#formats)把`--osm.turn-lanes`定义为导入箭头以辅助建立连接；它确实会影响最终通路，不只是显示标记。官方[连接说明](https://sumo.dlr.de/docs/Networks/PlainXML.html#connection_descriptions)也说明未明确给出的连接使用推导规则，完整lane-to-lane输入可避免这类推导。

OSM的`type=restriction`、from/via/to禁转关系另走[RelationHandler::applyRestriction](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netimport/NIImporter_OpenStreetMap.cpp#L2895-L2944)，处理only/no及例外。被冻结输入有85个relation，但未找到涉及186821028、186821027或28665128的关系。这不证明现场没有限制，却表明当前缺失的lane3/4直行不能直接称为已找到的显式restriction证据。

导入完成后，车辆route使用已有网络连接。当前passenger若要从`-186821028`继续到535，只能使用2→2，或在上游合法变到lane2；route选择和`departLane=best`不会重新生成缺失的lane3/4连接。

## 仓库实际选项

当前`osm_network.py:742`的reference visual两种profile会加入`--osm.turn-lanes`、bike/sidewalk/crossing及TLS猜测选项，默认TLS类型为actuated。该profile保留turnaround；vehicle_core不加入这批profile选项，另外默认传`--no-turnarounds`。`build_osm_network`把这些选项加入实际command；`osm_workflow.py:3665`附近的视觉详细网络调用明确选择reference_visual_detail。

冻结原始网络头部也记录`osm.turn-lanes=true`，不是仅由当前仓库默认值推断。查询函数显式请求restriction relations，过滤器保留涉及保留way的restriction；本次没有推断仓库故意忽略禁转。

结论限于：存在一个可解释当前映射的导入推导机制；支路与掉头作为第三目标可能使三类箭头发生按序错配，并缩窄直行支持。它不是已证实的现场限制，也尚不是构网执行级的SUMO缺陷证明。不据此全局关闭arrow导入、删除停车/掉头、自行车连接或信号，也没有生成修复候选。
