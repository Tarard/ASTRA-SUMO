"""Read sealed one-pair FCD, queues and actual TLS; never run SUMO or edit inputs."""
from bisect import bisect_right
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
TRACE = REPO / 'outputs/hamburg-multifield-substitution-20261023-v1/trace-v2/baseline'
WINDOWS = ((14295, 14318, 'upstream_signal_gates'), (14348, 14363, 'receiving_lane_spillback'), (14363, 14371, 'receiving_release'))
LANES = ('-142944318_2', '-142944318_3', '-186821026_2', '-186821026_3', '-186821028_2', '-186821028_3', '-186821028_4',
    '186821027#0_2', '186821027#0_3', '186821027#0_4', '186821027#0_5', '142944337#1_0', '142944337#1_1', '486864288_1', '486864288_2')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def table(name, values):
    with (OUT / name).open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(values[0]))
        writer.writeheader()
        writer.writerows(values)


def main():
    names = ('cohort-fcd.xml', 'lanechanges.xml', 'tls-switch-states.xml', 'queues.xml', 'network.net.xml', 'demand.rou.xml',
        'lane-intentions.json', 'tripinfo.xml', 'record-result.json', 'signal-programs.add.xml')
    hashes = {n: digest(TRACE / n) for n in names}
    gate = json.loads((TRACE / 'record-result.json').read_bytes())
    assert gate['status'] == 'pass' and len(gate['checks']) == 12 and all(gate['checks'].values())
    demand = ET.parse(TRACE / 'demand.rou.xml').getroot()
    vehicles = {v.get('id'): v for v in demand.findall('vehicle')}
    trips = {v.get('id'): v for v in ET.parse(TRACE / 'tripinfo.xml').getroot().findall('tripinfo')}
    running = {i for i, v in trips.items() if float(v.get('arrival')) < 0}
    never_inserted = vehicles.keys() - trips.keys()
    assert len(running) == 16 and len(never_inserted) == 27
    assert all(vehicles[i].find('route').get('edges').split()[0] == '-142944318' for i in running | never_inserted)
    fields = {v['vehicle_id']: v['field_id'] for v in json.loads((TRACE / 'lane-intentions.json').read_bytes())['vehicles']}
    history, times = defaultdict(list), {}
    for _, r in ET.iterparse(TRACE / 'tls-switch-states.xml', events=('end',)):
        if r.tag == 'tlsState' and r.get('id') in ('1975693623', '315029332', 'LSA535_part0'):
            history[r.get('id')].append(dict(r.attrib))
        r.clear()
    for key, values in history.items():
        times[key] = [float(r['time']) for r in values]

    def state(identity, t):
        row = history[identity][bisect_right(times[identity], t)-1]
        links = (1,) if identity != 'LSA535_part0' else (2, 3, 4, 5, 7, 8)
        return dict(event_time_s=float(row['time']), phase=row['phase'], program=row['programID'],
            link_states={str(k): row['state'][k] for k in links})

    samples, fcd = defaultdict(list), {}
    for _, r in ET.iterparse(TRACE / 'cohort-fcd.xml', events=('end',)):
        if r.tag == 'timestep':
            t = float(r.get('time'))
            records = [dict(v.attrib, time_s=t, intended_field=fields[v.get('id')]) for v in r if v.get('id') in running]
            for v in records:
                samples[v['id']].append(v)
            if 14290 <= t <= 14390:
                fcd[t] = records
            r.clear()
    assert samples.keys() == running
    queues = {}
    for _, r in ET.iterparse(TRACE / 'queues.xml', events=('end',)):
        if r.tag == 'data':
            t = float(r.get('timestep'))
            if 14290 <= t <= 14390:
                queues[t] = {v.get('id'): dict(v.attrib) for v in r.findall('./lanes/lane') if v.get('id') in LANES}
            r.clear()
    timeline = []
    for t in sorted(queues):
        row = dict(time_s=t, tls197_link1=state('1975693623', t)['link_states']['1'], tls315_link1=state('315029332', t)['link_states']['1'])
        for k, value in state('LSA535_part0', t)['link_states'].items():
            row['tls535_link'+k] = value
        row.update({lane+'_reported_queue_extent_m': queues[t].get(lane, {}).get('queueing_length', '') for lane in LANES})
        timeline.append(row)
    table('queue-and-tls-14290-14390.csv', timeline)
    summaries, terminal = [], []
    for identity, values in sorted(samples.items()):
        final = values[-1]
        terminal.append(final)
        summaries.append(dict(vehicle_id=identity, intended_field=fields[identity], first_FCD_s=values[0]['time_s'], last_FCD_s=final['time_s'],
            last_lane=final['lane'], last_pos_m=final['pos'], last_speed_m_s=final['speed'], last_leader=final['leaderID'], last_gap_m=final['leaderGap'],
            near_stop_samples=sum(float(r['speed']) < .1 for r in values), samples=len(values),
            lane_samples=json.dumps(Counter(r['lane'] for r in values)), requested_depart_s=vehicles[identity].get('depart'), actual_depart_s=trips[identity].get('depart')))
    table('running16-summary.csv', summaries)
    table('running16-last-FCD.csv', terminal)
    table('not-inserted27-requests.csv', [dict(vehicle_id=i, requested_depart_s=vehicles[i].get('depart'), intended_field=fields[i], origin='-142944318', position='unknown: never inserted') for i in sorted(never_inserted)])
    scenes = []
    for begin, end, label in WINDOWS:
        scenes.append(dict(label=label, begin_s=begin, end_exclusive_s=end, samples=[dict(time_s=t, FCD=fcd.get(t, []),
            actual_TLS={identity: state(identity, t) for identity in history}, queues=queues.get(t, {})) for t in range(begin, end)]))
    save('scenes.json', scenes)
    changes = [dict(r.attrib) for r in ET.parse(TRACE / 'lanechanges.xml').getroot() if r.get('id') in running]
    save('running16-lanechanges.json', changes)
    save('actual-TLS-events.json', {key: [r for r in values if 14290 <= float(r['time']) < 14391] for key, values in history.items()})
    net = ET.parse(TRACE / 'network.net.xml').getroot()
    topology = [dict(r.attrib) for r in net.findall('connection') if r.get('from') in ('-142944318', '-186821026', '-186821028', '186821027#0')]
    save('current-lane-connections.json', topology)
    save('source-hashes.json', dict(native_runs=0, source=str(TRACE), sha256=hashes, observer_parity_checks=12))
    summary = dict(status='review_required', new_native_runs=0, running=16, never_inserted=27,
        first_running_cohort_FCD_s=min(v[0]['time_s'] for v in samples.values()), last_FCD_s=14399,
        last_lane_distribution=dict(Counter(r['lane'] for r in terminal)), intervals=WINDOWS,
        boundary='Only the declared terminal cohort has FCD. Queue extent is an identity-free aggregate; a missing queue row does not establish empty storage. No position is assigned to the 27 never-inserted requests. These late windows cannot identify the first queue onset over the whole run.')
    save('analysis.json', summary)
    assert hashes == {n: digest(TRACE / n) for n in names}
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
