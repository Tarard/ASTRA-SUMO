"""One bounded normal-entry timing revision; reuse the frozen safety driver."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    frozen = root.parent / 'run_smoke.executed-v5.py'
    spec = spec_from_file_location('frozen_safety_driver', frozen)
    driver = module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.ROOT = root
    candidate = root.parent.parent / 'candidate-v5'
    driver.run('uturn-yellow', 'native', (candidate / 'network.net.xml').resolve(strict=True),
        (candidate / 'control.add.xml').resolve(strict=True))


if __name__ == '__main__':
    main()
