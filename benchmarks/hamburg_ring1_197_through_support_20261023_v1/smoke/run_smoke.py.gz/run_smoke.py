"""Prepare or explicitly run a small normal-entry safety probe; never calibrate."""
import argparse
from collections import Counter, defaultdict
import copy
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import time
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SELECTED = REPO / 'outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation'
BASE = SELECTED.parents[1] / 'prepared'
FIELDS = {5: 'hh_0535_Z_5_30894', 6: 'hh_0535_Z_6_33855', 7: 'hh_0535_Z_7_29316', 8: 'hh_0535_Z_8_34287'}
MOVEMENTS = {14: ('-186821028', 3, '186821027#0', 4), 15: ('-186821028', 4, '186821027#0', 5),
    9: ('186821029#1', 3, '186821027#0', 5), 2: ('-186821028', 3, '28665128#0', 0)}
CASES = ('original8', 'uturn-p0', 'uturn-p1', 'uturn-yellow', 'left-p3', 'through-yellow', 'solo9', 'new14')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def allowed(lane):
    return ('allow' not in lane.attrib or 'passenger' in lane.get('allow').split()) and 'passenger' not in lane.get('disallow', '').split()


def route_support(network, route):
    lanes = {r.get('id'): r for r in network.iter('lane')}
    for before, after in zip(route, route[1:]):
        assert any(c.get('from') == before and c.get('to') == after and allowed(lanes[f"{before}_{c.get('fromLane')}"])
            and allowed(lanes[f"{after}_{c.get('toLane')}"]) for c in network.findall('connection')), (before, after)


def pair_jobs(representatives):
    specs = [('uturn-p0', 'minor', 9, dict(phase=0, cycle=0)),
        ('uturn-p0', 'major', 15, dict(phase=0, cycle=0, anchor_vehicle='uturn-p0_minor', anchor_distance_m=12)),
        ('uturn-p1', 'minor', 9, dict(phase=1, cycle=0)),
        ('uturn-p1', 'major', 15, dict(phase=1, cycle=0, anchor_vehicle='uturn-p1_minor', anchor_distance_m=12)),
        ('uturn-yellow', 'minor', 9, dict(phase=1, cycle=0, remaining_at_most_s=1.5)),
        ('uturn-yellow', 'major', 15, dict(phase=[1, 2], cycle=0, anchor_vehicle='uturn-yellow_minor', anchor_distance_m=12)),
        ('left-p3', 'minor', 2, dict(phase=3, cycle=0)), ('left-p3', 'major', 15, dict(phase=3, cycle=0)),
        ('through-yellow', 'minor', 2, dict(phase=3, cycle=0, remaining_at_most_s=.2)),
        ('through-yellow', 'major', 15, dict(phase=3, cycle=0, remaining_at_most_s=.1)),
        ('solo9', 'minor', 9, dict(phase=0, cycle=0)), ('new14', 'major', 14, dict(phase=0, cycle=0))]
    jobs = []
    for case, role, movement, trigger in specs:
        z = 7 if movement == 14 else 8
        original = representatives[z]
        attrs = dict(original.attrib)
        attrs['departLane'] = str(MOVEMENTS[movement][1])
        jobs.append(dict(id=case+'_'+role, case=case, field=None if movement == 2 else FIELDS[z], source_id=original.get('id'),
            route_id=f'r_m{movement}', vehicle_attributes=attrs, trigger=trigger, movement=movement))
    return jobs


def prepare():
    out = ROOT / 'inputs'
    assert not out.exists(), 'Preserve prepared inputs; do not overwrite them.'
    out.mkdir()
    source = ET.parse(SELECTED / 'demand.rou.xml').getroot()
    fields = {r['vehicle_id']: r['field_id'] for r in json.loads((SELECTED / 'lane-intentions.json').read_bytes())['vehicles']}
    network = ET.parse(BASE / 'network.net.xml').getroot()
    routes = ET.Element('routes')
    for r in source:
        if r.tag != 'vehicle':
            routes.append(copy.deepcopy(r))
    jobs, representatives = [], {}
    for z, field in FIELDS.items():
        originals = [v for v in source.findall('vehicle') if fields[v.get('id')] == field and v.find('route').get('edges').split()[0] == '-142944318'][:2]
        assert len(originals) == 2
        representatives[z] = originals[0]
        for k, original in enumerate(originals):
            identity = f'original_Z{z}_{k}'
            route = ET.SubElement(routes, 'route', id='r_'+identity, edges=original.find('route').get('edges'))
            for stop in original.findall('stop'):
                route.append(copy.deepcopy(stop))
            route_support(network, route.get('edges').split())
            assert ET.tostring(route.find('stop')) == ET.tostring(original.find('stop'))
            assert set(original.attrib) == {'type', 'departLane', 'departPos', 'departSpeed', 'id', 'depart'}
            jobs.append(dict(id=identity, case='original8', field=field, source_id=original.get('id'), route_id=route.get('id'),
                vehicle_attributes=dict(original.attrib), trigger=dict(time_s=len(jobs)*3), movement=None))
    suffix = ['186821027#0', '186821036#1', '186821036#2', '142944477']
    for movement in (14, 15, 9):
        first, lane, _, _ = MOVEMENTS[movement]
        z = 7 if movement == 14 else 8
        route = ET.SubElement(routes, 'route', id=f'r_m{movement}', edges=' '.join([first] + suffix))
        route.append(copy.deepcopy(representatives[z].find('stop')))
        route_support(network, [first] + suffix)
    ET.SubElement(routes, 'route', id='r_m2', edges='-186821028 28665128#0')
    route_support(network, ['-186821028', '28665128#0'])
    jobs += pair_jobs(representatives)
    ET.ElementTree(routes).write(out / 'routes.rou.xml', encoding='utf-8', xml_declaration=True)
    (out / 'field-loops.add.xml').write_bytes((BASE / 'field-loops.add.xml').read_bytes())
    save(out / 'jobs.json', dict(formal_result=False, end_s=600, seed=104, step_s=.1, jobs=jobs,
        actual_event_coverage_required=True, nominal_phase_duration_not_used=True,
        allowed_mutators=['normal vehicle.add with declared ordinary-road entry parameters', 'existing LaneSectionHold laneChangeMode only'],
        prohibited=['setSpeed', 'changeLane', 'moveTo', 'moveToXY', 'setPhase', 'setRedYellowGreenState', 'collision disabling']))
    save(out / 'preparation.json', dict(status='prepared_awaiting_final_candidate', new_native_runs=0,
        sources={str(p): sha(p) for p in (SELECTED / 'demand.rou.xml', SELECTED / 'lane-intentions.json', BASE / 'network.net.xml', BASE / 'field-loops.add.xml')},
        inputs={p.name: sha(p) for p in out.iterdir()}, route_stops='Original moving-stop XML copied into native named route definitions; route schema vehicleRouteType permits stop children.',
        source_vType=ET.tostring(source.find('vType'), encoding='unicode'), case_sizes=dict(Counter(r['case'] for r in jobs))))
    print('Prepared five independent two-car cases plus solo Uturn and new14; no native simulation.', flush=True)


def support(net_file, control_file):
    net, control = ET.parse(net_file).getroot(), ET.parse(control_file).getroot()
    lanes = {r.get('id'): r for r in net.iter('lane')}
    paths = {}
    for index, (before, before_lane, after, after_lane) in MOVEMENTS.items():
        matches = [c for c in net.findall('connection') if (c.get('from'), int(c.get('fromLane')), c.get('to'), int(c.get('toLane'))) == (before, before_lane, after, after_lane)]
        assert len(matches) == 1 and matches[0].get('tl') == '1975693623' and int(matches[0].get('linkIndex')) == index
        assert allowed(lanes[f'{before}_{before_lane}']) and allowed(lanes[f'{after}_{after_lane}'])
        via, path = matches[0].get('via'), []
        while via:
            assert via not in path and allowed(lanes[via])
            path.append(via)
            edge, lane = via.rsplit('_', 1)
            next_links = [c for c in net.findall('connection') if c.get('from') == edge and int(c.get('fromLane')) == int(lane)]
            assert len(next_links) == 1
            via = next_links[0].get('via')
        paths[index] = path
    program = next(r for r in control.findall('tlLogic') if r.get('id') == '1975693623')
    assert program.get('type') == 'actuated'
    phases = program.findall('phase')
    assert len(phases) == 7 and all(len(r.get('state')) == 16 for r in phases)
    assert all(r.get('state')[14:] == r.get('state')[1]*2 for r in phases)
    assert all(phases[k].get('state')[9] == 'g' and phases[k].get('state')[15] == 'G' for k in (0, 1))
    assert phases[2].get('state')[9] == 'y' and phases[3].get('state')[9] == 'r' and phases[4].get('state')[15] == 'y'
    original = next(r for r in ET.parse(BASE / 'control.add.xml').getroot().findall('tlLogic') if r.get('id') == '1975693623')
    for old, new in zip(original.findall('phase'), phases, strict=True):
        assert {k: v for k, v in old.attrib.items() if k != 'state'} == {k: v for k, v in new.attrib.items() if k != 'state'}
        expected = list(old.get('state'))
        for index in (2, 9):
            if expected[index] == 'G' and new.get('state')[15] == 'G':
                expected[index] = 'g'
        assert new.get('state')[:14] == ''.join(expected)
    for r in ET.parse(ROOT / 'inputs/routes.rou.xml').getroot().findall('route'):
        route_support(net, r.get('edges').split())
    return net, paths


def run(case, name, net_file, control_file):
    # This function is reached only by the explicit --execute CLI action.
    import libsumo as api
    import sumo
    from traci import constants as tc
    from astra_sumo.core.lane_section_hold import LaneSectionHold
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

    assert api.__version__ == '1.27.1' and {version(n) for n in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')} == {'1.27.1'}
    net, paths = support(net_file, control_file)
    settings = json.loads((ROOT / 'inputs/jobs.json').read_bytes())
    jobs = [r for r in settings['jobs'] if r['case'] == case]
    end, out = settings['end_s'], ROOT / name
    assert not out.exists() and name not in ('inputs', '.', '..') and out.parent == ROOT
    out.mkdir()
    source_paths = [net_file, control_file, ROOT / 'inputs/routes.rou.xml', ROOT / 'inputs/field-loops.add.xml', ROOT / 'inputs/jobs.json', Path(__file__)]
    source_paths += [REPO / 'plugins/astra-sumo/src/astra_sumo/core' / n for n in ('lane_section_hold.py', 'route_sensor_matrix.py')]
    hashes = {str(p): sha(p) for p in source_paths}
    loops = ET.parse(ROOT / 'inputs/field-loops.add.xml').getroot()
    instant, mapping, detectors = ET.Element('additional'), {}, {}
    for r in loops:
        r.set('file', str(out / 'field-counts.xml'))
        r.set('period', str(end))
        r.set('end', str(end))
        detectors[r.get('id')] = (r.get('lane'), float(r.get('pos')))
        identity = 'instant_' + r.get('id')
        mapping[identity] = r.get('id')
        ET.SubElement(instant, 'instantInductionLoop', id=identity, lane=r.get('lane'), pos=r.get('pos'), file=str(out / 'instant-e1.xml'))
    assert len(detectors) == 13
    ET.ElementTree(loops).write(out / 'loops.add.xml', encoding='utf-8', xml_declaration=True)
    ET.ElementTree(instant).write(out / 'instant.add.xml', encoding='utf-8', xml_declaration=True)
    observer = ET.Element('additional')
    ET.SubElement(observer, 'timedEvent', type='SaveTLSSwitchStates', dest=str(out / 'tls-switch-states.xml'))
    ET.ElementTree(observer).write(out / 'observer.add.xml', encoding='utf-8', xml_declaration=True)
    command = [str(Path(sumo.__file__).parent / 'bin/sumo.exe'), '--net-file', str(net_file), '--route-files', str(ROOT / 'inputs/routes.rou.xml'),
        '--additional-files', ','.join(map(str, (control_file, out / 'loops.add.xml', out / 'instant.add.xml', out / 'observer.add.xml'))),
        '--end', str(end), '--step-length', '.1', '--seed', '104', '--precision', '12', '--time-to-teleport', '-1', '--collision.check-junctions', 'true',
        '--summary-output', str(out / 'summary.xml'), '--tripinfo-output', str(out / 'tripinfo.xml'), '--tripinfo-output.write-unfinished', 'true',
        '--vehroute-output', str(out / 'vehicle-routes.xml'), '--vehroute-output.exit-times', 'true', '--collision-output', str(out / 'collisions.xml'),
        '--lanechange-output', str(out / 'lanechanges.xml'), '--fcd-output', str(out / 'fcd.xml'), '--device.fcd.probability', '1', '--device.fcd.period', '.1',
        '--error-log', str(out / 'sumo-errors.log'), '--log', str(out / 'sumo.log'), '--no-step-log', 'true']
    body_nodes = ('14398547', '205069138', '18653534', 'LSA104_part0')
    internal = {lane.get('id'): float(lane.get('length')) for edge in net.findall('edge') if edge.get('function') == 'internal'
        and any(edge.get('id').startswith(':'+n+'_') for n in body_nodes) for lane in edge.findall('lane')}
    assignments = {r['id']: detectors[r['field']] for r in jobs if r['field'] is not None}
    driver = LaneSectionHold(assignments, junction_lane_lengths=internal)
    commands, samples, entered, pending, insertions = [], [], {}, {r['id']: r for r in jobs}, {}
    transitions, flags = [], defaultdict(list)
    from libsumo import _libsumo
    save(out / 'request.json', dict(command=command, inputs=hashes, case=case, jobs=jobs, paths=paths, formal_result=False,
        runtime=dict(python=str(Path(__import__('sys').executable)), versions={n: version(n) for n in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')}, libsumo_sha256=sha(Path(_libsumo.__file__))),
        mutator_scope='Normal vehicle.add only, plus unchanged core LaneSectionHold mode512/restoration. No position, lane, speed, TLS or collision overrides.'))

    class LoggedVehicle:
        def __getattr__(self, key):
            return getattr(api.vehicle, key)

        def setLaneChangeMode(self, identity, mode):
            commands.append(dict(time_s=api.simulation.getTime(), api='vehicle.setLaneChangeMode', arguments=[identity, mode], source='unchanged core LaneSectionHold'))
            api.vehicle.setLaneChangeMode(identity, mode)

    previous_phase, cycle, started, native_started = None, -1, time.perf_counter(), False
    try:
        api.start(command)
        native_started = True
        save(out / 'native-version.json', dict(native_version=api.getVersion()))
        while api.simulation.getTime() < end:
            now = round(api.simulation.getTime(), 1)
            phase, signal = api.trafficlight.getPhase('1975693623'), api.trafficlight.getRedYellowGreenState('1975693623')
            remaining = api.trafficlight.getNextSwitch('1975693623') - now
            if phase != previous_phase:
                if phase == 0:
                    cycle += 1
                transitions.append(dict(time_s=now, previous=previous_phase, phase=phase, state=signal, next_switch_s=now+remaining, cycle=cycle))
                previous_phase = phase
            for identity, job in list(pending.items()):
                trigger = job['trigger']
                phases = trigger.get('phase')
                allowed_phases = phases if isinstance(phases, list) else [phases]
                ready = now >= trigger['time_s'] if 'time_s' in trigger else phase in allowed_phases and cycle == trigger['cycle'] and remaining <= trigger.get('remaining_at_most_s', float('inf')) + 1e-7
                if ready and 'anchor_vehicle' in trigger:
                    anchor = trigger['anchor_vehicle']
                    ready = anchor in api.vehicle.getIDList() and any(t[0] == '1975693623' and t[2] <= trigger['anchor_distance_m'] for t in api.vehicle.getNextTLS(anchor))
                if not ready:
                    continue
                attrs = job['vehicle_attributes']
                arguments = dict(vehID=identity, routeID=job['route_id'], typeID=attrs['type'], depart='now',
                    departLane=attrs['departLane'], departPos=attrs['departPos'], departSpeed=attrs['departSpeed'])
                api.vehicle.add(**arguments)
                assert len(api.vehicle.getStops(identity)) == int(job['field'] is not None)
                if job['field'] is not None:
                    assert float(api.vehicle.getStopParameter(identity, 0, 'speed')) == 13.888889
                commands.append(dict(time_s=now, api='vehicle.add', arguments=arguments, actual_phase=phase, actual_state=signal, next_switch_s=now+remaining))
                insertions[identity] = dict(requested_add_s=now, actual_insert_s=None)
                del pending[identity]
            api.simulationStep()
            now = round(api.simulation.getTime(), 1)
            phase, signal = api.trafficlight.getPhase('1975693623'), api.trafficlight.getRedYellowGreenState('1975693623')
            present = api.vehicle.getIDList()
            states = {i: {tc.VAR_LANE_ID: api.vehicle.getLaneID(i), tc.VAR_LANEPOSITION: api.vehicle.getLanePosition(i),
                tc.VAR_DISTANCE: api.vehicle.getDistance(i), tc.VAR_SPEED: api.vehicle.getSpeed(i)} for i in present}
            driver.step(LoggedVehicle(), {i: r for i, r in states.items() if i in assignments}, now)
            row = dict(time_s=now, phase=phase, state=signal, next_switch_s=api.trafficlight.getNextSwitch('1975693623'), vehicles={})
            by_id = {r['id']: r for r in jobs}
            for identity in present:
                assert api.vehicle.getSpeedMode(identity) == 31
                if insertions[identity]['actual_insert_s'] is None:
                    insertions[identity].update(actual_insert_s=api.vehicle.getDeparture(identity), first_seen_poststep_s=now,
                        native_depart_delay_s=api.vehicle.getDepartDelay(identity), delay_from_add_s=api.vehicle.getDeparture(identity)-insertions[identity]['requested_add_s'])
                movement = by_id[identity]['movement']
                lane = api.vehicle.getLaneID(identity)
                position = api.vehicle.getLanePosition(identity)
                next_tls = api.vehicle.getNextTLS(identity)
                near_197 = bool(movement and lane in paths[movement]) or any(t[0] == '1975693623' and t[2] <= 25 for t in next_tls)
                row['vehicles'][identity] = dict(lane=lane, pos_m=position, speed_m_s=api.vehicle.getSpeed(identity), near_197=near_197,
                    leader=api.vehicle.getLeader(identity, 100), next_TLS=next_tls, next_links=api.vehicle.getNextLinks(identity),
                    speed_mode=31, lane_change_mode=api.vehicle.getLaneChangeMode(identity))
                if movement and identity not in entered and lane in paths[movement]:
                    entered[identity] = dict(time_s=now, phase=phase, state=signal, movement=movement, lane=lane,
                        previous_sample_phase=samples[-1]['phase'] if samples else None, previous_sample_s=samples[-1]['time_s'] if samples else None)
                if movement == 9 and identity in entered and (lane in paths[9] or lane == '186821027#0_5' and position < api.vehicle.getLength(identity)) and phase == 3:
                    flags['old9_body_occupied_phase3'].append(dict(time_s=now, vehicle_id=identity, lane=lane, pos_m=position, state=signal))
            samples.append(row)
    except Exception as error:
        save(out / 'failure.json', dict(status='failed', error=f'{type(error).__name__}: {error}', native_started=native_started,
            pending_jobs=sorted(pending), entered_movements=entered, insertion_records=insertions, formal_result=False))
        raise
    finally:
        if native_started:
            api.close()
        save(out / 'commands.json', commands)
        save(out / 'samples.json', samples)
        save(out / 'driver-holds.json', driver.report())
    events = read_contributing_e1_passages(instant_file=out / 'instant-e1.xml', periodic_file=out / 'field-counts.xml', detector_ids=mapping, step_length=.1)
    save(out / 'complete-passages.json', events)
    actual = defaultdict(list)
    for event in sorted(events['passages'], key=lambda r: r['time_s']):
        actual[event['vehicle_id']].append(event['detector_id'])
    complete = all(actual[r['id']].count(r['field']) == 1 if r['field'] is not None else not actual[r['id']] for r in jobs)
    collisions = [r.attrib for r in ET.parse(out / 'collisions.xml').getroot().findall('collision')]
    trips = ET.parse(out / 'tripinfo.xml').getroot().findall('tripinfo')
    final = ET.parse(out / 'summary.xml').getroot()[-1]
    unsafe = {k: int(final.get(k)) for k in ('collisions', 'teleports', 'discarded')}
    coverage = dict(all_jobs_injected=not pending, all_inserted=len(insertions) == len(jobs) and all(r['actual_insert_s'] is not None for r in insertions.values()),
        all_arrived=len(trips) == len(jobs) and all(float(r.get('arrival')) >= 0 and not r.get('vaporized', '') for r in trips),
        all_expected_fields_complete=complete, no_unexpected_fields=all(set(actual[r['id']]) <= ({r['field']} if r['field'] else set()) for r in jobs),
        reconciled_E1=events['reconciled'], all_declared_movements_used=all(r['id'] in entered for r in jobs if r['movement'] is not None))
    if case in ('uturn-p0', 'uturn-p1', 'left-p3'):
        target_phase, minor = {'uturn-p0': (0, 9), 'uturn-p1': (1, 9), 'left-p3': (3, 2)}[case]
        coverage['actual_parallel_minor_g_major_G'] = any(r['phase'] == target_phase and r['state'][minor] == 'g' and r['state'][15] == 'G'
            and all(r['vehicles'].get(i, {}).get('near_197', False) for i in (case+'_minor', case+'_major')) for r in samples)
    if case == 'uturn-yellow':
        coverage.update(old9_enters_in_yellow=any(r['movement'] == 9 and r['phase'] == r['previous_sample_phase'] == 2 and r['state'][9] == 'y' for r in entered.values()),
            old9_body_occupied_phase3=bool(flags['old9_body_occupied_phase3']))
    if case == 'through-yellow':
        coverage['through_enters_phase4_yellow'] = any(r['movement'] == 15 and r['phase'] == r['previous_sample_phase'] == 4 and r['state'][15] == 'y' for r in entered.values())
    result = dict(status='blocked' if collisions or any(unsafe.values()) else 'pass' if all(coverage.values()) else 'review_required', formal_result=False,
        toy_only_not_count_fit=True, safety=unsafe, collision_rows=collisions, coverage=coverage, entered_movements=entered, actual_insertions=insertions,
        pending_jobs=sorted(pending), transitions=transitions, body_coverage=flags, actual_fields=dict(actual), elapsed_s=time.perf_counter()-started,
        source_inputs_unchanged=all(sha(Path(p)) == h for p, h in hashes.items()))
    save(out / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--prepare-only', action='store_true')
    actions.add_argument('--execute', action='store_true')
    parser.add_argument('--case', choices=CASES)
    parser.add_argument('--name')
    parser.add_argument('--net-file', type=Path)
    parser.add_argument('--control-file', type=Path)
    args = parser.parse_args()
    if args.prepare_only:
        prepare()
    else:
        if not all((args.case, args.name, args.net_file, args.control_file)):
            parser.error('--execute requires --case, --name, --net-file and --control-file.')
        run(args.case, args.name, args.net_file.resolve(strict=True), args.control_file.resolve(strict=True))


if __name__ == '__main__':
    main()
