"""The one authorized corrective pair; reuse the frozen normal-entry driver."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    spec = spec_from_file_location('frozen_safety_driver', root.parent / 'run_smoke.executed-v5.py')
    driver = module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.ROOT = root
    candidate = root.parent.parent / 'candidate-v5'
    driver.run('uturn-p0', 'native', (candidate / 'network.net.xml').resolve(strict=True),
        (candidate / 'control.add.xml').resolve(strict=True))


if __name__ == '__main__':
    main()
