# 197候选v5的有限普通入口探针

实际完成10次小运行、24个小车请求：9项pass，1项review_required。没有完整8640辆运行，也不构成计数标定或全交通安全保证。候选固定为network `68d2f6d2…`、control `f9adfb5c…`；实际执行脚本`run_smoke.executed-v5.py` SHA256为`54d8bb583c8690d0e087f96d1a29adcdcc0e366c23d29b0559b85923ad947107`。所有运行均为0碰撞、0传送、0丢弃，原始警告日志保留。

原生FCD与TLS以步骤起点标时；`samples.json`中的TraCI时间为步后时间，比原生标时大0.1秒。`audit_smokes.py`已对全部逐车样本的车道、位置、速度和197实际state/phase重新核对；下表使用原生时间。

| 运行 | 实际覆盖 | 结论 |
|---|---|---|
| original8-v5 | 原始-142入口与Z5–8全路线各2辆；全部到达、指定完整贡献各2，无意外字段 | pass；两Z7车实际经新14，两Z8车实际经新15 |
| uturn-p0-v5 | phase0为g9/G15；直行1.2秒进入，掉头2.5秒进入 | pass，均正常到达 |
| uturn-p1-v5 | phase1为g9/G15；直行6.3秒进入，掉头7.6秒进入 | pass |
| left-p3-v5 | phase3为g2/G15；直行13.4秒进入，原停车左转14.0秒进入 | pass |
| uturn-yellow-v5 | 原掉头11.0秒在phase2黄灯进入，原生13.0/13.1秒phase3后体仍未清空 | pass；此运行的直行已较早通过，不单凭它宣称并行清空冲突已覆盖 |
| through-yellow-v5 | 新15于18.2秒在phase4黄灯进入；原左转等待下一绿灯后才通过 | pass，不把左转等待说成黄灯承诺 |
| solo9-v5 | 单独原掉头经原9全路径、完成Z8并到达合法边界 | pass |
| clearance-revision/native | 只改直行的普通add请求为实际phase2末段；phase3时其报告尚未清空的掉头车为leader | pass；未修改前一运行的输入 |
| new14-v5 | 正常用到新14，但试验将Z7 lane4 waypoint接到Z8后缀，需走既有535 link5 | review_required：该link无绿，600秒仍停lane4 pos25.619m，无完整贡献；保留原失败，不重跑掩盖 |
| corrective-new14-old9/native | 单独保存的唯一纠正pair：新14改回原Z7全后缀，原9保留原Z8全后缀；实际phase0 g9/G14 | pass；原生1.2/2.5秒分别入新14/原9，均到达，只各贡献Z7/Z8 |

新14的合法完整路线证据来自original8：`original_Z7_0/_1`在原生15.1–15.5秒、18.2–18.7秒实际经过`:1975693623_0_2`，随后沿原Z7→43305966→551303415路线到达并完成Z7。失败solo所用535 link5的声明state集合不含g/G；这不是新14路段缺失的证据，也不能把它改称成功。

主任务另行授权的最后纠正pair只修正上述试验字段与后缀的不匹配，并与原掉头配对。`assembly-check.json`先确认原Z7 lane4→43305966为535 link4且有绿服务，再运行普通入口两车；没有修改v5、原9车路线或前9项输入。该对完成g9/G14并行近场、两条实际内部路径和不同字段完整贡献。前9项摘要、文档、审核脚本与manifest另存`*-pre-corrective-9`或`manifest.before-corrective-9.json`，坏solo保留。

唯一追加的clearance小对照保留原掉头请求，只将直行请求改到实际phase2末端，另存完整输入。原生13.0/13.1秒，掉头前端在接收lane5 pos4.040/4.635m，5米车体的后端仍未清空；直行尚在入口lane4，原生速度5.180/5.353m/s，报告该掉头车为leader、gap4.949/5.009m。它于13.5秒进入新15，此时旧车后体已清空。这里只报告这次正常跟驰和清空顺序，没有强制两车车头同时进入冲突区。

全部车辆通过普通`vehicle.add`进入原普通道路，保留源vType、正常入口参数及相应moving-stop；原停车左转按合法28665128边界离开，没有检测waypoint。未使用setSpeed、changeLane、moveTo、位置重设、信号强制或碰撞禁用。唯一车道模式指令来自原LaneSectionHold，完整模式指令与add请求在commands.json；全部实际speedMode为31，实际出发与延迟以原生getDeparture/getDepartDelay及tripinfo核对。

phase0/3按实际感应状态和getNextSwitch观测触发，未把nominal63秒当固定phase0。入口延迟、未覆盖条件和未完成行程均保留。此次未加入行人、自行车或连续饱和来流，不能替代这些场景验证，更不证明现场信号或几何来源正确。

`audit.json`逐项保存原始状态、原生计数和时标核对；`execution-v5.json`是启动前快照，`inputs/preparation.json`及早期jobs草稿为准备历史。所有真实运行、失败solo、唯一追加对照、FCD/LC/TLS/summary/trips/routes/collisions/E1和日志均保留。没有继续追加原生运行。
