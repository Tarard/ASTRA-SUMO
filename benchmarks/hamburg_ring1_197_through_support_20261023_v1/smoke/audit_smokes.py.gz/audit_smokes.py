"""Reconcile completed toy probes with raw native outputs; never start SUMO."""
from bisect import bisect_right
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
NAMES = ('original8', 'left-p3', 'uturn-p0', 'uturn-p1', 'uturn-yellow', 'through-yellow', 'solo9', 'new14')


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(path):
    result, request, samples = [read(path / name) for name in ('result.json', 'request.json', 'samples.json')]
    assert result['status'] in ('pass', 'review_required') and result['source_inputs_unchanged']
    assert (result['status'] == 'pass') == all(result['coverage'].values())
    assert not any(result['safety'].values()) and result['collision_rows'] == []
    assert all(sha(Path(p)) == h for p, h in request['inputs'].items())
    assert all(row['api'] in ('vehicle.add', 'vehicle.setLaneChangeMode') for row in read(path / 'commands.json'))
    assert all(row['source'] == 'unchanged core LaneSectionHold' for row in read(path / 'commands.json') if row['api'] == 'vehicle.setLaneChangeMode')
    command = request['command']
    assert command[command.index('--time-to-teleport')+1] == '-1' and command[command.index('--collision.check-junctions')+1] == 'true'
    assert len(ET.parse(path / 'collisions.xml').getroot()) == 0
    jobs = {r['id']: r for r in request['jobs']}
    trips = {r.get('id'): r for r in ET.parse(path / 'tripinfo.xml').getroot()}
    assert trips.keys() == jobs.keys()
    final = ET.parse(path / 'summary.xml').getroot()[-1]
    assert all(int(final.get(k)) == len(jobs) for k in ('loaded', 'inserted'))
    arrived = {i for i, r in trips.items() if float(r.get('arrival')) >= 0 and not r.get('vaporized', '')}
    assert int(final.get('arrived')) == len(arrived) and int(final.get('running')) == len(jobs)-len(arrived)
    assert all(int(final.get(k)) == 0 for k in ('waiting', 'collisions', 'teleports', 'discarded'))
    for identity, trip in trips.items():
        assert trip.get('vaporized', '') in ('', 'end')
        insertion = result['actual_insertions'][identity]
        assert float(trip.get('depart')) == insertion['actual_insert_s']
        assert math.isclose(float(trip.get('departDelay')), insertion['native_depart_delay_s'], abs_tol=1e-9)
    route_file = Path(next(p for p in request['inputs'] if p.endswith('routes.rou.xml')))
    routes = {r.get('id'): r for r in ET.parse(route_file).getroot().findall('route')}
    native_routes = {r.get('id'): r.find('route') for r in ET.parse(path / 'vehicle-routes.xml').getroot().findall('vehicle')}
    assert native_routes.keys() == arrived
    for identity, route in native_routes.items():
        assert route.get('edges') == routes[jobs[identity]['route_id']].get('edges')
        exits = list(map(float, route.get('exitTimes').split()))
        assert len(exits) == len(route.get('edges').split()) and all(math.isfinite(t) and t >= 0 for t in exits)
    tls = [r.attrib for r in ET.parse(path / 'tls-switch-states.xml').getroot() if r.get('id') == '1975693623']
    tls_times = [float(r['time']) for r in tls]
    fcd = {int(round(float(t.get('time'))*10)): {v.get('id'): v.attrib for v in t} for t in ET.parse(path / 'fcd.xml').getroot()}
    checked = 0
    for sample in samples:
        tick = int(round(sample['time_s']*10)) - 1
        state = tls[bisect_right(tls_times, tick/10 + 1e-8)-1]
        assert state['state'] == sample['state'] and int(state['phase']) == sample['phase']
        actual = fcd[tick]
        assert actual.keys() == sample['vehicles'].keys()
        for identity, row in sample['vehicles'].items():
            assert row['speed_mode'] == 31 and row['lane_change_mode'] in (512, 1621)
            assert row['lane'] == actual[identity]['lane']
            assert math.isclose(row['pos_m'], float(actual[identity]['pos']), abs_tol=1e-9)
            assert math.isclose(row['speed_m_s'], float(actual[identity]['speed']), abs_tol=1e-9)
            checked += 1
    counts = {(r.get('id'), float(r.get('begin')), float(r.get('end'))): int(r.get('nVehContrib')) for r in ET.parse(path / 'field-counts.xml').getroot() if r.get('begin') != r.get('end')}
    assert len(counts) == 13
    passages = read(path / 'complete-passages.json')
    assert passages['reconciled'] and Counter((r['detector_id'], r['interval_begin_s'], r['interval_end_s']) for r in passages['passages']) == Counter(counts)
    entries = {identity: dict(r, native_FCD_time_s=round(r['time_s']-.1, 1), poststep_API_time_s=r['time_s']) for identity, r in result['entered_movements'].items()}
    return dict(status=result['status'], evidence_reconciled=True, toy_vehicles=len(jobs), safety=result['safety'], coverage=result['coverage'], entry_events=entries,
        poststep_FCD_TLS_samples_checked=checked, all_full_routes_arrived=len(arrived)==len(jobs), arrived=len(arrived), running=len(jobs)-len(arrived),
        native_E1_contributions=dict(Counter(r['detector_id'] for r in passages['passages'])),
        warning_lines=(path / 'sumo-errors.log').read_text(encoding='utf-8').count('Warning:'), result_sha256=sha(path / 'result.json'))


def main():
    reports = {n: audit(ROOT / (n+'-v5')) for n in NAMES}
    reports['clearance-revision'] = audit(ROOT / 'clearance-revision/native')
    reports['corrective-new14-old9'] = audit(ROOT / 'corrective-new14-old9/native')
    corrected = read(ROOT / 'corrective-new14-old9/native/result.json')
    assert corrected['entered_movements']['uturn-p0_major']['movement'] == 14
    assert corrected['entered_movements']['uturn-p0_minor']['movement'] == 9
    corrected_samples = read(ROOT / 'corrective-new14-old9/native/samples.json')
    actual_g9_G14 = any(r['phase'] in (0, 1) and r['state'][9] == 'g' and r['state'][14] == 'G'
        and all(r['vehicles'].get(i, {}).get('near_197') for i in ('uturn-p0_major', 'uturn-p0_minor')) for r in corrected_samples)
    assert actual_g9_G14
    assert corrected['actual_fields'] == {'uturn-p0_major': ['hh_0535_Z_7_29316'], 'uturn-p0_minor': ['hh_0535_Z_8_34287']}
    samples = read(ROOT / 'clearance-revision/native/samples.json')
    overlap = []
    for row in samples:
        minor = row['vehicles'].get('uturn-yellow_minor', {})
        major = row['vehicles'].get('uturn-yellow_major', {})
        if row['phase'] == 3 and minor.get('lane') == '186821027#0_5' and minor['pos_m'] < 5 and major.get('near_197'):
            assert major['leader'][0] == 'uturn-yellow_minor' and row['state'][15] == 'G'
            overlap.append(dict(poststep_API_time_s=row['time_s'], native_FCD_time_s=round(row['time_s']-.1, 1),
                old9_front_pos_m=minor['pos_m'], old9_rear_still_before_receiving_start_m=5-minor['pos_m'],
                new15_lane=major['lane'], new15_pos_m=major['pos_m'], new15_native_speed_m_s=major['speed_m_s'], leader=major['leader']))
    assert len(overlap) == 2
    original_entries = {i: [] for i in ('original_Z7_0', 'original_Z7_1', 'original_Z8_0', 'original_Z8_1')}
    for t in ET.parse(ROOT / 'original8-v5/fcd.xml').getroot():
        for v in t:
            if v.get('id') in original_entries and v.get('lane') in (':1975693623_0_2', ':1975693623_4_0'):
                original_entries[v.get('id')].append(dict(native_FCD_time_s=float(t.get('time')), lane=v.get('lane')))
    assert all(original_entries.values()) and reports['original8']['all_full_routes_arrived']
    control_file = Path(next(p for p in read(ROOT / 'new14-v5/request.json')['inputs'] if p.endswith('control.add.xml')))
    program = next(r for r in ET.parse(control_file).getroot() if r.get('id') == 'LSA535_part0')
    link5_states = sorted({r.get('state')[5] for r in program.findall('phase')})
    assert not set(link5_states) & {'g', 'G'} and reports['new14']['status'] == 'review_required'
    report = dict(status='review_required', all_raw_evidence_reconciled=True, formal_result=False, new_native_runs=10, toy_vehicle_requests=sum(r['toy_vehicles'] for r in reports.values()),
        cases=reports, clearance_overlap=overlap,
        corrective_pair_actual_g9_G14_and_both_full_routes=True,
        original_fullroute_actual_new_movements=original_entries,
        retained_failed_case=dict(case='new14-v5', source_link5_states=link5_states, reason='The solo toy assigned Z7 lane4 but used the Z8 left-turn suffix via the unchanged 535 link5 without a green. It used new14 normally, then remained at receiving lane4; do not call it a completed support pass. Original8 uses the legal original Z7 suffix and provides two completed new14 passages.'),
        timing_semantics='API samples are post-step. Raw native FCD/TLS times are API time minus 0.1s; every recorded sample is independently reconciled.',
        boundary='Toy normal-entry support and specified phase coverage only. Not a full-demand safety guarantee, count fit, field geometry/controller validation or proof of all pedestrian/bicycle conflict cases.')
    (ROOT / 'audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(status=report['status'], raw_evidence_reconciled=True, new_native_runs=10, toy_vehicle_requests=report['toy_vehicle_requests'],
        case_statuses={n:r['status'] for n,r in reports.items()}, clearance_overlap=overlap), indent=2))


if __name__ == '__main__':
    main()
