# 实际core产物candidate-v5的独立静态审查

静态审查通过，没有发现阻断项。总体仍为`review_required`，不把静态通过、load或小车辆试验当成完整交通安全、真实控制或计数拟合证明。

本审查读取实际发布的`network.net.xml`（SHA256 `68d2f6d2e8630c23f2135202ed906fb47943587cd986ac055c8d99279d582e5c`）和`control.add.xml`（`f9adfb5cceb734a533082f8be1edf907fd43ef88f717f514286850528aac2fc4`）。前者与最终`priority-candidate.net.xml`字节相同；同目录`candidate.net.xml`是较早中间产物，不作为此次结论的输入。

`audit_v5.py`没有调用新core的检查函数来代替审查。它直接核源/产物哈希、原始XML、完整loaded权限、原曲线及端点/总长度/宽速、pedestrian几何和连接、程序，以及sumolib独立解析的16项request映射。

- 只新增`-186821028`的3→4、4→5；原turn及全部class权限保留，238条普通道路相同。
- 旧优先字符仅三处：phase0/1的旧9 G→g，phase3的旧2 G→g。原颜色、全部phase属性、type、offset保持；新14/15均继承旧1。其他50个network程序结构相同，external文件去掉197块后连原始字节也相同。
- 16项request和intLanes逐项等于最终第二次native输出；没有覆盖foe/response表。新G与任何其他同时G的foe组合均为0。
- 旧完整内部曲线、方向端点、总逻辑长度、宽速及crossing/walkingarea几何与连接均保持。静态长度保持仍不等于已核最终runtime全部lane长度。

实际绑定供原生测试核对：

| movement | TLS索引 | request索引 | 首内部lane |
|---|---:|---:|---|
| 原2→2直行 | 1 | 1 | `:1975693623_0_1` |
| 新3→4 | 14 | 2 | `:1975693623_0_2` |
| 原3→parking | 2 | 3 | `:1975693623_3_0` |
| 新4→5 | 15 | 4 | `:1975693623_4_0` |
| 原opposite Uturn | 9 | 11 | `:1975693623_11_0` |

旧parking request3与旧Uturn request11均响应新15 request4，反向不响应，且分别互为foes。记录不再使用早先“新15小g让旧9大G”的失败解释。

动态检查应以实际phase/state确认覆盖：phase0/1的旧9小g与新15大G、phase3的旧2小g与新15大G，以及黄灯承诺进入和内部车尾未清空。phase0的nominal63与min5/max50、phase3的nominal6与min5/max50不构成固定日历。新小g也可能改变感应资格，实际切换记录必须保留。

`review.json`包含全部源哈希、16项独立索引、旧几何明细和phase表。核心实现及测试由其他任务维护，本次未改；未启动native。
