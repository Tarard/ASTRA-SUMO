"""Independent static review of the actual core-generated candidate-v5."""

from hashlib import sha256
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

import sumolib

from astra_sumo.core.junction_split_fanout import _curve, _internal_path
from astra_sumo.core.local_network_conversion import loaded_turn_permissions


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
CASE = OUT.parent / "candidate-v5"
sys.path.insert(0, str(OUT.parent / "candidate-review"))
from check_uturn_yields import canonical, conns  # noqa: E402


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def outside197(raw):
    return re.sub(rb"<tlLogic\b[^>]*>[\s\S]*?</tlLogic>",
                  lambda m: b"" if ET.fromstring(m.group()).get("id") == "1975693623" else m.group(), raw)


def main():
    manifest = json.loads((CASE / "manifest.json").read_bytes())
    assert len(manifest["checks"]) == 16 and all(manifest["checks"].values())
    assert all(digest(Path(path)) == value for path, value in manifest["source_hashes"].items())
    assert digest(CASE / "network.net.xml") == manifest["candidate_sha256"]
    assert digest(CASE / "control.add.xml") == manifest["control_sha256"]
    assert Path(manifest["candidate_file"]).resolve() == (CASE / "network.net.xml").resolve()
    assert (CASE / "network.net.xml").read_bytes() == (CASE / "priority-candidate.net.xml").read_bytes()
    source_net = next(Path(p) for p in manifest["source_hashes"] if Path(p).name == "network.net.xml")
    source_control = next(Path(p) for p in manifest["source_hashes"] if Path(p).name == "control.add.xml")
    old_root, root, native_root = [ET.parse(path).getroot() for path in [source_net, CASE / "network.net.xml", CASE / "priority.native-local-output.net.xml"]]
    old, new = conns(old_root), conns(root)
    additions = {("-186821028", 3, "186821027#0", 4), ("-186821028", 4, "186821027#0", 5)}
    a, b = loaded_turn_permissions(old_root), loaded_turn_permissions(root)
    assert set(b) == set(a) | additions and all(b[k] == v for k, v in a.items())
    assert {k for k, row in new.items() if row.get("tl")} == {k for k, row in old.items() if row.get("tl")} | additions
    assert all(all(new[k].get(attr) == row.get(attr) for attr in ["tl", "linkIndex", "linkIndex2"]) for k, row in old.items() if row.get("tl"))
    assert {e.get("id"): canonical(e) for e in old_root.findall("edge") if not e.get("function")} == {
        e.get("id"): canonical(e) for e in root.findall("edge") if not e.get("function")}
    for tag in ["edge", "junction"]:
        first = {e.get("id"): canonical(e) for e in old_root.findall(tag) if e.get("id") != "1975693623" and not e.get("id", "").startswith(":1975693623_")}
        last = {e.get("id"): canonical(e) for e in root.findall(tag) if e.get("id") != "1975693623" and not e.get("id", "").startswith(":1975693623_")}
        assert first == last
    assert [canonical(e) for e in old_root if e.tag not in {"edge", "junction", "connection", "tlLogic"}] == [
        canonical(e) for e in root if e.tag not in {"edge", "junction", "connection", "tlLogic"}]
    assert outside197(source_control.read_bytes()) == outside197((CASE / "control.add.xml").read_bytes())
    expected_changes = {(0, 9, "G", "g"), (1, 9, "G", "g"), (3, 2, "G", "g")}
    phase_table = []
    for label, before, after in [("network", old_root, root), ("additional", ET.parse(source_control).getroot(), ET.parse(CASE / "control.add.xml").getroot())]:
        old_programs = {p.get("id"): p for p in before.findall("tlLogic")}
        new_programs = {p.get("id"): p for p in after.findall("tlLogic")}
        assert old_programs.keys() == new_programs.keys()
        assert all(canonical(new_programs[k]) == canonical(v) for k, v in old_programs.items() if k != "1975693623")
        left, right = old_programs["1975693623"], new_programs["1975693623"]
        assert left.attrib == right.attrib
        assert [canonical(c) for c in left if c.tag != "phase"] == [canonical(c) for c in right if c.tag != "phase"]
        assert len(left.findall("phase")) == len(right.findall("phase")) == 7
        changes = set()
        for i, (old_phase, new_phase) in enumerate(zip(left.findall("phase"), right.findall("phase"), strict=True)):
            old_state, state = old_phase.get("state"), new_phase.get("state")
            assert len(state) == 16 and old_state.lower() == state[:14].lower() and state[14:] == old_state[1] * 2
            assert {k: v for k, v in old_phase.attrib.items() if k != "state"} == {k: v for k, v in new_phase.attrib.items() if k != "state"}
            changes |= {(i, j, x, y) for j, (x, y) in enumerate(zip(old_state, state[:14], strict=True)) if x != y}
            if label == "additional":
                phase_table.append({"phase": i, **new_phase.attrib, "parking2": state[2], "Uturn9": state[9], "new14": state[14], "new15": state[15]})
        assert changes == expected_changes
    node, original_node = [r.find("junction[@id='1975693623']") for r in [root, old_root]]
    assert all(node.get(k) == original_node.get(k) for k in ["x", "y", "z", "shape", "customShape"])
    assert [r.attrib for r in node.findall("request")] == [r.attrib for r in native_root.find("junction[@id='1975693623']").findall("request")]
    assert node.get("intLanes") == native_root.find("junction[@id='1975693623']").get("intLanes")
    requests = {int(r.get("index")): r.attrib for r in node.findall("request")}
    assert set(requests) == set(range(16)) and all(len(r["response"]) == len(r["foes"]) == 16 for r in requests.values())
    net = sumolib.net.readNet(str(CASE / "network.net.xml"), withInternal=True)
    mapping = []
    for key, row in new.items():
        if row.get("tl") != "1975693623":
            continue
        conn = next(c for c in net.getEdge(key[0]).getConnections(net.getEdge(key[2])) if c.getFromLane().getIndex() == key[1] and c.getToLane().getIndex() == key[3])
        mapping.append({"key": key, "TLS_index": conn.getTLLinkIndex(), "request_index": conn.getJunctionIndex(), "via": conn.getViaLaneID()})
    assert len(mapping) == 16 and {r["request_index"] for r in mapping} == set(range(16))
    indexed = {r["TLS_index"]: r for r in mapping}
    def bit(own, other, attr):
        return requests[indexed[own]["request_index"]][attr][-1 - indexed[other]["request_index"]] == "1"
    relations = {}
    for turn in [2, 9]:
        relations[str(turn)] = {"mutual_foes": bit(turn, 15, "foes") and bit(15, turn, "foes"),
                               "old_turn_yields": bit(turn, 15, "response"), "new15_yields_back": bit(15, turn, "response")}
        assert relations[str(turn)] == {"mutual_foes": True, "old_turn_yields": True, "new15_yields_back": False}
    for phase in phase_table:
        state = phase["state"]
        assert all(not (state[new_signal] == state[other] == "G" and (bit(new_signal, other, "foes") or bit(other, new_signal, "foes")))
                   for new_signal in [14, 15] for other in range(16) if new_signal != other)
    geometry = []
    for key in a:
        if old[key].get("tl") != "1975693623":
            continue
        one, two = _internal_path(old_root, old[key]), _internal_path(root, new[key])
        x, y = _curve(old_root, old[key]), _curve(root, new[key])
        assert x.hausdorff_distance(y) <= 1e-6
        assert sum((p - q) ** 2 for p, q in zip(x.coords[0], y.coords[0], strict=True)) <= 1e-12
        assert sum((p - q) ** 2 for p, q in zip(x.coords[-1], y.coords[-1], strict=True)) <= 1e-12
        length_one, length_two = [sum(float(e.get("length")) for e in path) for path in [one, two]]
        assert abs(length_one - length_two) <= 1e-6
        assert {(float(e.get("width", "3.2")), float(e.get("speed"))) for e in one} == {
            (float(e.get("width", "3.2")), float(e.get("speed"))) for e in two}
        geometry.append({"key": key, "curve_difference_m": x.hausdorff_distance(y), "length_delta_m": length_two - length_one,
                         "old_total_length_m": length_one, "new_internal_lanes": [e.attrib for e in two]})
    foot = {e.get("id") for e in old_root.findall("edge") if e.get("function") in {"crossing", "walkingarea"} and e.get("id", "").startswith(":1975693623_")}
    assert all(canonical(old_root.find(f"edge[@id='{identity}']")) == canonical(root.find(f"edge[@id='{identity}']")) for identity in foot)
    assert sorted(canonical(c) for c in old_root.findall("connection") if c.get("from") in foot or c.get("to") in foot) == sorted(
        canonical(c) for c in root.findall("connection") if c.get("from") in foot or c.get("to") in foot)
    command = manifest["priority_execution"]["command"]
    assert "--tllogic-files" in command and str(CASE / "final-program.tll.xml") in command
    files = [source_net, source_control, CASE / "network.net.xml", CASE / "control.add.xml", CASE / "priority.native-local-output.net.xml",
             CASE / "final-program.tll.xml", CASE / "manifest.json", ROOT / "plugins/astra-sumo/src/astra_sumo/core/hamburg_197_through_support.py"]
    result = {"status": "review_required", "static_review": "pass", "blocking_static_findings": [], "native_runs_by_this_review": 0,
        "candidate_sha256": digest(CASE / "network.net.xml"), "control_sha256": digest(CASE / "control.add.xml"),
        "actual_scope_priority_changes": sorted(expected_changes), "all_old_colors_and_phase_parameters_preserved": True,
        "external_other50_program_bytes_identical": True, "native_final_requests_and_intLanes_not_overlaid": True,
        "controlled_TLS_request_mapping": mapping, "old_turn_new15_priority": relations, "phases": phase_table, "old_geometry": geometry,
        "no_new_major_green_with_major_foe": True, "original16_manifest_checks_recomputed_or_independently_covered": True,
        "test_requirements": ["Actual phase0/1 Uturn9 g vs new15 G; phase3 parking2 g vs new15 G", "Actual yellow commitment and internal rear-clear cases; do not infer times from phase0 duration63", "Original bike and new14/new15 paths plus source runtime lengths", "No claim of full-demand safety, field SPaT or fit from small probes"],
        "source_hashes": {str(p): digest(p) for p in files}}
    (OUT / "review.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ["status", "static_review", "blocking_static_findings", "candidate_sha256", "control_sha256", "old_turn_new15_priority"]}, indent=2))


if __name__ == "__main__":
    main()
