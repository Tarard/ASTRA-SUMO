"""Inspect an existing prototype and final-control requirements without native calls."""

from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import sumolib

from astra_sumo.core.junction_split_fanout import _curve, _internal_path
from astra_sumo.core.local_network_conversion import loaded_turn_permissions


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SOURCE = ROOT / "outputs/hamburg-joint-od-spsa-20261023-v1/prepared/network.net.xml"
CONTROL = SOURCE.with_name("control.add.xml")
PROTOTYPE = OUT.parent / "prototype-load-restored/candidate.net.xml"
WARNING = PROTOTYPE.with_name("sumo-errors.log")


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def bit(row, target):
    return row[-1 - target] == "1"


def main():
    root = ET.parse(PROTOTYPE).getroot()
    source = ET.parse(SOURCE).getroot()
    node = root.find("junction[@id='1975693623']")
    requests = {int(r.get("index")): r.attrib for r in node.findall("request")}
    assert len(requests) == 16 and all(len(r["response"]) == len(r["foes"]) == 16 for r in requests.values())
    net = sumolib.net.readNet(str(PROTOTYPE), withInternal=True)
    indices = {}
    keys = {"new14": ("-186821028", 3, "186821027#0", 4),
            "new15": ("-186821028", 4, "186821027#0", 5),
            "old9": ("186821029#1", 3, "186821027#0", 5)}
    for name, key in keys.items():
        conn = next(c for c in net.getEdge(key[0]).getConnections(net.getEdge(key[2]))
                    if c.getFromLane().getIndex() == key[1] and c.getToLane().getIndex() == key[3])
        index = conn.getJunctionIndex()
        indices[name] = {"movement_key": key, "prototype_TLS_index": conn.getTLLinkIndex(),
                         "junction_request_index": index, "via": conn.getViaLaneID(), "request": requests[index]}
    a, b = indices["new15"]["junction_request_index"], indices["old9"]["junction_request_index"]
    priority = {"new15_foes_old9": bit(requests[a]["foes"], b),
                "new15_response_to_old9": bit(requests[a]["response"], b),
                "old9_response_to_new15": bit(requests[b]["response"], a)}
    assert priority == {"new15_foes_old9": True, "new15_response_to_old9": False, "old9_response_to_new15": True}
    phases = []
    for program in source.findall("tlLogic[@id='1975693623']") + ET.parse(CONTROL).getroot().findall("tlLogic[@id='1975693623']"):
        for index, phase in enumerate(program.findall("phase")):
            old = phase.get("state")
            new14 = old[1]
            new15 = "g" if old[1] == "G" and old[9] in "Ggy" else old[1]
            phases.append({"programID": program.get("programID"), "phase": index, "old_attributes": phase.attrib,
                           "proposed16_state": old + new14 + new15, "new14": new14, "new15": new15, "old9": old[9]})
    old_access, new_access = loaded_turn_permissions(source), loaded_turn_permissions(root)
    old_connections = {(c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))): c
                       for c in source.findall("connection") if c.get("fromLane") is not None}
    new_connections = {(c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))): c
                       for c in root.findall("connection") if c.get("fromLane") is not None}
    geometry = []
    for key, old in old_connections.items():
        if old.get("tl") != "1975693623" or key not in old_access:
            continue
        assert old_access[key] == new_access[key]
        path1, path2 = _internal_path(source, old), _internal_path(root, new_connections[key])
        geometry.append({"movement_key": key, "hausdorff_m": _curve(source, old).hausdorff_distance(_curve(root, new_connections[key])),
                         "source_total_length_m": sum(float(lane.get("length")) for lane in path1),
                         "prototype_total_length_m": sum(float(lane.get("length")) for lane in path2)})
    result = {"status": "review_required", "native_runs": 0, "prototype_shared_G_priority_suitable_for_final_g": False,
        "movement_index_map": indices, "prototype_priority_bits": priority,
        "proposed_phase_extension": phases, "prototype_old_motor_bike_geometry": geometry,
        "source_hashes": {str(p): digest(p) for p in [SOURCE, CONTROL, PROTOTYPE, WARNING]},
        "claim_boundary": "Existing shared-G prototype only. New g/G bindings must be fed into native ROW construction and checked afterward. This record does not review a final recompiled candidate or establish dynamic safety."}
    (OUT / "prototype-finding.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"priority": priority, "index_map": {k: v["junction_request_index"] for k, v in indices.items()},
                      "max_old_curve_difference_m": max(r["hausdorff_m"] for r in geometry),
                      "max_old_logical_length_difference_m": max(abs(r["source_total_length_m"] - r["prototype_total_length_m"]) for r in geometry)}, indent=2))


if __name__ == "__main__":
    main()
