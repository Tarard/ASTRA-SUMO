"""Inspect the completed U-turn-yields prototype; no native execution."""

from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import sumolib

from astra_sumo.core.junction_split_fanout import _curve, _internal_path
from astra_sumo.core.local_network_conversion import loaded_turn_permissions


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PROTOTYPE = OUT.parent / "prototype-uturn-yields"
SOURCE = ROOT / "outputs/hamburg-joint-od-spsa-20261023-v1/prepared/network.net.xml"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def canonical(element):
    return element.tag, sorted(element.attrib.items()), [canonical(e) for e in element]


def conns(root):
    return {(c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane"))): c
            for c in root.findall("connection")}


def main():
    before, after, native = [ET.parse(path).getroot() for path in [SOURCE, PROTOTYPE / "candidate.net.xml", PROTOTYPE / "row.native-local-output.net.xml"]]
    before_control, after_control = [ET.parse(path).getroot() for path in [SOURCE.with_name("control.add.xml"), PROTOTYPE / "control.add.xml"]]
    additions = {("-186821028", 3, "186821027#0", 4), ("-186821028", 4, "186821027#0", 5)}
    old, new = conns(before), conns(after)
    old_controlled = {key for key, row in old.items() if row.get("tl")}
    new_controlled = {key for key, row in new.items() if row.get("tl")}
    assert new_controlled == old_controlled | additions
    access_old, access_new = loaded_turn_permissions(before), loaded_turn_permissions(after)
    assert all(access_new[key] == value for key, value in access_old.items())
    assert set(access_new) - set(access_old) == additions
    ordinary_old = {e.get("id"): canonical(e) for e in before.findall("edge") if not e.get("function")}
    ordinary_new = {e.get("id"): canonical(e) for e in after.findall("edge") if not e.get("function")}
    assert ordinary_old == ordinary_new
    phase_rows = []
    for scope, first_root, last_root in [("network", before, after), ("additional", before_control, after_control)]:
        old_programs = {p.get("id"): p for p in first_root.findall("tlLogic")}
        new_programs = {p.get("id"): p for p in last_root.findall("tlLogic")}
        assert old_programs.keys() == new_programs.keys()
        assert all(canonical(new_programs[key]) == canonical(value) for key, value in old_programs.items() if key != "1975693623")
        a, b = old_programs["1975693623"], new_programs["1975693623"]
        assert a.attrib == b.attrib and len(a.findall("phase")) == len(b.findall("phase")) == 7
        assert [canonical(e) for e in a if e.tag != "phase"] == [canonical(e) for e in b if e.tag != "phase"]
        for i, (old_phase, new_phase) in enumerate(zip(a.findall("phase"), b.findall("phase"), strict=True)):
            assert {k: v for k, v in old_phase.attrib.items() if k != "state"} == {k: v for k, v in new_phase.attrib.items() if k != "state"}
            expected = list(old_phase.get("state"))
            if i in [0, 1]:
                assert expected[9] == "G"
                expected[9] = "g"
            expected = "".join(expected) + old_phase.get("state")[1] * 2
            assert new_phase.get("state") == expected
            if scope == "additional":
                phase_rows.append({"phase": i, **new_phase.attrib, "old9": expected[9], "new14": expected[14], "new15": expected[15],
                    "calendar_interval_inferred": False})
    for key in old_controlled:
        assert all(new[key].get(attr) == old[key].get(attr) for attr in ["tl", "linkIndex", "linkIndex2"])
    assert new["-186821028", 3, "186821027#0", 4].get("linkIndex") == "14"
    assert new["-186821028", 4, "186821027#0", 5].get("linkIndex") == "15"
    junction = after.find("junction[@id='1975693623']")
    raw_junction = native.find("junction[@id='1975693623']")
    assert [r.attrib for r in junction.findall("request")] == [r.attrib for r in raw_junction.findall("request")]
    requests = {int(r.get("index")): r.attrib for r in junction.findall("request")}
    assert len(requests) == 16 and all(len(r["response"]) == len(r["foes"]) == 16 for r in requests.values())
    net = sumolib.net.readNet(str(PROTOTYPE / "candidate.net.xml"), withInternal=True)
    indices = {}
    for name, key in [("new14", ("-186821028", 3, "186821027#0", 4)), ("new15", ("-186821028", 4, "186821027#0", 5)),
                      ("old9", ("186821029#1", 3, "186821027#0", 5))]:
        c = next(c for c in net.getEdge(key[0]).getConnections(net.getEdge(key[2])) if c.getFromLane().getIndex() == key[1] and c.getToLane().getIndex() == key[3])
        indices[name] = {"movement_key": key, "TLS_index": c.getTLLinkIndex(), "request_index": c.getJunctionIndex(),
                         "request": requests[c.getJunctionIndex()]}
    u, t = indices["old9"]["request_index"], indices["new15"]["request_index"]
    assert requests[u]["response"][-1 - t] == "1" and requests[t]["response"][-1 - u] == "0"
    assert requests[u]["foes"][-1 - t] == requests[t]["foes"][-1 - u] == "1"
    old9_key = ("186821029#1", 3, "186821027#0", 5)
    path = _internal_path(after, new[old9_key])
    internal = [j.attrib for j in after.findall("junction") if j.get("id") in {lane.get("id") for lane in path}]
    geometry = []
    for key, row in old.items():
        if row.get("tl") != "1975693623" or key not in access_old:
            continue
        a, b = _internal_path(before, row), _internal_path(after, new[key])
        geometry.append({"key": key, "curve_max_difference_m": _curve(before, row).hausdorff_distance(_curve(after, new[key])),
                         "old_total_length": sum(float(e.get("length")) for e in a), "new_total_length": sum(float(e.get("length")) for e in b)})
    for e in before.findall("edge"):
        if e.get("function") in {"crossing", "walkingarea"} and e.get("id", "").startswith(":1975693623_"):
            assert canonical(e) == canonical(after.find(f"edge[@id='{e.get('id')}']"))
    assert max(r["curve_max_difference_m"] for r in geometry) <= 1e-6
    assert max(abs(r["old_total_length"] - r["new_total_length"]) for r in geometry) <= 1e-9
    files = [SOURCE, SOURCE.with_name("control.add.xml"), PROTOTYPE / "candidate.net.xml", PROTOTYPE / "control.add.xml",
             PROTOTYPE / "row.native-local-output.net.xml", PROTOTYPE / "load-check.json", PROTOTYPE / "sumo-errors.log"]
    result = {"status": "review_required", "static_checks": "pass", "native_runs_by_this_audit": 0,
        "two_additions_only_all_old_permissions_preserved": True, "ordinary_roads_identical": True,
        "other50_network_and_additional_programs_identical": True,
        "old_priority_change_only": "TLS9 G→g in phase0/1; all other old characters and all timing/type attributes unchanged",
        "movement_indices": indices, "native_request_table_not_overlaid": True, "all_requests_size16": True,
        "old9_internal_path": [{"lane": e.get("id"), "length": e.get("length")} for e in path], "old9_internal_junctions": internal,
        "old_geometry": geometry, "phase_coverage_by_observed_index": phase_rows,
        "dynamics_required": ["phase0/1 old9 g vs new15 G normal-entry near-simultaneous arrivals and actual order", "phase1→2 yellow commitment and phase2→3 uncleared old Uturn", "old Uturn alone/with finite gap completes", "new14 and retained bicycle/pedestrian conflict regression"],
        "claim_boundary": "Final static source/graph/priority consistency only. Actuated phases have no fixed inferred calendar here. Existing zero-vehicle load is not a pair safety or field SPaT result.",
        "source_hashes": {str(p): digest(p) for p in files}}
    (OUT / "uturn-yields-static-review.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "static_checks": "pass", "indices": {k: v["request_index"] for k, v in indices.items()},
        "old9_cont": requests[u]["cont"], "old9_path": result["old9_internal_path"], "max_old_length_delta": max(abs(r["old_total_length"] - r["new_total_length"]) for r in geometry)}, indent=2))


if __name__ == "__main__":
    main()
