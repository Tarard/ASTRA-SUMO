# 197两条新增直行的控制与请求表审查

当前结论为`review_required`。只新增3→4和4→5的物理范围可独立审查；本记录未运行native，也没有修改实现、连接、信号或请求表。

## 已拒绝的两种优先分配

| 尝试 | 控制表达 | 静态证据 | 结论 |
|---|---|---|---|
| 原共享索引 | 新through共用旧1=G，旧Uturn9仍G | 同一outlane5有两个大G，原生已警告 | 保留失败，不能接受 |
| 新15小g让旧9大G | 新14继承旧1；新15在旧9活动时g | 最终16位程序也交给第二次netconvert后，response仍要求旧9让新15 | 所声明让行方向未成立，阻断保留 |

TLS索引不能直接用作junction request索引。用安装版sumolib的movement key→`getJunctionIndex`核得，新3→4为request2，新4→5为request4，旧TLS9掉头为request11。两个native尝试中均是`request4.foes[11]=1`、`request4.response[11]=0`、`request11.response[4]=1`。位串从右到左读，TLS状态串则从左到右读。

固定1.27.1的[NBRequest.cpp224–232](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBRequest.cpp#L224-L232)在构建基本优先关系时把turnaround置为非优先，解释了为何native仍保持掉头让直行。运行期[MSRightOfWayJunction.cpp93–108](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/microsim/MSRightOfWayJunction.cpp#L93-L108)将response位装成需响应的来车集合；不是只要foes存在就会按所想方向让行。

不能用内部等待点解释第二次尝试的旧9大G让行。该最终网旧9的`cont=0`，只有一段4.342758 m内部lane，随后为state=M的普通出口。此前被警告的共享G尝试才有`cont=1`和两段1.148646393526+3.194111606474 m。固定[MSLink.cpp935–950](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/microsim/MSLink.cpp#L935-L950)对major状态通常优先放行。没有依据声称第二次网的旧9会在一个不存在的内部等待点让行。

## 更新后的条件方案

主任务随后提出：新14/15均继承旧through1；只在旧phase0/1把旧Uturn9的G改g，保留绿色、全部时长/min/max/type及其他字符。这个方向与native已给出的ROW一致：新直行大G、旧掉头小g；它是可继续验证的推定控制模型。

这已经改变旧9的优先权，不能继续声称旧0..13字符全部相同，也不是现场SPaT或真实控制器归属已获证实。保留原失败证据和声明新的优先假设是必要的。[官方说明](https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html#interaction-between-signal-plans-and-right-of-way-rules)要求新g/G关系与网络一起交给netconvert更新ROW；完成该步骤仍需检查实际生成关系，不能以没有同大G警告替代验证。

必须通过以下检查后，才能把该条件方案称为结构兼容候选：

1. **最终输入下的ROW。** 最终16位程序和每条connection的实际TLS绑定同时进入native转换；通过movement key重新求request索引，核旧9响应新15为1、新15反向为0、互为foes。检查旧9实际cont、内部等待点及内部foe链；不手改response/cont来迎合断言。若native仍相反，保持阻断。
2. **范围和几何。** 原有全部turn与各class权限保留；只加两项。两份network/additional程序只有明确列出的旧9 phase0/1 G→g和新增14/15，其他50控制程序、phase属性完全一致。原普通道路、旧完整内部曲线和旧总逻辑长度保持。已读共享G静态产物的旧曲线最大差约2.98e−10 m、总长度差0；最终再转换产物仍须重核。尤其最终runtime旧bike/car长度应复核已接受的6.576078 m，不能用单次XML长度代替。新lane保持native计算长度，不为计数调长度。
3. **正常入口的合流与清空。** 针对新4→5与旧9同出lane5，用普通入口、原phase时间、安全默认和原生junction collision检查，测同步/错位到达；覆盖phase0/1并行绿、phase1→2黄灯及phase2→3后仍有旧车占用。核实际等待和通过顺序、无碰撞/传送/丢弃。另核新增3→4及旧bike/pedestrian冲突。成功load只确认输入可读，不能确认这些行为。

旧9小g在连续直行流中是否仍有可用间隙也需分列；“合法转向保留”不等于原服务机会不变。actuated属性不变同样不保证实际切换历史相同，新通路会改变来车和感应响应。任何完整比较都应保留实际控制记录与全部计数/安全/积压，不能只比较名义时长。

`prototype-finding.json`和`final-minor-through-finding.json`绑定两个已失败产物及其源哈希。当前记录不包含后续修正方案的最终native安全验收，不授权删信号、删原掉头或人为提前消车。

## 已读更新方案的静态结果

`prototype-uturn-yields`的第二次native产物已独立读查通过静态约束，结果在`uturn-yields-static-review.json`。只增加两项，原所有loaded turn/class权限、238条普通道路与其他50程序结构不变。旧197 phase0/1仅9位G→g；所有其他旧字符、phase属性与type不变，新14/15均取旧1。16条request与native原始输出逐项相同，没有覆盖foe/response表。旧9响应新15、反向不响应，且互为foes；旧9现在cont=1，实际两段总长4.342758 m，内部等待结构与小g相容。旧完整曲线差在1e−6 m内，旧总长度差0，crossing/walkingarea边几何按源保留。

实际观测应覆盖以下phase，而不是按nominal duration推导固定时刻：

| phase | 旧9 | 新14/15 | 声明时间属性 | 重点 |
|---:|---|---|---|---|
| 0 | g | G/G | duration63，min5/max50 | 正常入口同时到达、旧掉头让行 |
| 1 | g | G/G | 5 s | 绿灯末段合流 |
| 2 | y | G/G | 3 s | 黄灯承诺进入、旧车清空 |
| 3 | r | G/G | duration6，min5/max50 | 旧内部车辆尚未清空时的直行 |
| 4 | r | y/y | 3 s | 直行黄灯清空 |
| 5/6 | r | r/r | 各5 s | 非机动车及全红回归 |

phase0和3为感应区间；源码中的detector可用性还取决于同一lane所辖连接的优先状态。旧9从G变g可能改变其共享lane的感应资格，不应承诺旧实际切换历史不变。测试需记录实际phase/state、进入内部lane的时刻及两车轨迹，只有真正落在上述状态时才算覆盖。现有load-check明确是0车辆，静态通过仍不代替这些动态检查或现场来源验证。
