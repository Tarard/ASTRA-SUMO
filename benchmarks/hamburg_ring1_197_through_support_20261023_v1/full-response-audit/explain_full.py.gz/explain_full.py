"""Retain exact residual rankings and observed events for every unfinished trip."""

from collections import Counter, defaultdict
import gzip
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from audit_full import OUT, SOURCE, STUDY, audit, digest, seal


def passages(path):
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    result = defaultdict(list)
    for event in data["passages"]:
        result[event["vehicle_id"]].append(event)
    return result


def main():
    output = OUT / "complete"
    scan = json.loads((output / "scan.json").read_bytes())
    assert scan["status"] == "pass"
    residuals = audit.read_csv_rows(output / "residual182-before-after.csv")
    main_rows = [r for r in residuals if float(r["begin"]) >= 3600]
    field_rows = []
    for field in sorted({r["field"] for r in main_rows}):
        selected = [r for r in main_rows if r["field"] == field]
        field_rows.append({"field": field, "target_main": sum(int(r["target"]) for r in selected),
            "reference_main": sum(int(r["reference_count"]) for r in selected), "candidate_main": sum(int(r["candidate_count"]) for r in selected),
            "reference_TAE": sum(abs(int(r["reference_residual"])) for r in selected),
            "candidate_TAE": sum(abs(int(r["candidate_residual"])) for r in selected),
            "reference_SSE": sum(int(r["reference_residual"]) ** 2 for r in selected),
            "candidate_SSE": sum(int(r["candidate_residual"]) ** 2 for r in selected)})
    audit.table(output / "field13-counts-and-errors.csv", field_rows)
    largest = sorted(main_rows, key=lambda r: (-abs(int(r["candidate_residual"])), r["field"], float(r["begin"])))[:15]
    audit.table(output / "largest15-main-residuals.csv", largest)
    old_events = passages(SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz")
    evaluation = STUDY / "full/evaluation"
    new_events = passages(evaluation / "contributing-passages.json.gz")
    old_tripinfo, tripinfo = [{r.get("id"): r.attrib for r in ET.parse(p).getroot().findall("tripinfo")}
                            for p in [SOURCE / "native/tripinfo.xml", evaluation / "native/tripinfo.xml"]]
    vehicles = {v.get("id"): v for v in ET.parse(evaluation / "demand.rou.xml").getroot().findall("vehicle")}
    terminal = audit.read_csv_rows(output / "terminal-vehicles.csv")
    terminal_rows = []
    for row in terminal:
        identity = row["vehicle_id"]
        assert identity in tripinfo and float(tripinfo[identity]["arrival"]) < 0
        assert identity in old_tripinfo and float(old_tripinfo[identity]["arrival"]) >= 0
        path = vehicles[identity].find("route").get("edges").split()
        terminal_rows.append({"vehicle_id": identity, "requested_origin": path[0], "requested_destination": path[-1],
            "requested_departure_s": vehicles[identity].get("depart"), "departure_bin": row["departure_bin"],
            "prior_primary_fields": json.loads(row["intended_fields"]), "source_actual_events": audit.event_view(old_events.get(identity, [])),
            "candidate_actual_events": audit.event_view(new_events.get(identity, [])),
            "source_arrival_s": old_tripinfo[identity]["arrival"], "candidate_arrival_s": tripinfo[identity]["arrival"],
            "source_actual_depart_s": old_tripinfo[identity].get("depart"), "candidate_actual_depart_s": tripinfo[identity].get("depart"),
            "candidate_completed_field": bool(new_events.get(identity)), "candidate_final_lane_inferred": False})
    assert len(terminal_rows) == 34
    assert all(r["requested_origin"] == "963776077#0" and r["prior_primary_fields"] == ["hh_0119_Z_5_30494"] for r in terminal_rows)
    audit.table(output / "terminal34-source-candidate-events.csv", terminal_rows)
    fixed = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}
    fixed_rows = [r for r in residuals if r["field"] in fixed]
    assert len(fixed_rows) == 56 and all(int(r["candidate_residual"]) == 0 for r in fixed_rows)
    phase_related = []
    for name, path in [("reference", SOURCE / "native/stall-monitor.json"), ("candidate", evaluation / "native/stall-monitor.json")]:
        monitor = json.loads(path.read_bytes())
        library = monitor.get("native_library")
        assert library and digest(Path(library["path"])) == library["sha256"]
        phase_related.append({"case": name, "native_library": library, "source_file": str(path), "source_sha256": digest(path)})
    summary = {"status": "pass", "new_native_runs": 0,
        "535_Z5to8_exact_real_bins": len(fixed_rows), "535_Z5to8_real_target_and_measured": sum(int(r["target"]) for r in fixed_rows),
        "535_Z5to8_main_TAE_change": sum(int(r["candidate_TAE"]) - int(r["reference_TAE"]) for r in field_rows if r["field"] in fixed),
        "535_Z5to8_main_SSE_change": sum(int(r["candidate_SSE"]) - int(r["reference_SSE"]) for r in field_rows if r["field"] in fixed),
        "other_fields_main_TAE_change": sum(int(r["candidate_TAE"]) - int(r["reference_TAE"]) for r in field_rows if r["field"] not in fixed),
        "other_fields_main_SSE_change": sum(int(r["candidate_SSE"]) - int(r["reference_SSE"]) for r in field_rows if r["field"] not in fixed),
        "candidate_main_exact_rows": sum(int(r["candidate_residual"]) == 0 for r in main_rows),
        "largest_field_by_TAE_and_SSE": max(field_rows, key=lambda r: r["candidate_SSE"]),
        "largest_main_residual": largest[0], "terminal_vehicle_count": len(terminal_rows),
        "terminal_departure_bins": dict(Counter(r["departure_bin"] for r in terminal_rows)),
        "terminal_completed_own_field": sum(r["candidate_completed_field"] for r in terminal_rows),
        "terminal_not_completed_own_field": sum(not r["candidate_completed_field"] for r in terminal_rows),
        "terminal34_source_event_regions": dict(Counter("initialization" if e["interval_begin_s"] < 3600 else "main" if e["interval_begin_s"] < 12600 else "tail"
            for row in terminal_rows for e in old_events[row["vehicle_id"]])),
        "terminal34_candidate_event_regions": dict(Counter("initialization" if e["interval_begin_s"] < 3600 else "main" if e["interval_begin_s"] < 12600 else "tail"
            for row in terminal_rows for e in new_events.get(row["vehicle_id"], []))),
        "all_terminal34_were_arrived_in_reference": True, "runtime_library_provenance": phase_related,
        "claim_boundary": "The unfinished cohort is now963/119Z5, but final lane and physical queue location are not observed here. Connections and three declared priority changes are a combined treatment; these count differences do not causally separate them or establish true demand/control."}
    audit.save(output / "remaining-error-summary.json", summary)
    seal(output)
    seal(OUT)
    print(json.dumps({k: v for k, v in summary.items() if k not in ["runtime_library_provenance", "claim_boundary"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
