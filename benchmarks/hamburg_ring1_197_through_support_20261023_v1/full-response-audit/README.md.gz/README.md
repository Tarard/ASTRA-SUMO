# 197连接修复的完整运行独立对账

`audit_full.py`复用前substitution分析的原生证据读取、误差、完整事件与终态函数，不运行SUMO或再生成需求。当前`--scope-only`已通过：8640个selected请求、route、depart、moving stop和字段意向字节相同，全部130/52真实targets及检测布局相同，network/control精确对应实际v5，执行脚本和输入哈希匹配。

主任务通知`full/verdict.json`完成后，从仓库根目录单次执行：

```powershell
$env:PYTHONUTF8 = '1'
$env:PYTHONPATH = "$PWD/plugins/astra-sumo/src"
.venv/Scripts/python.exe outputs/hamburg-197-through-support-20261023-v1/full-response-audit/audit_full.py
```

没有verdict时不解析候选原生XML，不轮询。`complete/scan.json`将分列原selected与新运行的130主窗、52初始化、182真实行、208原生行、40派生站点、安全、完整性、积压和原verdict。原生summary需有144000步；完整事件逐行闭合208个`nVehContrib`。40行是派生合计，不进入独立损失。所有字段、所有出发与检测窗均保留，未据误差好坏删行。

`native208-cohort-comparison.csv`把实际计数变化分为原入口`-142944318`且原意向535 Z5–8、原意向119 Z5、其余车辆三群，逐行精确闭合总差。分组使用固定输入标签，事件字段仍使用本次真实原生记录；旧primary intention之外的完整事件单列报告，不能因此过滤或改标原生计数。

`field13-main-residuals.csv`保存每字段主窗SSE/TAE变化，`vehicle-event-changes.csv`保留各车真实事件窗/时刻变化。`terminal-vehicles.csv`按请求入口、原意向和真实完整事件分组；不把初始lane或只含arrived车辆的vehroute当作最终排队位置。

本项改变连接和声明的局部让行优先，影响从零时刻开始，不能预设初始化52行相同。两处新增物理连接的来源、优先模型兼容性、原生安全和计数拟合分别评价；不会把前一次行程替代的strict-improvement选择条件强加到物理修复，也不因来源支持就忽略拟合退步。正式计数目标仍是130项完全相同并且健康完成，不提前宣布归零。

输入、执行snapshot和所复用分析函数的哈希在`input-proof.json`，最终原生证据哈希在`complete/scan.json`。本目录不会修改正在运行的driver、core、网络、控制、需求或原始verdict。
