"""Reuse the sealed native readers for the unchanged-demand 197 full run."""

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
PREVIOUS = STUDY.parent / "hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(PREVIOUS))
import audit_response as audit  # noqa: E402
from audit_scope import BASE, SOURCE, digest  # noqa: E402
from summarize_response import backlog  # noqa: E402


def seal(output):
    audit.save(output / "manifest.json", {"native_runs": 0, "files": [
        {"path": p.relative_to(output).as_posix(), "size_bytes": p.stat().st_size, "sha256": digest(p)}
        for p in sorted(output.rglob("*")) if p.is_file() and p != output / "manifest.json" and "__pycache__" not in p.parts]})


def scope_check():
    full, candidate = STUDY / "full", STUDY / "candidate-v5"
    preflight = json.loads((full / "preflight.json").read_bytes())
    manifest = json.loads((candidate / "manifest.json").read_bytes())
    assert all(manifest["checks"].values()) and len(manifest["checks"]) == 16
    assert manifest["priority_case_changes"] == [
        {"phase_index": 0, "signal_index": 9, "before": "G", "after": "g"},
        {"phase_index": 1, "signal_index": 9, "before": "G", "after": "g"},
        {"phase_index": 3, "signal_index": 2, "before": "G", "after": "g"}]
    assert digest(candidate / "network.net.xml") == manifest["candidate_sha256"]
    assert digest(candidate / "control.add.xml") == manifest["control_sha256"]
    assert all(digest(Path(p)) == h for p, h in preflight["source_hashes"].items())
    assert all(digest(full / "prepared" / p) == h for p, h in preflight["prepared_hashes"].items())
    for name in ["demand.rou.xml", "lane-intentions.json"]:
        assert (full / "prepared" / name).read_bytes() == (SOURCE / name).read_bytes() == (full / "evaluation" / name).read_bytes()
    for name in ["field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]:
        assert (full / "prepared" / name).read_bytes() == (BASE / name).read_bytes()
    for name in ["network.net.xml", "control.add.xml"]:
        assert (full / "prepared" / name).read_bytes() == (candidate / name).read_bytes()
    assert (full / "executed-driver.py").read_bytes() == (STUDY / "measure_full.py").read_bytes()
    source_scenario, scenario = [json.loads(p.read_bytes()) for p in [BASE / "scenario.json", full / "prepared/scenario.json"]]
    changes = [k for k in set(source_scenario) | set(scenario) if source_scenario.get(k) != scenario.get(k)]
    assert set(changes) <= {"network_sha256", "control_sha256", "connection_candidate", "control_assumptions", "demand_prior"}
    signatures = {r["vehicle_id"]: [r["field_id"]] for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    vehicles = {v.get("id"): v for v in ET.parse(SOURCE / "demand.rou.xml").getroot().findall("vehicle")}
    assert signatures.keys() == vehicles.keys() and len(vehicles) == 8640
    result = {"status": "pass", "N": 8640, "demand_intentions_and_all_observation_bytes_unchanged": True,
        "network_control_exact_candidate_v5": True, "priority_changes": manifest["priority_case_changes"],
        "scenario_metadata_changed_keys": changes, "preflight_source_hashes": preflight["source_hashes"],
        "prepared_hashes": preflight["prepared_hashes"],
        "executed_implementation_hashes": {str(p): digest(p) for p in sorted((full / "implementation").glob("*.py"))},
        "analysis_implementation_hashes": {str(PREVIOUS / name): digest(PREVIOUS / name) for name in ["audit_response.py", "audit_scope.py", "summarize_response.py"]},
        "claim_boundary": "Input proof only. No active native XML read. Unlike late demand substitutions, geometry/control changes start at zero, so initialization count equality is not presumed."}
    audit.save(OUT / "input-proof.json", result)
    return signatures, vehicles


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scope-only", action="store_true")
    args = parser.parse_args()
    signatures, vehicles = scope_check()
    if args.scope_only:
        seal(OUT)
        print(json.dumps({"status": "pass", "scope_only": True, "N": len(vehicles)}))
        return
    full = STUDY / "full"
    if not (full / "verdict.json").exists():
        print(json.dumps({"status": "review_required", "reason": "No complete verdict; in-progress native output not read"}))
        return
    verdict = json.loads((full / "verdict.json").read_bytes())
    compact = SOURCE.parents[1] / "selected-next-diagnosis/selected-contributing-passages.json.gz"
    reference = audit.evidence(BASE, SOURCE, compact, 8640)
    current = audit.evidence(full / "prepared", full / "evaluation", full / "evaluation/contributing-passages.json.gz", 8640)
    assert reference["periodic"].keys() == current["periodic"].keys()
    assert verdict["before"] == reference["recorded"] and verdict["after"] == current["recorded"]
    assert verdict["all182_TAE"] == current["metrics182"]["TAE"] and verdict["complete_contributions"] == current["event_count"]
    assert set(current["by_vehicle"]) <= vehicles.keys()
    fields535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}

    def group(identity):
        origin = vehicles[identity].find("route").get("edges").split()[0]
        primary = signatures[identity][0]
        return "minus142_535_Z5to8" if origin == "-142944318" and primary in fields535 else "119_Z5" if primary == "hh_0119_Z_5_30494" else "all_other"

    cohort_names = ["minus142_535_Z5to8", "119_Z5", "all_other"]
    before_groups, after_groups = {}, {}
    for name in cohort_names:
        members = {identity for identity in vehicles if group(identity) == name}
        before_groups[name], after_groups[name] = [audit.counts(data["by_vehicle"], members) for data in [reference, current]]
    main_keys, init_keys = [{audit.key(r) for r in current[name]} for name in ["main", "initial"]]
    bins = []
    for k in sorted(current["periodic"], key=lambda k: (k[1], k[0])):
        old_count, count = int(reference["periodic"][k]["nVehContrib"]), int(current["periodic"][k]["nVehContrib"])
        row = {"field": k[0], "begin": k[1], "end": k[2], "region": "main" if k in main_keys else "initialization" if k in init_keys else "tail",
               "reference_count": old_count, "candidate_count": count, "delta": count - old_count}
        for name in cohort_names:
            row[name + "_before"], row[name + "_after"] = before_groups[name][k], after_groups[name][k]
            row[name + "_delta"] = after_groups[name][k] - before_groups[name][k]
        assert row["delta"] == sum(row[name + "_delta"] for name in cohort_names)
        bins.append(row)
    output = OUT / "complete"
    output.mkdir(exist_ok=True)
    for name in ["main", "initial", "stations"]:
        audit.table(output / f"{name}-comparison.csv", current[name])
    reference182 = {audit.key(row): row for row in reference["initial"] + reference["main"]}
    residual182 = []
    for row in current["initial"] + current["main"]:
        old = reference182[audit.key(row)]
        old_error, error = int(old["diff_nVehContrib_minus_expected"]), int(row["diff_nVehContrib_minus_expected"])
        residual182.append({"field": row["detector_id"], "begin": row["begin"], "end": row["end"], "target": row["expected_total"],
            "reference_count": old["measured_nVehContrib"], "candidate_count": row["measured_nVehContrib"],
            "reference_residual": old_error, "candidate_residual": error,
            "absolute_error_change": abs(error) - abs(old_error), "squared_error_change": error * error - old_error * old_error})
    audit.table(output / "residual182-before-after.csv", residual182)
    audit.table(output / "native208-cohort-comparison.csv", bins)
    audit.table(output / "cohort-region-summary.csv", [{"cohort": name, "region": region,
        "requested_vehicles": sum(group(identity) == name for identity in vehicles),
        "reference_events": sum(row[name + "_before"] for row in bins if row["region"] == region),
        "candidate_events": sum(row[name + "_after"] for row in bins if row["region"] == region),
        "event_delta": sum(row[name + "_delta"] for row in bins if row["region"] == region)}
        for name in cohort_names for region in ["initialization", "main", "tail"]])
    field_rows = []
    for field in sorted({k[0] for k in current["periodic"]}):
        a, b = [audit.metrics([r for r in data["main"] if r["detector_id"] == field]) for data in [reference, current]]
        field_rows.append({"field": field, "before_SSE": a["SSE"], "after_SSE": b["SSE"], "SSE_change": b["SSE"] - a["SSE"],
                           "before_TAE": a["TAE"], "after_TAE": b["TAE"], "TAE_change": b["TAE"] - a["TAE"]})
    audit.table(output / "field13-main-residuals.csv", field_rows)
    changed = []
    for identity in sorted(vehicles):
        old, new = [audit.event_view(data["by_vehicle"].get(identity, [])) for data in [reference, current]]
        if old != new:
            changed.append({"vehicle_id": identity, "input_cohort": group(identity), "prior_primary_intention": signatures[identity][0],
                            "reference_events": old, "candidate_events": new,
                            "field_bin_signature_changed": [(r["field"], r["begin"]) for r in old] != [(r["field"], r["begin"]) for r in new]})
    audit.table(output / "vehicle-event-changes.csv", changed)
    terminal, terminal_groups = backlog(full / "evaluation", signatures)
    audit.table(output / "terminal-vehicles.csv", terminal)
    reference_terminal, reference_terminal_groups = backlog(SOURCE, signatures)
    audit.table(output / "reference-terminal-vehicles.csv", reference_terminal)
    extra = [{"vehicle_id": identity, **audit.event_view([e])[0]} for identity, events in current["by_vehicle"].items() for e in events if e["detector_id"] not in signatures[identity]]
    repeated = [{"vehicle_id": identity, "field": f, "count": n} for identity, events in current["by_vehicle"].items() for f, n in Counter(e["detector_id"] for e in events).items() if n > 1]
    assert len(extra) == len(verdict["contributions_outside_prior_primary_intention"]) and bool(repeated) == bool(verdict["repeated_vehicle_fields"])
    summary = {"schema": "astra.hamburg.197-full-response-audit/v1", "status": "pass", "native_runs_by_audit": 0,
        "raw_verdict_status": verdict["status"], "formal_result_as_recorded": verdict["formal_result"],
        "reference": {k: reference[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion"]},
        "candidate": {k: current[k] for k in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count"]},
        "source_hashes": {"reference": reference["source_hashes"], "candidate": current["source_hashes"]},
        "terminal_groups_by_requested_origin_and_prior_field": terminal_groups, "reference_terminal_groups": reference_terminal_groups,
        "event_time_or_signature_changes": len(changed),
        "field_bin_signature_changes": sum(r["field_bin_signature_changed"] for r in changed),
        "outside_prior_primary_intention_count": len(extra), "outside_prior_primary_intention_events": extra, "repeated_vehicle_fields": repeated,
        "all_actual_fields_retained_in_objective": True,
        "claim_boundary": "Actual nVehContrib for all fields/windows, with no relabelling or filtering by inherited intentions. Physical/source support and count fit are separate; this audit does not reuse a trip-substitution improvement gate. A changed initialization or poorer fit is reported, not hidden. Cohort differences are arithmetic, not causal isolation or true OD identification."}
    audit.save(output / "scan.json", summary)
    seal(output)
    seal(OUT)
    print(json.dumps({k: v for k, v in summary.items() if k not in ["source_hashes", "outside_prior_primary_intention_events", "claim_boundary", "terminal_groups_by_requested_origin_and_prior_field"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
