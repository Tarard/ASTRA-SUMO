# 197 节点：旧 V1 与当前生成网的局部差异

结论为 `review_required`。独立 TLS 已存在于最初 OSM 生成网，并非后来 238 道路修复才加入。旧 V1 同一点没有 TLS，但局部支路、车道用途、连接和冲突关系均不同，不能把两网差异归结为一个猜灯参数。原输入、核心代码、网络和控制均未修改；本次没有生成候选或运行仿真。

两网均用 EPSG:25832。按各自 netOffset 还原后，197 节点位置差约 0.0038 米。`local-comparison.json` 保存局部普通道路、完整类权限、编译连接、请求表和投影坐标。按各边 passenger 车道顺序匹配，共享车道折线的 Hausdorff 差仍为 1.267–5.703 米；这里只做几何对照，不把这些顺序配对视为已经核准的现场车道对应。

| 项目 | 旧 V1 | 最初生成网 / 当前 |
| --- | --- | --- |
| 197 类型 | priority | traffic_light + actuated |
| 普通关联道路 | 4 条 tertiary（两入两出） | 同 4 条 + 28665128#0 service 出口 |
| 主路 priority | 均 10 | 均 10；service 为 1 |
| -186821028 的 passenger 车道 | 0/1/2 | 2/3/4；0 为步行、1 为自行车 |
| 进入 186821027#0 的 passenger 直行 | 0→0、1→1、2→2/3，共 4 条 | 仅 2→2；1→1 为 bicycle-only |
| 其他该进口 passenger 转向 | 无 | 3→286 左转、4→反向道路掉头 |
| 反向及支路连接 | 两条直行 | 新增停车支路右转、掉头；另有自行车连接 |
| request 数 | 6，foes 全零 | 14，包含非零冲突及过街 |

最初生成网与当前 197 的全部普通连接、编译类权限和 request 属性逐项相同。当前只有一条 passenger 直行连接，是原始导入结果，不是后来双字段替换或局部修复造成。旧 V1 不包含 28665128#0，当前焦点车的新出口恰为这条支路；不能直接移植旧连接/零冲突表。

两份原始转换头已逐字提取。10 月 21 日最初生成网明确启用 `tls.guess`、`tls.guess-signals`、`tls.default-type=actuated`、`tls.rebuild`，并保留自行车、步行与 OSM turn-lanes。旧 V1 的头仅记录 8 月 31 日从已有 sumo-net-file 加载 `lsa535.con.xml` 和 `approach-phase.tll.xml` 的最后一次转换，没有最初 OSM 生成命令。头中不见 guess 参数，不能解释成“旧网最初猜灯关闭”。当前导出网不再保存转换配置头，故追溯使用已冻结的 original-osm.net.xml。

仓库 `osm_network._netconvert_profile_options` 在 reference visual 类配置中明确加入上述猜灯、过街和 turn-lanes 参数；默认 vehicle_core 返回空附加参数。它说明仓库存在不同生成假设，但没有证明旧 V1 当初选择了哪一个配置，也没有隔离出这次 197 TLS 由哪一条猜测规则触发。`tls_aggregation` 另有全网 discard/rebuild/join 流程，不适合作为只变一个节点的最小诊断。源码位置及当前哈希见 `reusable-code.json`。

未来若另获授权做单节点撤控反事实，现有最小原语是 `prepare_geometry_frozen_input`、`run_scoped_native_conversion`、`validate_local_conversion` 与 `compare_frozen_geometry`。可在新目录冻结全部普通车道形状/长度和节点轮廓，只把197及其五条关联道路作为本地转换范围，显式调用项目 netconvert 的 `--tls.unset 1975693623`、关闭坐标归一化并保持精度及 internal-link-detail；不得重新 guess/join/rebuild 全网。合并时从原源逐项保留范围外内容，并仅从控制副本移去197对应程序，保持其他50个程序和真实观测不变。

这只是现有方法的可用性说明，尚未证明输出会保持所有内部曲线。现有 geometry freeze 明确不认证 internal 路径。真正的控制单变量诊断必须另外逐条验证：所有普通/内部 lane 的形状、长度、宽度、权限及全部当前合法转向不变；本节点 request/response 按原生 netconvert 重新计算；foes 按真实连接关系核对，不能按旧下标直接复制或全清零；内部连接及 request 的新索引必须一致。若 native 转换改变任何所要求的内部几何，就应拒绝该候选，而非默认为控制变化。`demote_tls_ids` 只删 tl/linkIndex、程序并改 priority，不重算请求表，单独使用不足以满足这一要求。这里未调用上述生成函数。

下一单一问题已明确：原 OSM 的方向性 turn:lanes 是否在停车接入口197提前消耗了本应服务下一535停线的直行车道。应先结合源 way/node、官方535进口1车道和既有航片核对，不能随意添加连接或放宽 bicycle lane1 权限。该问题另作只读来源分析；本目录不以吞吐量或旧 V1 结果赋予改动依据。
