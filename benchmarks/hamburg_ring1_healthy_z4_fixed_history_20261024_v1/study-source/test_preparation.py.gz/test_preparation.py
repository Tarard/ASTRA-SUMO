"""Offline scope and tamper checks; native execution is never called."""

import csv
import importlib.util
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("fixed_history_runner", ROOT / "run.py")
RUN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUN)


@pytest.mark.parametrize("variant", ["reference", "one-car"])
def test_prepared_control_only_scope(variant):
    case = ROOT / variant
    p = RUN.check(case)
    source = Path(p["source_case"]) / "prepared"
    for name in ("network.net.xml", "demand.rou.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json"):
        assert (source / name).read_bytes() == (case / "prepared" / name).read_bytes()
    assert (case / "prepared/control.add.xml").read_bytes() == (ROOT / "reference/prepared/control.add.xml").read_bytes()
    programs = ET.parse(case / "prepared/control.add.xml").getroot()
    assert len(programs) == len({r.get("id") for r in programs}) == 50
    assert all(r.get("type") == "static" for r in programs)
    assert not (case / "evaluation").exists() and not (case / "native-result.json").exists()


def test_exact_original31s_contrast_and_program_mapping():
    routes = [ET.parse(ROOT / v / "prepared/demand.rou.xml").getroot() for v in ("reference", "one-car")]
    a, b = [{r.get("id"): r for r in tree.findall("vehicle")} for tree in routes]
    assert len(a) == len(b) == 8640 and a.keys() == b.keys()
    assert [i for i in a if a[i].get("depart") != b[i].get("depart")] == ["od_0206_v00001"]
    identity = "od_0206_v00001"
    assert float(b[identity].get("depart")) - float(a[identity].get("depart")) == 31
    with (ROOT / "program-mapping.csv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 50 and all(r["source_program_id"] == r["frozen_program_id"] for r in rows)
    assert all(r["phase_ordinal_is_original_index"] == "False" for r in rows)


def test_tampered_prepared_program_refused(tmp_path):
    fake = tmp_path / "fake"
    shutil.copytree(ROOT / "reference/prepared", fake / "prepared")
    shutil.copyfile(ROOT / "reference/preflight.json", fake / "preflight.json")
    control = fake / "prepared/control.add.xml"
    control.write_bytes(control.read_bytes() + b"\n")
    with pytest.raises(AssertionError):
        RUN.check(fake)
    assert not (fake / "evaluation").exists()
