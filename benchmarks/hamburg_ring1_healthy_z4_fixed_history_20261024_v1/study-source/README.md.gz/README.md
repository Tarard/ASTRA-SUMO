# 固定健康源灯色历史：仅准备条件对照

两份输入共用刚录得的 reference 50 个完整 SaveTLSProgram 程序，control SHA256 为 `74bff7513926a6b62a772439c058d47c318765791538e8bbc077702f70a39dc2`。50 个唯一直接 tlLogic 均为 static，每条恰覆盖 14400 秒，状态长度绑定当前网络，颜色与持续时间逐条匹配 reference SwitchStates。`program-validation.json` 保留复核，`program-mapping.csv` 列出原外部 50 个 id/type/programID 到静态历史的映射。programID 保留；导出 phase ordinal 不代表原 phase index。

reference 保留健康 full-priority 的全部原 8640 需求；one-car 保留已拒绝 batch-1 的完整需求，仍只有原先那一辆 `od_0206_v00001` 延后 31 秒。两份需求及各自 lane-intentions 均与来源原字节相同，没有再改发车时刻或调用 OD 生成器。两份都用当前 `99f208c9…` 网络，不恢复旧几何或其他配时。全部 routes/stops/vTypes、真实 130/52 targets、探头、四个 body-hold 节点、Libsumo 1.27.1、0.1 秒、seed104 和空网起点保持。唯一控制处理是把原外部程序替换为同一段模拟灯色历史；scenario 只补其来源声明。

本轮尚未运行 native。仅 root 审查后显式运行：

```powershell
.venv/Scripts/python.exe outputs/hamburg-healthy-z4-fixed-history-20261024-v1/run.py --case reference --run
.venv/Scripts/python.exe outputs/hamburg-healthy-z4-fixed-history-20261024-v1/run.py --case one-car --run
```

运行前使用项目 PYTHONPATH。两条命令可放在独立进程并行执行；每条通过原 core 启动独立 Libsumo 进程。只加入原生 SwitchStates 输出，不增加控制或驾驶 setter。`--check-only` 只核输入哈希，`--help` 不运行仿真。planned-native-request.json 保存完整拟执行命令。

reference 必须先通过与原健康运行的严格复核：208 行 E1 全属性、144000 行 summary（仅排除 CPU duration）、全部 instant 事件、tripinfo、完整 arrived routes/stops/exitTimes、driver hold 报告、期末状态，以及逐 0.1 秒全部 50 TLS 的颜色/program 一致。原 phase index 不要求一致。每份实际 130/40/52/182、53556、完成与安全情况均从新输出重算；不复制旧评价或缓存哈希。

两份结束后 `audit.py --pair` 才给出 reference gate。reference 不等价时，counterpart 原样保留且不作因果解释。即使通过，也只是基于模拟历史的条件控制对照，不是现场 SPaT、真实 OD 证明或标定接受。不超过 14400 秒，不作历史外推。
