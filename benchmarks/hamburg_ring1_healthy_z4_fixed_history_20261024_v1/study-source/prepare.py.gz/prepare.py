"""Prepare two fixed simulated-history conditions without running SUMO."""

import csv
from importlib.metadata import version
import json
from pathlib import Path
import runpy
import shutil
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
RECORD = REPO / "outputs/hamburg-healthy-z4-control-response-20261023-v1"
PROGRAM = RECORD / "reference/tls-recorded-programs.add.xml"
SOURCES = {
    "reference": REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority",
    "one-car": REPO / "outputs/hamburg-healthy-z4-feedback-20261023-v1/batch-1",
}
NAMES = ("network.net.xml", "demand.rou.xml", "field-loops.add.xml", "expected-counts.csv",
         "initialization-counts.csv", "lane-intentions.json", "scenario.json")
OLD = REPO / "outputs/hamburg-z5-native-feedback-20261023-v1/tls-feedback-diagnosis"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    assert not (ROOT / "preparation.json").exists(), "Preserve existing prepared conditions."
    assert Path(sys.executable).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    helper = runpy.run_path(str(RECORD / "compare_tls.py"))
    widths = {}
    for row in ET.parse(SOURCES["reference"] / "prepared/network.net.xml").getroot().findall("connection"):
        if row.get("tl"):
            widths[row.get("tl")] = max(widths.get(row.get("tl"), 0), int(row.get("linkIndex")) + 1)
    states = helper["read_states"](RECORD / "reference/tls-switch-states.xml", widths)
    export = helper["audit_program"](PROGRAM, widths, states)
    assert export["status"] == "pass"
    record = json.loads((RECORD / "reference/record-result.json").read_bytes())
    assert record["status"] == "pass" and all(record["checks"].values())
    old_programs = {r.get("id"): r for r in ET.parse(SOURCES["reference"] / "prepared/control.add.xml").getroot()}
    fixed_programs = {r.get("id"): r for r in ET.parse(PROGRAM).getroot()}
    assert old_programs.keys() == fixed_programs.keys() == widths.keys() and len(widths) == 50
    mapping = [dict(tls_id=i, source_active_type=old_programs[i].get("type"),
                    source_program_id=old_programs[i].get("programID"),
                    frozen_type=fixed_programs[i].get("type"), frozen_program_id=fixed_programs[i].get("programID"),
                    state_width=widths[i], horizon_s=14400, phase_ordinal_is_original_index=False)
               for i in sorted(widths)]
    assert all(r["frozen_type"] == "static" and r["source_program_id"] == r["frozen_program_id"] for r in mapping)
    with (ROOT / "program-mapping.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(mapping[0]))
        writer.writeheader()
        writer.writerows(mapping)
    save(ROOT / "program-validation.json", export)
    versions = {n: version(n) for n in ("eclipse-sumo", "libsumo", "traci", "sumolib")}
    assert set(versions.values()) == {"1.27.1"}
    from libsumo import _libsumo
    binaries = [Path(sys.executable), REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe", Path(_libsumo.__file__)]
    for variant, source in SOURCES.items():
        case = ROOT / variant
        (case / "prepared").mkdir(parents=True)
        prepared = case / "prepared"
        for name in NAMES:
            shutil.copyfile(source / "prepared" / name, prepared / name)
        shutil.copyfile(PROGRAM, prepared / "control.add.xml")
        scenario = json.loads((prepared / "scenario.json").read_bytes())
        scenario.update(control_sha256=sha(PROGRAM), formal_result=False,
            control_treatment=dict(kind="recorded_healthy_simulated_history_static", source=str(PROGRAM),
                sha256=sha(PROGRAM), horizon_s=14400, post_horizon_extrapolation=False, observed_field_spat=False,
                phase_ordinal_is_original_phase_index=False,
                claim="Same healthy simulated color history for both demand conditions; not fieldSPaT or calibrated controls."))
        save(prepared / "scenario.json", scenario)
        assert all((source / "prepared" / n).read_bytes() == (prepared / n).read_bytes() for n in NAMES if n != "scenario.json")
        native = source / "evaluation/native"
        request = json.loads((native / "native-request.json").read_bytes())
        target_native = case / "evaluation/native"
        command = [part.replace(str(native), str(target_native)) for part in request["command"]]
        command[command.index("--additional-files") + 1] += "," + str(target_native / "tls-observer.add.xml")
        planned = {**request, "command": command, "monitor_file": str(target_native / "stall-monitor.json")}
        for key in ("lane_intentions_file", "route_file", "e1_file"):
            planned[key] = planned[key].replace(str(native), str(target_native))
        assert request["backend"] == "libsumo" and request["end_s"] == 14400 and request["junction_body_hold"]
        assert len(request["junction_body_hold_nodes"]) == 4 and command[command.index("--step-length") + 1] == "0.1"
        assert not any("fcd" in part.lower() or "load-state" in part for part in command)
        save(case / "planned-native-request.json", planned)
        implementation = case / "implementation"
        implementation.mkdir()
        for frozen in (source / "implementation").glob("*.py"):
            current = REPO / "plugins/astra-sumo/src/astra_sumo/core" / frozen.name
            assert current.read_bytes() == frozen.read_bytes(), current
            shutil.copyfile(current, implementation / frozen.name)
        assert sha(Path(_libsumo.__file__)) == json.loads((native / "stall-monitor.json").read_bytes())["native_library"]["sha256"]
        bound = [source / "prepared" / n for n in (*NAMES, "control.add.xml")]
        bound += [PROGRAM, RECORD / "reference/record-result.json", RECORD / "reference/tls-switch-states.xml",
                  RECORD / "compare_tls.py", native / "native-request.json", source / "verdict.json",
                  OLD / "run_frozen_self_replay.py", OLD / "audit_frozen_self_replay.py", *binaries]
        save(case / "preflight.json", dict(status="prepared", native_runs=0, formal_result=False,
             source_case=str(source), source_native=str(native), frozen_history_sha256=sha(PROGRAM),
             source_hashes={str(p): sha(p) for p in bound}, versions=versions,
             actual_binary_paths={str(p): sha(p) for p in binaries},
             core_source_hashes={p.name: sha(p) for p in implementation.iterdir()},
             prepared_hashes={p.name: sha(p) for p in prepared.iterdir()},
             only_control_program_content_replaced=True, no_depart_route_stop_lane_driver_changes=True,
             end_s=14400, step_s=.1, seed=104, post_horizon_extrapolation=False,
             phase_index_equality_required=False, reference_full_native_parity_required_before_interpretation=True))
    assert (ROOT / "reference/prepared/network.net.xml").read_bytes() == (ROOT / "one-car/prepared/network.net.xml").read_bytes()
    assert (ROOT / "reference/prepared/control.add.xml").read_bytes() == (ROOT / "one-car/prepared/control.add.xml").read_bytes() == PROGRAM.read_bytes()
    for name in ("run_frozen_self_replay.py", "audit_frozen_self_replay.py"):
        shutil.copyfile(OLD / name, ROOT / ("reused-" + name + ".txt"))
    save(ROOT / "preparation.json", dict(status="ready_for_root_review", native_runs=0, formal_result=False,
         variants=list(SOURCES), frozen_control_sha256=sha(PROGRAM), export=export,
         reference_gate="208E1 attrs/144000summary exceptCPUduration/allinstant/trips/routes/driverholds/endstate plus50TLS colors/programs exact to healthy reference",
         counterpart_gate="Retain results even if run concurrently; interpret only after reference parity passes",
         claim_boundary="Conditional control-history experiment using simulated history, not fieldSPaT or calibration acceptance. No post14400 extrapolation; exported phase ordinals are not original phase indices."))
    print(json.dumps(dict(status="prepared", native_runs=0, frozen_control_sha256=sha(PROGRAM), programs=50)))


if __name__ == "__main__":
    main()
