"""Audit saved fixed-history results; a failed reference blocks interpretation."""

import argparse
import json
from pathlib import Path
import runpy
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows, write_csv

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OLD = REPO / "outputs/hamburg-z5-native-feedback-20261023-v1/tls-feedback-diagnosis/audit_frozen_self_replay.py"
RECORD = REPO / "outputs/hamburg-healthy-z4-control-response-20261023-v1"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def metrics(rows):
    errors = [int(r["diff_nVehContrib_minus_expected"]) for r in rows]
    return dict(rows=len(rows), SSE=sum(v*v for v in errors), TAE=sum(map(abs, errors)),
                MAE=sum(map(abs, errors))/len(rows), max_abs_error=max(map(abs, errors)))


def audit_case(variant):
    case = ROOT / variant
    evaluation, prepared = case / "evaluation", case / "prepared"
    native = evaluation / "native"
    p = json.loads((case / "preflight.json").read_bytes())
    source = Path(p["source_native"])
    report = json.loads((native / "run.json").read_bytes())
    prior = json.loads((source / "run.json").read_bytes())
    old = runpy.run_path(str(OLD))
    comparisons = {"E1": old["compare_rows"](source / "field-counts.xml", native / "field-counts.xml", tag="interval"),
                   "summary": old["compare_rows"](source / "summary.xml", native / "summary.xml", tag="step", ignore=("duration",)),
                   "instant": old["compare_rows"](source / "instant-e1.xml", native / "instant-e1.xml", tag="instantOut")}
    trips = [old["keyed_xml"](folder / "tripinfo.xml", "tripinfo") for folder in (source, native)]
    routes = [old["keyed_xml"](folder / "vehicle-routes.xml", "vehicle") for folder in (source, native)]
    helper = runpy.run_path(str(RECORD / "compare_tls.py"))
    widths = {}
    for row in ET.parse(prepared / "network.net.xml").getroot().findall("connection"):
        if row.get("tl"):
            widths[row.get("tl")] = max(widths.get(row.get("tl"), 0), int(row.get("linkIndex")) + 1)
    reference_states = helper["read_states"](RECORD / "reference/tls-switch-states.xml", widths)
    actual_states = helper["read_states"](native / "tls-switch-states.xml", widths)
    color_differences = []
    for identity in sorted(widths):
        a, b = reference_states[identity], actual_states[identity]
        boundaries = sorted({0, 144000} | {r["tick"] for r in a+b})
        ai = bi = 0
        for begin, end in zip(boundaries, boundaries[1:]):
            while ai+1 < len(a) and a[ai+1]["tick"] <= begin:
                ai += 1
            while bi+1 < len(b) and b[bi+1]["tick"] <= begin:
                bi += 1
            if (a[ai]["state"], a[ai]["programID"]) != (b[bi]["state"], b[bi]["programID"]):
                color_differences.append(dict(tls_id=identity, begin_tick=begin, end_tick=end))
    unsafe = any(report["completion"][k] for k in ("collisions", "teleports", "discarded"))
    fresh = json.loads((case / "native-result.json").read_bytes())
    checks = dict(fresh_native_completed=report["native_status"] == "pass" and report["stall_monitor"]["status"] == "completed",
                  input_hashes_unchanged=fresh["source_inputs_unchanged"] and
                      all(old["digest"](Path(path)) == h for path, h in p["source_hashes"].items()) and
                      all(old["digest"](prepared / n) == h for n, h in p["prepared_hashes"].items()),
                  exact50_color_and_program_histories=len(widths) == 50 and not color_differences,
                  full14400_horizon=report["end_s"] == 14400 and report["step_length_s"] == .1 and report["stall_monitor"]["simulation_time_s"] == 14400,
                  raw208_E1_and144000_summary_complete=len(ET.parse(native / "field-counts.xml").getroot()) == 208 and
                      sum(1 for _ in old["elements"](native / "summary.xml", "step")) == 144000,
                  complete_trip_and_arrived_route_records=len(trips[1]) == report["completion"]["inserted"] and len(routes[1]) == report["completion"]["arrived"],
                  no_unsafe=not unsafe and not ET.parse(native / "collisions.xml").getroot().findall("collision"))
    reference_checks = dict(E1_208_allattrs_exact=comparisons["E1"]["same"] and comparisons["E1"]["rows"] == 208,
                            summary_144000_exceptCPUduration_exact=comparisons["summary"]["same"] and comparisons["summary"]["rows"] == 144000,
                            all_instant_events_exact=comparisons["instant"]["same"], all_tripinfo_exact=trips[0] == trips[1],
                            all_arrived_routes_stops_exitTimes_exact=routes[0] == routes[1],
                            all_driver_holds_exact=prior["stall_monitor"]["lane_section_hold"] == report["stall_monitor"]["lane_section_hold"],
                            completion_and_health_exact=prior["completion"] == report["completion"] and prior["healthy"] == report["healthy"])
    main = audit_expected_to_e1_strict(read_csv_rows(prepared / "expected-counts.csv"), native / "field-counts.xml", count_attribute="nVehContrib")
    initial = audit_expected_to_e1_strict(read_csv_rows(prepared / "initialization-counts.csv"), native / "field-counts.xml", count_attribute="nVehContrib")
    assert len(main) == 130 and len(initial) == 52
    fields535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}
    all535 = [r for r in main + initial if r["detector_id"] in fields535]
    assert len(all535) == 56
    for name, rows in (("all182", main+initial), ("initialization52", initial), ("535-all56", all535)):
        write_csv(evaluation / f"{name}-comparison.csv", rows, list(rows[0]))
    required = {**checks, **reference_checks} if variant == "reference" else checks
    result = dict(status="pass" if all(required.values()) else "blocked", variant=variant, formal_result=False,
                  checks=required, comparisons_with_original_same_demand=reference_checks,
                  raw_comparisons=comparisons, color_differences=color_differences,
                  metrics130=metrics(main), metrics52=metrics(initial), metrics182=metrics(main+initial),
                  all53556=metrics(all535), evaluation=json.loads((evaluation / "evaluation.json").read_bytes()),
                  completion=report["completion"], healthy=report["healthy"], phase_index_equality_required=False,
                  causal_interpretation_pending_reference_gate=True,
                  claim_boundary="Conditional simulated color-history control. Original phase indices need not match. Reference must exactly reproduce healthy traffic before interpreting counterpart; no fieldSPaT or calibration acceptance.")
    save(case / "parity.json", result)
    return result


def pair():
    results = {v: audit_case(v) for v in ("reference", "one-car")}
    eligible = all(r["status"] == "pass" for r in results.values())
    result = dict(status="pass" if eligible else "blocked", formal_result=False,
                  reference_parity_passed=results["reference"]["status"] == "pass",
                  conditional_comparison_interpretable=eligible, results=results,
                  claim_boundary="Counterpart preserved if reference fails; no causal reading or calibration acceptance then. Even on pass this is simulated-history conditioning, not fieldSPaT.")
    save(ROOT / "paired-result.json", result)
    print(json.dumps(dict(status=result["status"], conditional_comparison_interpretable=eligible)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument("--case", choices=("reference", "one-car"))
    choice.add_argument("--pair", action="store_true")
    args = parser.parse_args()
    pair() if args.pair else print(json.dumps(audit_case(args.case), ensure_ascii=False))
