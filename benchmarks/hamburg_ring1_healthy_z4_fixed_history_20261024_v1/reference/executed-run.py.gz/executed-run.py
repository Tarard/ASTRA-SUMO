"""Explicitly run one prepared simulated-history condition using the existing core."""

import argparse
import gzip
import json
from pathlib import Path
import shutil
import sys
import time
import traceback
import xml.etree.ElementTree as ET

from astra_sumo.core import detector_demand_replay as replay
from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.hamburg_od_spsa import summarize_hamburg_od_measurement
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def check(case):
    p = json.loads((case / "preflight.json").read_bytes())
    assert p["status"] == "prepared" and not p["post_horizon_extrapolation"]
    assert all(sha(Path(path)) == h for path, h in p["source_hashes"].items())
    assert all(sha(case / "prepared" / name) == h for name, h in p["prepared_hashes"].items())
    assert all(sha(REPO / "plugins/astra-sumo/src/astra_sumo/core" / n) == h for n, h in p["core_source_hashes"].items())
    return p


def run(variant):
    case = ROOT / variant
    p = check(case)
    assert Path(sys.executable).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    prepared, evaluation = case / "prepared", case / "evaluation"
    assert not evaluation.exists() and not (case / "native-result.json").exists(), "Preserve all existing native results."
    evaluation.mkdir()
    for name in ("demand.rou.xml", "lane-intentions.json"):
        shutil.copyfile(prepared / name, evaluation / name)
    shutil.copyfile(__file__, case / "executed-run.py")
    source_request = json.loads((Path(p["source_native"]) / "native-request.json").read_bytes())
    planned = json.loads((case / "planned-native-request.json").read_bytes())
    original_run_command = replay.run_command
    calls = []

    def observer_command(command, *, cwd, timeout_seconds):
        # Same request-file output adapter as the prior frozen-history tool.
        request_file = Path(command[-1])
        assert request_file == evaluation / "native/native-request.json" and not calls
        request = json.loads(request_file.read_bytes())
        observer = ET.Element("additional")
        observer_file = evaluation / "native/tls-observer.add.xml"
        ET.SubElement(observer, "timedEvent", type="SaveTLSSwitchStates", dest=str(evaluation / "native/tls-switch-states.xml"))
        ET.ElementTree(observer).write(observer_file, encoding="utf-8", xml_declaration=True)
        request["command"][request["command"].index("--additional-files") + 1] += "," + str(observer_file)
        assert request == planned, "Only planned output paths and observer are allowed."
        save(request_file, request)
        calls.append(dict(request_sha256=sha(request_file), observer_sha256=sha(observer_file),
                          monitor_command=command, timeout_seconds=timeout_seconds,
                          no_driver_or_TLS_setter_hook=True))
        save(case / "observer-adapter.json", calls[0])
        return original_run_command(command, cwd=cwd, timeout_seconds=timeout_seconds)

    started = time.perf_counter()
    save(case / "execution.json", dict(status="running", variant=variant, formal_result=False,
         executed_script_sha256=sha(case / "executed-run.py"), preflight_sha256=sha(case / "preflight.json"),
         planned_request_sha256=sha(case / "planned-native-request.json")))
    replay.run_command = observer_command
    try:
        native = replay.run_point_detector_demand(
            net_file=prepared / "network.net.xml", route_file=prepared / "demand.rou.xml",
            e1_additional_file=prepared / "field-loops.add.xml", expected_counts_csv=prepared / "expected-counts.csv",
            output_dir=evaluation / "native", end_s=14400, step_length=.1, seed=104, timeout_seconds=4800,
            sumo_binary=source_request["command"][0], signal_program_file=prepared / "control.add.xml",
            lane_intentions_file=prepared / "lane-intentions.json", junction_body_hold=True,
            junction_body_hold_nodes=tuple(source_request["junction_body_hold_nodes"]), backend="libsumo")
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        events = read_contributing_e1_passages(
            instant_file=evaluation / "native/instant-e1.xml", periodic_file=evaluation / "native/field-counts.xml",
            detector_ids=native["instant_to_periodic_ids"], step_length=.1)
        assert events["reconciled"]
        (evaluation / "contributing-passages.json.gz").write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        result = dict(status="completed_parity_pending", native_status=native["native_status"],
                      completion=native["completion"], healthy=native["healthy"], formal_result=False,
                      source_inputs_unchanged=all(sha(Path(path)) == h for path, h in p["source_hashes"].items()),
                      observer_calls=len(calls), fresh_native_measurement=True, post_horizon_extrapolation=False)
    except Exception as error:
        result = dict(status="failed", formal_result=False, partial_outputs_preserved=True,
                      error=f"{type(error).__name__}: {error}")
        (case / "failure.log").write_text(traceback.format_exc(), encoding="utf-8")
    finally:
        replay.run_command = original_run_command
    result["elapsed_s"] = time.perf_counter() - started
    save(case / "native-result.json", result)
    save(case / "execution.json", {**result, "variant": variant})
    if result["status"] == "failed":
        raise SystemExit(1)
    from audit import audit_case
    print(json.dumps(audit_case(variant), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("reference", "one-car"), required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.check_only:
        p = check(ROOT / args.case)
        print(json.dumps(dict(status="pass", native_runs=0, case=args.case,
                              frozen_control_sha256=p["frozen_history_sha256"])))
    else:
        run(args.case)
