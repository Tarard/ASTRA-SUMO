"""Independently verify two sealed fixed-color histories and raw traffic output."""

from collections import Counter
from copy import deepcopy
from decimal import Decimal
import itertools
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
RECORD = REPO / "outputs/hamburg-healthy-z4-control-response-20261023-v1"
HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPERS))
import audit_response as audit  # noqa: E402


END_TICK = 144000
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def elements(path, tag):
    for _, row in ET.iterparse(path, events=("end",)):
        if row.tag == tag:
            yield row
            row.clear()


def compare_rows(a, b, tag, ignored=()):
    differences, count = [], 0
    for old, new in itertools.zip_longest(elements(a, tag), elements(b, tag)):
        assert old is not None and new is not None, (tag, "row count differs")
        count += 1
        oa = {k: v for k, v in old.attrib.items() if k not in ignored}
        na = {k: v for k, v in new.attrib.items() if k not in ignored}
        if oa != na and len(differences) < 10:
            differences.append({"row": count - 1, "before": oa, "after": na})
    return {"same": not differences, "rows": count, "differences": differences}


def keyed(path, tag):
    rows = {}
    for row in elements(path, tag):
        identity = row.get("id")
        assert identity not in rows
        rows[identity] = ET.canonicalize(ET.tostring(row, encoding="unicode"), strip_text=True)
    return rows


def histories(path, widths):
    result = {identity: [] for identity in widths}
    for row in elements(path, "tlsState"):
        identity = row.get("id")
        assert identity in widths
        tick_value = Decimal(row.get("time")) * 10
        assert tick_value == tick_value.to_integral_value()
        tick = int(tick_value)
        if tick >= END_TICK:
            continue
        state, program = row.attrib["state"], row.attrib["programID"]
        assert len(state) == widths[identity]
        records = result[identity]
        assert not records or records[-1][0] < tick
        if not records or records[-1][1:] != (state, program):
            records.append((tick, state, program))
    assert all(records and records[0][0] == 0 for records in result.values())
    return result


def program_histories(path, widths):
    programs = ET.parse(path).getroot().findall("tlLogic")
    assert len(programs) == len({p.get("id") for p in programs}) == 50
    result, phases = {}, {}
    for program in programs:
        identity = program.get("id")
        assert identity in widths and program.get("type") == "static" and Decimal(program.get("offset", "0")) == 0
        tick, records = 0, []
        phases[identity] = len(program.findall("phase"))
        for phase in program.findall("phase"):
            duration = Decimal(phase.get("duration")) * 10
            assert duration > 0 and duration == duration.to_integral_value()
            state = phase.get("state")
            assert len(state) == widths[identity]
            if not records or records[-1][1:] != (state, program.get("programID")):
                records.append((tick, state, program.get("programID")))
            tick += int(duration)
        assert tick == END_TICK
        result[identity] = records
    return result, phases


def difference_ticks(a, b):
    boundaries = sorted({0, END_TICK} | {row[0] for row in a + b})
    ai = bi = count = 0
    for begin, end in zip(boundaries, boundaries[1:]):
        while ai + 1 < len(a) and a[ai + 1][0] <= begin:
            ai += 1
        while bi + 1 < len(b) and b[bi + 1][0] <= begin:
            bi += 1
        if a[ai][1:] != b[bi][1:]:
            count += end - begin
    return count


def main():
    paired_path = STUDY / "paired-result.json"
    paired = json.loads(paired_path.read_bytes())
    assert paired["status"] == "pass"
    source_hashes = {str(paired_path): audit.digest(paired_path)}
    scopes = {}
    for label in ["reference", "one-car"]:
        case = STUDY / label
        preflight = json.loads((case / "preflight.json").read_bytes())
        assert preflight["status"] == "prepared" and not preflight["post_horizon_extrapolation"]
        assert set(preflight["versions"].values()) == {"1.27.1"}
        for path, value in {**preflight["source_hashes"], **preflight["actual_binary_paths"]}.items():
            assert audit.digest(Path(path)) == value
            source_hashes[path] = value
        for name, value in preflight["prepared_hashes"].items():
            assert audit.digest(case / "prepared" / name) == value
            source_hashes[str(case / "prepared" / name)] = value
        for name, value in preflight["core_source_hashes"].items():
            assert audit.digest(case / "implementation" / name) == value
            source_hashes[str(case / "implementation" / name)] = value
        source = Path(preflight["source_case"])
        for name in ["network.net.xml", "demand.rou.xml", "lane-intentions.json", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]:
            assert (case / "prepared" / name).read_bytes() == (source / "prepared" / name).read_bytes()
        assert audit.digest(case / "prepared/control.add.xml") == preflight["frozen_history_sha256"]
        assert (case / "executed-run.py").read_bytes() == (STUDY / "run.py").read_bytes()
        native_request = json.loads((case / "evaluation/native/native-request.json").read_bytes())
        assert native_request == json.loads((case / "planned-native-request.json").read_bytes())
        adapter = json.loads((case / "observer-adapter.json").read_bytes())
        assert adapter["request_sha256"] == audit.digest(case / "evaluation/native/native-request.json")
        assert adapter["observer_sha256"] == audit.digest(case / "evaluation/native/tls-observer.add.xml")
        assert adapter["no_driver_or_TLS_setter_hook"]
        assert json.loads((case / "native-result.json").read_bytes())["fresh_native_measurement"]
        for name in ["executed-run.py", "planned-native-request.json", "observer-adapter.json", "native-result.json", "execution.json", "parity.json"]:
            source_hashes[str(case / name)] = audit.digest(case / name)
        for name in ["native-request.json", "tls-observer.add.xml"]:
            source_hashes[str(case / "evaluation/native" / name)] = audit.digest(case / "evaluation/native" / name)
        scopes[label] = preflight
        source_hashes[str(case / "preflight.json")] = audit.digest(case / "preflight.json")
    folders = [STUDY / label / "prepared" for label in ["reference", "one-car"]]
    for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]:
        assert (folders[0] / name).read_bytes() == (folders[1] / name).read_bytes()
    routes = [{v.get("id"): v for v in ET.parse(folder / "demand.rou.xml").getroot().findall("vehicle")} for folder in folders]
    assert routes[0].keys() == routes[1].keys() and len(routes[0]) == 8640
    changed = []
    for identity in routes[0]:
        old, new = routes[0][identity], routes[1][identity]
        if old.get("depart") != new.get("depart"):
            changed.append(identity)
        restored = deepcopy(new)
        restored.set("depart", old.get("depart"))
        assert ET.tostring(old) == ET.tostring(restored)
    assert changed == ["od_0206_v00001"]
    identity = changed[0]
    requested_departures = [Decimal(rows[identity].get("depart")) for rows in routes]
    requested_delta = requested_departures[1] - requested_departures[0]
    assert abs(requested_delta - Decimal(31)) <= Decimal("0.000000000002")
    assert requested_departures[1].quantize(Decimal(".001")) - requested_departures[0].quantize(Decimal(".001")) == Decimal("31.000")
    assert [i for i in routes[0] if i != identity] == [i for i in routes[1] if i != identity]
    metadata = [{r["vehicle_id"]: r for r in json.loads((folder / "lane-intentions.json").read_bytes())["vehicles"]} for folder in folders]
    assert all(metadata[0][i]["field_id"] == metadata[1][i]["field_id"] and metadata[0][i]["od_cell"] == metadata[1][i]["od_cell"] for i in routes[0])
    assert [i for i in metadata[0] if metadata[0][i] != metadata[1][i]] == [identity]
    metadata_restored = dict(metadata[1][identity])
    assert Decimal(str(metadata_restored.pop("depart_s"))) == requested_departures[1]
    assert metadata_restored == metadata[0][identity]
    top_metadata = [json.loads((folder / "lane-intentions.json").read_bytes()) for folder in folders]
    assert [k for k in top_metadata[0] if k != "vehicles" and top_metadata[0][k] != top_metadata[1][k]] == ["mechanism"]
    widths = {}
    for row in ET.parse(folders[0] / "network.net.xml").getroot().findall("connection"):
        if row.get("tl"):
            widths[row.get("tl")] = max(widths.get(row.get("tl"), 0), int(row.get("linkIndex")) + 1)
    assert len(widths) == 50
    source_states_path = RECORD / "reference/tls-switch-states.xml"
    source_states = histories(source_states_path, widths)
    programs, phase_counts = program_histories(folders[0] / "control.add.xml", widths)
    actual_states = {label: histories(STUDY / label / "evaluation/native/tls-switch-states.xml", widths) for label in ["reference", "one-car"]}
    colour_rows = []
    for tls in sorted(widths):
        row = {"tls_id": tls, "controlled_link_width": widths[tls], "frozen_phase_count": phase_counts[tls],
            "frozen_program_vs_recorded_actual_diff_ticks": difference_ticks(programs[tls], source_states[tls]),
            "reference_vs_recorded_actual_diff_ticks": difference_ticks(actual_states["reference"][tls], source_states[tls]),
            "one_car_vs_recorded_actual_diff_ticks": difference_ticks(actual_states["one-car"][tls], source_states[tls]),
            "one_car_vs_reference_diff_ticks": difference_ticks(actual_states["one-car"][tls], actual_states["reference"][tls])}
        assert all(value == 0 for key, value in row.items() if key.endswith("diff_ticks"))
        colour_rows.append(row)
    audit.table(OUT / "all50-colour-program-histories.csv", colour_rows)
    source_hashes[str(source_states_path)] = audit.digest(source_states_path)
    for label in ["reference", "one-car"]:
        path = STUDY / label / "evaluation/native/tls-switch-states.xml"
        source_hashes[str(path)] = audit.digest(path)
    baseline = audit.evidence(SOURCE / "prepared", SOURCE / "evaluation", SOURCE / "evaluation/contributing-passages.json.gz", 8640)
    data = {label: audit.evidence(STUDY / label / "prepared", STUDY / label / "evaluation", STUDY / label / "evaluation/contributing-passages.json.gz", 8640) for label in ["reference", "one-car"]}
    source_native, reference_native = SOURCE / "evaluation/native", STUDY / "reference/evaluation/native"
    parity = {name: compare_rows(source_native / file, reference_native / file, tag, ignored) for name, file, tag, ignored in [
        ("E1", "field-counts.xml", "interval", ()), ("summary", "summary.xml", "step", ("duration",)), ("instant", "instant-e1.xml", "instantOut", ())]}
    assert all(row["same"] for row in parity.values())
    for file, tag in [("tripinfo.xml", "tripinfo"), ("vehicle-routes.xml", "vehicle")]:
        a, b = [keyed(folder / file, tag) for folder in [source_native, reference_native]]
        assert a == b and len(a) == len(b) == 8640
        parity[file] = {"same": True, "records": len(a)}
        source_hashes[str(source_native / file)] = audit.digest(source_native / file)
        source_hashes[str(reference_native / file)] = audit.digest(reference_native / file)
    monitors = [json.loads((folder / "stall-monitor.json").read_bytes()) for folder in [source_native, reference_native]]
    assert monitors[0]["lane_section_hold"] == monitors[1]["lane_section_hold"]
    parity["driver_holds"] = {"same": True}
    field_rows, native_rows = [], []
    for key in sorted(data["reference"]["periodic"]):
        a, b = [d["periodic"][key] for d in data.values()]
        native_rows.append({"field": key[0], "begin_s": key[1], "end_s": key[2], "reference_count": a["nVehContrib"], "one_car_count": b["nVehContrib"],
            "all_raw_attributes_identical": a == b, "count_identical": a["nVehContrib"] == b["nVehContrib"]})
    audit.table(OUT / "native208-paired-counts.csv", native_rows)
    for field in sorted({r["field"] for r in native_rows}):
        rows = [r for r in native_rows if r["field"] == field]
        a, b = [audit.metrics([r for r in d["main"] if r["detector_id"] == field]) for d in data.values()]
        field_rows.append({"field": field, "all16_counts_identical": all(r["count_identical"] for r in rows),
            "all16_raw_attributes_identical": all(r["all_raw_attributes_identical"] for r in rows),
            "reference_TAE": a["TAE"], "one_car_TAE": b["TAE"], "reference_SSE": a["SSE"], "one_car_SSE": b["SSE"]})
    audit.table(OUT / "field13-exactness-and-errors.csv", field_rows)
    results = {}
    for label, measured in data.items():
        for name in ["main", "initial", "stations"]:
            audit.table(OUT / (label + "-" + name + ".csv"), measured[name])
        audit.table(OUT / (label + "-all182.csv"), measured["initial"] + measured["main"])
        raw_result = paired["results"][label]
        assert all(measured[name] == raw_result[name] for name in ["metrics130", "metrics52", "metrics182", "completion", "healthy"])
        signatures = metadata[0 if label == "reference" else 1]
        repeat = [(i, f, count) for i, events in measured["by_vehicle"].items() for f, count in Counter(e["detector_id"] for e in events).items() if count > 1]
        outside = [(i, e["detector_id"]) for i, events in measured["by_vehicle"].items() for e in events if e["detector_id"] != signatures[i]["field_id"]]
        assert not repeat and not outside and measured["safe"] and measured["healthy"]
        rows535 = [r for r in measured["initial"] + measured["main"] if r["detector_id"] in FIELDS535]
        assert len(rows535) == 56 and audit.metrics(rows535)["TAE"] == 0
        results[label] = {**{name: measured[name] for name in ["metrics130", "metrics52", "metrics182", "completion", "healthy", "safe", "station40_MAE", "event_count"]},
            "station40_max": max(abs(r["residual"]) for r in measured["stations"]), "unique_complete_vehicles": len(measured["by_vehicle"]),
            "repeat": repeat, "outside": outside, "all53556": audit.metrics(rows535), "raw_source_hashes": measured["source_hashes"]}
    for field in ["hh_0119_Z_4_29437", "hh_0119_Z_5_30494", "hh_0119_Z_15_29375"]:
        assert next(row for row in field_rows if row["field"] == field)["all16_counts_identical"]
    assert data["reference"]["recorded"] == baseline["recorded"]
    assert Decimal(data["one-car"]["tripinfo"][identity]["depart"]) - Decimal(data["reference"]["tripinfo"][identity]["depart"]) == 31
    report = {"schema": "astra.hamburg.healthy-z4-fixed-history-independent/v1", "audit_status": "pass", "native_runs_by_audit": 0,
        "reference_strict_parity": parity, "all50_colour_and_program_timelines_equal_every_point1s": True,
        "phase_ordinal_equality_required": False, "no_post14400_extrapolation": True,
        "one_vehicle_departure_change": {"vehicle_id": identity, "request_delta_s": 31,
            "raw_request_departures": [str(v) for v in requested_departures], "raw_decimal_delta_s": str(requested_delta),
            "request_millisecond_delta_s": "31.000", "request_decimal_serialization_difference_s": str(requested_delta - Decimal(31)),
            "source_actual_depart_s": data["reference"]["tripinfo"][identity]["depart"],
            "counterpart_actual_depart_s": data["one-car"]["tripinfo"][identity]["depart"],
            "reference_actual_events": audit.event_view(data["reference"]["by_vehicle"][identity]), "one_car_actual_events": audit.event_view(data["one-car"]["by_vehicle"][identity])},
        "results": results, "field_rows": field_rows,
        "fit_improvement": data["one-car"]["metrics130"]["MAE"] < data["reference"]["metrics130"]["MAE"],
        "paired_pass_is_calibration_acceptance": False,
        "provable": ["Reference strict full-native parity", "All50 actual color/programID histories equal imposed healthy simulation history", "Same8640 requests exceptone+31s departure and corresponding metadata", "Both healthy/safe and raw130/40/52/182/208 closed", "Z4/Z5/Z15 all16-bin counts unchanged"],
        "not_proven": ["Fit improvement or130zero", "FieldSPaT/control ownership ortrueOD", "Original phase ordinals equal frozen phase ordinals", "A unique controller caused the original endogenous cascade", "Linear subtraction of losses is a causal controller contribution"],
        "source_hashes": source_hashes,
        "claim_boundary": "Pass confirms a valid conditional simulated-history comparison. It is not an improvement acceptance. The counterpart still has higher MAE/SSE and182TAE. Counts and color-history consistency do not establish field control correctness."}
    audit.save(OUT / "summary.json", report)
    print(json.dumps({"audit_status": report["audit_status"], "results": {k: {n: v[n] for n in ["metrics130", "metrics52", "metrics182", "station40_MAE", "completion"]} for k, v in results.items()}, "focus_fields": [row for row in field_rows if row["field"] in {"hh_0119_Z_4_29437", "hh_0119_Z_5_30494", "hh_0119_Z_15_29375"}]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
