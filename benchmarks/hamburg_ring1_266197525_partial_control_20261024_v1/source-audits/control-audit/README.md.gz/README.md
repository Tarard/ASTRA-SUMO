Current266197525 is`actuated`, program`readme_fixed_A`, offset0. The name does not make it static. Its six actual movements use TLindices0/1/5/8/6/7 and native REQindices0/1/2/3/4/5. TL8 is REQ3. TLindices2–4 have no current movement.

| Phase | External state | Nominal duration | min/max | Current service |
|---|---|---:|---:|---|
|0|rrrrrGGGG|27|5/50|734lane0→270 and734lanes0/1/2→110lanes0/1/2|
|1|rrrrryyyy|3|3/3|Yellow for those four movements|
|2|rrrrrrrrr|27|5/50|All red, no movement served|
|3|rrrrrrrrr|3|3/3|All red|
|4|GGrrrrrrr|27|5/50|Two25866659#2→25866655#0 movements|
|5|yyrrrrrrr|3|3/3|Yellow for those two movements|

In SUMO1.27.1, a pure green requires aG/g and noY/y. A phase can still be marked actuated by unequal min/max when its colors are all red. On phase entry, the default actuated switch routine schedules the next check fromminDur. For a non-green phase, gapControl returns no extension. With this program's plain sequential transitions and no custom conditions or coordination, phase2 therefore takes5s after entry and phase3 takes3s. Nominal27 does not establish an observed27s wait or fixed90s cycle. See[MSPhaseDefinition.h](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/microsim/traffic_lights/MSPhaseDefinition.h#L174) and[MSActuatedTrafficLightLogic.cpp](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/microsim/traffic_lights/MSActuatedTrafficLightLogic.cpp#L818).

The saved currentv3 five-car smoke provides37 complete all-red intervals of8s, including8–16 and32–40. SaveTLSSwitchStates does not emit the same-color phase2→3 transition. Its phase2 index must not be filled forward as an8s phase2 history. This is currentv3 smoke evidence, not the full8640 run's actual color history. The old +15 episode at4410 is not used here.

The same-node removal was already tested. `hamburg-directed-backlog-20261023-v1/exit-stage` removed only phase2 and retained the separate3s all-red phase. On that older7de network with8603 requests and static-coordinated GS, MAE worsened12.246→15.108, waiting516→735, and running232→331. It had zero collisions/teleports/discards and was rejected. This is not the currentv3 setting, but it prevents calling a new removal the first such test.

An unbound model phase does not prove that the field has no service at that time. The official stopline/SG ownership audit must determine applicability. No controller, road, candidate, or simulation changed. All source hashes,36 phase/movement rows, current smoke intervals, and historical input/result references are retained.
