"""Audit the saved525 binding, actuated semantics, and existing empty-stage test."""

from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CANDIDATE = REPO / "outputs/hamburg-209-ordinal-connection-20261024-v1/candidate-v3"
HISTORY = REPO / "outputs/hamburg-directed-backlog-20261023-v1"
SMOKE = CANDIDATE.parent / "smoke/native-coverage/tls-switch-states.xml"
CODE = REPO / "outputs/hamburg-197-through-support-20261023-v1/candidate-review/MSActuatedTrafficLightLogic.cpp"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    net = ET.parse(CANDIDATE / "network.net.xml").getroot()
    control = ET.parse(CANDIDATE / "control.add.xml").getroot().find("tlLogic[@id='266197525']")
    node = net.find("junction[@id='266197525']")
    bound = sorted((r for r in net.findall("connection") if r.get("tl") == "266197525"), key=lambda r: int(r.get("linkIndex")))
    assert len(bound) == 6
    movements = [{"from_edge": row.get("from"), "from_lane": int(row.get("fromLane")), "to_edge": row.get("to"),
        "to_lane": int(row.get("toLane")), "TLS_index": int(row.get("linkIndex")),
        "request_index": node.get("intLanes").split().index(row.get("via")), "via": row.get("via")} for row in bound]
    assert {r["TLS_index"] for r in movements} == {0, 1, 5, 6, 7, 8}
    assert next(r["request_index"] for r in movements if r["TLS_index"] == 8) == 3
    phase_rows, matrix = [], []
    for index, phase in enumerate(control.findall("phase")):
        state = phase.get("state")
        assert len(state) == 9
        duration = float(phase.get("duration"))
        minimum, maximum = float(phase.get("minDur", duration)), float(phase.get("maxDur", duration))
        row = {"phase_index": index, "state": state, "nominal_duration_s": duration, "min_s": minimum, "max_s": maximum,
            "bound_green_TLS_indices": ";".join(str(r["TLS_index"]) for r in movements if state[r["TLS_index"]] in "gG"),
            "bound_yellow_TLS_indices": ";".join(str(r["TLS_index"]) for r in movements if state[r["TLS_index"]] in "yY"),
            "all_bound_red": all(state[r["TLS_index"]] == "r" for r in movements),
            "full_state_all_red": set(state) == {"r"}, "unbound_TLS_indices": "2;3;4",
            "default_non_green_dwell_s": minimum if "G" not in state and "g" not in state else None}
        phase_rows.append(row)
        for movement in movements:
            matrix.append({"phase_index": index, "nominal_duration_s": duration, "min_s": minimum, "max_s": maximum,
                **movement, "actual_bound_color": state[movement["TLS_index"]]})
    assert [r["phase_index"] for r in phase_rows if r["full_state_all_red"]] == [2, 3]
    events = [row.attrib for _, row in ET.iterparse(SMOKE, events=("end",)) if row.tag == "tlsState" and row.get("id") == "266197525"]
    allred = [{"begin_s": float(row["time"]), "end_s": float(events[i + 1]["time"]),
        "duration_s": float(events[i + 1]["time"]) - float(row["time"]), "emitted_phase_at_begin": row["phase"],
        "next_emitted_phase": events[i + 1]["phase"]} for i, row in enumerate(events[:-1]) if set(row["state"]) == {"r"}]
    assert all(row["duration_s"] == 8 for row in allred)
    history = json.loads((HISTORY / "exit-stage-verdict.json").read_bytes())
    old = ET.parse(HISTORY / "merge-prepared/control.add.xml").getroot().find("tlLogic[@id='266197525']")
    new = ET.parse(HISTORY / "exit-stage-prepared/control.add.xml").getroot().find("tlLogic[@id='266197525']")
    assert len(old.findall("phase")) == 6 and len(new.findall("phase")) == 5
    assert old[2].get("state") == "rrrrrr" and float(old[2].get("minDur")) == 5
    assert [row.attrib for i, row in enumerate(old) if i != 2] == [row.attrib for row in new]
    summary = {"status": "pass", "formal_result": False, "new_native_runs": 0,
        "program": control.attrib, "bound_movement_count": 6, "unbound_TLS_indices": [2, 3, 4],
        "all_red_phases": [2, 3], "phase2_nominal_min_max_s": [27, 5, 50], "phase3_effective_min_max_s": [3, 3],
        "source_semantics": {"MSPhaseDefinition.h": {"green_test_lines": [174, 182], "isActuated_lines": [202, 204], "duration_defaults_lines": [119, 123]},
            "MSActuatedTrafficLightLogic.cpp": {"getMinDur_lines": [552, 558], "default_next_phase_lines": [622, 643],
                "trySwitch_lines": [818, 917], "new_phase_min_retry_lines": [915, 917], "non_green_gap_control_lines": [941, 961]}},
        "default_rule": "No custom next/targets/conditions/coordination parameters exist in this program. Upon entry, retry uses minDur. gapControl returns no extension for non-green. Thus after entry phase2 consumes5s, then phase3 consumes3s; nominal27 is not a27s observed wait or fixed90s cycle.",
        "current_v3_smoke_only": {"all_red_windows": allred, "duration_distribution": dict(Counter(row["duration_s"] for row in allred)),
            "claim": "Actual v3 five-car smoke, not v3 full color history. SaveTLSSwitchStates omits same-color phase2→3, so each8s interval includes both phases; its emitted phase2 index must not be forward-filled as the complete phase history."},
        "history_same_node_test": {"path": str(HISTORY / "exit-stage-verdict.json"), "status": history["status"],
            "network_sha256": json.loads((HISTORY / "exit-stage-preflight.json").read_bytes())["protected_sha256"]["network.net.xml"],
            "vehicles": history["after"]["completion"]["loaded"], "parent_MAE": history["parent"]["MAE"], "after_MAE": history["after"]["MAE"],
            "parent_waiting_running": [history["parent"]["completion"][key] for key in ("waiting", "running")],
            "after_waiting_running": [history["after"]["completion"][key] for key in ("waiting", "running")],
            "safe": history["safe"], "removed_source_phase_index": 2,
            "scope": "One full native test already removed this node's empty phase2 while preserving the separate3s all-red phase. Old7de network,8603 demand and static-coordinated GS differ from v3/8640/priority. The rejection is historical evidence, not current-v3 transfer or field correctness proof."},
        "claim_boundary": "An unbound phase in the pruned model does not prove a missing field service or authorize deletion. Source stopline/SG ownership must be combined with these facts. No candidate, control edit, road edit, or new native simulation was made. Old+15 episode timestamps are not used as v3 full colors."}
    save(ROOT / "summary.json", summary)
    table(ROOT / "movement-bindings.csv", movements)
    table(ROOT / "phase-summary.csv", phase_rows)
    table(ROOT / "phase-by-bound-movement.csv", matrix)
    table(ROOT / "v3-smoke-allred-windows.csv", allred)
    paths = [CANDIDATE / "network.net.xml", CANDIDATE / "control.add.xml", SMOKE, CODE, ROOT / "MSPhaseDefinition.h", Path(__file__),
        HISTORY / "run_exit_stage.py", HISTORY / "exit-stage-preflight.json", HISTORY / "exit-stage-verdict.json",
        HISTORY / "merge-prepared/control.add.xml", HISTORY / "exit-stage-prepared/control.add.xml"]
    save(ROOT / "source-hashes.json", {str(path): {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in paths})
    print(json.dumps({"status": "pass", "new_native_runs": 0, "phase_rows": len(phase_rows), "movement_rows": len(matrix),
        "current_v3_smoke_8s_allred_intervals": len(allred), "historical_same_node_test": history["status"]}))


if __name__ == "__main__":
    main()
