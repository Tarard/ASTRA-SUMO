"""Read-only source comparison for the six current266197525 movements."""
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

import sumolib
from astra_sumo.core.digital_twin import parse_mapem
from astra_sumo.core.hamburg_map_kml import (
    bind_hamburg_map_kml_to_mapem,
    parse_hamburg_map_kml,
)

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
ASSETS = ROOT / "outputs/hamburg-119-downstream-control-source-20261024-v1/official-209-retry"
NET = ROOT / "outputs/hamburg-209-ordinal-connection-20261024-v1/candidate-v3/network.net.xml"
CONTROL = NET.with_name("control.add.xml")
OLD = ROOT / "benchmarks/hamburg_ring1_readme_v1_zero_20261023_v1/inputs/network.net.xml.gz"
ORIGINAL = ROOT / "benchmarks/hamburg_ring1_end_to_end_20261021_v1/source-stages/original-osm.net.xml"
OSM = ROOT / "benchmarks/hamburg_ring1_primary_branch_repair_20261023_v1/source/source.osm.xml.gz"
PHASE = ROOT / "outputs/hamburg-266197525-control-audit-20261024-v1"
EPISODE = ROOT / "outputs/hamburg-119-zero-discharge-observer-20261024-v1/episode-analysis"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unit(a, b):
    delta = b[0] - a[0], b[1] - a[1]
    length = math.hypot(*delta)
    assert length > 0.01
    return delta[0] / length, delta[1] / length


def main():
    assert not (OUT / "manifest.json").exists(), "Preserve sealed outputs."
    assert Path(sumolib.__file__).resolve().is_relative_to(ROOT / ".venv")
    assert sha(NET) == "4cd5d1b95cce0f43b0626e82c7066cce3b1807db35840c115bcf66252437ae80"
    assert sha(CONTROL) == "27220b430aa68c24f0ad360c57ee3bd0f4b8dcdc88aead5344bcff00e4f43e3b"
    root, original = ET.parse(NET).getroot(), ET.parse(ORIGINAL).getroot()
    old = ET.fromstring(gzip.decompress(OLD.read_bytes()))
    osm = ET.fromstring(gzip.decompress(OSM.read_bytes()))
    net = sumolib.net.readNet(str(NET), withInternal=True)
    original_net = sumolib.net.readNet(str(ORIGINAL), withInternal=True)
    raw_xml = gzip.decompress((ASSETS / "map_xml.xml.gz").read_bytes())
    raw_kml = gzip.decompress((ASSETS / "map_kml.xml.gz").read_bytes())
    with tempfile.TemporaryDirectory() as temporary:
        folder = Path(temporary)
        (folder / "209.xml").write_bytes(raw_xml)
        (folder / "209.kml").write_bytes(raw_kml)
        lanes, connections = parse_mapem(folder / "209.xml")
        bound = bind_hamburg_map_kml_to_mapem(
            parse_hamburg_map_kml(folder / "209.kml"), lanes, connections, expected_node_id="209"
        )
    semantics = {lane.lane_id: lane for lane in lanes}
    xml_lanes = {r.findtext("laneID"): r for r in ET.fromstring(raw_xml).findall(".//GenericLane")}
    official, projected = [], {}
    for lane in bound["lanes"]:
        points = [net.convertLonLat2XY(*xy[:2]) for xy in lane["coordinates"]]
        projected[lane["lane_id"]] = points
        meaning = semantics[lane["lane_id"]]
        if not meaning.is_vehicle or not meaning.is_ingress:
            continue
        nodes = xml_lanes[lane["lane_id"]].findall("nodeList/nodes/NodeXY")
        assert [i for i, row in enumerate(nodes) if row.find(".//stopLine") is not None] == [0]
        official.append(dict(lane=lane["lane_id"], approach=meaning.ingress_approach,
                             stop=points[0], direction=unit(points[1], points[0]),
                             connections=[dict(egress=c.egress_lane_id, signal_group=c.signal_group)
                                          for c in connections if c.ingress_lane_id == lane["lane_id"]]))

    def candidates(lane_id, source_net=net):
        shape = source_net.getLane(lane_id).getShape()
        end, direction = shape[-1], unit(shape[-2], shape[-1])
        rows = []
        for target in official:
            delta = target["stop"][0] - end[0], target["stop"][1] - end[1]
            angle = math.degrees(math.acos(max(-1, min(1, sum(a * b for a, b in zip(direction, target["direction"]))))))
            rows.append(dict(official_lane=target["lane"], approach=target["approach"],
                             distance_m=math.hypot(*delta), heading_difference_deg=angle,
                             signed_ahead_m=sum(a * b for a, b in zip(delta, direction)),
                             official_connections=target["connections"]))
        return sorted(rows, key=lambda r: r["distance_m"])

    node = root.find("junction[@id='266197525']")
    movements = [r for r in root.findall("connection") if r.get("tl") == "266197525"]
    assert len(movements) == 6
    requests = {r.get("index"): dict(r.attrib) for r in node.findall("request")}
    internal = node.get("intLanes").split()
    movement_rows = []
    for row in movements:
        lane_id = row.get("from") + "_" + row.get("fromLane")
        is_primary = row.get("from") == "73474895"
        nearby = candidates(lane_id)
        compatible = [r for r in nearby if r["heading_difference_deg"] <= 20]
        if is_primary:
            assert not compatible
        request = str(internal.index(row.get("via")))
        movement_rows.append(dict(from_edge=row.get("from"), from_lane=row.get("fromLane"),
                                  to_edge=row.get("to"), to_lane=row.get("toLane"), via=row.get("via"),
                                  tls_index=row.get("linkIndex"), request_index=request,
                                  passenger=net.getLane(lane_id).allows("passenger"),
                                  bicycle=net.getLane(lane_id).allows("bicycle"),
                                  candidate_scope=is_primary, keep_control_binding=not is_primary,
                                  closest_stopline=nearby[0],
                                  closest_direction_compatible=compatible[0] if compatible else None,
                                  native_request=requests[request]))
    assert sorted(int(r["tls_index"]) for r in movement_rows if r["candidate_scope"]) == [5, 6, 7, 8]
    assert sorted(int(r["tls_index"]) for r in movement_rows if r["keep_control_binding"]) == [0, 1]
    for i in range(2, 6):
        assert requests[str(i)]["response"][-1] == requests[str(i)]["response"][-2] == "1"
    old_node = old.find("junction[@id='266197525']")
    assert old_node.get("type") == "priority" and "284139902_0" in old_node.get("incLanes")
    assert "25866659#2_0" not in old_node.get("incLanes")
    assert root.find("junction[@id='6390683112']") is None
    assert root.find("edge[@id='25866659#0']") is None
    tags = {r.get("k"): r.get("v") for r in osm.find("node[@id='266197525']").findall("tag")}
    assert tags == {"ele": "6.0", "source": "HH LGV 2012"}
    old_movements = [dict(r.attrib) for r in old.findall("connection") if r.get("from") in ["284139902", "73474895"] and r.get("to") == "1108564798#0"]
    counter = {}
    for native_id, official_id, native_net in [
        ("199799715_3", "3", original_net), ("25866659#2_1", "3", net),
        ("25866655#0_1", "42", net), ("25866655#1_1", "42", net),
    ]:
        counter[native_id] = next(r for r in candidates(native_id, native_net) if r["official_lane"] == official_id)
    control = ET.parse(CONTROL).getroot()
    programs = {name: dict(control.find(f"tlLogic[@id='{name}']").attrib,
                           phases=[dict(r.attrib) for r in control.find(f"tlLogic[@id='{name}']").findall("phase")])
                for name in ["266197525", "9844196560", "GS_26084079"]}
    report = dict(schema="astra.hamburg.266197525-ownership-source/v1", status="review_required",
                  formal_result=False, new_native_runs=0, source_map_gates=bound["gates"],
                  movements=movement_rows, counter_stopline_comparisons=counter,
                  source_osm_node_tags=tags, old_v1=dict(node=dict(old_node.attrib), movements=old_movements),
                  original_import_node_type=original.find("junction[@id='266197525']").get("type"),
                  upstream_model_boundary="6390683112 and25866659#0 absent;25866659#1 starts at703147136 boundary",
                  programs=programs, bike_signal_group_binding=None,
                  scope=dict(remove_independent_stop_requirement_only_tls_indices=[5, 6, 7, 8],
                             preserve_counter_control_tls_indices=[0, 1], preserve_all_legal_turns=True,
                             preserve_bicycle_permissions=True, whole_tls_removal_supported=False,
                             require_native_row_recomputation_and_conflict_yield=True),
                  boundaries=["MAP2022 configuration is not2026-10-19 implementation or measuredSPaT.",
                              "Native ordinary lane ends are geometric proxies, not observed painted stoplines.",
                              "No compatible MAP ingress line at734 is not proof that the field has no signal.",
                              "Alsterufer control may act as a model gate for omitted upstream signals; this is a hypothesis, not field ownership.",
                              "Native bicycle movement has no identified MAPbikeSG binding; no permission/control removal follows.",
                              "Keep27064186 legal; MAP14→5/SG6 corresponds to a different Alsterufer branch, not270.",
                              "V1 has a different second approach, so its priority node is not an exact restoration target.",
                              "The old+15 v50 red-light episode is not currentv3 full history; empty-phase deletion failed on a different older model."])
    source_paths = [NET, CONTROL, ORIGINAL, OLD, OSM, ASSETS / "manifest.json", ASSETS / "map_xml.xml.gz",
                    ASSETS / "map_kml.xml.gz", ASSETS / "access.json", PHASE / "manifest.json",
                    PHASE / "summary.json", PHASE / "source-hashes.json", EPISODE / "manifest.json", EPISODE / "evidence.json",
                    ROOT / "outputs/hamburg-119-downstream-control-source-20261024-v1/egress5-source-audit/manifest.json",
                    ROOT / "outputs/hamburg-119-downstream-control-source-20261024-v1/egress5-source-audit/summary.json"]
    for parent in [ASSETS, PHASE, EPISODE]:
        sealed = json.loads((parent / "manifest.json").read_text(encoding="utf-8"))
        for row in sealed["files"]:
            path = parent / row["path"]
            assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"]
    provenance = dict(source_hashes=[dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=sha(p)) for p in source_paths],
                      official_xml_payload_sha256=hashlib.sha256(raw_xml).hexdigest(),
                      official_kml_payload_sha256=hashlib.sha256(raw_kml).hexdigest(),
                      runtime=dict(python=sys.executable, sumolib=sumolib.__file__, native_calls=0))
    (OUT / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (OUT / "source-hashes.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (OUT / "movements.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = ["from_edge", "from_lane", "to_edge", "to_lane", "via", "tls_index", "request_index", "passenger", "bicycle", "candidate_scope", "keep_control_binding"]
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(movement_rows)
    files = [dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]
    (OUT / "manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1", new_native_runs=0, files=files), indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status="pass", movements=len(movement_rows), native_runs=0, manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
