Pinned Libsumo1.27.1 uses these Python layouts:

| Index | getNextLinks | getJunctionFoes |
|---:|---|---|
|0|approached lane|foe ID|
|1|priority flag|ego distance|
|2|opened flag|foe distance|
|3|foe flag|ego exit distance|
|4|via/internal lane|foe exit distance|
|5|link state|ego internal lane|
|6|direction|foe internal lane|
|7|length|ego response flag|
|8|—|foe response flag|

The pinned SWIG typemap defines these tuples directly. See its raw source lines187–201 and404–418. The separate TraCI getNextLinks documentation placesvia at1. That layout must not decode Libsumo output. `decoder.py` checks tuple length and types and rejects this mix. See[the pinned typemap](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/libsumo/libsumo_typemap.i#L187).

Vehicle.cpp recomputesopened at query time using current time and speed limits. It is not the driver's private link request. A response bit is a ROW relation, not proof that a car actually yielded. getJunctionFoes also has the previously identifiedNO_INTERSECTION enumeration issue in this version. An empty result is not evidence of no runtime foe.

This audit reads the saved candidate samples and preserves all original native runs and reviews. It starts no simulation and does not certify yielding coverage.
