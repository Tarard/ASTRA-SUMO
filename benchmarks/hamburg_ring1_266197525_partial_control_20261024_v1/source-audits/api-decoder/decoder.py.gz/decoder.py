"""Decode the pinned Libsumo1.27.1 Python tuples, not the TraCI wire order."""

import json
import math
from pathlib import Path


NEXT_LINK_FIELDS = ("lane", "priority", "opened", "foe", "via", "state", "direction", "length")
JUNCTION_FOE_FIELDS = ("foeId", "egoDist", "foeDist", "egoExitDist", "foeExitDist", "egoLane", "foeLane", "egoResponse", "foeResponse")


def decode_next_link(row):
    if len(row) != 8 or any(type(row[index]) is not bool for index in (1, 2, 3)):
        raise ValueError("Expected Libsumo1.27.1 link order: lane,priority,opened,foe,via,state,direction,length.")
    if any(not isinstance(row[index], str) for index in (0, 4, 5, 6)) or isinstance(row[7], bool) or not math.isfinite(row[7]):
        raise ValueError("Invalid Libsumo next-link field types.")
    return dict(zip(NEXT_LINK_FIELDS, row, strict=True))


def decode_junction_foe(row):
    if len(row) != 9 or any(type(row[index]) is not bool for index in (7, 8)):
        raise ValueError("Expected Libsumo1.27.1 nine-field junction-foe tuple.")
    if any(not isinstance(row[index], str) for index in (0, 5, 6)) or any(isinstance(row[index], bool) or not math.isfinite(row[index]) for index in (1, 2, 3, 4)):
        raise ValueError("Invalid Libsumo junction-foe field types.")
    return dict(zip(JUNCTION_FOE_FIELDS, row, strict=True))


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    source = repo / "outputs/hamburg-266197525-partial-control-20261024-v1/smoke/native-candidate/samples.json"
    frames = json.loads(source.read_bytes())
    links = [decode_next_link(link) for frame in frames for vehicle in frame["vehicles"].values() for link in vehicle["next_links"]]
    foes = [decode_junction_foe(foe) for frame in frames for vehicle in frame["vehicles"].values() for foe in vehicle["junction_foes"]]
    sample = ["out_0", False, True, False, ":via_0", "m", "s", 12.5]
    assert decode_next_link(sample)["via"] == ":via_0"
    wrong_order = [sample[i] for i in (0, 4, 1, 2, 3, 5, 6, 7)]
    try:
        decode_next_link(wrong_order)
    except ValueError:
        pass
    else:
        raise AssertionError("The TraCI layout was silently accepted as Libsumo.")
    synthetic_foe = ["other", 1.0, -2.0, 6.0, 3.0, ":ego", ":foe", True, False]
    assert decode_junction_foe(synthetic_foe)["egoResponse"] is True
    result = {"status": "pass", "native_runs": 0, "links_type_checked": len(links), "foes_type_checked": len(foes),
        "wrong_traci_order_rejected": True, "sample_decoded": links[0] if links else None,
        "claim_boundary": "Tuple layout only. opened/foe flags and response bits do not establish an actual yielding episode. Empty query results do not prove no runtime conflict."}
    (root / "selfchecks.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))
