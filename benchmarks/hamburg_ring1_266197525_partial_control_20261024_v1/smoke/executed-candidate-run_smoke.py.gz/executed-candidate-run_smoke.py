"""Prepare or explicitly run one16-vehicle normal-entry source/candidate fixture."""
import argparse
import copy
import hashlib
import importlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.local_network_conversion import loaded_turn_permissions

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full/prepared"
CANDIDATE = ROOT.parent / "candidate-v2"
OLD_DRIVER = REPO / "outputs/hamburg-209-ordinal-connection-20261024-v1/smoke/shared-driver.py"
MOVES = {0: ("25866659#2", 0, "25866655#0", 0), 1: ("25866659#2", 1, "25866655#0", 1),
         5: ("73474895", 0, "27064186#0", 0), 8: ("73474895", 0, "1108564798#0", 0),
         6: ("73474895", 1, "1108564798#0", 1), 7: ("73474895", 2, "1108564798#0", 2)}
BIKE = ["25866659#1", "25866659#2", "25866655#0", "25866655#1", "73474902#0", "73474902#1"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_driver():
    spec = spec_from_file_location("existing_525_native_smoke_driver", ROOT / "shared-driver.py")
    driver = module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.REPO = REPO
    driver.MOVEMENTS = MOVES
    return driver


def support(network, control):
    net = ET.parse(network).getroot()
    permissions = loaded_turn_permissions(net)
    paths = {}
    for index, key in MOVES.items():
        mode = "bicycle" if index == 0 else "passenger"
        assert mode in permissions[key], key
        matches = [r for r in net.findall("connection") if (r.get("from"), int(r.get("fromLane")), r.get("to"), int(r.get("toLane"))) == key]
        assert len(matches) == 1
        via, path = matches[0].get("via"), []
        while via:
            assert via not in path
            path.append(via)
            edge, lane = via.rsplit("_", 1)
            following = [r for r in net.findall("connection") if r.get("from") == edge and r.get("fromLane") == lane]
            assert len(following) == 1
            via = following[0].get("via")
        paths[index] = path
    routes = ET.parse(ROOT / "inputs/routes.rou.xml").getroot()
    settings = json.loads((ROOT / "inputs/jobs.json").read_bytes())
    by_route = {r["route_id"]: r for r in settings["jobs"]}
    for route in routes.findall("route"):
        edges = route.get("edges").split()
        mode = by_route[route.get("id")]["vehicle_class"]
        assert len(edges) == len(set(edges))
        # Keep one continuous legal lane path; do not accept disconnected per-edge witnesses.
        possible = {int(by_route[route.get("id")]["vehicle_attributes"]["departLane"])}
        for before, after in zip(edges, edges[1:]):
            possible = {key[3] for key, modes in permissions.items() if key[0] == before and key[1] in possible and key[2] == after and mode in modes}
            assert possible, (route.get("id"), before, after)
            # Cars may change lane on an ordinary road; bicycle route is a single dedicated lane.
            if mode == "passenger":
                possible = {int(lane.get("index")) for lane in net.find(f"edge[@id='{after}']").findall("lane")
                            if "passenger" not in lane.get("disallow", "").split() and (not lane.get("allow") or "passenger" in lane.get("allow").split())}
    assert not any(k[0] == BIKE[-1] and k[1] == 0 and "bicycle" in modes for k, modes in permissions.items())
    return net, paths


def prepare():
    assert not (ROOT / "inputs").exists(), "Preserve prepared inputs."
    source = ET.parse(SOURCE / "demand.rou.xml").getroot()
    intentions = {r["vehicle_id"]: r["field_id"] for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    witnesses = {}
    counts = dict(primary=0, residential=0, counter=0)
    for vehicle in source.findall("vehicle"):
        edges = vehicle.find("route").get("edges").split()
        if "73474895" in edges:
            kind = "residential" if edges[edges.index("73474895") + 1] == "27064186#0" else "primary"
            witnesses.setdefault(kind, vehicle)
            counts[kind] += 1
        if edges[0] == "25866659#1":
            witnesses.setdefault("counter", vehicle)
            counts["counter"] += 1
    assert counts == dict(primary=1986, residential=603, counter=106)
    net = ET.parse(SOURCE / "network.net.xml").getroot()
    lengths = {r.get("id"): float(r.get("length")) for r in net.iter("lane")}
    routes, jobs = ET.Element("routes"), []
    for element in source:
        if element.tag != "vehicle":
            routes.append(copy.deepcopy(element))
    ET.SubElement(routes, "vType", id="fixture_default_bicycle", vClass="bicycle")
    specs = []
    for wave, times in [("conflict", [0, 25, 50, 75]), ("late_solo", [300, 330, 360, 390])]:
        specs += [(f"{wave}_main_{move}", "residential" if move == 5 else "primary", move, start, wave)
                  for move, start in zip([5, 8, 6, 7], times, strict=True)]
    specs += [(f"counter_car_{i}", "counter", 1, start, "counter_car") for i, start in enumerate([10, 30, 50, 70])]
    specs += [(f"counter_bicycle_{i}", "bicycle", 0, start, "counter_bicycle") for i, start in enumerate([20, 40, 60, 80])]
    for identity, kind, movement, start, role in specs:
        original = witnesses["counter" if kind == "bicycle" else kind]
        edges = original.find("route").get("edges").split()
        stops = []
        if kind in ("primary", "residential"):
            edges = edges[edges.index("141050980#0"):]
            target_lane = MOVES[movement][1]
            entry_lane = target_lane + 2
            waypoints = [(f"141050980#0_{entry_lane}", 7.5), (f"141050980#1_{entry_lane}", .1), (f"73474895_{target_lane}", .1)]
            if kind == "primary":
                waypoints.append((f"1108564798#0_{target_lane}", .1))
            stops = [ET.Element("stop", lane=lane, endPos=f"{lengths[lane] - margin:.9f}", speed="13.888889") for lane, margin in waypoints]
            field = None
        else:
            entry_lane = 0 if kind == "bicycle" else 1
            field = None if kind == "bicycle" else intentions[original.get("id")]
            edges = BIKE if kind == "bicycle" else edges
            stops = [] if kind == "bicycle" else [copy.deepcopy(r) for r in original.findall("stop")]
        route = ET.SubElement(routes, "route", id="r_" + identity, edges=" ".join(edges))
        route.extend(stops)
        attrs = dict(original.attrib, departLane=str(entry_lane))
        if kind == "bicycle":
            attrs["type"] = "fixture_default_bicycle"
        jobs.append(dict(id=identity, case="paired", role=role, field=field, movement=movement,
                         source_id=original.get("id") if kind != "bicycle" else None,
                         route_id=route.get("id"), vehicle_attributes=attrs,
                         vehicle_class="bicycle" if kind == "bicycle" else "passenger",
                         trigger=dict(time_s=start), expected_stop_count=len(stops),
                         boundary_exit=edges[-1], explicit_route=edges))
    (ROOT / "inputs").mkdir()
    ET.ElementTree(routes).write(ROOT / "inputs/routes.rou.xml", encoding="utf-8", xml_declaration=True)
    (ROOT / "inputs/field-loops.add.xml").write_bytes((SOURCE / "field-loops.add.xml").read_bytes())
    save(ROOT / "inputs/jobs.json", dict(end_s=900, jobs=jobs))
    code = OLD_DRIVER.read_text(encoding="utf-8").replace("'266197536'", "'266197525'")
    code = code.replace("bool(movement and lane", "bool(movement is not None and lane")
    code = code.replace("if movement and identity not in entered", "if movement is not None and identity not in entered")
    old_near = "                near_197 = bool(movement is not None and lane in paths[movement]) or any(t[0] == '266197525' and t[2] <= 25 for t in next_tls)"
    assert code.count(old_near) == 1
    code = code.replace(old_near, "                near_197 = lane.startswith(('73474895_', '25866659#1_', '25866659#2_', ':266197525_')) or (lane.startswith(('25866655#0_', '1108564798#0_', '27064186#0_')) and position < 10)")
    old = "                    speed_mode=31, lane_change_mode=api.vehicle.getLaneChangeMode(identity))"
    assert code.count(old) == 1
    code = code.replace(old, "                    speed_mode=31, lane_change_mode=api.vehicle.getLaneChangeMode(identity),\n                    junction_foes=api.vehicle.getJunctionFoes(identity,100) if near_197 else [],\n                    stop_state=api.vehicle.getStopState(identity), acceleration_m_s2=api.vehicle.getAcceleration(identity),\n                    vehicle_length_m=api.vehicle.getLength(identity))")
    (ROOT / "shared-driver.py").write_text(code, encoding="utf-8")
    save(ROOT / "plan.json", dict(schema="astra.hamburg.266197525-partial-control-smoke-plan/v1",
        status="prepared_awaiting_static_candidate", native_runs=0, end_s=900, step_s=.1, seed=104,
        count=len(jobs), jobs=jobs, source_population_counts=counts, original_vType=source.find("vType").attrib,
        source_network_sha256=sha(SOURCE / "network.net.xml"), source_control_sha256=sha(SOURCE / "control.add.xml"),
        inputs={p.name: sha(p) for p in (ROOT / "inputs").iterdir()},
        source_hashes={str(p): sha(p) for p in [SOURCE / "demand.rou.xml", SOURCE / "lane-intentions.json", OLD_DRIVER, Path(__file__)]},
        adapted_driver_sha256=sha(ROOT / "shared-driver.py"),
        fixture_scope="Four734 movements each once under a counter stream and once in a late window;4counter cars+4default bicycles;16 normal adds, no speed/position/lane/TLS setters or removals. Cars use source vType and complete source boundary suffixes; counter cars retain complete route and original moving field stop. Bike ends at current bicycle-permitted graph boundary73474902#1, not a passenger boundary or early removal.",
        measurement_boundary="No real count targets or MAE. No field validity, congestion, throughput or full8640 safety claim. Source and candidate share the same fixed request times. Observed actual entries may differ.",
        acceptance="Actual six-movement native via+receiving-lane coverage and all boundary arrivals,0unsafe; candidate additionally requires an observed main conflict response/braking-and-release witness separately for car and bicycle, and actual734 passage during an unused old red bit with no nearby counter. Missing mechanism coverage is review_required, not pass.",
        budget="One paired source/candidate fixture; at most one further paired timing correction only for safe missing coverage; preserve all prior artifacts."))
    support(SOURCE / "network.net.xml", SOURCE / "control.add.xml")
    print(json.dumps(dict(status="prepared", native_runs=0, count=len(jobs), plan_sha256=sha(ROOT / "plan.json"))))


def check():
    plan = json.loads((ROOT / "plan.json").read_bytes())
    assert all(sha(ROOT / "inputs" / p) == h for p, h in plan["inputs"].items())
    assert all(sha(Path(p)) == h for p, h in plan["source_hashes"].items())
    assert sha(ROOT / "shared-driver.py") == plan["adapted_driver_sha256"]
    assert sha(SOURCE / "network.net.xml") == plan["source_network_sha256"]
    assert sha(SOURCE / "control.add.xml") == plan["source_control_sha256"]
    support(SOURCE / "network.net.xml", SOURCE / "control.add.xml")
    manifest = json.loads((CANDIDATE / "manifest.json").read_bytes())
    assert manifest["schema"] == "astra.hamburg.266197525-partial-control/v1"
    assert manifest["status"] == "review_required" and all(manifest["checks"].values())
    assert manifest["source_unchanged"] and not manifest["traffic_simulation_run"]
    assert sha(CANDIDATE / "network.net.xml") == manifest["candidate_sha256"]
    assert sha(CANDIDATE / "control.add.xml") == manifest["control_sha256"] == plan["source_control_sha256"]
    support(CANDIDATE / "network.net.xml", CANDIDATE / "control.add.xml")
    modules = {n: str(Path(importlib.import_module(n).__file__).resolve()) for n in ("libsumo", "traci", "sumolib", "sumo")}
    assert Path(sys.executable).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    assert all(Path(p).is_relative_to((REPO / ".venv").resolve()) for p in modules.values())
    return plan, manifest, modules


def audit(name, plan, network):
    out = ROOT / ("native-" + name)
    result = json.loads((out / "result.json").read_bytes())
    samples = json.loads((out / "samples.json").read_bytes())
    _, paths = support(network, SOURCE / "control.add.xml")
    jobs = {r["id"]: r for r in plan["jobs"]}
    arrived = {r.get("id"): r.find("route") for r in ET.parse(out / "vehicle-routes.xml").getroot().findall("vehicle")}
    coverage, yields, bypasses = [], [], []
    for identity, job in jobs.items():
        route = arrived.get(identity)
        complete = route is not None and route.get("edges").split() == job["explicit_route"] and all(float(t) >= 0 for t in route.get("exitTimes").split())
        history = [(r, r["vehicles"][identity]) for r in samples if identity in r["vehicles"]]
        hits = [i for i, (_, vehicle) in enumerate(history) if vehicle["lane"] in paths[job["movement"]]]
        after = next((v["lane"] for _, v in history[max(hits) + 1:] if not v["lane"].startswith(":")), None) if hits else None
        key = MOVES[job["movement"]]
        coverage.append(dict(vehicle_id=identity, movement=job["movement"], complete_route=complete,
                             actual_via_lanes=sorted({v["lane"] for _, v in history}.intersection(paths[job["movement"]])),
                             first_receiving_lane=after, covered=bool(hits) and after == f"{key[2]}_{key[3]}" and complete))
        if job["movement"] not in (5, 6, 7, 8) or not hits:
            continue
        entry = history[min(hits)][0]["time_s"]
        for row, vehicle in history[:min(hits)]:
            if vehicle["lane"].startswith("73474895_"):
                links = [link for link in vehicle["next_links"] if link[1] in paths[job["movement"]]]
                leader = vehicle["leader"]
                for foe in vehicle["junction_foes"]:
                    foe_id = foe[0]
                    if foe_id not in jobs or jobs[foe_id]["role"] not in ("counter_car", "counter_bicycle"):
                        continue
                    slowed = vehicle["speed_m_s"] <= .3 or vehicle["acceleration_m_s2"] < -.2
                    unobstructed = not leader or leader[1] > 10
                    released = next((later["time_s"] for later, state in history[:min(hits) + 1]
                                     if later["time_s"] > row["time_s"] and any(link[1] in paths[job["movement"]] and link[3] and not link[4] for link in state["next_links"])), None)
                    if foe[7] and links and not links[0][3] and links[0][4] and slowed and unobstructed and vehicle["stop_state"] == 0 and released is not None:
                        yields.append(dict(main_id=identity, counter_id=foe_id, counter_class=jobs[foe_id]["vehicle_class"],
                                           time_s=row["time_s"], speed_m_s=vehicle["speed_m_s"], acceleration_m_s2=vehicle["acceleration_m_s2"],
                                           native_foe=foe, native_next_link=links[0], subsequent_open_no_foe_s=released,
                                           subsequent_actual_entry_s=entry))
        first_row = history[min(hits)][0]
        prior_row = history[max(0, min(hits) - 1)][0]
        nearby = [i for i, v in first_row["vehicles"].items() if jobs[i]["role"] in ("counter_car", "counter_bicycle") and v["near_197"]]
        if first_row["state"][job["movement"]] == prior_row["state"][job["movement"]] == "r" and not nearby:
            bypasses.append(dict(vehicle_id=identity, movement=job["movement"], entry_s=entry,
                                 unused_old_state=first_row["state"], no_counter_within_monitored525_proximity=True))
    base = dict(all_actual_movement_transitions=all(r["covered"] for r in coverage),
                shared_native_driver_pass=result["status"] == "pass", input_hashes_unchanged=result["source_inputs_unchanged"])
    mechanism = dict(car_native_yield_witness=any(r["counter_class"] == "passenger" for r in yields),
                     bicycle_native_yield_witness=any(r["counter_class"] == "bicycle" for r in yields),
                     old_red_without_counter_actual_passage=bool(bypasses))
    unsafe = bool(result["collision_rows"]) or any(result["safety"].values())
    passed = all(base.values()) and (name == "source" or all(mechanism.values()))
    verdict = dict(schema="astra.hamburg.266197525-partial-control-smoke/v1", case=name,
                   status="blocked" if unsafe else "pass" if passed else "review_required", formal_result=False,
                   MAE=None, toy_only=True, checks=base, candidate_mechanism_checks=mechanism,
                   actual_movements=coverage, yield_witnesses=yields, old_red_passages=bypasses,
                   interpretation="A native foe-response, closed/foe link, no close queried leader, no active stop, braking/standstill and later actual entry is a narrow ROW witness. No collision alone is not yield evidence. No claim of field control validity or all-demand safety.")
    save(out / "smoke-verdict.json", verdict)
    print(json.dumps(dict(case=name, status=verdict["status"], checks=base, mechanism=mechanism)))


def execute(name):
    plan, manifest, modules = check()
    network = (SOURCE if name == "source" else CANDIDATE) / "network.net.xml"
    control = (SOURCE if name == "source" else CANDIDATE) / "control.add.xml"
    driver = load_driver()
    driver.support = support
    (ROOT / f"executed-{name}-run_smoke.py").write_bytes(Path(__file__).read_bytes())
    save(ROOT / f"execution-{name}.json", dict(plan_sha256=sha(ROOT / "plan.json"),
         candidate_manifest_sha256=sha(CANDIDATE / "manifest.json"), module_paths=modules,
         candidate_status=manifest["status"], source_or_candidate=name, native_runs_requested=1))
    driver.run("paired", "native-" + name, network.resolve(), control.resolve())
    audit(name, plan, network)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare-only", action="store_true")
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", choices=["source", "candidate"])
    args = parser.parse_args()
    if args.prepare_only:
        prepare()
    elif args.check_only:
        plan, _, modules = check()
        print(json.dumps(dict(status="pass", native_runs=0, count=plan["count"], module_paths=modules)))
    else:
        execute(args.run)
