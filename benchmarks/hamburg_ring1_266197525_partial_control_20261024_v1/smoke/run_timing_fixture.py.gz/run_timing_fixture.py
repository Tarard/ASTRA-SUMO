"""At most four bounded candidate timing schedules; no route or driving changes."""
import argparse
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import shutil

from audit_native import audit

ROOT = Path(__file__).resolve().parent
TIMES = {
    1: {"conflict_main_8":31, "conflict_main_6":62, "conflict_main_7":79},
    2: {"conflict_main_8":62, "conflict_main_6":63, "conflict_main_7":88,
        **{f"counter_car_{i}":60+.8*i for i in range(4)},
        **{f"counter_bicycle_{i}":85+.8*i for i in range(4)}},
}


def main(number, case):
    target = ROOT / f"timing-{number}"
    if not target.exists():
        assert case == "candidate" and number in TIMES
        target.mkdir()
        shutil.copytree(ROOT / "inputs", target / "inputs")
        shutil.copy2(ROOT / "shared-driver.py", target / "shared-driver.py")
        plan = json.loads((ROOT / "plan.json").read_bytes())
        jobs = json.loads((target / "inputs/jobs.json").read_bytes())
        for row in jobs["jobs"]:
            if row["id"] in TIMES[number]:
                row["trigger"]["time_s"] = TIMES[number][row["id"]]
        (target / "inputs/jobs.json").write_text(json.dumps(jobs,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        plan["jobs"] = jobs["jobs"]
        plan["inputs"]["jobs.json"] = hashlib.sha256((target / "inputs/jobs.json").read_bytes()).hexdigest()
        plan["timing_correction"] = dict(parent_plan_sha256=hashlib.sha256((ROOT / "plan.json").read_bytes()).hexdigest(), times=TIMES[number],
            basis="First paired actual TLS/FCD:main missed counter windows; upstream196/244/536 gates can absorb shifts. Candidate timing2 groups car then bicycle normal entries to prolong native counter service. This is a bounded mechanism fixture, not demand calibration.")
        plan["source_hashes"][str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        (target / "plan.json").write_text(json.dumps(plan,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    spec = spec_from_file_location("unchanged_prepared_525_fixture", ROOT / "run_smoke.py")
    runner = module_from_spec(spec)
    spec.loader.exec_module(runner)
    runner.ROOT = target
    runner.execute(case)
    native = target / ("native-" + case)
    result = json.loads((native / "result.json").read_bytes())
    assert not result["collision_rows"] and not any(result["safety"].values()), "Unsafe fixture: stop all later schedules."
    audit(native, (runner.SOURCE if case == "source" else runner.CANDIDATE) / "network.net.xml")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--schedule",type=int,choices=[1,2],required=True)
    parser.add_argument("--case",choices=["source","candidate"],default="candidate")
    args = parser.parse_args()
    main(args.schedule,args.case)
