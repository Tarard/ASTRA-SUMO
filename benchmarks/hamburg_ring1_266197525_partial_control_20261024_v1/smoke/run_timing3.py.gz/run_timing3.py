"""Final bounded timing correction: separate car2 from bicycle2, preserve16 routes."""
import argparse
import hashlib
import json
from pathlib import Path

import run_timing_fixture as fixture

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=["source", "candidate"], default="candidate")
    args = parser.parse_args()
    fixture.TIMES[3] = dict(fixture.TIMES[1], counter_bicycle_2=120)
    request = fixture.ROOT / "timing-3-request.json"
    if not request.exists():
        request.write_text(json.dumps(dict(times=fixture.TIMES[3],
            rationale="Root selected after reading timing1 raw:delay onlybike2 to isolate car2 conflict; main times inherit timing1. Timing1 bike-only internal yield evidence stays separate.",
            script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2) + "\n", encoding="utf-8")
    fixture.main(3, args.case)
