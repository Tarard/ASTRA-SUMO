"""Offline525 fixture audit; decode the pinned libsumo SWIG tuple layout."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

MOVES = {0: ("25866659#2", 0, "25866655#0", 0), 1: ("25866659#2", 1, "25866655#0", 1),
         5: ("73474895", 0, "27064186#0", 0), 8: ("73474895", 0, "1108564798#0", 0),
         6: ("73474895", 1, "1108564798#0", 1), 7: ("73474895", 2, "1108564798#0", 2)}


def link(row):
    assert len(row) == 8 and isinstance(row[0], str) and isinstance(row[4], str)
    assert all(isinstance(row[i], bool) for i in [1, 2, 3])
    return dict(lane=row[0], priority=row[1], opened=row[2], foe=row[3], via=row[4], state=row[5])


def audit(folder, network):
    folder, network = Path(folder), Path(network)
    assert not (folder / "mechanism-audit.json").exists(), "Preserve sealed audits."
    plan = json.loads((folder.parent / "plan.json").read_bytes())
    jobs = {r["id"]: r for r in plan["jobs"]}
    result = json.loads((folder / "result.json").read_bytes())
    samples = json.loads((folder / "samples.json").read_bytes())
    net = ET.parse(network).getroot()
    connections = {(r.get("from"), int(r.get("fromLane")), r.get("to"), int(r.get("toLane"))): r
                   for r in net.findall("connection") if not r.get("from").startswith(":")}
    paths = {m: [connections[key].get("via")] for m, key in MOVES.items()}
    arrived = {r.get("id"): r.find("route") for r in ET.parse(folder / "vehicle-routes.xml").getroot().findall("vehicle")}
    coverage, witnesses, red_passages = [], [], []
    for identity, job in jobs.items():
        route = arrived.get(identity)
        exits = [] if route is None else list(map(float, route.get("exitTimes").split()))
        complete = route is not None and route.get("edges").split() == job["explicit_route"] and len(exits) == len(job["explicit_route"]) and all(t >= 0 for t in exits) and exits == sorted(exits)
        history = [(r, r["vehicles"][identity]) for r in samples if identity in r["vehicles"]]
        move, key = job["movement"], MOVES[job["movement"]]
        hits = [i for i, (_, v) in enumerate(history) if v["lane"] in paths[move]]
        after = next((v["lane"] for _, v in history[max(hits) + 1:] if not v["lane"].startswith(":")), None) if hits else None
        direct = bool(hits) and after == f"{key[2]}_{key[3]}"
        # A0.1m receiving edge may be traversed between two0.1s frames.
        receiving = net.find(f"edge[@id='{key[2]}']")
        unique_single_lane = len(receiving.findall("lane")) == 1 and key[3] == 0
        internal_edge, internal_lane = paths[move][-1].rsplit("_", 1)
        outgoing = [r for r in net.findall("connection") if r.get("from") == internal_edge and r.get("fromLane") == internal_lane]
        native_exit = complete and key[2] in job["explicit_route"] and exits[job["explicit_route"].index(key[2])] > 0
        derived = bool(hits) and unique_single_lane and len(outgoing) == 1 and outgoing[0].get("to") == key[2] and outgoing[0].get("toLane") == "0" and native_exit
        coverage.append(dict(vehicle_id=identity, movement=move, covered=complete and (direct or derived),
                             evidence_type="sampled_via_and_receiving_lane" if direct else "native_route_exit_and_unique_connection_derived" if derived else "missing",
                             actual_via_lanes=sorted({v["lane"] for _, v in history}.intersection(paths[move])),
                             first_sampled_receiving_lane=after, complete_route=complete))
        if move not in [5, 6, 7, 8] or not hits:
            continue
        entry = history[min(hits)][0]["time_s"]
        for row, v in history[:min(hits)]:
            decoded = [link(r) for r in v["next_links"]]
            target = next((i for i, r in enumerate(decoded) if r["via"] in paths[move]), None)
            if target is None:
                continue
            current = decoded[target]
            no_upstream_red = all(r["opened"] and r["state"] not in "rRu" for r in decoded[:target])
            leader_clear = not v["leader"] or v["leader"][1] > 10
            slowed = v["speed_m_s"] <= .3 or v["acceleration_m_s2"] < -.2
            if current["opened"] or not current["foe"] or not no_upstream_red or not leader_clear or v["stop_state"] != 0 or not slowed:
                continue
            released = next((later["time_s"] for later, lv in history[:min(hits) + 1] if later["time_s"] > row["time_s"] and any(d["via"] in paths[move] and d["opened"] and not d["foe"] for d in map(link, lv["next_links"]))), None)
            if released is None:
                continue
            strict = [f for f in v["junction_foes"] if len(f) == 9 and f[0] in jobs and jobs[f[0]]["role"] in ["counter_car", "counter_bicycle"] and f[7] and f[5] in paths[move] and f[6] in paths[jobs[f[0]]["movement"]]]
            nearby = {i: cv for i, cv in row["vehicles"].items() if jobs[i]["role"] in ["counter_car", "counter_bicycle"] and (cv["lane"] in paths[jobs[i]["movement"]] or cv["lane"].startswith("25866659#2_"))}
            classes = {jobs[i]["vehicle_class"] for i in nearby}
            if strict:
                evidence = [(f[0], "getJunctionFoes_response_and_closed_foe_link", f) for f in strict]
            elif len(classes) == 1 and nearby:
                evidence = [(i, "closed_foe_link_and_single_counter_class_in_conflict_approach", None) for i in nearby]
            else:
                evidence = []
            for foe_id, method, raw_foe in evidence:
                witnesses.append(dict(main_id=identity, counter_id=foe_id, counter_class=jobs[foe_id]["vehicle_class"], method=method,
                    time_s=row["time_s"], main_lane=v["lane"], speed_m_s=v["speed_m_s"], acceleration_m_s2=v["acceleration_m_s2"],
                    raw_next_link=v["next_links"][target], raw_foe=raw_foe, counter_positions=nearby,
                    subsequent_open_no_foe_s=released, subsequent_actual_via_entry_s=entry))
        at, previous = history[min(hits)][0], history[max(0, min(hits) - 1)][0]
        counter = [i for i, v in at["vehicles"].items() if jobs[i]["role"] in ["counter_car", "counter_bicycle"] and v["near_197"]]
        if at["state"][move] == previous["state"][move] == "r" and not counter:
            red_passages.append(dict(vehicle_id=identity, movement=move, actual_entry_s=entry, old_unused_state=at["state"], counter_near525=[]))
    checks = dict(all16_complete_six_movements=all(r["covered"] for r in coverage),
                  native_driver_pass=result["status"] == "pass", inputs_unchanged=result["source_inputs_unchanged"],
                  car_yield_and_release=any(r["counter_class"] == "passenger" for r in witnesses),
                  bicycle_yield_and_release=any(r["counter_class"] == "bicycle" for r in witnesses),
                  no_counter_unused_red_pass=bool(red_passages))
    unsafe = bool(result["collision_rows"]) or any(result["safety"].values())
    source = folder.name == "native-source"
    passed = all(v for k, v in checks.items() if not source or k in ["all16_complete_six_movements", "native_driver_pass", "inputs_unchanged"])
    report = dict(schema="astra.hamburg.266197525-native-mechanism-audit/v1", status="blocked" if unsafe else "pass" if passed else "review_required",
                  formal_result=False, native_runs_started_by_audit=0, checks=checks, coverage=coverage,
                  yield_witnesses=witnesses, red_passages=red_passages,
                  tuple_contract="Pinned1.27.1 libsumo SWIG:lane,priority,opened,foe,via,state,direction,length;JunctionFoes9fields unchanged. Original runner verdicts are retained; their nextLinks decoder used a differing TraCI doc order.",
                  boundary="Narrow nativeROW witness only. Foe-less/single-class proof is labelled separately, never called getJunctionFoes evidence.0unsafe is not yield proof. Single-lane0.1m receiving-edge evidence is labelled derived, not a sampled lane observation.",
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [network, folder / "samples.json", folder / "result.json", folder / "vehicle-routes.xml", Path(__file__)]})
    (folder / "mechanism-audit.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(folder=str(folder),status=report["status"],checks=checks,witnesses=len(witnesses))))
    return report
