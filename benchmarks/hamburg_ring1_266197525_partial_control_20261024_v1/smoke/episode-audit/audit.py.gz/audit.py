"""Summarize the completed bounded525 fixtures without changing prior verdicts."""
import csv
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
SMOKE = OUT.parent
REPO = SMOKE.parents[2]
DECODER = REPO / "outputs/hamburg-libsumo-observation-decoder-20261024-v1/decoder.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not (OUT / "manifest.json").exists(), "Preserve sealed episode audits."
    spec = spec_from_file_location("pinned_libsumo_observation_decoder", DECODER)
    decoder = module_from_spec(spec)
    spec.loader.exec_module(decoder)
    spec = spec_from_file_location("completed525_fixture_offline_audit", SMOKE / "audit_native.py")
    supplemental = module_from_spec(spec)
    spec.loader.exec_module(supplemental)
    folders = [SMOKE / "native-source", SMOKE / "native-candidate"]
    folders += [SMOKE / f"timing-{i}/native-candidate" for i in [1, 2, 3]]
    folders += [SMOKE / "timing-3/native-source"]
    source_net = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full/prepared/network.net.xml"
    candidate_net = SMOKE.parent / "candidate-v2/network.net.xml"
    cases, hashes = [], {str(DECODER): sha(DECODER), str(source_net): sha(source_net), str(candidate_net): sha(candidate_net)}
    for folder in folders:
        if not (folder / "mechanism-audit.json").exists():
            supplemental.audit(folder, source_net if folder.name == "native-source" else candidate_net)
        result = json.loads((folder / "result.json").read_bytes())
        audit = json.loads((folder / "mechanism-audit.json").read_bytes())
        trips = ET.parse(folder / "tripinfo.xml").getroot().findall("tripinfo")
        assert result["status"] == "pass" and all(result["coverage"].values())
        assert not result["collision_rows"] and not any(result["safety"].values())
        assert len(trips) == 16 and all(float(t.get("arrival")) >= 0 and not t.get("vaporized") for t in trips)
        assert audit["checks"]["all16_complete_six_movements"]
        cases.append(dict(path=folder.relative_to(SMOKE).as_posix(), native_driver_status=result["status"],
                          original_runner_status=json.loads((folder / "smoke-verdict.json").read_bytes())["status"],
                          strict_corrected_audit_status=audit["status"], arrived=16, unsafe=result["safety"],
                          actual_movement_coverage=audit["coverage"], red_passages=audit["red_passages"],
                          actual_entries={i: r["time_s"] for i, r in result["entered_movements"].items()}))
        for path in folder.iterdir():
            if path.is_file():
                hashes[str(path)] = sha(path)
    traces = {i: json.loads((SMOKE / f"timing-{i}/native-candidate/samples.json").read_bytes()) for i in [1, 3]}

    def extract(number, start, end):
        rows = []
        for frame in traces[number]:
            if not start <= frame["time_s"] <= end or "conflict_main_6" not in frame["vehicles"]:
                continue
            vehicle = frame["vehicles"]["conflict_main_6"]
            links = [decoder.decode_next_link(r) for r in vehicle["next_links"]]
            foes = [decoder.decode_junction_foe(r) for r in vehicle["junction_foes"]]
            counter = {i: dict(lane=v["lane"], position_m=v["pos_m"], speed_m_s=v["speed_m_s"])
                       for i, v in frame["vehicles"].items() if i.startswith("counter_") and v["near_197"]}
            rows.append(dict(time_s=frame["time_s"], main_lane=vehicle["lane"], main_position_m=vehicle["pos_m"],
                             speed_m_s=vehicle["speed_m_s"], acceleration_m_s2=vehicle["acceleration_m_s2"],
                             leader=vehicle["leader"], stop_state=vehicle["stop_state"], next_TLS=vehicle["next_TLS"],
                             next_links=links, junction_foes=foes, counter_positions=counter))
        return rows

    bike = extract(1, 67, 75)
    car = extract(3, 67, 72)
    bike_braking = [r for r in bike if 71.4 <= r["time_s"] <= 72.3 and r["acceleration_m_s2"] < -.2
                    and r["leader"] is None and r["stop_state"] == 0 and len(r["junction_foes"]) == 1
                    and r["junction_foes"][0]["foeId"] == "counter_bicycle_2"
                    and r["junction_foes"][0]["egoResponse"] and not r["junction_foes"][0]["foeResponse"]
                    and r["junction_foes"][0]["egoDist"] > 0 and r["junction_foes"][0]["foeExitDist"] > 0]
    bike_tail_clear = next(r for r in bike if r["time_s"] >= 72.3 and any(f["foeId"] == "counter_bicycle_2" and f["foeExitDist"] < 0 for f in r["junction_foes"]))
    bike_resume = next(r for r in bike if r["time_s"] > bike_tail_clear["time_s"] and r["acceleration_m_s2"] > 0)
    bike_query_empty = next(r for r in bike if r["time_s"] > bike_resume["time_s"] and not r["junction_foes"])
    car_closed = [r for r in car if any(item["via"] == ":266197525_3_1" and item["state"] == "m" and item["foe"] and not item["opened"] for item in r["next_links"])]
    car_braking = [r for r in car if 68.5 <= r["time_s"] <= 69.2 and r["acceleration_m_s2"] < -.2 and r["leader"] is None and r["stop_state"] == 0]
    car_response = [r for r in car if r["junction_foes"] and all(f["foeId"] == "counter_car_2" and f["egoResponse"] and not f["foeResponse"] for f in r["junction_foes"])]
    assert all(not any(i.startswith("counter_bicycle_") for i in r["counter_positions"]) for r in car if 67.1 <= r["time_s"] <= 71)
    car_resume_clear = next(r for r in car if r["time_s"] >= 71 and not r["junction_foes"] and r["acceleration_m_s2"] > 0)
    assert bike_braking and car_closed and car_braking and car_response
    for name, rows in [("timing1-bike-window", bike), ("timing3-car-window", car)]:
        with (OUT / (name + ".csv")).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in r.items()} for r in rows)
    report = dict(schema="astra.hamburg.266197525-completed-smoke-episodes/v1", status="pass", formal_result=False,
        new_native_runs=0, completed_native_calls=6, candidate_timing_schedules=4, source_timing_schedules=2,
        cases=cases, checks=dict(all96_arrived=True, all_six_movements_covered_per_case=True, no_unsafe_all_cases=True,
        bike_internal_response_braking_and_resume=bool(bike_braking), car_only_closed_foe_braking_response_and_resume=bool(car_response),
        retained_counter_control=True, candidate_no_counter_old_red_passage=all(any(c["red_passages"]) for c in cases if c["path"].endswith("native-candidate"))),
        bike_episode=dict(case="timing-1/native-candidate", main_id="conflict_main_6", counter_id="counter_bicycle_2",
            braking_start_s=bike_braking[0]["time_s"], braking_end_s=bike_braking[-1]["time_s"],
            front_before_conflict=True, native_counter_tail_clear_s=bike_tail_clear["time_s"], resume_s=bike_resume["time_s"], query_empty_s=bike_query_empty["time_s"],
            interpretation="Actual egoResponse with onlybike2 in the query, no leader/active stop, braking inside the long525via, then acceleration after the native foe-exit distance becomes negative. The entry link is no longer returned after entry; no invented isOpen value is used there."),
        car_episode=dict(case="timing-3/native-candidate", main_id="conflict_main_6", counter_id="counter_car_2",
            closed_foe_link_start_s=car_closed[0]["time_s"], closed_foe_link_end_s=car_closed[-1]["time_s"],
            braking_start_s=car_braking[0]["time_s"], braking_end_s=car_braking[-1]["time_s"],
            sole_car_query_start_s=car_response[0]["time_s"], sole_car_query_end_s=car_response[-1]["time_s"], clear_query_acceleration_s=car_resume_clear["time_s"],
            interpretation="Only the car class is in the monitored conflict approach. Closed+foe at the exact525m link precedes braking; later the junction query names onlycar2 and egoResponse. The isOpen query is predictive and becomes true before physical crossing is finished. These are an episode sequence, not a claim that all flags and braking occur in one frame or that all braking has a unique cause."),
        prior_verdicts="All original smoke-verdict.json and strict mechanism-audit.json files retain their original values. The first runner used the differing TraCI-doc nextLinks order; the corrected strict same-frame/entry gate missed predictive link opening and internal-via braking. This supplemental audit is written after the terminal runs and does not pretend to predate root approval/full launch.",
        boundaries=["Two response episodes come from different candidate timing schedules; they are not a single paired causal experiment.",
                    "Timing3 has its own identical fixed-time source counterpart; the initial timing schedule also has its own source counterpart.",
                    "The0.1m residential receiving edge can be absent from frames; derived evidence uses its unique via, single allowed receivinglane and actual full route exitTimes, labelled separately.",
                    "Bike ends at the present bicycle-permitted graph boundary73474902#1; no vehicle.remove or early termination was used.",
                    "All16 normal-entry routes arrive and all four original counter-car fields contribute once. No real calibration targets or MAE are supplied.",
                    "This does not validate field control ownership, measuredSPaT, congestion capacity, every arrival order or full8640 safety."],
        source_sha256=hashes)
    assert all(report["checks"].values())
    (OUT / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    manifest = dict(schema="astra.evidence.manifest/v1", native_runs_started_by_audit=0,
                    files=[dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"])
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status=report["status"], calls=6, manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
