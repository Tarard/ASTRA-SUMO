# 525少车原生证据

共6次原生调用：4个candidate时刻表、2个source对照。每次均为同16辆、同路线、同车型、step0.1、seed104、end900；全部96车次到达，无碰撞、传送、discard。没有完整8640运行，没有真实目标MAE。

四个734 movement与counter机动车、自行车均有实际原生via覆盖。住宅接收边270仅0.1m，个别frame跳过它；对应记录明确标为“native route exitTimes＋唯一connection＋单lane接收边”推得，不冒称直接lane观测。自行车终点73474902#1是当前bicycle允许图的边界，没有中途remove。

timing1：main6在71.4–72.3的525长内道中制动，getJunctionFoes只列bike2，egoResponse=true，foeResponse=false，无leader或active stop。72.4原生foeExitDist转负，72.8开始加速，73.8查询为空。不能要求让行只能发生在3.217m的734边上。

timing3：只将timing1的bike2发车从60改到120，保留其余16车路线和时刻。67.1–67.8，main6的525目标m link为closed＋foe；68.5–69.2制动；69.4–70.9查询只列car2且egoResponse=true；71.0查询为空并加速。此处是先后相连的证据，不能把opened预测量解释为车身是否已离开，也不声称每一帧制动只有一个原因。timing3另有同时间表source对照。两类让行证据来自不同candidate时间表，如实分列。

晚窗还实见无附近counter时，734车辆在旧未绑定红位通过。0unsafe本身不作让行证据。当前结果只支持受限原生机制，不证明现场控制归属、真实SPaT、所有到达次序或全量安全。

原始smoke-verdict.json全部保留review_required。首入口把TraCI文档的nextLinks字段顺序用于libsumo；原始观测不受影响，但该旧解码不能判让行。修正后严格同帧/入口门仍漏掉预测opened与内道制动，原mechanism-audit.json也不重写。本目录复用已封口的1.27.1 SWIG decoder，独立记录补证；不冒称这份补充报告早于root原始证据批准或full启动。
