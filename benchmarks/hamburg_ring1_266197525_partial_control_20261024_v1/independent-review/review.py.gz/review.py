"""Independently audit saved source/raw/final files; never run a converter or traffic."""

import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))


def main():
    from astra_sumo.core.junction_split_fanout import _canonical, _curve, _internal_path, _key
    from astra_sumo.core.local_network_conversion import loaded_turn_permissions
    from astra_sumo.core.osm_access import _permission_set

    folder = ROOT.parent / "candidate-v2"
    report = json.loads((folder / "manifest.json").read_bytes())
    source = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full/prepared"
    before = ET.parse(source / "network.net.xml").getroot()
    after = ET.parse(folder / "network.net.xml").getroot()
    raw = ET.parse(report["conversion"]["native_output"]["path"]).getroot()
    node = "266197525"
    ordinary = {r.get("id"): r for r in before.findall("edge") if not r.get("function")}
    mains = {("73474895", 0, "27064186#0", 0), ("73474895", 0, "1108564798#0", 0),
        ("73474895", 1, "1108564798#0", 1), ("73474895", 2, "1108564798#0", 2)}
    counters = {("25866659#2", 0, "25866655#0", 0): "0", ("25866659#2", 1, "25866655#0", 1): "1"}
    keys = mains | counters.keys()

    def movements(root):
        return {_key(c): c for c in root.findall("connection") if c.get("from") in ordinary and ordinary[c.get("from")].get("to") == node}

    def requests(root):
        junction = root.find(f"junction[@id='{node}']")
        internal = junction.get("intLanes").split()
        index = {key: internal.index(_internal_path(root, row)[-1].get("id")) for key, row in movements(root).items()}
        reqs = {int(row.get("index")): row for row in junction.findall("request")}
        assert set(index.values()) == set(reqs) == set(range(6))
        result = {}
        for key, ordinal in index.items():
            request = reqs[ordinal]
            assert all(len(request.get(attribute)) == 6 for attribute in ("response", "foes"))
            result[key] = {attribute: sorted(other for other in keys if request.get(attribute)[-1 - index[other]] == "1") for attribute in ("response", "foes")}
            result[key]["cont"] = request.get("cont")
        return result

    old, new = movements(before), movements(after)
    checks = {"six_exact_movement_keys": old.keys() == new.keys() == keys,
        "all_turn_permissions_equal": loaded_turn_permissions(before) == loaded_turn_permissions(after),
        "all_ordinary_roads_xml_equal": {r.get("id"): _canonical(r) for r in before.findall("edge") if not r.get("function")} == {r.get("id"): _canonical(r) for r in after.findall("edge") if not r.get("function")},
        "all_program_inventory_and_xml_equal": {(r.get("id"), r.get("programID")): _canonical(r) for r in before.findall("tlLogic")} == {(r.get("id"), r.get("programID")): _canonical(r) for r in after.findall("tlLogic")},
        "external_control_bytes_equal": (source / "control.add.xml").read_bytes() == (folder / "control.add.xml").read_bytes(),
        "all_four_main_state_m_and_no_tls": all(new[key].get("state") == "m" and not any(attr in new[key].attrib for attr in ("tl", "linkIndex", "linkIndex2")) for key in mains),
        "counter_O_and_TL0_1": all(new[key].get("state") == "O" and new[key].get("tl") == node and new[key].get("linkIndex") == signal for key, signal in counters.items()),
        "source_and_final_response_foes_cont_equal_by_key": requests(before) == requests(after),
        "raw_and_final_native_response_foes_cont_equal_by_key": requests(raw) == requests(after)}
    first, last = before.find(f"junction[@id='{node}']"), after.find(f"junction[@id='{node}']")
    checks["all_target_attrs_except_intLanes_equal"] = {k: v for k, v in first.attrib.items() if k != "intLanes"} == {k: v for k, v in last.attrib.items() if k != "intLanes"}
    checks["unique_program_keys_and_exact_count"] = len(before.findall("tlLogic")) == len(after.findall("tlLogic")) == len({(p.get("id"), p.get("programID")) for p in after.findall("tlLogic")})
    excluded = {"tl", "linkIndex", "linkIndex2", "state", "via", "uncontrolled", "shape", "speed", "length", "contPos"}
    checks["other_connection_attrs_equal"] = all({k: v for k, v in old[key].attrib.items() if k not in excluded} == {k: v for k, v in new[key].attrib.items() if k not in excluded} for key in keys)
    checks["contPos_hint_only_source_single_primary_paths"] = all((new[key].get("contPos") is None or float(new[key].get("contPos")) == 0)
        if key in mains and key[2] == "1108564798#0" else new[key].get("contPos") == old[key].get("contPos") for key in keys)
    rows = []
    for key in keys:
        a, b = _internal_path(before, old[key]), _internal_path(after, new[key])
        row = {"movement": key, "source_parts": len(a), "candidate_parts": len(b), "curve_offset_m": _curve(before, old[key]).hausdorff_distance(_curve(after, new[key])),
            "length_delta_m": sum(float(r.get("length")) for r in b) - sum(float(r.get("length")) for r in a),
            "widths_equal": [float(r.get("width", "3.2")) for r in a] == [float(r.get("width", "3.2")) for r in b],
            "speeds_equal": [float(r.get("speed")) for r in a] == [float(r.get("speed")) for r in b],
            "LC_equal": [(r.get("changeLeft"), r.get("changeRight")) for r in a] == [(r.get("changeLeft"), r.get("changeRight")) for r in b],
            "lane_permissions_equal": [_permission_set(r.attrib, network_version=before.get("version")) for r in a] == [_permission_set(r.attrib, network_version=after.get("version")) for r in b]}
        rows.append(row)
    checks["all_internal_parts_curves_lengths_preserved"] = all(row["source_parts"] == row["candidate_parts"] == 1 and row["curve_offset_m"] <= 1e-6 and abs(row["length_delta_m"]) <= 1e-6 for row in rows)
    checks["all_internal_width_speed_LC_permissions_equal"] = all(row["widths_equal"] and row["speeds_equal"] and row["LC_equal"] and row["lane_permissions_equal"] for row in rows)
    def exterior(root):
        return [_canonical(r) for r in root if not (r.tag in ("edge", "junction") and (r.get("id") == node or r.get("id", "").startswith(":" + node + "_"))
            or r.tag == "connection" and (r.get("from", "").startswith(":" + node + "_") or r.get("from") in ordinary and ordinary[r.get("from")].get("to") == node))]
    checks["exterior_xml_and_order_equal"] = exterior(before) == exterior(after)
    paths = [source / "network.net.xml", source / "control.add.xml", folder / "network.net.xml", folder / "control.add.xml", folder / "manifest.json",
        Path(report["conversion"]["native_output"]["path"]), Path(__file__)]
    result = {"status": "pass" if all(checks.values()) else "blocked", "formal_result": False, "new_native_runs": 0, "new_conversion_runs": 0,
        "checks": checks, "movement_geometry": rows,
        "candidate_sha256": hashlib.sha256((folder / "network.net.xml").read_bytes()).hexdigest(),
        "source_hashes": {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        "fixture_opinion": "Eligible for one bounded natural-entry yield fixture. This is construction/ROW support, not runtime safety or field-applicability proof. Include an actual counter arrival against mainm and preserve mode31/keepClear; count improvements are a separate later question.",
        "failed_v1": "Retained blocked. Native primary paths split and cont changed0→1;v2 explicitly pins only those source-single primary paths tocontPos0 before native compilation."}
    (ROOT / "review.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert result["status"] == "pass", checks
    print(json.dumps({"status": result["status"], "checks": checks, "candidate_sha256": result["candidate_sha256"]}))


if __name__ == "__main__":
    main()
