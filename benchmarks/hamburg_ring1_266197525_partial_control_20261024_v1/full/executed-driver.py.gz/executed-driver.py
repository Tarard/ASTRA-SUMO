"""Evaluate one reviewed partial-control candidate with unchanged complete demand."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full"
SHARED = SOURCE.parent / "run_full.py"
CANDIDATE = ROOT / "candidate-v2"
CASE = ROOT / "full"
REVIEW = ROOT / "reviewed-smoke-binding.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert sha(SHARED) == "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"
BASE = runpy.run_path(str(SHARED))


def save(path, value):
    if path == CASE / "preflight.json":
        value["shared_measurement_driver"] = {"path": str(CASE / "executed-shared-driver.py"),
            "sha256": sha(CASE / "executed-shared-driver.py"), "source_sha256": sha(SHARED)}
    if path == CASE / "verdict.json":
        if "source_plus15" in value:
            value["source_209_parent"] = value.pop("source_plus15")
        comparison = value.get("comparison", {})
        if "plus15_parent" in comparison:
            comparison["parent_209_full"] = comparison.pop("plus15_parent")
        value.update(study_role="four_734_movements_without_independent_525_signal_binding",
            claim_boundary="Only four734 movements lose their525 signal binding and retain native yielding to the two controlled counter movements. All roads, legal turns, geometry, permissions, programs, demand and observations stay fixed. Actuated realization may respond to changed binding. Source applicability and field SPaT remain review_required. Main130 zero plus valid completion remains the target; initial52 and derived station40 remain reported.")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prepare():
    candidate = json.loads((CANDIDATE / "manifest.json").read_bytes())
    assert candidate["status"] == "review_required" and all(candidate["checks"].values())
    prepared = CASE / "prepared"
    prepared.mkdir(parents=True, exist_ok=False)
    for name in BASE["NAMES"]:
        origin = CANDIDATE if name in {"network.net.xml", "control.add.xml"} else SOURCE / "prepared"
        shutil.copyfile(origin / name, prepared / name)
    scenario = json.loads((prepared / "scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False,
        network_sha256=sha(prepared / "network.net.xml"), control_sha256=sha(prepared / "control.add.xml"),
        connection_candidate="Same209 ordinal network; only four734 movements no longer have an independent525 stop requirement. Counter motor/bicycle control, native conflict yielding, all upstream/downstream programs and complete demand remain fixed. This is a source-supported hypothesis, not observed field SPaT.")
    save(prepared / "scenario.json", scenario)
    paths = [SOURCE / "prepared" / name for name in BASE["NAMES"]]
    paths += [CANDIDATE / name for name in ("network.net.xml", "control.add.xml", "manifest.json")]
    paths += [SHARED, Path(__file__), SOURCE / "verdict.json", SOURCE / "preflight.json",
        BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"], BASE["AUDIT_HELPER"].parent / "audit_scope.py"]
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "hamburg_od_spsa.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    save(CASE / "scope-proof.json", {"status": "pass", "formal_result": False,
        "source_hashes": {str(path): sha(path) for path in paths},
        "prepared_hashes": {name: sha(prepared / name) for name in BASE["NAMES"]},
        "unchanged_input_names": [name for name in BASE["NAMES"] if name not in {"network.net.xml", "scenario.json"}],
        "N": 8640, "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo"})


def require_smoke():
    reviewed = json.loads(REVIEW.read_bytes())
    assert reviewed["status"] == "pass" and reviewed["candidate_network_sha256"] == sha(CASE / "prepared/network.net.xml")
    assert reviewed["candidate_control_sha256"] == sha(CASE / "prepared/control.add.xml")
    assert all(sha(path) == value for path, value in reviewed["reviewed_evidence_hashes"].items())
    return {"status": "pass", "path": str(REVIEW), "sha256": sha(REVIEW), **reviewed}


def check():
    proof = json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(sha(path) == value for path, value in proof["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in proof["prepared_hashes"].items())
    assert all((CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes() for name in proof["unchanged_input_names"])
    assert len(ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle")) == 8640
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    parent_runtime = json.loads((SOURCE / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent_runtime["modules"] and runtime["native_library"] == parent_runtime["native_library"]
    assert all(sha(path) == value for path, value in parent_runtime["binaries"].items())
    runtime["binaries"] = parent_runtime["binaries"]
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    parent = json.loads((SOURCE / "verdict.json").read_bytes())
    assert parent["healthy"] and parent["safe"] and parent["unique_intended_fields"] and parent["after"]["metrics130"]["TAE"] == 421
    return {"status": "pass", "native_runs": 0, "runtime": runtime, "smoke": require_smoke()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--check-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.prepare:
        prepare()
        print("Prepared only; native requires reviewed smoke evidence.")
    elif args.check_only:
        print(json.dumps({key: value for key, value in check().items() if key != "runtime"}))
    else:
        check()
        assert not (CASE / "evaluation").exists() and not (CASE / "executed-shared-driver.py").exists()
        # The two drivers share a basename; retain the delegated measurement code separately.
        shutil.copyfile(SHARED, CASE / "executed-shared-driver.py")
        BASE["run"].__globals__.update(ROOT=ROOT, CASE=CASE, SOURCE=SOURCE, CANDIDATE=CANDIDATE,
            check=check, require_smoke=require_smoke, save=save, __file__=str(Path(__file__)))
        BASE["run"]()
