"""Bind completed raw smoke evidence before the single full evaluation."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


target = ROOT / "reviewed-smoke-binding.json"
assert not target.exists() and not (ROOT / "full/evaluation").exists()
candidate = ROOT / "candidate-v2"
manifest = read(candidate / "manifest.json")
assert all(manifest["checks"].values()) and manifest["status"] == "review_required"
network = candidate / "network.net.xml"
assert sha(network) == "6c52382e7664eca33fceff6fd02ae700d93139a316a3f9f5139d0e139d7a18ce"
paths = [Path(__file__), candidate / "manifest.json", network, candidate / "control.add.xml",
    ROOT / "independent-review/manifest.json", ROOT / "independent-review/review.json",
    REPO / "outputs/hamburg-libsumo-observation-decoder-20261024-v1/manifest.json"]
cases = [("", "source"), ("", "candidate"), ("timing-1", "candidate"),
    ("timing-2", "candidate"), ("timing-3", "candidate"), ("timing-3", "source")]
for timing, name in cases:
    folder = ROOT / "smoke" / timing / ("native-" + name)
    result, request = read(folder / "result.json"), read(folder / "request.json")
    assert result["status"] == "pass" and all(result["coverage"].values())
    assert not any(result["safety"].values()) and not result["collision_rows"] and not result["pending_jobs"]
    assert result["source_inputs_unchanged"] and len(request["jobs"]) == 16
    assert all(sha(Path(p)) == digest for p, digest in request["inputs"].items())
    if name == "candidate":
        assert request["inputs"][str(network)] == manifest["candidate_sha256"]
    command = request["command"]
    assert Path(command[0]).is_relative_to(REPO / ".venv")
    assert command[command.index("--end") + 1] == "900"
    assert float(command[command.index("--step-length") + 1]) == .1
    assert command[command.index("--seed") + 1] == "104"
    paths += [folder / n for n in ("result.json", "request.json", "samples.json", "vehicle-routes.xml", "commands.json", "native-version.json")]

episodes = []
for timing, foe, brake_time, clear_time in [("timing-1", "counter_bicycle_2", 72.0, 74.0),
        ("timing-3", "counter_car_2", 70.5, 71.0)]:
    folder = ROOT / "smoke" / timing / "native-candidate"
    frames = {round(r["time_s"], 1): r for r in read(folder / "samples.json")}
    brake = frames[brake_time]["vehicles"]["conflict_main_6"]
    clear = frames[clear_time]["vehicles"]["conflict_main_6"]
    assert brake["lane"] == ":266197525_3_1" and brake["stop_state"] == 0 and brake["leader"] is None
    assert brake["acceleration_m_s2"] < -2 and brake["speed_m_s"] > 0
    assert {r[0] for r in brake["junction_foes"]} == {foe}
    assert all(len(r) == 9 and r[5] == ":266197525_3_1" and r[7] is True and r[8] is False for r in brake["junction_foes"])
    assert not clear["junction_foes"] and clear["acceleration_m_s2"] > 0
    vehicle = ET.parse(folder / "vehicle-routes.xml").getroot().find("vehicle[@id='conflict_main_6']")
    assert vehicle is not None and vehicle.find("route").get("edges").split()[-1] == "199500676"
    assert all(float(t) >= 0 for t in vehicle.find("route").get("exitTimes").split())
    episodes.append({"case": timing, "foe": foe, "braking_time_s": brake_time, "clear_and_accelerate_time_s": clear_time,
        "braking_sample": brake, "clear_sample": clear})

# A 0.1m receiving lane may be crossed between samples; the unique native path and completed route remain evidence.
net = ET.parse(network).getroot()
residential = [r for r in net.findall("connection") if r.get("from") == ":266197525_2" and r.get("fromLane") == "0"]
assert len(residential) == 1 and residential[0].get("to") == "27064186#0" and residential[0].get("toLane") == "0"
assert len(net.find("edge[@id='27064186#0']").findall("lane")) == 1
value = {"schema": "astra.hamburg.525-reviewed-raw-smoke/v1", "status": "pass", "formal_result": False,
    "candidate_network_sha256": sha(network), "candidate_control_sha256": sha(candidate / "control.add.xml"),
    "reviewed_evidence_hashes": {str(p): sha(p) for p in paths}, "native_cases": cases, "vehicles_per_case": 16,
    "episodes": episodes, "original_review_required_verdicts_preserved": True,
    "scope": "Permit one complete fixed-demand diagnostic evaluation. Separate car-only and bicycle-only native response/braking/recovery episodes occur in different timing fixtures. This is narrow native ROW support, not isolated causal attribution or field SPaT/capacity/full-demand safety certification. No real count fit is asserted by the toy runs."}
target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "pass", "raw_native_cases": len(cases), "distinct_class_episodes": len(episodes), "binding_sha256": sha(target)}))
