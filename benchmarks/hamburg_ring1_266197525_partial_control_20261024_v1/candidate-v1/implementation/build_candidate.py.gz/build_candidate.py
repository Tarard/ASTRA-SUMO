"""Compile only the declared525 partial-control candidate; never drive vehicles."""

import json
from pathlib import Path

from astra_sumo.core.hamburg_266197525_partial_control import materialize_hamburg_266197525_partial_control


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    source = repo / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full/prepared"
    result = materialize_hamburg_266197525_partial_control(source_file=source / "network.net.xml", control_file=source / "control.add.xml",
        output_dir=root / "candidate-v1", netconvert_binary=repo / ".venv/Lib/site-packages/sumo/bin/netconvert.exe")
    print(json.dumps(result, ensure_ascii=False))
