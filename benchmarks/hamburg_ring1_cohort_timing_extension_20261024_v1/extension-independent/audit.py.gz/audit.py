"""Read the completed extension prefix and bind its actual input inventory."""

from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
CASE = ROOT / "extension"
SOURCE = ROOT.parent / "hamburg-causal-second-prefix-20261024-v1/advance-second900-126232"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    record = load(CASE / "record-result.json")
    assert record["status"] == "pass" and len(record["checks"]) == 20 and all(record["checks"].values())
    assert sha(CASE / "executed-run.py") == sha(ROOT / "run_prefix.py") == "a1cfe270dd3a024fdc725450cd3504553705c5db63497a8fa9a8312aedaee132"
    helpers = runpy.run_path(str(ROOT / "run_prefix.py"))
    helpers["check"](CASE)
    preflight, core = load(CASE / "preflight.json"), load(CASE / "core-result.json")
    assert not core["errors"] and core["inputs_unchanged"] and record["preflight_sha256"] == sha(CASE / "preflight.json")
    assert preflight["runner_sha256"] == sha(CASE / "executed-run.py")
    for mapping in [preflight["source_hashes"], preflight["binaries"], record["native_output_hashes"]]:
        assert all(sha(Path(p)) == h for p, h in mapping.items())
    assert all(sha(CASE / "prepared" / n) == h for n, h in preflight["prepared_hashes"].items())
    assert all(sha(CASE / "implementation" / n) == h for n, h in preflight["implementation_sha256"].items())
    assert all(sha(Path(r["path"])) == r["sha256"] for r in core["inputs"] + core["snapshots"])
    native = CASE / "native"
    raw = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=core["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(CASE / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        assert raw == json.load(handle)
    assert raw["reconciled"] and not raw["outside_periodic_intervals"]
    intents = {r["vehicle_id"]: r for r in load(CASE / "prepared/lane-intentions.json")["vehicles"]}
    frozen = {r.get("id") for r in ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle") if helpers["native_ms"](r.get("depart")) < 1800000}
    assert len(intents) == 8640 and len(frozen) == 901
    assert len(raw["passages"]) == 901 and {r["vehicle_id"] for r in raw["passages"]} == frozen
    assert max(Counter((r["vehicle_id"], r["detector_id"]) for r in raw["passages"]).values()) == 1
    assert all(r["detector_id"] == intents[r["vehicle_id"]]["field_id"] for r in raw["passages"])
    rows = audit_expected_to_e1_strict(read_csv_rows(ROOT / "prefix26.csv"), native / "field-counts.xml")
    assert len(rows) == 26 and all(r["diff_nVehContrib_minus_expected"] == 0 for r in rows)
    summary = helpers["summaries"](native / "summary.xml")
    source_summary = helpers["summaries"](SOURCE / "native/summary.xml")
    assert len(summary) == 18000 and float(summary[-1]["time"]) == 1799.9
    monitor, command = load(native / "stall-monitor.json"), load(native / "command.json")
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 1800 and monitor["library_completed"] and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"] and sha(Path(monitor["native_library"]["path"])) == monitor["native_library"]["sha256"]
    assert command["status"] == "pass" and command["returncode"] == 0
    assert not ET.parse(native / "collisions.xml").getroot().findall("collision") and not any(int(summary[-1][k]) for k in ["collisions", "teleports", "discarded"])
    trips = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
    assert {r.get("id") for r in trips} == frozen and len(trips) == int(summary[-1]["inserted"]) == 901
    assert all(0 <= float(r.get("depart")) <= 1800 and r.get("vaporized", "") in ({"", "end"} if float(r.get("arrival")) < 0 else {""}) for r in trips)
    coverage = load(CASE / "all182-coverage.json")
    assert len(coverage) == 182 and sum(r["measured_nVehContrib"] is None for r in coverage) == 156
    assert record["full130_metrics"] is None and record["remaining26_initial_metrics"] is None and record["combined182_metrics"] is None and not record["full130_calibration_acceptance"]
    first_difference = next((dict(index=i, source=a, extension=b) for i, (a, b) in enumerate(zip(source_summary, summary)) if a != b), None)
    report = dict(schema="astra.hamburg.cohort-extension-prefix-independent/v1", audit_status="pass", metrics26=record["prefix26_metrics"], measured_rows=rows, prefix_completion=summary[-1],
        input_scope=dict(requests=8640, frozen_first901=True, future_timing_edits=7739, shift126_requests=3253, shift90_requests=4486, changed_native_bins=379, actual294_rebuilt=True, global21OD_totals_preserved=True, initialization_requests=1989, main_requests=6651, same_q_claim=False),
        complete_unique_frozen901=True, repeated_fields=0, outside_primary=0, unknown_IDs=0, safe=True, checked_hashes=True, source_summary_equal=source_summary == summary, first_source_summary_difference=first_difference,
        measured_real_rows=26, unmeasured_real_rows=156, main130_metrics=None, remaining26_initial_metrics=None, full_calibration_acceptance=False,
        claim_boundary="Only0–1800s is measured for the new whole input. All26 real rows are exact, including all901 frozen requests. The379 changed OD-period cells are explicit. Later26 initialization and130 main rows remain unmeasured. Source summary differences from future loading are recorded, not used as a blanket failure. Any full run must reproduce this new input's own prefix.")
    save(OUT / "summary.json", report)
    paths = [Path(__file__), ROOT / "prefix26.csv"] + [CASE / n for n in ["record-result.json", "preflight.json", "executed-run.py", "scope-proof.json", "od-vector.json", "departure-proposals.json"]]
    save(OUT / "source-hashes.json", {str(p): sha(p) for p in paths})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(metrics26=report["metrics26"], source_summary_equal=report["source_summary_equal"], manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
