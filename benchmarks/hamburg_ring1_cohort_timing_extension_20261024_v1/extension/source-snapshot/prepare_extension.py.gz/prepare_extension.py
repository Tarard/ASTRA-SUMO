"""Prepare the one authorized cohort timing extension without running SUMO."""

from collections import Counter
from copy import deepcopy
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASE = ROOT / "extension"
SOURCE = REPO / "outputs/hamburg-causal-second-prefix-20261024-v1/advance-second900-126232"
AUDIT = REPO / "outputs/hamburg-causal-extension-feasibility-20261024-v1"
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
         "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json")
EARLY = {"hh_0119_Z_11_28853", "hh_0119_Z_12_31546", "hh_0119_Z_13_34018"}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ms(value):
    return math.floor(float(value) * 1000 + .5)


def main():
    assert not CASE.exists(), "Preserve prior preparations and native evidence."
    raw = {name: (SOURCE / "prepared" / name).read_bytes() for name in NAMES}
    record = json.loads((SOURCE / "record-result.json").read_bytes())
    assert record["status"] == "pass" and record["prefix26_metrics"]["TAE"] == 0 and all(record["checks"].values())
    source_root = ET.fromstring(raw["demand.rou.xml"])
    old = {v.get("id"): v for v in source_root.findall("vehicle")}
    order = {identity: index for index, identity in enumerate(old)}
    metadata = json.loads(raw["lane-intentions.json"])
    old_metadata = {r["vehicle_id"]: deepcopy(r) for r in metadata["vehicles"]}
    assert len(old) == len(old_metadata) == 8640 and old.keys() == old_metadata.keys()
    proposals = []
    for identity, vehicle in old.items():
        depart = float(vehicle.get("depart"))
        if ms(depart) < 1800000:
            continue
        shift = 126 if old_metadata[identity]["field_id"] in EARLY else 90
        proposed = depart - shift
        assert ms(proposed) >= 1800000
        assert ms(depart) - ms(proposed) == shift * 1000
        assert ms(depart) // 900000 - ms(proposed) // 900000 in (0, 1)
        proposals.append({"vehicle_id": identity, "source_depart_s": depart, "proposed_depart_s": proposed,
                          "shift_s": -shift, "field_id": old_metadata[identity]["field_id"]})
    chosen = {r["vehicle_id"] for r in proposals}
    assert len(chosen) == len(proposals) == 7739
    assert Counter(r["shift_s"] for r in proposals) == {-126: 3253, -90: 4486}
    applied = apply_native_count_retiming(source_root, proposals)
    generated = {v.get("id"): v for v in applied.findall("vehicle")}
    sequence = sorted(generated, key=lambda identity: (float(generated[identity].get("depart")), order[identity]))
    matches = list(re.finditer(rb"<vehicle\b[^>]*>.*?</vehicle>", raw["demand.rou.xml"], flags=re.S))
    blocks = {ET.fromstring(m.group()).get("id"): m.group() for m in matches}
    assert len(blocks) == len(matches) == 8640
    assert all(not raw["demand.rou.xml"][a.end():b.start()].strip() for a, b in zip(matches, matches[1:]))
    new_blocks = dict(blocks)
    for identity in chosen:
        original = b'depart="' + old[identity].get("depart").encode() + b'"'
        replacement = b'depart="' + generated[identity].get("depart").encode() + b'"'
        assert new_blocks[identity].count(original) == 1
        new_blocks[identity] = new_blocks[identity].replace(original, replacement, 1)
    prefix, suffix = raw["demand.rou.xml"][:matches[0].start()], raw["demand.rou.xml"][matches[-1].end():]
    demand = prefix + b"".join(new_blocks[i] for i in sequence) + suffix
    new = {v.get("id"): v for v in ET.fromstring(demand).findall("vehicle")}
    accepted = [i for i in old if i not in chosen]
    assert len(accepted) == 901 and sequence[:901] == accepted
    assert all(blocks[i] == new_blocks[i] for i in accepted)
    assert demand.startswith(prefix + b"".join(blocks[i] for i in accepted))
    pairs = sorted({(v.find("route").get("edges").split()[0], v.find("route").get("edges").split()[-1]) for v in old.values()})
    assert len(pairs) == 21
    old_q, new_q = [0] * 294, [0] * 294
    crossings, changes = [], []
    old_stock, new_stock = Counter(), Counter()
    for row in metadata["vehicles"]:
        identity = row["vehicle_id"]
        before, after = old[identity], new[identity]
        restored = deepcopy(after)
        restored.set("depart", before.get("depart"))
        assert ET.tostring(restored) == ET.tostring(before)
        route = before.find("route").get("edges").split()
        pair = pairs.index((route[0], route[-1]))
        h0, h1 = ms(before.get("depart")) // 900000, ms(after.get("depart")) // 900000
        c0, c1 = h0 * 21 + pair, h1 * 21 + pair
        assert c0 == row["od_cell"] and 0 <= c1 < 294
        old_q[c0] += 1
        new_q[c1] += 1
        old_stock[row["field_id"], h0] += 1
        new_stock[row["field_id"], h1] += 1
        if identity in chosen:
            row.update(od_cell=c1, depart_s=float(after.get("depart")))
            assert {k: v for k, v in row.items() if k not in {"od_cell", "depart_s"}} == {k: v for k, v in old_metadata[identity].items() if k not in {"od_cell", "depart_s"}}
            change = {"vehicle_id": identity, "field_id": row["field_id"], "source_depart_s": before.get("depart"),
                      "candidate_depart_s": after.get("depart"), "old_native_bin": h0, "new_native_bin": h1,
                      "old_od_cell": c0, "new_od_cell": c1}
            changes.append(change)
            if c0 != c1:
                crossings.append(change)
        else:
            assert row == old_metadata[identity] and ET.tostring(before) == ET.tostring(after)
    assert len(changes) == 7739 and len(crossings) == 379 and sum(old_q) == sum(new_q) == 8640
    assert all(old_q[j] == new_q[j] for j in range(42))
    assert all(sum(old_q[j::21]) == sum(new_q[j::21]) for j in range(21))
    expected_crossings = {r["vehicle_id"] for r in csv.DictReader((AUDIT / "crossing379.csv").open(encoding="utf-8", newline=""))}
    assert {r["vehicle_id"] for r in crossings} == expected_crossings
    targets = []
    for name in ("initialization-counts.csv", "expected-counts.csv"):
        targets.extend(csv.DictReader(raw[name].decode("utf-8-sig").splitlines()))
    stocks = [{"field_id": t["detector_id"], "native_departure_bin": int(float(t["begin"]) // 900),
               "begin_s": t["begin"], "end_s": t["end"], "source_requested_stock": old_stock[t["detector_id"], int(float(t["begin"]) // 900)],
               "candidate_requested_stock": new_stock[t["detector_id"], int(float(t["begin"]) // 900)],
               "real_passage_target": int(t["expected_total"])} for t in targets]
    assert len(stocks) == 182
    for field in {r["field_id"] for r in stocks}:
        assert sum(n for (f, _), n in old_stock.items() if f == field) == sum(n for (f, _), n in new_stock.items() if f == field)
    initial = sum(n for (_, h), n in new_stock.items() if h < 4)
    assert initial == 1989
    prep = CASE / "prepared"
    prep.mkdir(parents=True)
    for name, value in raw.items():
        (prep / name).write_bytes(value)
    (prep / "demand.rou.xml").write_bytes(demand)
    save(prep / "lane-intentions.json", metadata)
    scenario = json.loads(raw["scenario.json"])
    scenario.update(status="conditional_timing_extension_prepared", demand_sha256=sha(demand), formal_result=False, exact_count_fit=False,
        initialization_vehicles=initial, main_vehicles=8640 - initial,
        demand_prior="Preserve all8640 identities, routes, stops and field intentions and21 globalOD totals. Preserve accepted first901 requests. Retiming the remaining7739 requests moves379 actual departure cells back one bin. No quantity repair or quantile resampling.",
        time_prior="Remaining3253 Z11/Z12/Z13 requests advance126s and other4486 advance90s. All new requests remain at or after1800. Initialization/main request descriptors now count actual native departure times1989/6651; the real1953/6687 passage targets are unchanged.",
        claim_boundary="One conditional cohort timing-extension hypothesis. Source0–1800 has26 exact observations, but its ancestor full-window branch was rejected. The overall best reference remains separate. Require the exact new full input to retain26 exact/safe prefix results before any full evaluation. No new count fit, field OD or safety result is claimed.")
    save(prep / "scenario.json", scenario)
    save(CASE / "departure-proposals.json", proposals)
    save(CASE / "od-vector.json", {"values": new_q, "integer_counts": new_q, "vehicle_count": 8640,
        "source_vector": old_q, "inventory_unchanged": False,
        "ordering": "native departure bin then lexicographic actual origin/destination; index=bin*21+OD", "new_OD_generation": False})
    save(CASE / "cells294.json", {"cells": [{"index": h * 21 + j, "origin": a, "destination": b,
          "begin_s": h * 900, "end_s": (h + 1) * 900} for h in range(14) for j, (a, b) in enumerate(pairs)]})
    table(CASE / "crossing379.csv", crossings)
    table(CASE / "departure-changes7739.csv", changes)
    table(CASE / "field-departure-stocks182.csv", stocks)
    deltas = [{"od_cell": i, "origin": pairs[i % 21][0], "destination": pairs[i % 21][1], "begin_s": i // 21 * 900,
               "source_count": a, "candidate_count": b, "delta": b - a} for i, (a, b) in enumerate(zip(old_q, new_q)) if a != b]
    table(CASE / "od-cell-deltas.csv", deltas)
    request_path = SOURCE / "native/native-request.json"
    request = json.loads(request_path.read_bytes())
    driver = {k: request[k] for k in ("backend", "end_s", "all_stopped_timeout_s", "junction_body_hold", "junction_body_hold_nodes")}
    command = request["command"]
    driver.update({k: command[command.index(flag) + 1] for k, flag in (("step_length_s", "--step-length"), ("seed", "--seed"), ("precision", "--precision"))})
    driver.update(authorized_prefix_end_s=1800, planned_full_end_s=14400)
    helper = REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_departure_probe.py"
    paths = [SOURCE / "prepared" / n for n in NAMES] + [SOURCE / "record-result.json", request_path, helper,
             Path(__file__).resolve(), CASE / "departure-proposals.json"]
    paths += [AUDIT / name for name in ("manifest.json", "summary.json", "crossing379.csv")]
    source_hashes = {str(p): sha(p.read_bytes()) for p in paths}
    snapshot = CASE / "source-snapshot"
    snapshot.mkdir()
    for name, value in raw.items():
        (snapshot / (name + ".gz")).write_bytes(gzip.compress(value, mtime=0))
    (snapshot / "prepare_extension.py").write_bytes(Path(__file__).read_bytes())
    for name, path in [("source-prefix-record-result.json", SOURCE / "record-result.json"), ("source-native-request.json", request_path),
                       ("hamburg_departure_probe.py", helper), ("feasibility-manifest.json", AUDIT / "manifest.json"),
                       ("feasibility-summary.json", AUDIT / "summary.json"), ("feasibility-crossing379.csv", AUDIT / "crossing379.csv")]:
        (snapshot / (name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    proof = {"status": "pass", "formal_result": False, "native_runs": 0, "N": 8640,
        "source_hashes": source_hashes, "prepared_hashes": {n: sha((prep / n).read_bytes()) for n in NAMES},
        "original_driver_scope": driver, "actual_changes": {"departures": 7739, "native_shifts_s": {-126: 3253, -90: 4486},
            "accepted_first901_raw_XML_exact": True, "native_bin_crossings": 379, "maximum_bins_crossed": 1,
            "metadata_depart_s_rows": 7739, "metadata_od_cell_changes": 379, "changed_actual_OD_cells": len(deltas),
            "source_actual_initial_main_requests": [1953, 6687], "candidate_actual_initial_main_requests": [initial, 8640 - initial]},
        "changes": proposals, "checks": {"all8640_IDs_and_global21OD_totals_preserved": True,
            "all_routes_stops_fields_vtypes_non_depart_attrs_preserved": True, "all13_field_totals_preserved": True,
            "first901_raw_XML_and_order_metadata_preserved": True, "new7739_times_at_or_after1800": True,
            "only379_previous_single_bin_crossings": True, "actual294_OD_inventory_and_metadata_rebuilt": True,
            "network_control_loops_and_all_real_targets_rawbytes_unchanged": all((prep / n).read_bytes() == raw[n] for n in NAMES if n not in {"demand.rou.xml", "lane-intentions.json", "scenario.json"})},
        "claim_boundary": "Preparation only. Departure stocks are not passage-bin observations. The allowed379 crossings change OD-period inventory; same-q is not claimed. No q repair, route/field/driver/control change, full zero-fit proof, native execution or promotion of the rejected search branch."}
    assert all(proof["checks"].values())
    save(CASE / "scope-proof.json", proof)
    save(CASE / "selfchecks.json", {"status": "pass", "native_runs": 0, "selected7739": True, "first901_exact": True,
        "crossings": 379, "actual_cells_changed": len(deltas), "OD_vector_L1": sum(abs(a - b) for a, b in zip(old_q, new_q)),
        "minimum_new_selected_depart_s": min(float(new[i].get("depart")) for i in chosen),
        "new_zero_OD_cells": sum(v == 0 for v in new_q), "prepared_hashes": proof["prepared_hashes"]})
    print(json.dumps({"status": "pass", "prepared": str(prep), "crossings": 379, "changed_actual_cells": len(deltas),
                      "demand_sha256": sha(demand), "scope_sha256": sha((CASE / "scope-proof.json").read_bytes())}))


if __name__ == "__main__":
    main()
