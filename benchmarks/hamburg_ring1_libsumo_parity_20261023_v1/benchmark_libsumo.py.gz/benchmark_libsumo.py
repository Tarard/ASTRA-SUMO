"""Compare the native library against the frozen socket baseline, without changing traffic inputs."""
import hashlib
import json
from pathlib import Path
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od

root = Path(__file__).resolve().parent
source = root / 'paired-full'
target = root / 'libsumo-baseline'
start = time.perf_counter()
values = json.loads((source / 'od-vector.json').read_bytes())['values']
result = measure_hamburg_od(prepared_dir=root / 'paired-prepared', values=values,
    output_dir=target, sumo_binary=Path(sumo.__file__).parent / 'bin/sumo.exe', backend='libsumo')
elapsed = time.perf_counter() - start
checks = {}
for name in ('network.net.xml', 'demand.rou.xml', 'source-e1.add.xml', 'expected-counts.csv', 'signal-programs.add.xml', 'lane-intentions.json'):
    checks['input:' + name] = (source / 'native' / name).read_bytes() == (target / 'native' / name).read_bytes()
for name, tag in (('field-counts.xml', 'interval'), ('vehicle-routes.xml', 'vehicle'), ('tripinfo.xml', 'tripinfo'), ('collisions.xml', 'collision')):
    def rows(path):
        return [ET.tostring(row) for row in ET.parse(path).getroot().findall(tag)]
    checks['traffic:' + name] = rows(source / 'native' / name) == rows(target / 'native' / name)
checks['all130'] = (source / 'native/field-comparison.csv').read_bytes() == (target / 'native/field-comparison.csv').read_bytes()
checks['all40'] = (source / 'station-comparison.csv').read_bytes() == (target / 'station-comparison.csv').read_bytes()
before_monitor = json.loads((source / 'native/stall-monitor.json').read_bytes())
after_monitor = json.loads((target / 'native/stall-monitor.json').read_bytes())
checks['lane_hold'] = before_monitor['lane_section_hold'] == after_monitor['lane_section_hold']
checks['completion'] = result == json.loads((source / 'evaluation.json').read_bytes())
record = {'checks': checks, 'correspondence': all(checks.values()), 'elapsed_seconds': elapsed,
    'evaluation': result, 'driver_sha256': {name: hashlib.sha256((Path.cwd() / 'plugins/astra-sumo/src/astra_sumo/core' / name).read_bytes()).hexdigest()
        for name in ('simulation_stall.py', 'detector_demand_replay.py', 'lane_section_hold.py', 'hamburg_od_spsa.py')},
    'formal_calibration': False}
(target / 'backend-correspondence.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2), flush=True)
assert all(checks.values()), checks
