"""Run five sparse vehicles, not the paired 8640-request experiment."""
from copy import deepcopy
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.artifact_io import write_json_atomic
from astra_sumo.core.candidate_contracts import file_sha256
from astra_sumo.core.command_runner import run_command


root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
prepared = out / 'prepared'
probe = out / 'sparse-probe'
probe.mkdir(exist_ok=False)
demand = ET.parse(prepared / 'demand.rou.xml').getroot()
intent = json.loads((prepared / 'lane-intentions.json').read_bytes())
fields = {r['vehicle_id']: r['field_id'] for r in intent['vehicles']}
wanted = {'hh_0119_Z_15_29375', 'hh_0119_Z_4_29437', 'hh_0119_Z_5_30494'}
routes = ET.Element('routes')
routes.extend(deepcopy(r) for r in demand if r.tag != 'vehicle')
vehicles = []
for vehicle in demand.findall('vehicle'):
    if fields[vehicle.get('id')] in wanted:
        wanted.remove(fields[vehicle.get('id')])
        vehicles.append(deepcopy(vehicle))
assert not wanted and len(vehicles) == 3
tail = '141050975 141050980#0 141050980#1 603103444 73474895 1108564798#0 1108564798#1 24483197 199500676'
for lane in (2, 3):
    v = ET.Element('vehicle', id=f'primary_lane_{lane}', depart=str(10 * lane), departLane=str(lane),
                   type='readme_lane_intent', departPos='5.1', departSpeed='max')
    ET.SubElement(v, 'route', edges=tail)
    vehicles.append(v)
routes.extend(sorted(vehicles, key=lambda v: float(v.get('depart'))))
route_file = probe / 'five-vehicles.rou.xml'
ET.ElementTree(routes).write(route_file, encoding='utf-8', xml_declaration=True)
binary = root / '.venv/Lib/site-packages/sumo/bin/sumo.exe'
version = run_command([str(binary), '--version'], cwd=probe)
command = [str(binary), '-n', str(prepared / 'network.net.xml'), '-r', str(route_file),
    '-a', str(prepared / 'control.add.xml'), '--end', '1800', '--step-length', '0.1', '--seed', '104',
    '--time-to-teleport', '-1', '--collision.check-junctions', 'true', '--no-step-log', 'true',
    '--duration-log.statistics', 'true', '--precision', '12', '--vehroute-output.exit-times', 'true',
    '--vehroute-output.write-unfinished', 'true', '--tripinfo-output.write-unfinished', 'true',
    '--vehroute-output', str(probe / 'vehicle-routes.xml'), '--tripinfo-output', str(probe / 'tripinfo.xml'),
    '--summary-output', str(probe / 'summary.xml'), '--collision-output', str(probe / 'collisions.xml'),
    '--fcd-output', str(probe / 'fcd.xml'), '--error-log', str(probe / 'sumo-errors.log')]
run = run_command(command, cwd=probe, timeout_seconds=60)
write_json_atomic(probe / 'command.json', run.to_dict())
trips = ET.parse(probe / 'tripinfo.xml').getroot().findall('tripinfo')
summary = ET.parse(probe / 'summary.xml').getroot().findall('step')[-1].attrib
collisions = ET.parse(probe / 'collisions.xml').getroot().findall('collision')
passed = {}
for v in ET.parse(probe / 'vehicle-routes.xml').getroot().findall('vehicle'):
    es = v.find('route').get('edges').split()
    ts = list(map(float, v.find('route').get('exitTimes').split()))
    passed[v.get('id')] = all(e in es and ts[es.index(e)] >= 0 for e in ('1108564798#0', '1108564798#1', '24483197'))
seen = set()
for _, v in ET.iterparse(probe / 'fcd.xml', events=('end',)):
    if v.tag == 'vehicle' and v.get('id', '').startswith('primary_lane_'):
        seen.add(v.get('lane'))
    v.clear()
checks = {'native_command_passed': run.status == 'pass' and run.returncode == 0,
    'all_five_arrived': len(trips) == 5 and all(float(t.get('arrival')) >= 0 for t in trips),
    'zero_collisions': not collisions, 'zero_teleports': int(summary['teleports']) == 0,
    'all_five_traversed_restored_branch': len(passed) == 5 and all(passed.values()),
    'both_source_primary_lanes_observed': {'1108564798#0_1', '1108564798#0_2'} <= seen,
    'none_running_or_waiting': int(summary['running']) == int(summary['waiting']) == 0}
record = {'status': 'pass' if all(checks.values()) else 'fail', 'formal_result': False,
    'checks': checks, 'summary': summary, 'source_route_requests': [v.get('id') for v in vehicles[:3]],
    'vehicle_count': 5, 'native_version': version.to_dict(), 'command': run.to_dict(),
    'inputs': {str(p): file_sha256(p) for p in (prepared/'network.net.xml', prepared/'control.add.xml', route_file)},
    'claim_boundary': 'Sparse source-route and branch-lane check only. The full 8640-request fit and safety remain unmeasured.'}
write_json_atomic(probe / 'probe-result.json', record)
print(json.dumps({'status': record['status'], 'checks': checks, 'summary': summary}))
assert all(checks.values()), checks
