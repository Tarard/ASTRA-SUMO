"""Measure the source-backed main-road restoration without regenerating routes."""
import csv
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement

repo=Path.cwd();root=Path(__file__).resolve().parent;prepared=root/'prepared';out=root/'evaluation';out.mkdir()
assert Path(sys.executable).resolve()==(repo/'.venv/Scripts/python.exe').resolve()
assert all(version(n)=='1.27.1' for n in ('eclipse-sumo','traci','sumolib','libsumo'))
proposal=json.loads((root/'repair-proposal.json').read_bytes());assert proposal['source_unchanged'] and all(proposal['preservation']['checks'].values())
for name in ('demand.rou.xml','lane-intentions.json'):shutil.copyfile(prepared/name,out/name)
prior=repo/'outputs/hamburg-directed-backlog-20261023-v1/original-seed-restored-evaluation'
vector=json.loads((prior/'od-vector.json').read_bytes());vector['generation']='Same OD counts, identities and departures; only source-backed Alsterglacis post-detector branch restored.'
(out/'od-vector.json').write_text(json.dumps(vector,indent=2)+'\n',encoding='utf8')
preflight={'network_sha256':hashlib.sha256((prepared/'network.net.xml').read_bytes()).hexdigest(),
    'demand_sha256':hashlib.sha256((prepared/'demand.rou.xml').read_bytes()).hexdigest(),
    'control_sha256':hashlib.sha256((prepared/'control.add.xml').read_bytes()).hexdigest(),
    'driver_sha256':{n:hashlib.sha256((repo/'plugins/astra-sumo/src/astra_sumo/core'/n).read_bytes()).hexdigest() for n in ('simulation_stall.py','detector_demand_replay.py','lane_section_hold.py','hamburg_od_spsa.py','hamburg_primary_branch_repair.py')},
    'versions':{n:version(n) for n in ('eclipse-sumo','traci','sumolib','libsumo')},'formal_result':False}
(root/'full-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf8');start=time.perf_counter()
native=run_point_detector_demand(net_file=prepared/'network.net.xml',route_file=prepared/'demand.rou.xml',e1_additional_file=prepared/'field-loops.add.xml',
    expected_counts_csv=prepared/'expected-counts.csv',output_dir=out/'native',end_s=14400,timeout_seconds=4800,
    sumo_binary=str(Path(sumo.__file__).parent/'bin/sumo.exe'),signal_program_file=prepared/'control.add.xml',lane_intentions_file=prepared/'lane-intentions.json',
    junction_body_hold=True,junction_body_hold_nodes=_body_hold_nodes(prepared),seed=104,backend='libsumo')
result=summarize_hamburg_od_measurement(prepared_dir=prepared,proposal_dir=out,native=native)
counts={(x.get('id'),float(x.get('begin')),float(x.get('end'))):int(x.get('nVehContrib')) for x in ET.parse(out/'native/field-counts.xml').getroot()};rows=[]
for name in ('initialization-counts.csv','expected-counts.csv'):
    for x in csv.DictReader((prepared/name).open()):
        value=counts[x['detector_id'],float(x['begin']),float(x['end'])];rows.append({**x,'measured_nVehContrib':value,'residual':value-int(x['expected_total'])})
with (out/'all182-comparison.csv').open('w',encoding='utf8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
before=json.loads((prior/'evaluation.json').read_bytes());safe=not any(result['completion'][k] for k in ('collisions','teleports','discarded'));all_error=sum(abs(x['residual']) for x in rows)
verdict={'status':'diagnostic_improvement' if safe and result['MAE']<before['MAE'] and result['completion']['waiting']<before['completion']['waiting'] else 'rejected',
    'safe':safe,'stage_goal_met':safe and result['MAE']<=10 and result['completion']['waiting']<=690,
    'formal_result':False,'before':before,'after':result,'all182_TAE':all_error,'elapsed_seconds':time.perf_counter()-start,
    'claim_boundary':'Paired8640 requests. Source-backed two-road restoration and necessary post-detector branch replacement only. No observed route-split share, actual field SPaT or zero-residual calibration is established by this diagnostic run.'}
(root/'full-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n',encoding='utf8');print(json.dumps(verdict,indent=2),flush=True)
