"""Test one 27-second merge handover change with the original fixed OD."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od
from astra_sumo.core.hamburg_spillback_repair import extend_merge_tail

repo=Path.cwd();root=Path(__file__).resolve().parent;parent=root/'merge-evaluation';prepared=root/'tail27-prepared'
shutil.copytree(root/'merge-prepared',prepared)
before=ET.parse(prepared/'control.add.xml').getroot();after=extend_merge_tail(before,27)
assert [a.get('id') for a,b in zip(before,after) if ET.tostring(a)!=ET.tostring(b)]==['GS_266199063']
ET.ElementTree(after).write(prepared/'control.add.xml',encoding='utf8',xml_declaration=True)
scenario=json.loads((prepared/'scenario.json').read_bytes());scenario.update(control_variant='merge_tail_extended_27_seconds',
    control_sha256=hashlib.sha256((prepared/'control.add.xml').read_bytes()).hexdigest(),
    control_assumptions=scenario.get('control_assumptions','')+' Extend the second-source green tail by 27 s and shorten the first-source green by 27 s. Retain the 90 s cycle, every yellow and all-red duration. This is a declared single-variable model experiment, not field SPaT.')
(prepared/'scenario.json').write_text(json.dumps(scenario,indent=2)+'\n',encoding='utf8')
preflight={'changed_from_parent':['GS_266199063'],'extension_s':27,'first_source_green_window_s':[39,73],
    'second_source_green_window_s':[80,123],'cycle_s':90,'all_clearance_durations_retained':True,'formal_result':False,
    'driver_sha256':{n:hashlib.sha256((repo/'plugins/astra-sumo/src/astra_sumo/core'/n).read_bytes()).hexdigest() for n in ('simulation_stall.py','detector_demand_replay.py','lane_section_hold.py','hamburg_od_spsa.py','hamburg_spillback_repair.py')}}
(root/'tail27-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf8')
values=json.loads((parent/'od-vector.json').read_bytes())['values'];start=time.perf_counter()
result=measure_hamburg_od(prepared_dir=prepared,values=values,output_dir=root/'tail27-evaluation',sumo_binary=Path(sumo.__file__).parent/'bin/sumo.exe',backend='libsumo')
for name in ('demand.rou.xml','lane-intentions.json'):
    assert (parent/name).read_bytes()==(root/'tail27-evaluation'/name).read_bytes()
counts={(x.get('id'),float(x.get('begin')),float(x.get('end'))):int(x.get('nVehContrib')) for x in ET.parse(root/'tail27-evaluation/native/field-counts.xml').getroot()}
rows=[]
for name in ('initialization-counts.csv','expected-counts.csv'):
    for x in csv.DictReader((prepared/name).open()):
        count=counts[x['detector_id'],float(x['begin']),float(x['end'])];rows.append({**x,'measured_nVehContrib':count,'residual':count-int(x['expected_total'])})
with (root/'tail27-evaluation/all182-comparison.csv').open('w',encoding='utf8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
before_result=json.loads((parent/'evaluation.json').read_bytes());safe=not any(result['completion'][k] for k in ('collisions','teleports','discarded'));all_error=sum(abs(x['residual']) for x in rows)
improved=safe and result['MAE']<before_result['MAE'] and all_error<=1883 and result['completion']['waiting']<=before_result['completion']['waiting'] and sum(result['completion'][k] for k in ('waiting','running'))<=sum(before_result['completion'][k] for k in ('waiting','running'))
verdict={'status':'diagnostic_improvement' if improved else 'rejected','safe':safe,'milestone_met':safe and result['MAE']<=10 and result['completion']['waiting']<=690,
    'formal_result':False,'before':before_result,'after':result,'after_all182_TAE':all_error,'elapsed_seconds':time.perf_counter()-start,
    'claim_boundary':'One handover change only. Fixed OD, vehicle requests, network and driver. All 182 real values reported; 130 main values define the stage target. No field SPaT or exact calibration claim.'}
(root/'tail27-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n',encoding='utf8');print(json.dumps(verdict,indent=2),flush=True)
