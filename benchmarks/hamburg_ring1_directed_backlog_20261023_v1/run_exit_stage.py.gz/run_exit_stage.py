"""Test removal of the source-proven deleted service after the merge experiment."""
from importlib.metadata import version
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od
from astra_sumo.core.hamburg_spillback_repair import remove_deleted_service_stage

repo = Path.cwd()
out = Path(__file__).resolve().parent
parent = out / 'merge-evaluation'
baseline = repo / 'outputs/lsa119-collision-diagnosis-20261023/libsumo-baseline'
prepared = out / 'exit-stage-prepared'
assert Path(sys.executable).resolve() == (repo / '.venv/Scripts/python.exe').resolve()
assert all(version(n) == '1.27.1' for n in ('eclipse-sumo','traci','sumolib','libsumo'))
assert not any(json.loads((parent / 'evaluation.json').read_bytes())['completion'][k] for k in ('collisions','teleports','discarded'))
shutil.copytree(out / 'merge-prepared', prepared)
control = ET.parse(prepared / 'control.add.xml').getroot()
original_path = repo / 'benchmarks/hamburg_ring1_primary_entry_full_20261022_v1/inputs/control.add.xml'
original = ET.parse(original_path).getroot()
identity = '266197525'
current = control.find(f"tlLogic[@id='{identity}']")
candidate, removed = remove_deleted_service_stage(original.find(f"tlLogic[@id='{identity}']"), current)
assert [x['source_phase_index'] for x in removed] == [2]
assert removed[0]['source_state'] == 'rrGGGrrr' and removed[0]['projected_state'] == 'rrrrrr' and removed[0]['duration_s'] == 27
before = {p.get('id'): ET.tostring(p) for p in control}
position = list(control).index(current)
control.remove(current)
control.insert(position, candidate)
assert [key for key in before if before[key] != ET.tostring(control.find(f"tlLogic[@id='{key}']"))] == [identity]
ET.ElementTree(control).write(prepared / 'control.add.xml', encoding='utf-8', xml_declaration=True)
scenario = json.loads((prepared / 'scenario.json').read_bytes())
scenario.update(control_variant='coordinated_merge_with_deleted_service_removed', control_sha256=hashlib.sha256((prepared / 'control.add.xml').read_bytes()).hexdigest(),
    control_assumptions=scenario.get('control_assumptions','') + ' At 266197525 remove only the projected 27-second phase-2 service whose source green links were deleted by pruning. Retain all original yellow and all-red clearance. No real field SPaT claim.')
(prepared / 'scenario.json').write_text(json.dumps(scenario,indent=2)+'\n',encoding='utf-8')
protected = {name:hashlib.sha256((prepared/name).read_bytes()).hexdigest() for name in ('network.net.xml','field-loops.add.xml','expected-counts.csv','od-model.json')}
assert all(sha==hashlib.sha256((out/'merge-prepared'/name).read_bytes()).hexdigest() for name,sha in protected.items())
preflight = {'changed_from_parent':[identity],'source_control_sha256':hashlib.sha256(original_path.read_bytes()).hexdigest(),
    'removed_stages':removed,'protected_sha256':protected,'source_parent_status':'rejected_due_to_maximum_error_increase',
    'formal_result':False,'backend':'libsumo'}
(out/'exit-stage-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf-8')
values=json.loads((baseline/'od-vector.json').read_bytes())['values'];start=time.perf_counter()
result=measure_hamburg_od(prepared_dir=prepared,values=values,output_dir=out/'exit-stage-evaluation',
    sumo_binary=Path(sumo.__file__).parent/'bin/sumo.exe',backend='libsumo')
for name in ('demand.rou.xml','lane-intentions.json'):
    assert (baseline/name).read_bytes()==(out/'exit-stage-evaluation'/name).read_bytes()
before=json.loads((baseline/'evaluation.json').read_bytes()); safe=not any(result['completion'][k] for k in ('collisions','teleports','discarded'))
improved=safe and result['MAE']<before['MAE'] and result['max_abs_error']<=before['max_abs_error'] and sum(result['completion'][k] for k in ('waiting','running'))<sum(before['completion'][k] for k in ('waiting','running'))
milestone=safe and result['MAE']<=10 and result['completion']['waiting']<=690
verdict={'status':'diagnostic_improvement' if improved else 'rejected','milestone_met':milestone,'safe':safe,'formal_result':False,
    'before':before,'parent':json.loads((parent/'evaluation.json').read_bytes()),'after':result,'elapsed_seconds':time.perf_counter()-start,
    'claim_boundary':'Second sequential single-controller intervention on an unpromoted diagnostic parent. Demand, network, true counts and driver unchanged. All 130 native values retained. No actual field signal timing is established.'}
(out/'exit-stage-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n',encoding='utf-8'); print(json.dumps(verdict,indent=2),flush=True)
