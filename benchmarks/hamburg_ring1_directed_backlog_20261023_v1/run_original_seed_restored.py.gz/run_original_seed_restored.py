"""Restore the true-count integer seed instead of a diagnostic SPSA perturbation."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import shutil
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od, write_hamburg_od_demand

repo=Path.cwd();root=Path(__file__).resolve().parent;prepared=root/'original-seed-restored-prepared'
shutil.copytree(root/'merge-prepared',prepared)
model=json.loads((prepared/'od-model.json').read_bytes());values=[x['initial_flow'] for x in model['cells']]
assert sum(values)==8640 and values==[len(x['templates']) for x in model['cells']]
preflight_demand=write_hamburg_od_demand(model_file=prepared/'od-model.json',values=values,output_dir=root/'original-seed-restored-preview')
intentions=json.loads((preflight_demand/'lane-intentions.json').read_bytes())['vehicles'];requested=Counter(x['field_id'] for x in intentions);expected=Counter()
for name in ('initialization-counts.csv','expected-counts.csv'):
    for row in csv.DictReader((prepared/name).open()):expected[row['detector_id']]+=int(row['expected_total'])
assert requested==expected,(requested,expected)
(root/'original-seed-restored-preflight.json').write_text(json.dumps({'vehicle_count':8640,'field_request_totals':dict(requested),'all182_expected_field_totals':dict(expected),
    'integer_source_seed_matches_every_field_total':True,'control_parent':'merge','true_observations_unchanged':True,
    'network_sha256':hashlib.sha256((prepared/'network.net.xml').read_bytes()).hexdigest(),
    'control_sha256':hashlib.sha256((prepared/'control.add.xml').read_bytes()).hexdigest(),'formal_result':False},indent=2)+'\n',encoding='utf8')
start=time.perf_counter();result=measure_hamburg_od(prepared_dir=prepared,values=values,output_dir=root/'original-seed-restored-evaluation',sumo_binary=Path(sumo.__file__).parent/'bin/sumo.exe',backend='libsumo')
assert (preflight_demand/'demand.rou.xml').read_bytes()==(root/'original-seed-restored-evaluation/demand.rou.xml').read_bytes()
counts={(x.get('id'),float(x.get('begin')),float(x.get('end'))):int(x.get('nVehContrib')) for x in ET.parse(root/'original-seed-restored-evaluation/native/field-counts.xml').getroot()};rows=[]
for name in ('initialization-counts.csv','expected-counts.csv'):
    for x in csv.DictReader((prepared/name).open()):
        count=counts[x['detector_id'],float(x['begin']),float(x['end'])];rows.append({**x,'measured_nVehContrib':count,'residual':count-int(x['expected_total'])})
with (root/'original-seed-restored-evaluation/all182-comparison.csv').open('w',encoding='utf8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
safe=not any(result['completion'][k] for k in ('collisions','teleports','discarded'));all_error=sum(abs(x['residual']) for x in rows)
before=json.loads((root/'merge-evaluation/evaluation.json').read_bytes());improved=safe and result['MAE']<before['MAE'] and all_error<=1883 and result['completion']['waiting']<=690
verdict={'status':'diagnostic_improvement' if improved else 'rejected','safe':safe,'milestone_met':safe and result['MAE']<=10 and result['completion']['waiting']<=690,
    'formal_result':False,'before':before,'after':result,'after_all182_TAE':all_error,'elapsed_seconds':time.perf_counter()-start,
    'claim_boundary':'Original field-count integer seed restored, rather than the SPSA plus perturbation. Vehicle populations differ by37 requests, so arrived totals are not fixed-demand performance evidence. All real observations retained; native fit and completion remain required.'}
(root/'original-seed-restored-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n',encoding='utf8');print(json.dumps(verdict,indent=2),flush=True)
