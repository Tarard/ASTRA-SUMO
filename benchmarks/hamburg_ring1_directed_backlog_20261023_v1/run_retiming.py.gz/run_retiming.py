"""Apply one bounded identity-specific correction using all 182 real observations."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import shutil
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.native_temporal_feedback import propose_native_count_retiming

repo=Path.cwd();out=Path(__file__).resolve().parent;parent=out/'merge-evaluation';prepared=out/'retiming-prepared';evaluation=out/'retiming-evaluation'
shutil.copytree(out/'merge-prepared',prepared);evaluation.mkdir()
routes=ET.parse(parent/'demand.rou.xml').getroot();intentions=json.loads((parent/'lane-intentions.json').read_bytes());intent={x['vehicle_id']:x for x in intentions['vehicles']}
requests=[{'vehicle_id':v.get('id'),'detector_id':intent[v.get('id')]['field_id'],'requested_depart_s':float(v.get('depart'))} for v in routes.findall('vehicle')]
passages=json.loads((out/'merge-native-passages.json').read_bytes());assert passages['reconciled']
counts={(x.get('id'),float(x.get('begin')),float(x.get('end'))):int(x.get('nVehContrib')) for x in ET.parse(parent/'native/field-counts.xml').getroot()}
targets=[]
for name in ('initialization-counts.csv','expected-counts.csv'):
    for x in csv.DictReader((prepared/name).open()):targets.append({**x,'measured_nVehContrib':counts[x['detector_id'],float(x['begin']),float(x['end'])]})
assert len(targets)==182
proposal=propose_native_count_retiming(requests=requests,passages=passages['passages'],measurements=targets,max_moves_per_field=64,max_shift_s=2700)
proposal.update(calibration_rows=182,main_rows=130,initialization_rows=52,
    initialization_requests_changed=sum(x['source_depart_s']<3600 for x in proposal['proposals']))
residuals={(x['detector_id'],float(x['begin']),float(x['end'])):int(x['measured_nVehContrib'])-int(x['expected_total']) for x in targets};predicted=residuals.copy()
for x in proposal['proposals']:
    a,b=tuple(x['source_interval']),tuple(x['target_interval']);predicted[b]+=1
    if a in predicted:predicted[a]-=1
proposal.update(before_all182_TAE=sum(map(abs,residuals.values())),predicted_all182_TAE=sum(map(abs,predicted.values())),
    predicted_main130_TAE=sum(abs(v) for k,v in predicted.items() if k[1]>=3600))
changed=apply_native_count_retiming(routes,proposal['proposals']); before={v.get('id'):v for v in routes.findall('vehicle')};after={v.get('id'):v for v in changed.findall('vehicle')}
assert before.keys()==after.keys() and len(after)==8603
actual_changes=[]
for identity,v in after.items():
    original=before[identity]
    if v.get('depart')!=original.get('depart'):actual_changes.append(identity)
    old=v.get('depart');v.set('depart',original.get('depart'));assert ET.tostring(v)==ET.tostring(original);v.set('depart',old)
assert set(actual_changes)=={x['vehicle_id'] for x in proposal['proposals']}
ET.ElementTree(changed).write(evaluation/'demand.rou.xml',encoding='utf-8',xml_declaration=True)
model=json.loads((prepared/'od-model.json').read_bytes());columns={(int(x['begin_s']//900),x['origin'],x['destination']):i for i,x in enumerate(model['cells'])};vector=[0]*len(columns)
for identity,v in after.items():
    edges=v.find('route').get('edges').split();cell=columns[int(float(v.get('depart'))//900),edges[0],edges[-1]];vector[cell]+=1;intent[identity]['od_cell']=cell
intentions['mechanism']='Same explicit routes and detector lane intentions; bounded native-count departure correction. od_cell records the corrected actual departure interval.'
(evaluation/'lane-intentions.json').write_text(json.dumps(intentions,indent=2)+'\n',encoding='utf-8')
(evaluation/'od-vector.json').write_text(json.dumps({'values':vector,'integer_counts':vector,'vehicle_count':sum(vector),'source_model_sha256':hashlib.sha256((prepared/'od-model.json').read_bytes()).hexdigest(),'generation':'Explicit native-count retiming, without quantile resampling.'},indent=2)+'\n',encoding='utf-8')
(out/'retiming-proposal.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf-8')
preflight={'changed_vehicle_requests':len(actual_changes),'only_departures_changed':True,'detector_lane_assignments_unchanged':True,'all182_real_observations_in_proposal':True,
    'protected_sha256':{n:hashlib.sha256((prepared/n).read_bytes()).hexdigest() for n in ('network.net.xml','control.add.xml','field-loops.add.xml','expected-counts.csv','initialization-counts.csv')},
    'driver_sha256':{n:hashlib.sha256((repo/'plugins/astra-sumo/src/astra_sumo/core'/n).read_bytes()).hexdigest() for n in ('simulation_stall.py','detector_demand_replay.py','lane_section_hold.py','hamburg_od_spsa.py','hamburg_departure_probe.py','native_temporal_feedback.py')}}
(out/'retiming-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf-8');start=time.perf_counter()
native=run_point_detector_demand(net_file=prepared/'network.net.xml',route_file=evaluation/'demand.rou.xml',e1_additional_file=prepared/'field-loops.add.xml',expected_counts_csv=prepared/'expected-counts.csv',
    output_dir=evaluation/'native',end_s=14400,timeout_seconds=4800,sumo_binary=str(Path(sumo.__file__).parent/'bin/sumo.exe'),signal_program_file=prepared/'control.add.xml',
    lane_intentions_file=evaluation/'lane-intentions.json',junction_body_hold=True,junction_body_hold_nodes=_body_hold_nodes(prepared),seed=104,backend='libsumo')
result=summarize_hamburg_od_measurement(prepared_dir=prepared,proposal_dir=evaluation,native=native)
actual={(x.get('id'),float(x.get('begin')),float(x.get('end'))):int(x.get('nVehContrib')) for x in ET.parse(evaluation/'native/field-counts.xml').getroot()}
all_rows=[{**x,'measured_nVehContrib':actual[x['detector_id'],float(x['begin']),float(x['end'])],
    'residual':actual[x['detector_id'],float(x['begin']),float(x['end'])]-int(x['expected_total'])} for x in targets]
with (evaluation/'all182-comparison.csv').open('w',encoding='utf-8',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(all_rows[0]));writer.writeheader();writer.writerows(all_rows)
before_result=json.loads((parent/'evaluation.json').read_bytes());safe=not any(result['completion'][k] for k in ('collisions','teleports','discarded'));all_error=sum(abs(x['residual']) for x in all_rows)
improved=safe and result['MAE']<before_result['MAE'] and all_error<=proposal['before_all182_TAE'] and result['completion']['waiting']<=before_result['completion']['waiting'] and sum(result['completion'][k] for k in ('waiting','running'))<=sum(before_result['completion'][k] for k in ('waiting','running'))
verdict={'status':'diagnostic_improvement' if improved else 'rejected','safe':safe,'milestone_met':safe and result['MAE']<=10 and result['completion']['waiting']<=690,
    'formal_result':False,'before':before_result,'after':result,'before_all182_TAE':proposal['before_all182_TAE'],'after_all182_TAE':all_error,'elapsed_seconds':time.perf_counter()-start,
    'claim_boundary':'All 182 real observations enter the timing proposal and are reported. The 130 main-window native E1 rows remain the stage objective. Unobserved vehicles and all routes remain unchanged. Pending vehicles and unconfirmed control still prevent calibration acceptance.'}
(out/'retiming-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n',encoding='utf-8');print(json.dumps(verdict,indent=2),flush=True)
