"""Recheck one historical merge coordination with fixed repaired network and OD."""
from importlib.metadata import version
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import libsumo
import sumo
import traci
from astra_sumo.core.hamburg_od_spsa import measure_hamburg_od
from astra_sumo.core.hamburg_spillback_repair import replay_frozen_merge_program

repo = Path.cwd()
out = Path(__file__).resolve().parent
source = repo / 'outputs/lsa119-collision-diagnosis-20261023'
baseline = source / 'libsumo-baseline'
prepared = out / 'merge-prepared'
assert Path(sys.executable).resolve() == (repo / '.venv/Scripts/python.exe').resolve()
assert all(version(n) == '1.27.1' for n in ('eclipse-sumo', 'sumolib', 'traci', 'libsumo'))
assert Path(traci.__file__).resolve().is_relative_to(repo / '.venv')
assert Path(libsumo.__file__).resolve().is_relative_to(repo / '.venv')
shutil.copytree(source / 'paired-prepared', prepared)
control = ET.parse(prepared / 'control.add.xml').getroot()
frozen_path = repo / 'benchmarks/hamburg_ring1_spillback_repair_20261022_v1/proposals/merge_coordinated/control.add.xml'
candidate = replay_frozen_merge_program(control, ET.parse(frozen_path).getroot())
changed = [a.get('id') for a, b in zip(control, candidate) if ET.tostring(a) != ET.tostring(b)]
assert changed == ['GS_266199063']
ET.ElementTree(candidate).write(prepared / 'control.add.xml', encoding='utf-8', xml_declaration=True)
scenario = json.loads((prepared / 'scenario.json').read_bytes())
scenario.update(control_variant='historical_merge_coordination_recheck_on_repaired_network',
    control_sha256=hashlib.sha256((prepared / 'control.add.xml').read_bytes()).hexdigest(),
    control_assumptions=scenario.get('control_assumptions','') + ' GS_266199063 uses the exact frozen 2026-10-22 merge_coordinated placeholder. This is a diagnostic control hypothesis, not measured field SPaT. No other program changes.')
(prepared / 'scenario.json').write_text(json.dumps(scenario, indent=2) + '\n', encoding='utf-8')
protected = {name: hashlib.sha256((prepared / name).read_bytes()).hexdigest()
    for name in ('network.net.xml', 'field-loops.add.xml', 'expected-counts.csv', 'od-model.json')}
for name, sha in protected.items():
    assert sha == hashlib.sha256((source / 'paired-prepared' / name).read_bytes()).hexdigest()
preflight = {'changed_controllers': changed, 'frozen_control_sha256': hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
    'protected_sha256': protected, 'demand_source': str(baseline), 'backend': 'libsumo', 'formal_result': False,
    'driver_sha256': {name: hashlib.sha256((repo / 'plugins/astra-sumo/src/astra_sumo/core' / name).read_bytes()).hexdigest()
        for name in ('simulation_stall.py', 'detector_demand_replay.py', 'lane_section_hold.py', 'hamburg_od_spsa.py', 'hamburg_spillback_repair.py')}}
(out / 'merge-preflight.json').write_text(json.dumps(preflight, indent=2) + '\n', encoding='utf-8')
values = json.loads((baseline / 'od-vector.json').read_bytes())['values']
started = time.perf_counter()
result = measure_hamburg_od(prepared_dir=prepared, values=values, output_dir=out / 'merge-evaluation',
    sumo_binary=Path(sumo.__file__).parent / 'bin/sumo.exe', backend='libsumo')
for name in ('demand.rou.xml', 'lane-intentions.json'):
    assert (baseline / name).read_bytes() == (out / 'merge-evaluation' / name).read_bytes()
assert all(hashlib.sha256((prepared / name).read_bytes()).hexdigest() == sha for name, sha in protected.items())
before = json.loads((baseline / 'evaluation.json').read_bytes())
safe = not any(result['completion'][k] for k in ('collisions','teleports','discarded'))
improved = safe and result['MAE'] < before['MAE'] and result['max_abs_error'] <= before['max_abs_error'] and sum(result['completion'][k] for k in ('waiting','running')) < sum(before['completion'][k] for k in ('waiting','running'))
verdict = {'status': 'diagnostic_improvement' if improved else 'rejected', 'safe': safe, 'formal_result': False,
    'before': before, 'after': result, 'elapsed_seconds': time.perf_counter()-started,
    'claim_boundary': 'One declared downstream control hypothesis. No field SPaT claim. All 130 native E1 values and 40 derived station values remain required, together with healthy completion for acceptance.'}
(out / 'merge-verdict.json').write_text(json.dumps(verdict, indent=2) + '\n', encoding='utf-8')
print(json.dumps(verdict, indent=2), flush=True)
