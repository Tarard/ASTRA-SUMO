"""Apply one hash-bound explicit timing proposal and measure all native counts."""
import argparse
import csv
import hashlib
from importlib.metadata import version
import json
import math
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--proposal', required=True, type=Path)
parser.add_argument('--output-dir', required=True, type=Path)
args = parser.parse_args()
repo = Path.cwd()
proposal = json.loads(args.proposal.read_bytes())
parent = Path(proposal['source_prepared'])
prior_native = Path(proposal['source_native'])
out = args.output_dir.resolve()
assert not out.exists() and not parent.is_relative_to(out) and not prior_native.is_relative_to(out)
assert Path(sys.executable).resolve() == (repo/'.venv/Scripts/python.exe').resolve()
assert all(version(name) == '1.27.1' for name in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib'))
for row in proposal['source_hashes']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
assert proposal['projection_improves'] and proposal['projected_objective_l1'] < proposal['before_objective_l1']
out.mkdir(parents=True)
prepared = out/'prepared'
shutil.copytree(parent, prepared)
before = ET.parse(parent/'demand.rou.xml').getroot()
after = apply_native_count_retiming(before, proposal['proposals'])
old_vehicles = {v.get('id'): v for v in before.findall('vehicle')}
new_vehicles = {v.get('id'): v for v in after.findall('vehicle')}
assert old_vehicles.keys() == new_vehicles.keys() and len(new_vehicles) == 8640
for identity, old in old_vehicles.items():
    new = ET.fromstring(ET.tostring(new_vehicles[identity]))
    new.set('depart', old.get('depart'))
    assert ET.tostring(old) == ET.tostring(new), identity
ET.ElementTree(after).write(prepared/'demand.rou.xml', encoding='utf8', xml_declaration=True)
intentions = json.loads((prepared/'lane-intentions.json').read_bytes())
counts = [0]*294
for row in intentions['vehicles']:
    depart = float(new_vehicles[row['vehicle_id']].get('depart'))
    assert 0 <= depart < 12600
    row['od_cell'] = math.floor(depart/900)*21 + row['od_cell'] % 21
    row['depart_s'] = depart
    counts[row['od_cell']] += 1
assert sum(counts) == 8640
(prepared/'lane-intentions.json').write_text(json.dumps(intentions, indent=2)+'\n', encoding='utf8')
scenario = json.loads((prepared/'scenario.json').read_bytes())
scenario.update(demand_sha256=hashlib.sha256((prepared/'demand.rou.xml').read_bytes()).hexdigest(),
    time_prior='Explicit bounded native-feedback departures. All identities, routes, lane fields and observations retained. Translation scores are not predictions of changed queues.')
(prepared/'scenario.json').write_text(json.dumps(scenario, indent=2)+'\n', encoding='utf8')
for name in ('network.net.xml', 'control.add.xml', 'expected-counts.csv', 'initialization-counts.csv', 'field-loops.add.xml'):
    assert (parent/name).read_bytes() == (prepared/name).read_bytes()
evaluation = out/'evaluation'
evaluation.mkdir()
for name in ('demand.rou.xml', 'lane-intentions.json'):
    shutil.copyfile(prepared/name, evaluation/name)
vector = json.loads((prior_native.parent/'od-vector.json').read_bytes())
vector.update(values=counts, integer_counts=counts, vehicle_count=8640,
    generation='Counts of the explicitly retimed requests in actual departure cells. The historical OD model supplies lineage only; no quantile regeneration.')
(evaluation/'od-vector.json').write_text(json.dumps(vector, indent=2)+'\n', encoding='utf8')
shutil.copyfile(args.proposal, out/'proposal.json')
shutil.copyfile(__file__, out/'executed-driver.py')
preflight = {'proposal_sha256': hashlib.sha256(args.proposal.read_bytes()).hexdigest(),
    'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in prepared.iterdir()},
    'implementation_sha256': {name: hashlib.sha256((repo/'plugins/astra-sumo/src/astra_sumo/core'/name).read_bytes()).hexdigest()
        for name in ('detector_demand_replay.py', 'simulation_stall.py', 'lane_section_hold.py', 'hamburg_od_spsa.py', 'hamburg_departure_probe.py')},
    'native_versions': {name: version(name) for name in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')},
    'changed_vehicles': proposal['changed_vehicles'], 'formal_result': False}
(out/'preflight.json').write_text(json.dumps(preflight, indent=2)+'\n', encoding='utf8')
start = time.perf_counter()
native = run_point_detector_demand(net_file=prepared/'network.net.xml', route_file=prepared/'demand.rou.xml',
    e1_additional_file=prepared/'field-loops.add.xml', expected_counts_csv=prepared/'expected-counts.csv',
    output_dir=evaluation/'native', end_s=14400, timeout_seconds=4800, seed=104, backend='libsumo',
    sumo_binary=str(Path(sumo.__file__).parent/'bin/sumo.exe'), signal_program_file=prepared/'control.add.xml',
    lane_intentions_file=prepared/'lane-intentions.json', junction_body_hold=True,
    junction_body_hold_nodes=_body_hold_nodes(prepared))
measured = summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
native_counts = {(r.get('id'), float(r.get('begin')), float(r.get('end'))): int(r.get('nVehContrib'))
    for r in ET.parse(evaluation/'native/field-counts.xml').getroot()}
rows = []
for name in ('initialization-counts.csv', 'expected-counts.csv'):
    for row in csv.DictReader((prepared/name).open(encoding='utf8', newline='')):
        value = native_counts[row['detector_id'], float(row['begin']), float(row['end'])]
        rows.append({**row, 'measured_nVehContrib': value, 'residual': value-int(row['expected_total'])})
with (evaluation/'all182-comparison.csv').open('w', encoding='utf8', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
assert len(rows) == 182
baseline = json.loads((prior_native.parent/'evaluation.json').read_bytes())
all_error = sum(abs(r['residual']) for r in rows)
safe = not any(measured['completion'][k] for k in ('collisions', 'teleports', 'discarded'))
no_more_unfinished = sum(measured['completion'][k] for k in ('running', 'waiting')) <= sum(baseline['completion'][k] for k in ('running', 'waiting'))
accepted = safe and measured['MAE'] < baseline['MAE'] and all_error <= proposal['before_all_l1'] and no_more_unfinished and measured['completion']['waiting'] <= baseline['completion']['waiting']
result = {'before': baseline, 'after': measured, 'elapsed_seconds': time.perf_counter()-start,
    'all182_TAE': all_error, 'formal_result': False, 'status': 'accepted_diagnostic_step' if accepted else 'rejected',
    'zero_residual_goal_complete': measured['exact_count_fit'],
    'claim_boundary': 'Fresh native evaluation of all130 main fields and40 derived stations. Every52 initialization target is also reported. Count timing proposals do not establish real OD or field SPaT.'}
(out/'verdict.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf8')
print(json.dumps(result, indent=2), flush=True)
