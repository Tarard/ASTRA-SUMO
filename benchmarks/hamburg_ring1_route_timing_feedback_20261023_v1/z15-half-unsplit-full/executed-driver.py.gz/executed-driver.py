"""Measure the Z15-only legal residential split with all native target values."""
import argparse
import csv
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import xml.etree.ElementTree as ET

import sumo
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement

repo = Path.cwd()
root = Path(__file__).resolve().parent
parent = repo / 'outputs/hamburg-primary-branch-repair-20261023-v1'
parser = argparse.ArgumentParser()
parser.add_argument('--variant', choices=('z15-residential', 'z15-half'), default='z15-residential')
parser.add_argument('--candidate-net', type=Path)
options = parser.parse_args()
variant = options.variant
out = root / f'{variant}{"-unsplit" if options.candidate_net else ""}-full'
out.mkdir()
prepared = out / 'prepared'
shutil.copytree(parent / 'prepared', prepared)
shutil.copyfile(root / f'{variant}-prefix-900/demand.rou.xml', prepared / 'demand.rou.xml')
if options.candidate_net:
    assert variant == 'z15-half'
    shutil.copyfile(options.candidate_net, prepared/'network.net.xml')
assert Path(sys.executable).resolve() == (repo / '.venv/Scripts/python.exe').resolve()
assert all(version(name) == '1.27.1' for name in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib'))
before = ET.parse(parent / 'prepared/demand.rou.xml').getroot()
after = ET.parse(prepared / 'demand.rou.xml').getroot()
changes = []
for first, second in zip(before.findall('vehicle'), after.findall('vehicle'), strict=True):
    assert first.attrib == second.attrib
    a, b = first.find('route').get('edges'), second.find('route').get('edges')
    if a != b:
        assert b == a.replace('1108564798#0 1108564798#1', '27064186#0 1073054122#1 1345098540')
        changes.append(first.get('id'))
        second.find('route').set('edges', a)
    assert ET.tostring(first) == ET.tostring(second)
prefix = json.loads((root/f'{variant}-prefix-900/result.json').read_bytes())
assert changes == prefix['changed_route_ids'] and len(before.findall('vehicle')) == 8640
assert len(changes) == (1205 if variant == 'z15-residential' else 603)
scenario = json.loads((prepared/'scenario.json').read_bytes())
scenario['branch_treatment'] = f'Only {len(changes)} Z15 post-detector tails use the original source residential branch to the same boundary. Other Z15 and all Z4/Z5 retain the restored primary branch. Route-split sensitivity, not an observed field split.'
scenario['demand_sha256'] = hashlib.sha256((prepared/'demand.rou.xml').read_bytes()).hexdigest()
scenario['network_sha256'] = hashlib.sha256((prepared/'network.net.xml').read_bytes()).hexdigest()
if options.candidate_net:
    scenario['internal_representation'] = 'Only the selected Z4 lane0 left movement uses native contPos=0. All road access, full physical curves and signal programs preserved. Native safety/count evaluation required.'
(prepared/'scenario.json').write_text(json.dumps(scenario, indent=2)+'\n', encoding='utf8')
evaluation = out / 'evaluation'
evaluation.mkdir()
for name in ('demand.rou.xml', 'lane-intentions.json'):
    shutil.copyfile(prepared/name, evaluation/name)
vector = json.loads((parent/'evaluation/od-vector.json').read_bytes())
vector['generation'] = scenario['branch_treatment']
(evaluation/'od-vector.json').write_text(json.dumps(vector, indent=2)+'\n', encoding='utf8')
preflight = {'changed_route_ids': changes, 'vehicle_count': 8640,
    'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in prepared.iterdir()},
    'implementation_sha256': {name: hashlib.sha256((repo/'plugins/astra-sumo/src/astra_sumo/core'/name).read_bytes()).hexdigest()
        for name in ('detector_demand_replay.py', 'simulation_stall.py', 'lane_section_hold.py', 'hamburg_od_spsa.py')},
    'versions': {name: version(name) for name in ('eclipse-sumo', 'traci', 'sumolib', 'libsumo')},
    'formal_result': False}
(out/'preflight.json').write_text(json.dumps(preflight, indent=2)+'\n', encoding='utf8')
shutil.copyfile(__file__, out/'executed-driver.py')
start = time.perf_counter()
native = run_point_detector_demand(net_file=prepared/'network.net.xml', route_file=prepared/'demand.rou.xml',
    e1_additional_file=prepared/'field-loops.add.xml', expected_counts_csv=prepared/'expected-counts.csv',
    output_dir=evaluation/'native', end_s=14400, timeout_seconds=4800, seed=104, backend='libsumo',
    sumo_binary=str(Path(sumo.__file__).parent/'bin/sumo.exe'), signal_program_file=prepared/'control.add.xml',
    lane_intentions_file=prepared/'lane-intentions.json', junction_body_hold=True,
    junction_body_hold_nodes=_body_hold_nodes(prepared))
measured = summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
counts = {(r.get('id'), float(r.get('begin')), float(r.get('end'))): int(r.get('nVehContrib'))
          for r in ET.parse(evaluation/'native/field-counts.xml').getroot()}
rows = []
for name in ('initialization-counts.csv', 'expected-counts.csv'):
    for row in csv.DictReader((prepared/name).open(encoding='utf8', newline='')):
        value = counts[row['detector_id'], float(row['begin']), float(row['end'])]
        rows.append({**row, 'measured_nVehContrib': value, 'residual': value-int(row['expected_total'])})
with (evaluation/'all182-comparison.csv').open('w', encoding='utf8', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
assert len(rows) == 182
baseline = json.loads((parent/'evaluation/evaluation.json').read_bytes())
if options.candidate_net:
    baseline = json.loads((root/'z15-half-full/evaluation/evaluation.json').read_bytes())
result = {'before': baseline, 'after': measured, 'elapsed_seconds': time.perf_counter()-start,
    'all182_TAE': sum(abs(r['residual']) for r in rows), 'formal_result': False,
    'status': 'diagnostic_improvement' if measured['MAE'] < (7.8307692307692305 if options.candidate_net else baseline['MAE']) and
        not any(measured['completion'][k] for k in ('collisions', 'teleports', 'discarded')) else 'rejected',
    'zero_residual_goal_complete': measured['exact_count_fit'],
    'claim_boundary': scenario['branch_treatment']}
(out/'verdict.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf8')
print(json.dumps(result, indent=2), flush=True)
