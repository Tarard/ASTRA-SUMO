# OD-field 分组与保字段实现的一致方向

搜索参考为 one-share：8640 全到达、零事故、planned Z4/Z5=760/624，但 MAE3.93846 仍被拒绝。此前健康 full-priority 的 MAE3.71538、TAE483 仍是最好结果。

完整请求按 `(origin,destination,field,900秒departure bin)` 得到 29 组×14=406 列，所有 prior 为正，最小 1；旧 294 列有 112 个混字段 cell。新的 130/182 行对账准确，数值秩分别为 130/182。满行秩不识别 406 个未知量，也不证明约束下零误差可行。241 个完整事件在真实目标窗之后，没有给尾部填假零。

只求一次方向：L1=32，19 列改变；冻结前 116 个 departure 列，保持 29 个 `(OD,field)` 总量，因而也保每 OD 和每 field 总量。半径使用 **max(1,floor(q×0.25))**、下界截 0；小 q 可改 1 辆，这是对早先严格 25% 规则的明确调整。两侧为 x0+d 和 x0−d，均合法，535 四字段 56 行的描述预测仍 exact。预测主 TAE 为 plus480、minus544，参考为512；这些不是原生结果或 Jacobian。

实现逐 field 调用既有 stable realizer，再合并为每侧 16 个只改 depart 的请求；没有改 core。全部 IDs/routes/stops/field 保持，初始化 1953 个请求与其他未选请求不变。原 v26 的 Z5 lane1 stop/field 没有被旧 model 重置。metadata 的 `od_cell` 从实际 route 和 native 毫秒时刻重算为真实 294 索引；406 坐标只在 `vector406.json` 单独保存。

plus/minus 均从同一个 one-share 显式需求独立出发。实际最大 native shift 为6291.912秒；中位分别1804.1825/1801.272秒，没有额外900秒限幅。优化分组与保字段实现一致只消除了已知的字段类型错配，不能使旧时滞或交通响应不变。两侧全窗由 root 独立运行和审查，后续动作等待结果。本离线准备没有启动原生仿真，也不预备其他候选。
