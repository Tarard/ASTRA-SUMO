"""Prepare one observed OD-field direction and two preserved-request realizations."""

from collections import Counter
import copy
import csv
import gzip
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming
from astra_sumo.core.od_assignment_feedback import propose_bounded_od_assignment
from astra_sumo.core.od_stable_realization import propose_stable_od_retiming

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"
MODEL = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    assert not (ROOT / "direction.json").exists(), "Preserve the one saved direction."
    source = SOURCE / "prepared"
    before = ET.parse(source / "demand.rou.xml").getroot()
    old = {r.get("id"): r for r in before.findall("vehicle")}
    intentions = json.loads((source / "lane-intentions.json").read_bytes())
    intent = {r["vehicle_id"]: r for r in intentions["vehicles"]}
    key_for = {}
    for identity, vehicle in old.items():
        edges = vehicle.find("route").get("edges").split()
        period = math.floor((math.floor(float(vehicle.get("depart"))*1000+.5)/1000)/900)
        key_for[identity] = edges[0], edges[-1], intent[identity]["field_id"], period
    inventory = Counter(key_for.values())
    keys = sorted(inventory, key=lambda k: (k[3], k[:3]))
    index = {k: i for i, k in enumerate(keys)}
    group_keys = sorted({k[:3] for k in keys})
    groups = np.array([group_keys.index(k[:3]) for k in keys], dtype=np.int64)
    q = np.array([inventory[k] for k in keys], dtype=np.int64)
    assert len(keys) == 406 and len(group_keys) == 29 and np.all(q > 0) and q.sum() == 8640
    compact_path = SOURCE / "evaluation/contributing-passages.json.gz"
    compact = json.loads(gzip.decompress(compact_path.read_bytes()))
    assert compact["reconciled"] and len(compact["passages"]) == 8640
    assert all(e["detector_id"] == intent[e["vehicle_id"]]["field_id"] for e in compact["passages"])
    rows = []
    for name in ("initialization-counts.csv", "expected-counts.csv"):
        rows.extend(csv.DictReader((source / name).open(encoding="utf-8", newline="")))
    row_keys = [(r["detector_id"], float(r["begin"]), float(r["end"])) for r in rows]
    row_index = {k: i for i, k in enumerate(row_keys)}
    C = np.zeros((182, 406), dtype=np.int64)
    tail = 0
    for event in compact["passages"]:
        key = event["detector_id"], event["interval_begin_s"], event["interval_end_s"]
        if key in row_index:
            C[row_index[key], index[key_for[event["vehicle_id"]]]] += 1
        else:
            tail += 1
    periodic = {(r.get("id"), float(r.get("begin")), float(r.get("end"))): int(r.get("nVehContrib"))
                for r in ET.parse(SOURCE / "evaluation/native/field-counts.xml").getroot()}
    assert np.array_equal(C.sum(axis=1), [periodic[k] for k in row_keys])
    target = np.array([int(r["expected_total"]) for r in rows])
    initial = np.array([k[1] < 3600 for k in row_keys])
    radius = np.maximum(1, q//4)
    lower, upper = np.maximum(0, q-radius), q+radius
    frozen = np.array([k[3] < 4 for k in keys])
    lower[frozen] = upper[frozen] = q[frozen]
    assert frozen.sum() == 116 and not np.any(C[initial][:, ~frozen])
    protect = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}
    exact = np.array([k[0] in protect for k in row_keys])
    np.savez_compressed(ROOT / "solver-inputs406.npz", C=C, q=q, y=target, od_groups=groups,
                        lower=lower, upper=upper, exact_rows=exact, frozen_columns=frozen)
    save(ROOT / "columns406.json", [dict(index=i, origin=k[0], destination=k[1], field=k[2],
         begin=900*k[3], end=900*(k[3]+1), prior=int(q[i]), group=int(groups[i])) for i, k in enumerate(keys)])
    save(ROOT / "rows182.json", rows)
    result = propose_bounded_od_assignment(contributions=C, prior=q, observations=target,
        od_groups=groups, lower=lower, upper=upper, exact_rows=exact, change_budget=32)
    save(ROOT / "solver-result.json", result)
    assert result["status"] == "candidate", result
    plus = np.array(result["solution"], dtype=np.int64)
    delta = plus-q
    minus = q-delta
    assert np.all(minus >= lower) and np.all(minus <= upper)
    assert np.array_equal(plus[frozen], q[frozen]) and np.array_equal(minus[frozen], q[frozen])
    A = C/q
    assert np.max(np.abs((A@plus-target)[exact])) < 1e-6
    assert np.max(np.abs((A@minus-target)[exact])) < 1e-6
    main_mask = ~initial
    save(ROOT / "direction.json", dict(status="prepared", native_runs=0, formal_result=False,
        reference=str(SOURCE), reference_main130_TAE=512, old_best_main130_TAE=483,
        prior406=q.tolist(), direction406=delta.tolist(), plus406=plus.tolist(), minus406=minus.tolist(),
        l1=int(np.abs(delta).sum()), changed_columns=int(np.count_nonzero(delta)),
        predicted_main130_TAE={label:float(np.abs((A@x-target)[main_mask]).sum()) for label,x in (("plus",plus),("minus",minus))},
        radius_policy="max(1,floor(q*.25)), lower clipped0; this explicitly permits1 change in small cells unlike the earlier strict25% rule",
        claim_boundary="One deterministic solver direction, not randomSPSA, a Jacobian or verified count response. Both sides start from the same healthy one-share source; oldbest3.715 remains the comparison best."))
    print(json.dumps(dict(status="direction_ready", changed_columns=int(np.count_nonzero(delta)),
                         l1=int(np.abs(delta).sum()), tail_events=tail)), flush=True)
    cells294 = json.loads(MODEL.read_bytes())["cells"]
    original_index = {(c["origin"], c["destination"], c["begin_s"]): i for i,c in enumerate(cells294)}
    fields = sorted({k[2] for k in keys})
    for label, solution in (("plus",plus),("minus",minus)):
        case = ROOT / label
        case.mkdir()
        moves = []
        for field in fields:
            columns = [i for i,k in enumerate(keys) if k[2] == field]
            local = {global_index: local_index for local_index,global_index in enumerate(columns)}
            cells = [dict(origin=keys[i][0], destination=keys[i][1], begin_s=900*keys[i][3], end_s=900*(keys[i][3]+1)) for i in columns]
            requests = [dict(vehicle_id=i, od_cell=local[index[key_for[i]]], requested_depart_s=float(v.get("depart")))
                        for i,v in old.items() if intent[i]["field_id"] == field]
            proposal = propose_stable_od_retiming(requests=requests,cells=cells,target=solution[columns].tolist())
            for move in proposal["proposals"]:
                moves.append({**move,"field_id":field,"source_assignment_cell406":columns[move["source_cell"]],
                              "target_assignment_cell406":columns[move["target_cell"]]})
        assert len({m["vehicle_id"] for m in moves}) == len(moves) == int(np.abs(delta).sum())//2
        save(case / "retiming-proposals.json", moves)
        after = apply_native_count_retiming(before,moves)
        new = {v.get("id"):v for v in after.findall("vehicle")}
        selected = {m["vehicle_id"]:m for m in moves}
        assert new.keys() == old.keys()
        for identity in old:
            check = copy.deepcopy(new[identity])
            if identity not in selected:
                assert ET.tostring(check) == ET.tostring(old[identity])
            check.set("depart",old[identity].get("depart"))
            assert ET.tostring(check) == ET.tostring(old[identity])
        prepared = case / "prepared"
        shutil.copytree(source,prepared)
        ET.ElementTree(after).write(prepared / "demand.rou.xml",encoding="utf-8",xml_declaration=True)
        metadata = copy.deepcopy(intentions)
        actual406, actual294 = np.zeros(406,dtype=int), [0]*294
        for row in metadata["vehicles"]:
            identity = row["vehicle_id"]
            depart = float(new[identity].get("depart"))
            period = math.floor((math.floor(depart*1000+.5)/1000)/900)
            route = new[identity].find("route").get("edges").split()
            i406 = index[route[0],route[-1],row["field_id"],period]
            i294 = original_index[route[0],route[-1],900*period]
            actual406[i406] += 1
            actual294[i294] += 1
            if identity in selected:
                assert i406 == selected[identity]["target_assignment_cell406"]
                row.update(od_cell=i294,depart_s=depart)
            else:
                assert row == intent[identity]
            assert row["field_id"] == intent[identity]["field_id"]
        assert np.array_equal(actual406,solution) and sum(actual294)==8640
        save(prepared / "lane-intentions.json",metadata)
        scenario=json.loads((source / "scenario.json").read_bytes())
        scenario.update(demand_sha256=sha(prepared / "demand.rou.xml"),formal_result=False,
            time_prior="One OD-field-stratified32L1 direction; stable preserved-request realization. No field reassignment or quantile population regeneration.")
        save(prepared / "scenario.json",scenario)
        save(case / "vector406.json",dict(values=solution.tolist(),direction_sign=label,columns_file=str(ROOT / "columns406.json")))
        vector=json.loads((SOURCE / "evaluation/od-vector.json").read_bytes())
        vector.update(values=actual294,integer_counts=actual294,vehicle_count=8640,
            generation="Actual294 OD-period counts from saved field-stratified stable requests; see separate406 vector. No OD model regeneration.",demand_generated_by_original_model=False)
        save(case / "od-vector.json",vector)
        fixed=("network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv")
        assert all((source/n).read_bytes()==(prepared/n).read_bytes() for n in fixed)
        implementation=case / "implementation"
        implementation.mkdir()
        core=REPO / "plugins/astra-sumo/src/astra_sumo/core"
        mapping=[]
        for name in ("od_assignment_feedback.py","od_stable_realization.py","hamburg_departure_probe.py","route_sensor_matrix.py"):
            shutil.copyfile(core/name,implementation/name)
            mapping.append(dict(original_path=str(core/name),snapshot_path=str(implementation/name),sha256=sha(implementation/name)))
        save(case / "source-snapshot-mapping.json",mapping)
        bound=[*source.iterdir(),compact_path,MODEL,ROOT/"direction.json",ROOT/"solver-inputs406.npz",ROOT/"columns406.json",Path(__file__)]
        bound += [Path(m[k]) for m in mapping for k in ("original_path","snapshot_path")]
        stats=dict(common_IDs=8640,added_IDs=0,removed_IDs=0,common_request_changed=len(moves),
            common_native_millisecond_departure_changed=len(moves),common_non_depart_attributes_changed=0,
            common_route_changed=0,common_stop_changed=0,common_field_intention_changed=0,
            other_requests_XML_exact=True,initial1953_requests_XML_exact=all(ET.tostring(old[i])==ET.tostring(new[i]) for i in old if float(old[i].get("depart"))<3600))
        save(case / "scope-proof.json",dict(status="pass",native_runs=0,formal_result=False,N=8640,actual_changes=len(moves),
            demand_generation_changes=stats,source_hashes={str(p.resolve()):sha(p) for p in bound},
            prepared_hashes={p.name:sha(p) for p in prepared.iterdir()},original_driver_scope=scenario["junction_body_hold_nodes"],
            metadata_od_cell_is294=True,separate406_vector=True,field_totals_unchanged=True,OD_totals_unchanged=True,
            source_snapshot_mapping=mapping,claim_boundary="Same explicit source and field totals on both direction sides. Descriptor predictions remain unverified; new source3.938 is healthy but rejected versus oldbest3.715."))
        print(json.dumps(dict(case=label,prepared=str(prepared),moves=len(moves))),flush=True)


if __name__ == "__main__":
    main()
