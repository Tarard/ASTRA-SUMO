"""Independently verify the saved406 direction and both explicit realizations."""

from collections import Counter
import copy
import gzip
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.candidate_contracts import file_sha256 as sha

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"


def main():
    data = np.load(ROOT / "solver-inputs406.npz")
    C,q,y,groups,lo,hi,exact,frozen = (data[k] for k in ("C","q","y","od_groups","lower","upper","exact_rows","frozen_columns"))
    columns=json.loads((ROOT / "columns406.json").read_bytes())
    rows=json.loads((ROOT / "rows182.json").read_bytes())
    initial=np.array([float(r["begin"])<3600 for r in rows])
    lookup={(r["origin"],r["destination"],r["field"],r["begin"]):i for i,r in enumerate(columns)}
    direction=json.loads((ROOT / "direction.json").read_bytes())
    before=ET.parse(SOURCE / "prepared/demand.rou.xml").getroot()
    old={v.get("id"):v for v in before.findall("vehicle")}
    intent={r["vehicle_id"]:r for r in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    A=C/q
    assert C.shape==(182,406) and len(np.unique(groups))==29 and np.all(q>0)
    assert all(not C[i,j] or rows[i]["detector_id"]==columns[j]["field"] for i in range(182) for j in range(406))
    compact_path=SOURCE / "evaluation/contributing-passages.json.gz"
    compact=json.loads(gzip.decompress(compact_path.read_bytes()))
    assert compact["reconciled"] and all(sha(Path(r["path"]))==r["sha256"] for r in compact["inputs"])
    periodic={(r.get("id"),float(r.get("begin")),float(r.get("end"))):int(r.get("nVehContrib"))
              for r in ET.parse(SOURCE / "evaluation/native/field-counts.xml").getroot()}
    assert np.array_equal(C.sum(axis=1),[periodic[r["detector_id"],float(r["begin"]),float(r["end"])] for r in rows])
    assert not np.any(C[initial][:,~frozen])
    pairs={}
    for label in ("plus","minus"):
        case=ROOT / label
        new_tree=ET.parse(case / "prepared/demand.rou.xml").getroot()
        new={v.get("id"):v for v in new_tree.findall("vehicle")}
        meta={r["vehicle_id"]:r for r in json.loads((case / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
        assert new.keys()==old.keys() and len(new)==8640
        counts=np.zeros(406,dtype=int)
        changed=[]
        for identity in old:
            v=new[identity]
            raw_depart=v.get("depart")
            if raw_depart!=old[identity].get("depart"):
                changed.append(identity)
            check=copy.deepcopy(v)
            check.set("depart",old[identity].get("depart"))
            assert ET.tostring(check)==ET.tostring(old[identity])
            assert meta[identity]["field_id"]==intent[identity]["field_id"]
            route=v.find("route").get("edges").split()
            begin=math.floor((math.floor(float(raw_depart)*1000+.5)/1000)/900)*900
            col=lookup[route[0],route[-1],meta[identity]["field_id"],begin]
            counts[col]+=1
            if identity not in changed:
                assert meta[identity]==intent[identity]
        expected=np.array(direction[label+"406"])
        assert np.array_equal(counts,expected) and len(changed)==16
        assert np.array_equal(counts[frozen],q[frozen]) and np.all(counts>=lo) and np.all(counts<=hi)
        assert np.abs(counts-q).sum()==32
        assert all(counts[groups==g].sum()==q[groups==g].sum() for g in np.unique(groups))
        assert np.max(np.abs((A@counts-y)[exact]))<1e-6
        assert new["od_0209_v00026"].find("stop").get("lane")=="24483344#1_1"
        assert meta["od_0209_v00026"]["field_id"]=="hh_0119_Z_5_30494"
        pairs[label]=dict(requests=8640,depart_only_changes=16,field_changes=0,prior1953_requests_unchanged=True,
            zero_target_columns=int(np.sum(counts==0)),predicted_main130_TAE=float(np.abs((A@counts-y)[~initial]).sum()),
            current_q294=json.loads((case / "od-vector.json").read_bytes())["integer_counts"])
    assert np.array_equal(np.array(direction["plus406"])+np.array(direction["minus406"]),2*q)
    old_cells=Counter((c["origin"],c["destination"],c["begin"]) for c in columns)
    result=dict(status="pass",formal_result=False,native_runs=0,reference="healthy but rejected one-share:MAE3.9384615",
        comparison_best="original healthy full-priority:MAE3.7153846 remains best",OD_field_groups=29,
        period_columns=406,zero_prior_slots=0,minimum_prior=int(q.min()),mixed_field_cells_in_old294=sum(n>1 for n in old_cells.values()),
        main130_numerical_rank=int(np.linalg.matrix_rank(A[~initial])),all182_numerical_rank=int(np.linalg.matrix_rank(A)),
        main130_zero_response_columns=int(np.sum(C[~initial].sum(axis=0)==0)),all182_zero_response_columns=int(np.sum(C.sum(axis=0)==0)),
        initial_frozen_columns=int(frozen.sum()),tail_events_without_true_targets=241,
        source_reconciled_events=len(compact["passages"]),cases=pairs,
        snapshot_hashes={str(p):sha(p) for p in (ROOT / "direction.json",ROOT / "solver-result.json",ROOT / "solver-inputs406.npz",ROOT / "columns406.json",compact_path)},
        implementation_boundary="Fieldwise realizer calls preserve each OD-field total. Pervehicle field/route/stop are unchanged and metadata od_cell remains294;406 lives only in separate vectors. Full rank rows do not identify406 unknowns or prove zero-fit feasibility.",
        claim_boundary="C/q is observed assignment, not a Jacobian. Frozen predicted535 and main scores require two new native measurements. No fieldSpAT or improvement claim.")
    (ROOT / "audit.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:result[k] for k in ("status","OD_field_groups","period_columns","main130_numerical_rank","all182_numerical_rank","zero_prior_slots")},ensure_ascii=False))


if __name__=="__main__":
    main()
