"""Rebuild the observed field-conditioned matrix and check both sealed inputs."""

from collections import Counter
from copy import deepcopy
import csv
import gzip
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import numpy as np

OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
SOURCE = REPO / "outputs/hamburg-z5-single-share-20261024-v1/one-share"
MODEL = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json"
HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0,str(HELPERS))
import audit_response as audit  # noqa: E402
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages  # noqa: E402

DONOR = "od_0209_v00026"
Z5 = "hh_0119_Z_5_30494"
PROTECT = {"hh_0535_Z_5_30894","hh_0535_Z_6_33855","hh_0535_Z_7_29316","hh_0535_Z_8_34287"}


def native_ms(v):
    return math.floor(float(v)*1000+.5)


def vehicle_key(v, field):
    edges=v.find("route").get("edges").split()
    return edges[0],edges[-1],field,native_ms(v.get("depart"))//900000


def inspect():
    direction=json.loads((STUDY/"direction.json").read_bytes())
    columns=json.loads((STUDY/"columns406.json").read_bytes())
    row_declarations=json.loads((STUDY/"rows182.json").read_bytes())
    solver=np.load(STUDY/"solver-inputs406.npz")
    saved_result=json.loads((STUDY/"solver-result.json").read_bytes())
    keys=[(c["origin"],c["destination"],c["field"],int(c["begin"]//900)) for c in columns]
    index={k:i for i,k in enumerate(keys)}
    assert len(columns)==len(index)==406 and [c["index"] for c in columns]==list(range(406))
    source_root=ET.parse(SOURCE/"prepared/demand.rou.xml").getroot()
    old={v.get("id"):v for v in source_root.findall("vehicle")}
    source_meta_top=json.loads((SOURCE/"prepared/lane-intentions.json").read_bytes())
    intent={r["vehicle_id"]:r for r in source_meta_top["vehicles"]}
    assert len(old)==len(intent)==8640 and old.keys()==intent.keys()
    assert intent[DONOR]["field_id"]==Z5 and old[DONOR].find("stop").get("lane")=="24483344#1_1"
    actual_inventory=Counter(vehicle_key(v,intent[i]["field_id"]) for i,v in old.items())
    q=np.array([actual_inventory[k] for k in keys],dtype=np.int64)
    assert actual_inventory.keys()==index.keys() and np.all(q>0) and q.sum()==8640
    assert np.array_equal(q,solver["q"]) and q.tolist()==direction["prior406"]
    assert [int(c["prior"]) for c in columns]==q.tolist()
    groups=np.array([c["group"] for c in columns])
    assert np.array_equal(groups,solver["od_groups"]) and len(set(groups))==29
    group_keys={}
    for c,k in zip(columns,keys):
        group_keys.setdefault(c["group"],k[:3])
        assert group_keys[c["group"]]==k[:3]
    assert len(set(group_keys.values()))==29
    assert all(sum(k[:3]==g for k in keys)==14 for g in group_keys.values())
    declared_rows=[]
    for name in ["initialization-counts.csv","expected-counts.csv"]:
        with (SOURCE/"prepared"/name).open(encoding="utf-8",newline="") as handle:
            declared_rows.extend(csv.DictReader(handle))
    assert declared_rows==row_declarations and len(declared_rows)==182
    row_keys=[(r["detector_id"],float(r["begin"]),float(r["end"])) for r in declared_rows]
    row_index={k:i for i,k in enumerate(row_keys)}
    assert len(row_index)==182
    y=np.array([int(r["expected_total"]) for r in declared_rows])
    assert np.array_equal(y,solver["y"])
    initial=np.array([k[1]<3600 for k in row_keys])
    frozen=np.array([k[3]<4 for k in keys])
    exact=np.array([k[0] in PROTECT for k in row_keys])
    assert initial.sum()==52 and (~initial).sum()==130 and frozen.sum()==116 and exact.sum()==56
    assert np.array_equal(frozen,solver["frozen_columns"]) and np.array_equal(exact,solver["exact_rows"])
    run=json.loads((SOURCE/"evaluation/native/run.json").read_bytes())
    raw=read_contributing_e1_passages(instant_file=SOURCE/"evaluation/native/instant-e1.xml",periodic_file=SOURCE/"evaluation/native/field-counts.xml",detector_ids=run["instant_to_periodic_ids"],step_length=.1)
    with gzip.open(SOURCE/"evaluation/contributing-passages.json.gz","rt",encoding="utf-8") as handle:
        assert raw==json.load(handle) and raw["reconciled"]
    assert len(raw["passages"])==len({e["vehicle_id"] for e in raw["passages"]})==8640
    C=np.zeros((182,406),dtype=np.int64)
    for e in raw["passages"]:
        assert e["detector_id"]==intent[e["vehicle_id"]]["field_id"]
        key=e["detector_id"],e["interval_begin_s"],e["interval_end_s"]
        if key in row_index:
            C[row_index[key],index[vehicle_key(old[e["vehicle_id"]],e["detector_id"])]]+=1
    assert np.array_equal(C,solver["C"])
    periodic={(r.get("id"),float(r.get("begin")),float(r.get("end"))):int(r.get("nVehContrib")) for r in ET.parse(SOURCE/"evaluation/native/field-counts.xml").getroot()}
    assert np.array_equal(C.sum(axis=1),[periodic[k] for k in row_keys]) and not np.any(C[initial][:,~frozen])
    A=C/q
    d=np.array(direction["direction406"],dtype=np.int64)
    assert len(d)==406 and int(abs(d).sum())==32 and np.count_nonzero(d)==19
    radius=np.maximum(1,q//4)
    lo,hi=np.maximum(0,q-radius),q+radius
    lo[frozen]=hi[frozen]=q[frozen]
    assert np.array_equal(lo,solver["lower"]) and np.array_equal(hi,solver["upper"])
    assert all(int(d[groups==g].sum())==0 for g in group_keys)
    model=json.loads(MODEL.read_bytes())
    keys294={(c["origin"],c["destination"],int(c["begin_s"]//900)):i for i,c in enumerate(model["cells"])}
    outcomes={}
    selected_by_case={}
    for label,sign in [("plus",1),("minus",-1)]:
        case=STUDY/label
        expected=q+sign*d
        assert expected.tolist()==direction[label+"406"]
        if label=="plus":
            assert expected.tolist()==saved_result["solution"]
        assert np.all(expected>=lo) and np.all(expected<=hi) and np.array_equal(expected[frozen],q[frozen])
        assert np.max(abs((A@expected-y)[exact]))<1e-6
        assert math.isclose(float(abs((A@expected-y)[~initial]).sum()),direction["predicted_main130_TAE"][label],abs_tol=1e-10)
        proof=json.loads((case/"scope-proof.json").read_bytes())
        mapping={r["original_path"]:r for r in proof["source_snapshot_mapping"]}
        bindings=[]
        for p,h in proof["source_hashes"].items():
            resolved=Path(mapping[p]["snapshot_path"]) if p in mapping else Path(p)
            assert audit.digest(resolved)==h
            bindings.append(dict(declared_path=p,audited_path=str(resolved),sha256=h))
        for name,h in proof["prepared_hashes"].items():
            assert audit.digest(case/"prepared"/name)==h
        for name in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
            assert (SOURCE/"prepared"/name).read_bytes()==(case/"prepared"/name).read_bytes()
        root=ET.parse(case/"prepared/demand.rou.xml").getroot()
        new={v.get("id"):v for v in root.findall("vehicle")}
        metadata_top=json.loads((case/"prepared/lane-intentions.json").read_bytes())
        metadata={r["vehicle_id"]:r for r in metadata_top["vehicles"]}
        assert new.keys()==old.keys()==metadata.keys() and len(root.findall("vehicle"))==8640
        assert [ET.tostring(v) for v in root if v.tag!="vehicle"]==[ET.tostring(v) for v in source_root if v.tag!="vehicle"]
        moves=json.loads((case/"retiming-proposals.json").read_bytes())
        selected={r["vehicle_id"]:r for r in moves}
        selected_by_case[label]=set(selected)
        assert len(selected)==len(moves)==16
        actual406=np.zeros(406,dtype=np.int64)
        actual294=np.zeros(294,dtype=np.int64)
        for identity,v in new.items():
            assert metadata[identity]["field_id"]==intent[identity]["field_id"]
            key=vehicle_key(v,metadata[identity]["field_id"])
            i406=index[key]
            i294=keys294[key[0],key[1],key[3]]
            assert metadata[identity]["od_cell"]==i294
            actual406[i406]+=1
            actual294[i294]+=1
            restored=deepcopy(v)
            restored.set("depart",old[identity].get("depart"))
            assert ET.tostring(restored)==ET.tostring(old[identity])
            if identity in selected:
                move=selected[identity]
                source_i,target_i=move["source_assignment_cell406"],move["target_assignment_cell406"]
                assert keys[source_i][:3]==keys[target_i][:3] and keys[target_i]==key
                assert keys[source_i]==vehicle_key(old[identity],intent[identity]["field_id"])
                local=[i for i,k in enumerate(keys) if k[2]==key[2]]
                assert local[move["source_cell"]]==source_i and local[move["target_cell"]]==target_i
                assert keys[source_i][3]>=4 and keys[target_i][3]>=4 and move["field_id"]==key[2]
                assert float(v.get("depart"))==move["proposed_depart_s"] and float(old[identity].get("depart"))==move["source_depart_s"]
                assert native_ms(v.get("depart"))!=native_ms(old[identity].get("depart"))
                restored_meta=dict(metadata[identity])
                assert restored_meta.pop("depart_s")==float(v.get("depart"))
                restored_meta["od_cell"]=intent[identity]["od_cell"]
                assert restored_meta==intent[identity]
            else:
                assert ET.tostring(v)==ET.tostring(old[identity]) and metadata[identity]==intent[identity]
        assert np.array_equal(actual406,expected)
        assert sum(ET.tostring(new[i])==ET.tostring(old[i]) for i in old if native_ms(old[i].get("depart"))<3600000)==1953
        assert [i for i in old if i not in selected]==[i for i in new if i not in selected]
        assert Counter(r["field_id"] for r in metadata.values())==Counter(r["field_id"] for r in intent.values())
        assert all(int(actual406[groups==g].sum())==int(q[groups==g].sum()) for g in group_keys)
        vector294=json.loads((case/"od-vector.json").read_bytes())
        vector406=json.loads((case/"vector406.json").read_bytes())
        assert vector294["values"]==vector294["integer_counts"]==actual294.tolist() and not vector294["demand_generated_by_original_model"]
        assert vector406["values"]==actual406.tolist() and vector406["direction_sign"]==label
        assert metadata[DONOR]["field_id"]==Z5 and new[DONOR].find("stop").get("lane")=="24483344#1_1"
        outcomes[label]=dict(status="pass",changed_departures=16,unchanged8624_XML_and_intents_exact=True,
            no_cross_field_or_cross_OD_transfer=True,field13_totals_fixed=True,ODfield29_totals_fixed=True,OD21_totals_fixed=True,
            initial1953_XML_fixed=True,initial116_conditioned_cells_fixed=True,metadata_od_cell_actual294=True,separate406_vector_exact=True,
            prior_donor_Z5_not_reset=True,prior_donor_departure_changed=DONOR in selected,
            max_native_absolute_shift_s=max(abs(native_ms(m["proposed_depart_s"])-native_ms(m["source_depart_s"]))/1000 for m in moves),
            median_native_absolute_shift_s=float(np.median([abs(native_ms(m["proposed_depart_s"])-native_ms(m["source_depart_s"]))/1000 for m in moves])),
            zero_target406_cells=int(np.count_nonzero(expected==0)),source_bindings=bindings,
            source_proof_sha256=audit.digest(case/"scope-proof.json"))
    report=dict(schema="astra.hamburg.field-stratified-input-independent/v1",status="pass",native_runs_by_audit=0,
        source=str(SOURCE),source_reference_MAE=512/130,global_best_MAE=483/130,
        C182x406_rebuilt_exact=True,prior406_rebuilt_exact=True,columns406_positive=True,groups29=True,
        native208_reconciliation=True,rank_main130=int(np.linalg.matrix_rank(A[~initial])),rank_all182=int(np.linalg.matrix_rank(A)),
        direction_L1=32,changed_columns=19,case_scope=outcomes,
        plus_minus_selected_ID_overlap=len(selected_by_case["plus"] & selected_by_case["minus"]),
        hashes={str(p):audit.digest(p) for p in [STUDY/"direction.json",STUDY/"solver-inputs406.npz",STUDY/"columns406.json",STUDY/"rows182.json",STUDY/"solver-result.json",SOURCE/"evaluation/contributing-passages.json.gz"]},
        claim_boundary="C/q is a measured assignment description, not a Jacobian. Full row rank does not prove constrained integer zero feasibility or changed-traffic response. Positive and negative endpoints retain the same observed field-conditioned support and actual source requests. No legacy OD generator resets the newZ5 prior.")
    audit.save(OUT/"input-scope.json",report)
    print(json.dumps({k:report[k] for k in ["status","C182x406_rebuilt_exact","rank_main130","rank_all182"]}))
    return report


if __name__=="__main__":
    inspect()
