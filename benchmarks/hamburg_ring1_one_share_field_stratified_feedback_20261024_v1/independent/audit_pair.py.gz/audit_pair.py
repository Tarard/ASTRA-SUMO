"""Audit completed endpoints against both declared native references."""

import argparse
from collections import Counter
import gzip
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from inspect_inputs import DONOR, OUT, PROTECT, REPO, SOURCE, STUDY, audit, inspect, read_contributing_e1_passages

BEST=REPO/"outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"


def gates(measured, reference, zero, repeated, outside):
    return dict(safe=measured["safe"],healthy=measured["healthy"],all53556_zero=zero,
        no_repeated_vehicle_fields=not repeated,no_contributions_outside_primary_intention=not outside,
        main130_MAE_improves=measured["metrics130"]["MAE"]<reference["metrics130"]["MAE"],
        main130_SSE_not_worse=measured["metrics130"]["SSE"]<=reference["metrics130"]["SSE"],
        all182_TAE_not_worse=measured["metrics182"]["TAE"]<=reference["metrics182"]["TAE"])


def read(folder):
    return audit.evidence(folder/"prepared",folder/"evaluation",folder/"evaluation/contributing-passages.json.gz",8640)


def evaluate(label,reference,best):
    case=STUDY/label
    verdict=json.loads((case/"verdict.json").read_bytes())
    assert verdict["native_response_measured"] and verdict["status"]!="invalid"
    target=OUT/label
    target.mkdir(exist_ok=True)
    preflight=json.loads((case/"preflight.json").read_bytes())
    assert preflight["source_proof_sha256"]==audit.digest(case/"scope-proof.json")
    assert preflight["search_reference_verdict_sha256"]==audit.digest(SOURCE/"verdict.json")
    assert preflight["global_best_verdict_sha256"]==audit.digest(BEST/"verdict.json")
    assert set(preflight["versions"].values())=={"1.27.1"} and preflight["backend"]=="libsumo"
    assert audit.digest(case/"executed-driver.py")==preflight["executed_driver_sha256"]
    assert (case/"executed-driver.py").read_bytes()==(STUDY/"run_candidate.py").read_bytes()
    for path,h in preflight["binaries"].items():
        assert audit.digest(Path(path))==h
    for name,h in preflight["implementation_sha256"].items():
        assert audit.digest(case/"implementation"/name)==h
        if (SOURCE/"implementation"/name).exists():
            assert (case/"implementation"/name).read_bytes()==(SOURCE/"implementation"/name).read_bytes()
    for name,h in preflight["prepared_hashes"].items():
        assert audit.digest(case/"prepared"/name)==h
    helpers=REPO/"outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
    assert audit.digest(helpers/"audit_response.py")==preflight["helper_sha256"]
    assert audit.digest(helpers/"audit_scope.py")==preflight["helper_scope_sha256"]
    measured=read(case)
    native=case/"evaluation/native"
    run=json.loads((native/"run.json").read_bytes())
    raw=read_contributing_e1_passages(instant_file=native/"instant-e1.xml",periodic_file=native/"field-counts.xml",detector_ids=run["instant_to_periodic_ids"],step_length=.1)
    with gzip.open(case/"evaluation/contributing-passages.json.gz","rt",encoding="utf-8") as handle:
        assert raw==json.load(handle) and raw["reconciled"]
    requests=[json.loads((folder/"evaluation/native/native-request.json").read_bytes()) for folder in [SOURCE,case]]
    normalized=[json.dumps(r,sort_keys=True).replace(str(folder).replace("\\","\\\\"),"{case}") for r,folder in zip(requests,[SOURCE,case])]
    assert normalized[0]==normalized[1]
    monitor=json.loads((native/"stall-monitor.json").read_bytes())
    assert monitor["library_completed"] and monitor["native_returncode"] is None and monitor["native_version"]==[22,"SUMO 1.27.1"]
    assert audit.digest(Path(monitor["native_library"]["path"]))==monitor["native_library"]["sha256"]
    for data,key in [(reference,"before"),(measured,"after"),(best,"global_best")]:
        assert all(data[k]==verdict[key][k] for k in verdict[key])
    for name,rows in [("130",measured["main"]),("52",measured["initial"]),("182",measured["initial"]+measured["main"]),("40",measured["stations"])]:
        audit.table(target/(name+".csv"),rows)
    metadata={r["vehicle_id"]:r for r in json.loads((case/"prepared/lane-intentions.json").read_bytes())["vehicles"]}
    vehicles={r.get("id"):r for r in ET.parse(case/"prepared/demand.rou.xml").getroot().findall("vehicle")}
    repeat=[(i,f,n) for i,events in measured["by_vehicle"].items() for f,n in Counter(e["detector_id"] for e in events).items() if n>1]
    outside=[(i,e["detector_id"]) for i,events in measured["by_vehicle"].items() for e in events if e["detector_id"]!=metadata[i]["field_id"]]
    protected=[r for r in measured["initial"]+measured["main"] if r["detector_id"] in PROTECT]
    assert len(protected)==56
    protected_zero=audit.metrics(protected)["TAE"]==0
    search_gates=gates(measured,reference,protected_zero,repeat,outside)
    best_gates=gates(measured,best,protected_zero,repeat,outside)
    assert search_gates==verdict["gates"] and best_gates==verdict["global_best_gates"]
    selection="working_best_improved_candidate" if all(best_gates.values()) else "search_reference_improved_candidate" if all(search_gates.values()) else "rejected"
    assert selection==verdict["status"]
    field_rows=[]
    for field in sorted({k[0] for k in measured["periodic"]}):
        a,b=[audit.metrics([r for r in d["main"] if r["detector_id"]==field]) for d in [reference,measured]]
        field_rows.append(dict(field=field,reference_TAE=a["TAE"],after_TAE=b["TAE"],delta_TAE=b["TAE"]-a["TAE"],reference_SSE=a["SSE"],after_SSE=b["SSE"],delta_SSE=b["SSE"]-a["SSE"]))
    audit.table(target/"field13-response.csv",field_rows)
    moves=json.loads((case/"retiming-proposals.json").read_bytes())
    selected={r["vehicle_id"] for r in moves}
    sets={"selected16":selected,"unmodified8624":set(vehicles)-selected}
    counts={name:[audit.counts(d["by_vehicle"],ids) for d in [reference,measured]] for name,ids in sets.items()}
    cohort_response={}
    for name,ids in sets.items():
        def signature(data,identity):
            return [(e["detector_id"],e["interval_begin_s"],e["interval_end_s"]) for e in data["by_vehicle"].get(identity,[])]
        cohort_response[name]=dict(IDs=len(ids),before_events=sum(len(reference["by_vehicle"].get(i,[])) for i in ids),after_events=sum(len(measured["by_vehicle"].get(i,[])) for i in ids),field_or_bin_or_event_presence_changed=sum(signature(reference,i)!=signature(measured,i) for i in ids))
    response=[]
    for k in sorted(reference["periodic"]):
        a,b=[int(d["periodic"][k]["nVehContrib"]) for d in [reference,measured]]
        row=dict(field=k[0],begin_s=k[1],end_s=k[2],reference=a,after=b,delta=b-a)
        row.update({name+"_delta":c[1][k]-c[0][k] for name,c in counts.items()})
        assert row["selected16_delta"]+row["unmodified8624_delta"]==b-a
        response.append(row)
    audit.table(target/"native208-cohort-accounting.csv",response)
    audit.table(target/"selected16-actual-events.csv",[dict(vehicle_id=r["vehicle_id"],field=r["field_id"],source_assignment_cell406=r["source_assignment_cell406"],target_assignment_cell406=r["target_assignment_cell406"],old_requested_s=r["source_depart_s"],new_requested_s=r["proposed_depart_s"],old_actual_depart_s=reference["tripinfo"].get(r["vehicle_id"],{}).get("depart"),new_actual_depart_s=measured["tripinfo"].get(r["vehicle_id"],{}).get("depart"),before_events=audit.event_view(reference["by_vehicle"].get(r["vehicle_id"],[])),after_events=audit.event_view(measured["by_vehicle"].get(r["vehicle_id"],[]))) for r in moves])
    arrived={i for i,t in measured["tripinfo"].items() if float(t["arrival"])>=0}
    route_rows=ET.parse(native/"vehicle-routes.xml").getroot().findall("vehicle")
    assert {r.get("id") for r in route_rows}==arrived and len(route_rows)==len(arrived)==measured["completion"]["arrived"]
    assert all(r.find("route").get("edges")==vehicles[r.get("id")].find("route").get("edges") for r in route_rows)
    terminal=[]
    for identity in sorted(set(vehicles)-arrived):
        trip=measured["tripinfo"].get(identity)
        route=vehicles[identity].find("route").get("edges").split()
        terminal.append(dict(vehicle_id=identity,origin=route[0],destination=route[-1],field=metadata[identity]["field_id"],state="not_inserted" if trip is None or float(trip["depart"])<0 else "inserted_unfinished",events=audit.event_view(measured["by_vehicle"].get(identity,[]))))
    assert len(terminal)==measured["completion"]["waiting"]+measured["completion"]["running"]
    audit.table(target/"terminal-unfinished-inputs-and-events.csv",terminal)
    initial_keys=[(r["detector_id"],float(r["begin"]),float(r["end"])) for r in reference["initial"]]
    report=dict(schema="astra.hamburg.field-stratified-endpoint-independent/v1",audit_status="pass",case=label,native_runs_by_audit=0,selection=selection,
        search_reference_gates=search_gates,global_best_gates=best_gates,reference={k:reference[k] for k in verdict["before"]},after={k:measured[k] for k in verdict["after"]},global_best={k:best[k] for k in verdict["global_best"]},
        station40_max=max(abs(r["residual"]) for r in measured["stations"]),all53556=audit.metrics(protected),field_rows=field_rows,cohort_response=cohort_response,
        initial52_count_rows_exact=all(reference["periodic"][k]["nVehContrib"]==measured["periodic"][k]["nVehContrib"] for k in initial_keys),
        unique_complete_vehicles=len(measured["by_vehicle"]),repeated=repeat,outside=outside,
        prior_Z5_donor_actual_events=measured["by_vehicle"].get(DONOR,[]),prior_Z5_donor_actual_hold=[r for r in monitor["lane_section_hold"]["events"] if r["vehicle_id"]==DONOR],
        terminal_count=len(terminal),terminal_by_origin=dict(Counter(r["origin"] for r in terminal)),terminal_by_field=dict(Counter(r["field"] for r in terminal)),
        raw_source_hashes=measured["source_hashes"],binding_hashes={str(p):audit.digest(p) for p in [case/"preflight.json",case/"verdict.json",case/"scope-proof.json",case/"executed-driver.py",native/"vehicle-routes.xml"]},
        claim_boundary="Actual endogenous response of the preserved-request field-conditioned endpoint. Measured descriptor fractions are not derivatives. Reference improvement and global-best improvement are distinct gates. Cohort accounting is not causal separation, and neither rank nor a quantity bound proves zero feasibility.")
    audit.save(target/"summary.json",report)
    print(json.dumps(dict(case=label,audit_status="pass",selection=selection,after=report["after"])))
    return report,measured


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--case",choices=["plus","minus","all"],default="all")
    args=parser.parse_args()
    labels=["plus","minus"] if args.case=="all" else [args.case]
    assert all((STUDY/label/"verdict.json").exists() for label in labels),"Only read sealed verdict cases."
    input_scope=inspect()
    reference,best=read(SOURCE),read(BEST)
    results={label:evaluate(label,reference,best) for label in labels}
    if len(results)==2:
        solver=np.load(STUDY/"solver-inputs406.npz")
        row_keys=[(r["detector_id"],float(r["begin"]),float(r["end"])) for r in json.loads((STUDY/"rows182.json").read_bytes())]
        prediction=(solver["C"]/solver["q"])@np.array(json.loads((STUDY/"direction.json").read_bytes())["direction406"])
        predicted=dict(zip(row_keys,prediction.tolist()))
        rows=[]
        for key in sorted(reference["periodic"]):
            r,p,m=[int(d["periodic"][key]["nVehContrib"]) for d in [reference,results["plus"][1],results["minus"][1]]]
            rows.append(dict(field=key[0],begin_s=key[1],end_s=key[2],reference=r,plus=p,minus=m,plus_delta=p-r,minus_delta=m-r,endpoint_half_difference=(p-m)/2,symmetric_difference=p+m-2*r,predicted_assignment_plus_delta=predicted.get(key)))
        audit.table(OUT/"paired-native208-response.csv",rows)
        response_diagnostics={}
        masks={"initial52":lambda r:r["begin_s"]<3600,"main130":lambda r:3600<=r["begin_s"]<12600,"tail26":lambda r:r["begin_s"]>=12600,"all208":lambda r:True}
        for name,mask in masks.items():
            selected=[r for r in rows if mask(r)]
            modelled=[r for r in selected if r["predicted_assignment_plus_delta"] is not None]
            response_diagnostics[name]=dict(rows=len(selected),plus_count_sum_change=sum(r["plus_delta"] for r in selected),minus_count_sum_change=sum(r["minus_delta"] for r in selected),
                endpoint_half_difference_L1=sum(abs(r["endpoint_half_difference"]) for r in selected),symmetric_difference_L1=sum(abs(r["symmetric_difference"]) for r in selected),
                symmetric_nonzero_rows=sum(r["symmetric_difference"]!=0 for r in selected),prediction_available_rows=len(modelled),
                half_difference_vs_assignment_direction_L1=sum(abs(r["endpoint_half_difference"]-r["predicted_assignment_plus_delta"]) for r in modelled) if modelled else None)
        audit.save(OUT/"summary.json",dict(schema="astra.hamburg.field-stratified-pair-independent/v1",audit_status="pass",native_runs_by_audit=0,input_scope_status=input_scope["status"],
            source_reference_MAE=reference["metrics130"]["MAE"],global_best_MAE=best["metrics130"]["MAE"],endpoints={k:v[0] for k,v in results.items()},
            response_diagnostics=response_diagnostics,half_difference_definition="(native_plus-native_minus)/2 per one signed saved direction",symmetric_difference_definition="native_plus+native_minus-2*native_source",
            claim_boundary="Both sides share one deterministic OD-field count direction. Endpoint half-difference is a finite observed total response, not a Jacobian. Symmetric deviation shows departure from frozen assignment response. No field truth, causally separated controller effect or zero-feasibility proof."))


if __name__=="__main__":
    main()
