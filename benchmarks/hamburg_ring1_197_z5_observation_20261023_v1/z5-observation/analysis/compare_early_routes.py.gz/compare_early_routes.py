"""Compare sealed arrived-route exit records for the 20 delayed early contributors."""

from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parents[1]
REPO = STUDY.parents[1]
REFERENCE = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"
CURRENT = STUDY / "full/evaluation/native"
MATERIAL_DELAY_S = 5.0


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_routes(path, identities):
    result = {}
    for _, vehicle in ET.iterparse(path, events=("end",)):
        if vehicle.tag != "vehicle":
            continue
        identity = vehicle.get("id")
        if identity in identities:
            route = vehicle.find("route")
            assert route is not None and float(vehicle.get("arrival")) >= 0
            result[identity] = {"attrs": dict(vehicle.attrib), "edges": route.get("edges").split(),
                "exits": [float(t) for t in route.get("exitTimes").split()]}
        vehicle.clear()
    assert result.keys() == identities
    return result


def main():
    cohort_path = STUDY / "next-observation-cohort/cohort.csv"
    with cohort_path.open(encoding="utf-8", newline="") as handle:
        cohort = {r["vehicle_id"]: r for r in csv.DictReader(handle)}
    identities = {identity for identity, row in cohort.items() if
        "reference_6300_7200_later_or_no_complete_event" in row["selection_reasons"]}
    assert len(identities) == 20
    route_paths = [REFERENCE / "vehicle-routes.xml", CURRENT / "vehicle-routes.xml"]
    before, after = [read_routes(path, identities) for path in route_paths]
    edges, summaries = [], []
    for identity in sorted(identities):
        old, new = before[identity], after[identity]
        assert old["edges"] == new["edges"]
        assert len(old["edges"]) == len(old["exits"]) == len(new["exits"])
        old_entry, new_entry = [float(v["attrs"]["depart"]) for v in [old, new]]
        rows = []
        for index, (edge, old_exit, new_exit) in enumerate(zip(old["edges"], old["exits"], new["exits"])):
            row = {"vehicle_id": identity, "edge_index": index, "edge_id": edge,
                "reference_previous_exit_or_depart_s": old_entry, "candidate_previous_exit_or_depart_s": new_entry,
                "reference_exit_s": old_exit, "candidate_exit_s": new_exit,
                "cumulative_exit_delay_s": round(new_exit - old_exit, 10),
                "reference_exit_interval_s": round(old_exit - old_entry, 10),
                "candidate_exit_interval_s": round(new_exit - new_entry, 10),
                "exit_interval_delay_change_s": round((new_exit - new_entry) - (old_exit - old_entry), 10)}
            rows.append(row)
            old_entry, new_entry = old_exit, new_exit
        edges.extend(rows)
        first_any = next((r for r in rows if abs(r["cumulative_exit_delay_s"]) > .05), None)
        first_later = next((r for r in rows if r["cumulative_exit_delay_s"] >= MATERIAL_DELAY_S), None)
        max_increment = max(rows, key=lambda r: r["exit_interval_delay_change_s"])
        metadata = cohort[identity]
        summaries.append({"vehicle_id": identity, "requested_origin": metadata["requested_origin"],
            "source_od_cell": metadata["source_od_cell"], "requested_departure_s": metadata["requested_departure_s"],
            "reference_e1_time_s": metadata["reference_e1_time_s"], "candidate_e1_time_s": metadata["candidate_e1_time_s"],
            "e1_delay_s": metadata["e1_delay_s"], "candidate_e1_bin_begin_s": metadata["candidate_e1_bin_begin_s"],
            "reference_depart_s": old["attrs"]["depart"], "candidate_depart_s": new["attrs"]["depart"],
            "first_any_exit_difference_edge": first_any["edge_id"] if first_any else "",
            "first_any_exit_difference_s": first_any["cumulative_exit_delay_s"] if first_any else "",
            "first_ge5s_exit_delay_edge": first_later["edge_id"] if first_later else "",
            "first_ge5s_reference_exit_s": first_later["reference_exit_s"] if first_later else "",
            "first_ge5s_candidate_exit_s": first_later["candidate_exit_s"] if first_later else "",
            "first_ge5s_exit_delay_s": first_later["cumulative_exit_delay_s"] if first_later else "",
            "largest_positive_exit_interval_delay_edge": max_increment["edge_id"],
            "largest_positive_exit_interval_delay_s": max_increment["exit_interval_delay_change_s"],
            "reference_arrival_s": old["attrs"]["arrival"], "candidate_arrival_s": new["attrs"]["arrival"]})
    table(OUT / "early20-edge-exit-times.csv", edges)
    table(OUT / "early20-route-delay-summary.csv", summaries)
    result = {"schema": "astra.hamburg.197-z5-early-route-delay/v1", "status": "pass", "native_runs": 0,
        "vehicles": len(identities), "all_arrived_in_both_runs": True, "all_route_edges_identical": True,
        "first_ge5s_edge_counts": dict(Counter(r["first_ge5s_exit_delay_edge"] for r in summaries)),
        "largest_positive_exit_interval_edge_counts": dict(Counter(r["largest_positive_exit_interval_delay_edge"] for r in summaries)),
        "material_cumulative_delay_threshold_s": MATERIAL_DELAY_S,
        "source_hashes": {str(path.resolve()): digest(path) for path in [cohort_path, *route_paths]},
        "claim_boundary": "ExitTimes show the recorded time at each ordinary-road exit, not full stepwise positions. Differences of successive ordinary-road exit times also include the intervening junction and must not be called isolated road travel times. The 5s threshold is a declared diagnostic marker, not a causal or statistical test. First divergence does not establish the mechanism. Observer FCD is not read here."}
    save(OUT / "early20-route-proof.json", result)
    print(json.dumps({k: result[k] for k in ["vehicles", "first_ge5s_edge_counts", "largest_positive_exit_interval_edge_counts"]}, ensure_ascii=False))
    for row in summaries:
        print(json.dumps(row, ensure_ascii=False))


if __name__ == "__main__":
    main()
