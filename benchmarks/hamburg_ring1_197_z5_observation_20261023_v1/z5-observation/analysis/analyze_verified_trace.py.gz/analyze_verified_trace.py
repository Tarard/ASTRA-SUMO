"""Read only after the complete native observation passed all 12 parity checks."""

from bisect import bisect_right
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from compare_early_routes import OUT, STUDY, digest, save, table


TRACE = OUT.parent / "baseline"
STOP_SPEED = .1
NEAR_GAP = 10.0
TLS_IDS = {"LSA104_part0", "LSA118_part0", "LSA119_part0", "GS_266199063", "1975693623"}


def category(row):
    if row["speed"] > STOP_SPEED:
        return "moving"
    if not row["leader_id"] or row["leader_gap"] < 0:
        return "stopped_leader_not_reported"
    if row["leader_gap"] > NEAR_GAP:
        return "stopped_reported_leader_far"
    return "stopped_near_stopped_leader" if row["leader_speed"] <= STOP_SPEED else "stopped_near_moving_leader"


def main():
    gate_path = TRACE / "record-result.json"
    gate = json.loads(gate_path.read_bytes())
    assert gate["status"] == "pass" and len(gate["checks"]) == 12 and all(gate["checks"].values())
    cohort_path = STUDY / "next-observation-cohort/cohort.csv"
    with cohort_path.open(encoding="utf-8", newline="") as handle:
        cohort = {r["vehicle_id"]: r for r in csv.DictReader(handle)}
    identities = set(cohort)
    declared = json.loads((TRACE / "observed-vehicle-ids.json").read_bytes())
    assert len(identities) == 54 and set(declared["vehicles"]) == identities
    assert declared["sha256"] == digest(cohort_path)
    samples, by_time = defaultdict(list), defaultdict(dict)
    now = None
    for event, element in ET.iterparse(TRACE / "cohort-fcd.xml", events=("start", "end")):
        if event == "start" and element.tag == "timestep":
            now = float(element.get("time"))
        elif event == "end" and element.tag == "vehicle":
            identity = element.get("id")
            assert identity in identities
            row = {"vehicle_id": identity, "time_s": now, "lane": element.get("lane"),
                "pos_m": float(element.get("pos")), "speed": float(element.get("speed")),
                "leader_id": element.get("leaderID", ""), "leader_gap": float(element.get("leaderGap", "-1")),
                "leader_speed": float(element.get("leaderSpeed", "-1"))}
            row["classification"] = category(row)
            samples[identity].append(row)
            by_time[now][identity] = row
            element.clear()
        elif event == "end" and element.tag == "timestep":
            element.clear()
    assert set(samples) == identities
    assert all(b["time_s"] - a["time_s"] == 1 for rows in samples.values() for a, b in zip(rows, rows[1:]))
    states, root = defaultdict(list), None
    for event, element in ET.iterparse(TRACE / "tls-switch-states.xml", events=("start", "end")):
        if root is None:
            root = element
        if event == "end" and element.tag == "tlsState":
            if element.get("id") in TLS_IDS:
                states[element.get("id")].append({"time_s": float(element.get("time")),
                    "state": element.get("state"), "phase": element.get("phase")})
            root.clear()
    state_times = {tls: [r["time_s"] for r in rows] for tls, rows in states.items()}
    assert states.keys() == TLS_IDS
    net = ET.parse(TRACE / "network.net.xml").getroot()
    lane_lengths = {lane.get("id"): float(lane.get("length")) for edge in net.findall("edge") for lane in edge.findall("lane")}
    connections = net.findall("connection")
    routes = {v.get("id"): v.find("route").get("edges").split() for v in ET.parse(TRACE / "demand.rou.xml").getroot().findall("vehicle")}
    internal_bindings = defaultdict(list)
    direct = defaultdict(list)
    for connection in connections:
        if connection.get("tl"):
            direct[connection.get("from") + "_" + connection.get("fromLane")].append(dict(connection.attrib))
            if connection.get("via"):
                internal_bindings[connection.get("via")].append(dict(connection.attrib))
    holds = defaultdict(list)
    hold_data = json.loads((TRACE / "stall-monitor.json").read_bytes())["lane_section_hold"]
    for kind, events in [("detector", hold_data["events"]), ("body", hold_data["junction_body_hold"]["events"])]:
        pending = {}
        for event in events:
            identity = event["vehicle_id"]
            if identity not in identities:
                continue
            if event["event"] == "held":
                pending[identity] = event
            elif identity in pending:
                begin = pending.pop(identity)
                holds[identity].append({"kind": kind, "begin_s": begin["time_s"], "end_s": event["time_s"], "lane_at_begin": begin["lane"]})
        for identity, begin in pending.items():
            holds[identity].append({"kind": kind, "begin_s": begin["time_s"], "end_s": 14400, "lane_at_begin": begin["lane"], "still_held": True})
    lane_counts, lane_ids = defaultdict(Counter), defaultdict(set)
    segments, stop_segments = [], []
    for identity, rows in samples.items():
        for row in rows:
            lane_counts[row["lane"]][row["classification"]] += 1
            lane_ids[row["lane"]].add(identity)
        start = 0
        for index in range(1, len(rows) + 1):
            if index < len(rows) and rows[index]["lane"] == rows[start]["lane"]:
                continue
            part = rows[start:index]
            segments.append({"vehicle_id": identity, "lane": part[0]["lane"], "first_sample_s": part[0]["time_s"],
                "last_sample_s": part[-1]["time_s"], "sample_count": len(part), "first_pos_m": part[0]["pos_m"],
                "last_pos_m": part[-1]["pos_m"], "stopped_samples": sum(r["speed"] <= STOP_SPEED for r in part)})
            start = index
        start = None
        for index in range(len(rows) + 1):
            stopped = index < len(rows) and rows[index]["speed"] <= STOP_SPEED
            if start is not None and (not stopped or any(rows[index][k] != rows[start][k] for k in ["lane", "classification", "leader_id"])):
                part = rows[start:index]
                stop_segments.append({"vehicle_id": identity, "lane": part[0]["lane"], "classification": part[0]["classification"],
                    "leader_id": part[0]["leader_id"], "first_sample_s": part[0]["time_s"], "last_sample_s": part[-1]["time_s"],
                    "sample_count": len(part), "pos_m": part[0]["pos_m"], "leader_gap_min_m": min(r["leader_gap"] for r in part),
                    "leader_gap_max_m": max(r["leader_gap"] for r in part)})
                start = None
            if stopped and start is None:
                start = index

    def scene(identity, time):
        row = dict(by_time[time][identity])
        row["lane_length_m"] = lane_lengths[row["lane"]]
        row["distance_to_lane_end_m"] = round(row["lane_length_m"] - row["pos_m"], 10)
        row["leader_sample_same_time_if_in_cohort"] = by_time[time].get(row["leader_id"])
        row["hold_intervals"] = [h for h in holds[identity] if h["begin_s"] <= time < h["end_s"]]
        row["actual_tls_states"] = {tls: entries[bisect_right(state_times[tls], time) - 1] for tls, entries in states.items()}
        road = row["lane"].rsplit("_", 1)[0]
        route = routes[identity]
        next_road = route[route.index(road) + 1] if road in route and route.index(road) + 1 < len(route) else None
        row["requested_next_ordinary_road"] = next_road
        row["direct_controlled_movements"] = [{**c, "actual_state": row["actual_tls_states"][c["tl"]]["state"][int(c["linkIndex"])]}
            for c in direct.get(row["lane"], []) if c["tl"] in row["actual_tls_states"] and c["to"] == next_road
            and "passenger" not in c.get("disallow", "").split() and (not c.get("allow") or "passenger" in c["allow"].split())]
        row["upstream_control_binding_if_on_first_internal_lane"] = [{**c,
            "actual_state_at_sample_not_entry_time": row["actual_tls_states"][c["tl"]]["state"][int(c["linkIndex"])]}
            for c in internal_bindings.get(row["lane"], []) if c["tl"] in row["actual_tls_states"]]
        return row

    terminal = {identity for identity, r in cohort.items() if r["candidate_terminal"] == "True"}
    terminal_rows = [scene(identity, samples[identity][-1]["time_s"]) for identity in sorted(terminal)]
    assert len(terminal_rows) == 34 and all(r["time_s"] == 14399 for r in terminal_rows)
    table(OUT / "lane-stay-segments.csv", segments)
    table(OUT / "stopped-segments.csv", sorted(stop_segments, key=lambda r: -r["sample_count"]))
    table(OUT / "lane-sample-summary.csv", [{"lane": lane, "vehicles": len(lane_ids[lane]),
        "sample_count": sum(counts.values()), **{k: counts[k] for k in ["moving", "stopped_near_stopped_leader",
        "stopped_near_moving_leader", "stopped_reported_leader_far", "stopped_leader_not_reported"]}}
        for lane, counts in sorted(lane_counts.items())])
    save(OUT / "terminal34-final-scenes.json", terminal_rows)
    early_ids = identities - terminal
    early_scenes = []
    for identity in sorted(early_ids):
        parts = [r for r in stop_segments if r["vehicle_id"] == identity and r["lane"].startswith("24483344#")]
        if parts:
            longest = max(parts, key=lambda r: r["sample_count"])
            early_scenes.append(scene(identity, longest["first_sample_s"]))
    save(OUT / "early20-representative-scenes.json", early_scenes)
    changes = []
    for _, element in ET.iterparse(TRACE / "lanechanges.xml", events=("end",)):
        if element.tag in {"change", "changeStarted", "changeEnded"} and element.get("id") in identities:
            changes.append({"tag": element.tag, **element.attrib})
        element.clear()
    save(OUT / "cohort-lanechanges.json", changes)
    paths = [gate_path, cohort_path, TRACE / "observed-vehicle-ids.json", TRACE / "cohort-fcd.xml", TRACE / "lanechanges.xml",
        TRACE / "tls-switch-states.xml", TRACE / "network.net.xml", TRACE / "stall-monitor.json", TRACE / "demand.rou.xml", Path(__file__).resolve()]
    proof = {"schema": "astra.hamburg.197-z5-observation/v1", "status": "pass", "native_runs": 0,
        "parity_checks": gate["checks"], "vehicles": len(samples), "samples": sum(map(len, samples.values())),
        "terminal34_final_lanes": dict(Counter(r["lane"] for r in terminal_rows)),
        "terminal34_final_leader_categories": dict(Counter(r["classification"] for r in terminal_rows)),
        "definitions": {"stopped_speed_le_m_s": STOP_SPEED, "near_leader_gap_le_m": NEAR_GAP,
            "sampling": "1-second FCD sample counts, not exact continuous stopped durations",
            "clock": "Direct native XML timestamps; no poststep API timestamps used",
            "leader_boundary": "Native route-sensitive leader search up to configured200m. Missing leader is not proof of empty downstream; leader outside cohort has no observed position here."},
        "source_hashes": {str(path.resolve()): digest(path) for path in paths},
        "claim_boundary": "Actual lane/position/speed and native reported leader are observed. Signal states alone do not prove a route is unconstrained or establish why a vehicle remained stopped. No new simulation or candidate was run by this audit."}
    save(OUT / "trace-proof.json", proof)
    print(json.dumps({k: proof[k] for k in ["vehicles", "samples", "terminal34_final_lanes", "terminal34_final_leader_categories"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
