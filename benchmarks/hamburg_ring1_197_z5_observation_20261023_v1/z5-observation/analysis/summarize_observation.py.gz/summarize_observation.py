"""Seal observed Z5 locations and a single bounded follow-up question."""

from collections import Counter
import csv
import json

from compare_early_routes import OUT, STUDY, digest, save, table


def main():
    with (STUDY / "next-observation-cohort/cohort.csv").open(encoding="utf-8", newline="") as handle:
        cohort = {r["vehicle_id"]: r for r in csv.DictReader(handle)}
    terminal = json.loads((OUT / "terminal34-final-scenes.json").read_bytes())
    final_rows = []
    for row in terminal:
        metadata = cohort[row["vehicle_id"]]
        states = row["actual_tls_states"]
        final_rows.append({"vehicle_id": row["vehicle_id"], "time_s": row["time_s"], "lane": row["lane"],
            "pos_m": row["pos_m"], "speed_m_s": row["speed"], "leader_id": row["leader_id"],
            "leader_gap_m": row["leader_gap"], "leader_speed_m_s": row["leader_speed"], "classification": row["classification"],
            "source_od_cell": metadata["source_od_cell"], "requested_departure_s": metadata["requested_departure_s"],
            "reference_e1_time_s": metadata["reference_e1_time_s"], "candidate_e1_time_s": metadata["candidate_e1_time_s"],
            "candidate_own_field_completed": bool(metadata["candidate_e1_time_s"]),
            "119_link13_state": states["LSA119_part0"]["state"][13],
            "118_link41_state": states["LSA118_part0"]["state"][41],
            "GS266_link4_state": states["GS_266199063"]["state"][4],
            "GS266_link5_state": states["GS_266199063"]["state"][5]})
    table(OUT / "terminal34-last-observed.csv", final_rows)
    with (OUT / "early20-route-delay-summary.csv").open(encoding="utf-8", newline="") as handle:
        early = list(csv.DictReader(handle))
    cross = [r for r in early if float(r["candidate_e1_bin_begin_s"]) == 7200]
    assert len(cross) == 8
    table(OUT / "eight-cross-bin-route-differences.csv", cross)
    changes = json.loads((OUT / "cohort-lanechanges.json").read_bytes())
    early_ids = {r["vehicle_id"] for r in early}
    relevant_changes = [r for r in changes if r["id"] in early_ids and
        ("24483344#" in r.get("from", "") or "24483344#" in r.get("to", ""))]
    assert not relevant_changes
    context = json.loads((OUT / "receiving-context.json").read_bytes())
    trace = json.loads((OUT / "trace-proof.json").read_bytes())
    result = {"schema": "astra.hamburg.197-z5-diagnosis/v1", "status": "pass", "native_runs_by_analysis": 0,
        "observation_parity_all12_pass": all(trace["parity_checks"].values()), "observed_vehicles": 54,
        "observed_fcd_samples": trace["samples"],
        "terminal34_last_sample_s": 14399, "terminal34_moving_at_last_sample": sum(r["speed_m_s"] > .1 for r in final_rows),
        "terminal34_stopped_at_last_sample": sum(r["speed_m_s"] <= .1 for r in final_rows),
        "terminal34_field_complete": sum(r["candidate_own_field_completed"] for r in final_rows),
        "terminal34_final_lane_counts": dict(Counter(r["lane"] for r in final_rows)),
        "early20_no_recorded_lane_change_on244": True,
        "original_target_6300_7200": 59, "reference_measured_6300_7200": 32, "new_measured_6300_7200": 24,
        "preexisting_target_deficit": 27, "additional_cross_bin_loss": 8,
        "eight_cross_bin_new_event_delay_range_s": [min(float(r["e1_delay_s"]) for r in cross), max(float(r["e1_delay_s"]) for r in cross)],
        "actual119_and_GS266_signals_unchanged_all14400s": context["actual_signal_comparison"],
        "single_next_action": "Source-check the 119 receiving chain :LSA119_part0_12_1 (69.101885m) ->79014037#1_1 (3.46m), GS_266199063, then186713429 (5.38726m), against the existing official119 MAP and frozen OSM. Establish physical junction/control ownership and source-supported storage before proposing a geometry or signal change. Keep the current inputs and native safety unchanged.",
        "why_this_question": "Early same-ID exit records first diverge only on244#0/#1. Native119 andGS266 programs and actual state histories are identical. Recorded stops under119G coincide both with a moving distant route-sensitive leader and, later, with an anonymous positive receiving queue whileGS266 is red. The short receiving chain therefore deserves one source/entry-condition check; these observations do not prove a duplicate controller or an entry-logic defect.",
        "missing_runtime_fields_for_mechanism": ["native junction foes and response flags at the stopped head", "actual IDs/positions on receiving and conflicting internal lanes", "nextTLS and pending stop state at the head"],
        "claim_boundary": "The 54 IDs are a complete declared diagnostic cohort, not a random network sample. Do not generalize its sample shares to all8640 trips. A single final FCD snapshot is not a deadlock diagnosis. None of the observations makes the original27-vehicle target deficit equal to the additional8 cross-bin loss, or causally separates the combined197 repair."}
    save(OUT / "diagnosis.json", result)
    print(json.dumps({k: result[k] for k in ["observed_fcd_samples", "terminal34_moving_at_last_sample", "terminal34_stopped_at_last_sample", "terminal34_field_complete", "eight_cross_bin_new_event_delay_range_s"]}, ensure_ascii=False))
    files = [{"path": path.relative_to(OUT).as_posix(), "size_bytes": path.stat().st_size, "sha256": digest(path)}
        for path in sorted(OUT.rglob("*")) if path.is_file() and path != OUT / "manifest.json" and "__pycache__" not in path.parts]
    save(OUT / "manifest.json", {"schema": "astra.hamburg.197-z5-diagnosis-manifest/v1", "native_runs_by_analysis": 0, "files": files})


if __name__ == "__main__":
    main()
