"""Join native signals, receiving queues and observed stop-line samples."""

from bisect import bisect_right
from collections import defaultdict
import json
import xml.etree.ElementTree as ET

from analyze_verified_trace import TRACE
from compare_early_routes import OUT, REPO, STUDY, digest, save, table


OLD = REPO / "outputs/hamburg-z5-upstream-delay-20261023-v1/trace/baseline"
OLD_NATIVE = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/probe-minus1/evaluation/native"
TLS = {"LSA119_part0": [13], "GS_266199063": [4, 5]}
LANES = {"79014037#1_1", "186713429_2", "186713429_3", "24483344#1_1", "24483344#0_1"}
TIMES = {6655., 6658., 6735., 6739., 6740., 6745., 6748., 6825., 6829., 6830., 6915., 6920.,
    7005., 7010., 7095., 7100., 7185., 7190., 7285., 7365., 11246., 11980., 12520., 14399.}


def read_states(path):
    result = defaultdict(list)
    for _, element in ET.iterparse(path, events=("end",)):
        if element.tag == "tlsState" and element.get("id") in TLS:
            result[element.get("id")].append({"time_s": float(element.get("time")), "state": element.get("state"), "phase": element.get("phase")})
        element.clear()
    return result


def at(states, times, tls, time):
    return states[tls][bisect_right(times[tls], time) - 1]


def queue_frames(path):
    result = defaultdict(dict)
    time = None
    for event, element in ET.iterparse(path, events=("start", "end")):
        if event == "start" and element.tag == "data":
            time = float(element.get("timestep"))
        elif event == "end" and element.tag == "lane":
            if time in TIMES and element.get("id") in LANES:
                result[time][element.get("id")] = dict(element.attrib)
            element.clear()
        elif event == "end" and element.tag == "data":
            element.clear()
    return result


def main():
    for root in [OLD, TRACE]:
        gate = json.loads((root / "record-result.json").read_bytes())
        assert gate["status"] == "pass" and len(gate["checks"]) == 12 and all(gate["checks"].values())
    states = {name: read_states(root / "tls-switch-states.xml") for name, root in [("reference", OLD), ("candidate", TRACE)]}
    times = {name: {tls: [r["time_s"] for r in records] for tls, records in entries.items()} for name, entries in states.items()}
    programs = [{p.get("id"): ET.canonicalize(ET.tostring(p, encoding="unicode"), strip_text=True)
        for p in ET.parse(root / "signal-programs.add.xml").getroot().findall("tlLogic")} for root in [OLD, TRACE]]
    assert all(programs[0][tls] == programs[1][tls] for tls in TLS)
    differences = {}
    for tls in TLS:
        first = None
        differing = 0
        for tick in range(144000):
            time = tick / 10
            a, b = [at(states[name], times[name], tls, time) for name in ["reference", "candidate"]]
            if (a["phase"], a["state"]) != (b["phase"], b["state"]):
                first = time if first is None else first
                differing += 1
        differences[tls] = {"first_actual_phase_or_state_difference_s": first, "differing_point1s_samples": differing}
    intervals = []
    for name, entries in states.items():
        for tls, links in TLS.items():
            records = entries[tls]
            for link in links:
                for index, record in enumerate(records):
                    end = records[index + 1]["time_s"] if index + 1 < len(records) else 14400
                    begin = record["time_s"]
                    if end <= 6300 or begin >= 7500:
                        continue
                    intervals.append({"case": name, "tls": tls, "link_index": link, "begin_s": max(begin, 6300),
                        "end_s": min(end, 7500), "phase": record["phase"], "signal": record["state"][link]})
    table(OUT / "early-actual-signal-intervals.csv", intervals)
    queues = {name: queue_frames(path) for name, path in [("reference", OLD_NATIVE / "queues.xml"), ("candidate", TRACE / "queues.xml")]}
    frames = []
    for name in queues:
        for time in sorted(TIMES):
            for lane in sorted(LANES):
                entry = queues[name][time].get(lane)
                frames.append({"case": name, "time_s": time, "lane": lane, "queue_record_present": bool(entry),
                    "queueing_length_m": entry["queueing_length"] if entry else "",
                    "queueing_length_experimental_m": entry["queueing_length_experimental"] if entry else ""})
    table(OUT / "receiving-queue-frames.csv", frames)
    head_samples = []
    time = None
    for event, element in ET.iterparse(TRACE / "cohort-fcd.xml", events=("start", "end")):
        if event == "start" and element.tag == "timestep":
            time = float(element.get("time"))
        elif event == "end" and element.tag == "vehicle":
            if element.get("lane") == "24483344#1_1" and float(element.get("pos")) >= 90 and float(element.get("speed")) <= .1:
                signals = {tls: at(states["candidate"], times["candidate"], tls, time) for tls in TLS}
                if signals["LSA119_part0"]["state"][13] == "G":
                    head_samples.append({"time_s": time, "vehicle_id": element.get("id"), "lane": element.get("lane"),
                        "pos_m": element.get("pos"), "speed_m_s": element.get("speed"), "leader_id": element.get("leaderID", ""),
                        "leader_gap_m": element.get("leaderGap", "-1"), "leader_speed_m_s": element.get("leaderSpeed", "-1"),
                        "119_link13": "G", "GS266_phase": signals["GS_266199063"]["phase"],
                        "GS266_link4": signals["GS_266199063"]["state"][4], "GS266_link5": signals["GS_266199063"]["state"][5]})
            element.clear()
        elif event == "end" and element.tag == "timestep":
            element.clear()
    table(OUT / "actual-stopline-stopped-under-green.csv", head_samples)
    net = ET.parse(TRACE / "network.net.xml").getroot()
    static = [{"edge_id": edge.get("id"), "lanes": [{"id": lane.get("id"), "length_m": lane.get("length")} for lane in edge.findall("lane")]}
        for edge in net.findall("edge") if edge.get("id") in {":LSA119_part0_12", "79014037#1", "186713429"}]
    paths = [TRACE / "record-result.json", OLD / "record-result.json", TRACE / "tls-switch-states.xml", OLD / "tls-switch-states.xml",
        TRACE / "signal-programs.add.xml", OLD / "signal-programs.add.xml", TRACE / "queues.xml", OLD_NATIVE / "queues.xml",
        TRACE / "cohort-fcd.xml", TRACE / "network.net.xml", STUDY / "full-response-audit/complete/remaining-error-summary.json"]
    report = {"schema": "astra.hamburg.197-z5-receiving-context/v1", "status": "pass", "native_runs": 0,
        "source_and_current_programs_identical_for_119_and_GS266": True, "actual_signal_comparison": differences,
        "stopline_stopped_under119G_samples": len(head_samples), "receiving_chain_lengths": static,
        "source_hashes": {str(path.resolve()): digest(path) for path in paths},
        "claim_boundary": "Queue lengths have no vehicle identity and are not assigned to a cohort leader. No queue record is not proof of empty receiving road. A native reported distant leader is route-sensitive and not proof of an empty crossing. Static signal programs remain identical; differing actual actuated histories are a total response, not an isolated causal effect."}
    save(OUT / "receiving-context.json", report)
    print(json.dumps({k: report[k] for k in ["actual_signal_comparison", "stopline_stopped_under119G_samples", "receiving_chain_lengths"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
