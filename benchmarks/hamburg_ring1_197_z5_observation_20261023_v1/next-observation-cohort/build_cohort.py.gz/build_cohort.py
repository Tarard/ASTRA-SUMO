"""Select same-input IDs for an observation-only replay; do not run SUMO."""

from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
ROOT = STUDY.parents[1]
SOURCE = ROOT / "outputs/hamburg-classical-od-calibration-20261023-v1"
FIELD = "hh_0119_Z_5_30494"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def read_events(path):
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    assert data["reconciled"] is True
    events = {}
    for event in data["passages"]:
        if event["detector_id"] == FIELD:
            identity = event["vehicle_id"]
            assert identity not in events
            events[identity] = event
    return events


def main():
    evaluation = SOURCE / "probe-minus1/evaluation"
    full = STUDY / "full/evaluation"
    model_path = SOURCE / "prepared/od-model.json"
    intent_path = evaluation / "lane-intentions.json"
    demand_path = evaluation / "demand.rou.xml"
    old_events_path = SOURCE / "selected-next-diagnosis/selected-contributing-passages.json.gz"
    new_events_path = full / "contributing-passages.json.gz"
    terminal_path = STUDY / "full-response-audit/complete/terminal34-source-candidate-events.csv"
    assert demand_path.read_bytes() == (full / "demand.rou.xml").read_bytes()
    assert intent_path.read_bytes() == (full / "lane-intentions.json").read_bytes()
    old, new = [read_events(path) for path in [old_events_path, new_events_path]]
    model = json.loads(model_path.read_bytes())
    intents = {r["vehicle_id"]: r for r in json.loads(intent_path.read_bytes())["vehicles"]}
    vehicles = {v.get("id"): v for v in ET.parse(demand_path).getroot().findall("vehicle")}
    old_trips, new_trips = [{r.get("id"): r.attrib for r in ET.parse(path).getroot().findall("tripinfo")}
        for path in [evaluation / "native/tripinfo.xml", full / "native/tripinfo.xml"]]
    with terminal_path.open(encoding="utf-8-sig", newline="") as handle:
        terminal = {r["vehicle_id"] for r in csv.DictReader(handle)}
    assert terminal == {identity for identity, trip in new_trips.items() if float(trip["arrival"]) < 0}
    assert len(terminal) == 34
    source_bin = {identity for identity, event in old.items() if event["interval_begin_s"] == 6300}
    current_bin = {identity for identity, event in new.items() if event["interval_begin_s"] == 6300}
    delayed = {identity for identity in source_bin if identity not in new or
        new[identity]["notification_time_s"] > old[identity]["notification_time_s"] + 1e-7}
    cohort = terminal | delayed
    rows = []
    for identity in sorted(terminal | source_bin):
        vehicle = vehicles[identity]
        route = vehicle.find("route").get("edges").split()
        intent = intents[identity]
        cell = model["cells"][intent["od_cell"]]
        depart = float(vehicle.get("depart"))
        assert intent["field_id"] == FIELD
        assert (cell["origin"], cell["destination"]) == (route[0], route[-1])
        assert cell["begin_s"] <= depart < cell["end_s"]
        before, after = old.get(identity), new.get(identity)
        before_time = before["notification_time_s"] if before else None
        after_time = after["notification_time_s"] if after else None
        reasons = []
        if identity in terminal:
            reasons.append("all_34_terminal")
        if identity in delayed:
            reasons.append("reference_6300_7200_later_or_no_complete_event")
        rows.append({
            "vehicle_id": identity, "selected_for_observation": identity in cohort,
            "selection_reasons": ";".join(reasons), "source_od_cell": intent["od_cell"],
            "requested_origin": route[0], "requested_destination": route[-1],
            "source_cell_begin_s": cell["begin_s"], "source_cell_end_s": cell["end_s"],
            "requested_departure_s": vehicle.get("depart"), "departure_bin": int(depart // 900),
            "prior_field": FIELD,
            "reference_e1_time_s": before_time if before else "",
            "candidate_e1_time_s": after_time if after else "",
            "e1_delay_s": round(after_time - before_time, 10) if before and after else "",
            "reference_e1_bin_begin_s": before["interval_begin_s"] if before else "",
            "candidate_e1_bin_begin_s": after["interval_begin_s"] if after else "",
            "reference_actual_depart_s": old_trips[identity]["depart"],
            "candidate_actual_depart_s": new_trips[identity]["depart"],
            "reference_arrival_s": old_trips[identity]["arrival"],
            "candidate_arrival_s": new_trips[identity]["arrival"],
            "candidate_terminal": identity in terminal,
            "route_edges": " ".join(route),
            "explicit_stops": json.dumps([s.attrib for s in vehicle.findall("stop")], ensure_ascii=False),
        })
    selected = [r for r in rows if r["selected_for_observation"]]
    source_rows = [r for r in rows if r["vehicle_id"] in source_bin]
    assert len(cohort) == len(selected) == 54 and len(delayed) == 20 and len(source_rows) == 32
    assert not (terminal & source_bin)
    assert len(source_bin - current_bin) == 8 and len(current_bin - source_bin) == 0
    table(OUT / "cohort.csv", selected)
    table(OUT / "source-bin-all32.csv", source_rows)
    inputs = [model_path, intent_path, demand_path, full / "demand.rou.xml", full / "lane-intentions.json",
        old_events_path, new_events_path, evaluation / "native/tripinfo.xml", full / "native/tripinfo.xml",
        terminal_path, STUDY / "full-response-audit/manifest.json", STUDY / "full/verdict.json",
        STUDY / "candidate-v5/network.net.xml", STUDY / "candidate-v5/control.add.xml"]
    result = {"schema": "astra.hamburg.197-observation-cohort/v1", "status": "pass", "native_runs": 0,
        "cohort_csv": "cohort.csv", "cohort_vehicle_count": len(cohort), "vehicle_ids": sorted(cohort),
        "terminal_all_included": len(terminal), "early_reference_bin": [6300, 7200],
        "early_reference_bin_actual_count": len(source_bin), "early_candidate_bin_actual_count": len(current_bin),
        "delayed_early_bin_included": len(delayed), "delayed_within_same_bin": len(delayed & current_bin),
        "delayed_to_later_bin": len(delayed - current_bin),
        "reference_bin_unchanged_event_controls_in_companion_csv": len(source_bin - delayed),
        "lost_from_bin_vehicle_ids": sorted(source_bin - current_bin), "entered_bin_vehicle_ids": sorted(current_bin - source_bin),
        "same_input_demand_and_intention_bytes": True,
        "source_od_cell_counts": dict(Counter(str(r["source_od_cell"]) for r in selected)),
        "requested_origin_counts": dict(Counter(r["requested_origin"] for r in selected)),
        "source_hashes": {str(p.resolve()): digest(p) for p in inputs},
        "selection_rule": "Include every current unfinished ID and every original-selected 119 Z5 contributor assigned to [6300,7200) whose new complete event is later or absent. No cap or sampling was applied; all 20 delayed early-bin contributors are included.",
        "event_time_semantics": "Notification times and periodic interval membership from reconciled nVehContrib contributing passages. Missing complete event is blank, not zero. Actual .1s notification is distinct from continuous detector leave time.",
        "observation_scope": "Read-only cohort for possible replay with unchanged input/control/driver, all 51 actual TLS states, lane/position/speed, leader route context and body-hold/lane-change observations. This script launches no replay.",
        "claim_boundary": "Same IDs and byte-identical demand give paired correspondence. These terminal IDs and count changes do not locate a physical queue or isolate causes among the two new connections, three priority changes, actuation, leader interactions or lane holds. No assignment model or predicted counts are generated."}
    save(OUT / "basis.json", result)
    print(json.dumps({k: result[k] for k in ["cohort_vehicle_count", "terminal_all_included", "early_reference_bin_actual_count", "early_candidate_bin_actual_count", "delayed_early_bin_included", "delayed_within_same_bin", "delayed_to_later_bin", "requested_origin_counts"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
