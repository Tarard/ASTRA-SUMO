# GS266：跨出口车道响应的静态解释

状态：`review_required`。只读 SUMO 1.27.1 固定源码和 priority-v3 的六条原生内部曲线；没有生成候选或运行 SUMO。网络 SHA256 为 `99f208c982b5c6d0251d552b412bfdc5ec6f7f8344705f580278dc376c521c00`。详细来源哈希、原连接及 request 表保存在 [JSON](lane-foes-analysis.json)，15 组曲线计算保存在 [CSV](lane-foes-geometry.csv)。

**默认响应来自入口道路层面的保守规则。** `check-lane-foes.all` 默认 false（[NBFrame.cpp 390–392](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBFrame.cpp#L390)）。`NBRequest.cpp` 740–742、793–795 的条件是 `!(checkLaneFoes || classCheck || cooperationCheck) || laneConflict(...)`。这里各连接均允许 passenger，classCheck 不成立；cooperationCheck 按整个入口 edge 汇总目标车道：603→{0,1}，790→{0,1,2,3}，交集非空。因此它对 790 的 lane1→2/3 也返回 false，`hasLaneConflict` 为 true。priority-v3 的四条 790 连接均响应 603 两条连接（`response=000011`），符合此规则；它不表示六条曲线逐对相交。[NBRequest.cpp 961–1021](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBRequest.cpp#L961)

**true 会启用车道顺序判断，并非删除所有不同车道的冲突。** `laneConflict` 对不同目标 edge 返回 true；同一目标 edge 按入口相对角度、掉头关系及目标车道顺序判断，比较含等号，因此共享出口车道仍冲突。这里 603 是右转、790 是直行：790 目标车道≤603 目标车道时，该分支保留冲突，包括真实交叉的 603→1 与 790→0。790→2/3 对 603→0/1 则被该分支排除。`getResponseString/getFoesString` 仍另有 merge、right-turn、opposite-left、bidi 等或条件。**该规则没有直接检测任意原生曲线的相交或车宽；不能保证所有自定义交叉形状都保留冲突。** 此处未重新编译，未宣称最终 true 版 request 位串已测得。[NBRequest.cpp 740–803、1003–1021](https://github.com/eclipse-sumo/sumo/blob/7717f2379d9e314a0c81c5cec748444de06a2a91/src/netbuild/NBRequest.cpp#L740)

REQ0/1 为 603→186 lane0/1；REQ2/3 为 790 lane0→186 lane0/1；REQ4/5 为 790 lane1→186 lane2/3。下表用完整内部 lane.shape 折线，单位米。

| REQ 对 | 中心线关系 | 期望 true 分支冲突 | 最小距离 | 宽度余量* |
|---|---|---|---:|---:|
| 0–2 | 同出口终点 | 保留 | 0 | −1.800 |
| 0–3 | 不相交 | 排除 | 3.200 | 1.400 |
| 0–4 | 不相交 | 排除 | 6.400 | 4.600 |
| 0–5 | 不相交 | 排除 | 7.291 | 5.491 |
| 1–2 | 内部交叉 | 保留 | 0 | −1.800 |
| 1–3 | 同出口终点 | 保留 | 0 | −1.800 |
| 1–4 | 不相交 | 排除 | 3.200 | 1.400 |
| 1–5 | 不相交 | 排除 | 5.208 | 3.408 |

对任意假定车宽，宽度带正余量的界限是 `(wA+wB)/2 < 最小距离`；等宽时即 `w < 最小距离`。表中保留/排除只预测该 laneConflict 分支，最终原生矩阵还需独立核对。

*宽度余量定义为中心线最小距离−(1.8+1.8)/2。1.8 米取固定版本 `internal-junctions.vehicle-width` 默认假设（NBFrame.cpp 380），不是本次对运行车辆宽度的查询。这只是中心线宽度带的静态余量，不是 5 米车身转弯扫掠、换道、轨迹误差或接收空间的验证。负值也不表示车辆已同时占据交点。完整六曲线包含同一入口车道的替代路径；这些同入口组合在 CSV 单列，不能当独立并行来流。

最小结论：默认跨车道响应有明确源码依据；不同出口并不自动免冲突，同出口及本例顺序交叉仍受 true 分支保护。当前 full-v3 已完成，本说明不提出另一轮原生试验。现场 GS 灯头及让行方向仍未确认，静态余量不能补足该来源证据。
