"""Read frozen GS curves; write static geometry facts without running SUMO."""

import csv
import hashlib
import itertools
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import shapely
from shapely.geometry import LineString
from shapely.ops import nearest_points

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
STAGE = OUT.parent
NET = STAGE / "candidate-priority-v3/network.net.xml"
COMMIT = "7717f2379d9e314a0c81c5cec748444de06a2a91"
SOURCES = {
    "NBRequest.cpp": ROOT / "outputs/hamburg-197-through-support-20261023-v1/candidate-review/NBRequest.cpp",
    "NBNode.cpp": ROOT / "outputs/hamburg-197-through-support-20261023-v1/import-semantics/NBNode.cpp",
    "NBEdge.cpp": ROOT / "outputs/hamburg-197-through-support-20261023-v1/import-semantics/NBEdge.cpp",
    "NBFrame.cpp": OUT / "NBFrame.cpp",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    net = ET.parse(NET).getroot()
    lanes = {lane.get("id"): lane for lane in net.findall("edge/lane")}
    connections = [
        c for c in net.findall("connection")
        if c.get("from") in {"603103445#2", "79014037#1"}
        and c.get("to") == "186713429"
    ]
    expected_vias = [f":266199063_0_{i}" for i in range(2)] + [
        f":266199063_2_{i}" for i in range(4)
    ]
    assert [c.get("via") for c in connections] == expected_vias
    curves = [LineString([
        tuple(map(float, point.split(",")))
        for point in lanes[c.get("via")].get("shape").split()
    ]) for c in connections]
    rows = []
    for i, j in itertools.combinations(range(6), 2):
        a, b = curves[i], curves[j]
        intersection = a.intersection(b)
        pa, pb = nearest_points(a, b)
        distance = a.distance(b)
        rows.append({
            "request_a": i, "request_b": j,
            "from_lane_a": connections[i].get("fromLane"),
            "from_lane_b": connections[j].get("fromLane"),
            "to_lane_a": connections[i].get("toLane"),
            "to_lane_b": connections[j].get("toLane"),
            "cross_incoming_pair": i < 2 <= j,
            "expected_lane_conflict_if_all_true": (
                int(connections[j].get("toLane")) <= int(connections[i].get("toLane"))
                if i < 2 <= j else None
            ),
            "centerlines_intersect": not intersection.is_empty,
            "intersection_wkt": intersection.wkt,
            "minimum_centerline_distance_m": distance,
            "width_only_clearance_at_1_8m_each_m": distance - 1.8,
            "strictly_positive_width_clearance_condition": f"(width_a+width_b)/2 < {distance:.12g}m",
            "nearest_a_wkt": pa.wkt, "nearest_b_wkt": pb.wkt,
        })
    with (OUT / "lane-foes-geometry.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    request = net.find("junction[@id='266199063']")
    sources = [{"path": str(p.relative_to(ROOT)).replace("\\", "/"),
                "sha256": sha(p),
                "url": f"https://raw.githubusercontent.com/eclipse-sumo/sumo/{COMMIT}/src/netbuild/{name}"}
               for name, p in SOURCES.items()]
    payload = {
        "schema": "astra.hamburg.gs-lane-foes-static/v1",
        "status": "review_required", "native_runs": 0,
        "source_commit": COMMIT, "shapely_version": shapely.__version__,
        "network": {"path": str(NET.relative_to(ROOT)).replace("\\", "/"), "sha256": sha(NET)},
        "control_sha256": sha(STAGE / "candidate-priority-v3/control.add.xml"),
        "sources": sources,
        "connections": [dict(c.attrib) for c in connections],
        "internal_lanes": [dict(lanes[c.get("via")].attrib) for c in connections],
        "requests": [dict(r.attrib) for r in request.findall("request")],
        "width_model": {
            "assumed_vehicle_width_m_each": 1.8,
            "formula": "minimum centerline distance - (width_a + width_b)/2",
            "basis": "NBFrame.cpp internal-junctions.vehicle-width default; explicit width-only diagnostic",
            "boundary": "Not a runtime width query or a full 5m vehicle swept-body envelope; no lane-change, tracking, speed or receiving-space claim",
        },
        "cross_incoming_pairs": [r for r in rows if r["cross_incoming_pair"]],
        "all_pairs_csv_sha256": sha(OUT / "lane-foes-geometry.csv"),
        "native_tables_with_option_true": "not_generated_or_measured",
        "claim_boundary": "Static converter-rule and frozen-curve analysis only. No network, control, keepClear or safety-mode change. Physical GS control/priority remains unconfirmed.",
    }
    (OUT / "lane-foes-analysis.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"native_runs": 0, "curves": len(curves), "pairs": len(rows),
                      "network_sha256": sha(NET)}, indent=2))


if __name__ == "__main__":
    main()
