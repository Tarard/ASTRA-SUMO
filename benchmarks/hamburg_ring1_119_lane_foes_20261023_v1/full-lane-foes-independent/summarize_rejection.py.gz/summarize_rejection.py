"""Keep measurement validity separate from the decision not to use this factor."""

from collections import Counter
import csv
import json

from audit_complete import OUT, SOURCE, CURRENT, audit, seal


def rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    summary = json.loads((OUT / "summary.json").read_bytes())
    terminal = rows(OUT / "all-unfinished-paired-events.csv")
    assert len(terminal) == 155 and all(float(row["before_arrival_s"]) >= 0 for row in terminal)
    field_counts = Counter(field for row in terminal for field in json.loads(row["intended_fields"]))
    origin_counts = Counter(row["requested_origin"] for row in terminal)
    fields = rows(OUT / "field13-errors-and-regions.csv")
    init = rows(OUT / "initial52-before-after.csv")
    initialization = []
    for field in sorted({row["field"] for row in init}):
        selected = [row for row in init if row["field"] == field]
        initialization.append({"field": field, "before_TAE": sum(abs(int(row["before_residual"])) for row in selected),
            "after_TAE": sum(abs(int(row["after_residual"])) for row in selected)})
    audit.table(OUT / "field13-initialization-errors.csv", initialization)
    audit.table(OUT / "terminal-groups.csv", summary["terminal_groups"]["after"])
    before, after = summary["before"], summary["after"]
    result = {"schema": "astra.hamburg.119-lane-foes-selection/v1", "status": "blocked", "measurement_integrity": "pass",
        "candidate_selection": "not_adopted", "working_base": str(SOURCE), "rejected_run": str(CURRENT), "native_runs_by_audit": 0,
        "reasons": {"main_MAE_worse": after["metrics130"]["MAE"] > before["metrics130"]["MAE"],
            "main_SSE_worse": after["metrics130"]["SSE"] > before["metrics130"]["SSE"],
            "all182_TAE_worse": after["metrics182"]["TAE"] > before["metrics182"]["TAE"],
            "new155_unfinished": len(terminal) == 155, "healthy_completion_lost": before["healthy"] and not after["healthy"]},
        "improvements_not_hidden": {"initialization_TAE": [before["metrics52"]["TAE"], after["metrics52"]["TAE"]],
            "119Z12_main_TAE": [81, 67], "53556_zero_preserved": summary["53556_exact_rows_after"] == 56},
        "terminal_intended_field_counts": dict(field_counts), "terminal_requested_origin_counts": dict(origin_counts),
        "terminal_already_completed_field": sum(row["has_any_complete_event"] == "True" for row in terminal),
        "terminal_not_completed_field": sum(row["has_any_complete_event"] == "False" for row in terminal),
        "all155_arrived_in_working_base": True,
        "field_error_changes": sorted(fields, key=lambda row: -int(row["SSE_change"])),
        "physical_correctness_conclusion": "not_established", "zero_error_feasibility_conclusion": "not_assessed",
        "claim_boundary": "The same conditional priority model with native lane-foe precision worsened this full run. This does not show that lane-foe checking is physically wrong, that the retained three conflicts are wrong, or that zero residual is infeasible. Initialization improvement and small safety probes do not override main loss and155 unfinished. Do not infer final queue positions from tripinfo or arrived-only routes."}
    assert all(result["reasons"].values())
    audit.save(OUT / "selection-decision.json", result)
    seal()
    print(json.dumps({key: result[key] for key in ["status", "candidate_selection", "terminal_intended_field_counts", "terminal_requested_origin_counts", "terminal_already_completed_field", "terminal_not_completed_field"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
