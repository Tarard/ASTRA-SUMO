"""Recompile the same conditional merge with SUMO's lane-level foe check."""
import argparse
import importlib.util
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("scoped_priority_build", ROOT / "build_priority_candidate.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
native_conversion = base.run_scoped_native_conversion


def lane_foes_conversion(**arguments):
    command = list(arguments["command"])
    assert "--check-lane-foes.all" not in command
    command += ["--check-lane-foes.all", "true"]
    return native_conversion(**{**arguments, "command": command})


def build(out):
    base.run_scoped_native_conversion = lane_foes_conversion
    result = base.build(out)
    result["scope_factor"] = "Relative to priority-v3, enable native lane-level foe checks at266199063 only. Retain actual shared-output and crossing conflicts, source geometry, native safety rules and the same conditional priority assumption."
    result["builder_hashes"] = {p.name: base.file_sha256(p) for p in (Path(__file__), ROOT / "build_priority_candidate.py")}
    if result["status"] == "review_required":
        node = ET.parse(out / "network.net.xml").getroot().find("junction[@id='266199063']")
        requests = node.findall("request")
        assert len(requests) == 6
        pairs = {(i, j) for i in (0, 1) for j in (2, 3, 4, 5) if requests[i].get("foes")[::-1][j] == "1"}
        expected = {(0, 2), (1, 2), (1, 3)}
        result["lane_foe_checks"] = {
            "three_shared_or_crossing_pairs_retained": pairs == expected,
            "mutual_foes": all(requests[i].get("foes")[::-1][j] == requests[j].get("foes")[::-1][i] for i in range(6) for j in range(6)),
            "790_yields_only_to_remaining_conflicts": all({i for i in range(6) if requests[j].get("response")[::-1][i] == "1"} == {i for i in (0, 1) if (i, j) in expected} for j in (2, 3, 4, 5)),
            "603_major_responses_still_empty": all(set(requests[i].get("response")) == {"0"} for i in (0, 1)),
            "external_control_bytes_identical_to_v3": (out / "control.add.xml").read_bytes() == (ROOT / "candidate-priority-v3/control.add.xml").read_bytes(),
        }
        result["requests"] = [dict(row.attrib) for row in requests]
        if not all(result["lane_foe_checks"].values()):
            result["status"] = "blocked"
    base.write_json_atomic(out / "manifest.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    result = build(parser.parse_args().output.resolve())
    print(result["status"], result.get("lane_foe_checks"), result.get("error"))
    assert result["status"] == "review_required"
