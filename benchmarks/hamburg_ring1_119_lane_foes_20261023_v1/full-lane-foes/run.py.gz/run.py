"""Prepare, or explicitly run once, the unchanged-demand native lane-foe precision comparison."""
import argparse
import gzip
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import time
import traceback

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = ROOT.parent / 'full-priority'
CANDIDATE = ROOT.parent / 'candidate-lane-foes-v1'


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def prepare():
    assert not (ROOT / 'preflight.json').exists(), 'Prepared inputs already exist; use audit.py --scope-only.'
    prepared, evaluation = ROOT / 'prepared', ROOT / 'evaluation'
    prepared.mkdir()
    evaluation.mkdir()
    files = {name: SOURCE / 'prepared' / name for name in ('demand.rou.xml', 'lane-intentions.json', 'field-loops.add.xml', 'expected-counts.csv', 'initialization-counts.csv', 'scenario.json')}
    files.update({name: CANDIDATE / name for name in ('network.net.xml', 'control.add.xml')})
    versions = {name: version(name) for name in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')}
    assert set(versions.values()) == {'1.27.1'}
    assert Path(sys.executable).resolve() == (REPO / '.venv/Scripts/python.exe').resolve()
    for name, path in files.items():
        shutil.copyfile(path, prepared / name)
    scenario = json.loads((prepared / 'scenario.json').read_bytes())
    scenario.update(network_sha256=sha(prepared / 'network.net.xml'), control_sha256=sha(prepared / 'control.add.xml'),
        control_variant='conditional_GS266_priority_native_lane_foes',
        control_assumptions=scenario['control_assumptions'] + ' Lane-precision check within the same conditional priority model: ' + 'At266199063 only, native --check-lane-foes.all true retains shared-output/crossing request pairs(0,2),(1,2),(1,3), excludes the other five noncrossing different-output pairs, and makes unopposed790 lane1 movements major. Preserve all8640 requests, real targets,50 control programs, geometry, turns, permissions and runtime/driver settings. GS field ownership and603-major priority remain unknown; this is not field SPaT.')
    save(prepared / 'scenario.json', scenario)
    for name in ('demand.rou.xml', 'lane-intentions.json'):
        shutil.copyfile(prepared / name, evaluation / name)
    implementation = ROOT / 'implementation'
    implementation.mkdir()
    implementation_paths = []
    for old in sorted((SOURCE / 'implementation').glob('*.py')):
        current = REPO / 'plugins/astra-sumo/src/astra_sumo/core' / old.name
        assert current.read_bytes() == old.read_bytes(), f'Changed implementation: {current}'
        shutil.copyfile(current, implementation / old.name)
        implementation_paths.extend([old, current, implementation / old.name])
    binaries = [REPO / '.venv/Scripts/python.exe', REPO / '.venv/Lib/site-packages/sumo/bin/sumo.exe']
    binaries += list((REPO / '.venv/Lib/site-packages/libsumo').glob('*.pyd'))
    assert len(binaries) >= 3
    bound = [*files.values(), CANDIDATE / 'manifest.json', SOURCE / 'preflight.json', SOURCE / 'verdict.json',
        SOURCE / 'executed-driver.py', ROOT / 'plan.json', ROOT / 'run.py', ROOT / 'audit.py', ROOT / 'offline_check.py', CANDIDATE / 'priority.native-local-output.net.xml', *implementation_paths, *binaries]
    helpers = REPO / 'outputs/hamburg-multifield-substitution-20261023-v1/response-audit'
    bound += [helpers / name for name in ('audit_response.py', 'audit_scope.py')]
    save(ROOT / 'preflight.json', {'status': 'prepared', 'native_runs': 0, 'formal_result': False,
        'source_hashes': {str(p.resolve()): sha(p) for p in bound},
        'prepared_hashes': {p.name: sha(p) for p in prepared.iterdir()}, 'versions': versions,
        'python': sys.executable, 'reference_prepared': str(SOURCE / 'prepared'),
        'reference_evaluation': str(SOURCE / 'evaluation'), 'candidate_manifest': str(CANDIDATE / 'manifest.json'),
        'run_parameters': {'backend': 'libsumo', 'step_length': .1, 'end_s': 14400, 'seed': 104, 'timeout_seconds': 4800,
            'junction_body_hold': True, 'junction_body_hold_nodes': _body_hold_nodes(prepared)},
        'demand_and_targets': 'All8640 explicit vehicles and all130 main plus52 initialization real counts retained byte for byte. Native E1 nVehContrib is compared with those real observations.'})
    from audit import check_inputs
    save(ROOT / 'input-proof.json', check_inputs())
    print(json.dumps({'status': 'prepared', 'native_runs': 0, 'N': 8640}), flush=True)


def run():
    from audit import audit_result, check_inputs
    check_inputs()
    assert not (ROOT / 'evaluation/native').exists() and not (ROOT / 'verdict.json').exists(), 'A run already exists; preserve it.'
    shutil.copyfile(__file__, ROOT / 'executed-driver.py')
    prepared, evaluation = ROOT / 'prepared', ROOT / 'evaluation'
    started = time.perf_counter()
    save(ROOT / 'runtime.json', {'status': 'running', 'backend': 'libsumo', 'python': sys.executable})
    try:
        native = run_point_detector_demand(net_file=prepared / 'network.net.xml', route_file=prepared / 'demand.rou.xml',
            e1_additional_file=prepared / 'field-loops.add.xml', expected_counts_csv=prepared / 'expected-counts.csv',
            output_dir=evaluation / 'native', end_s=14400, timeout_seconds=4800, step_length=.1, seed=104, backend='libsumo',
            sumo_binary=str(REPO / '.venv/Lib/site-packages/sumo/bin/sumo.exe'), signal_program_file=prepared / 'control.add.xml',
            lane_intentions_file=prepared / 'lane-intentions.json', junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared))
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        passages = read_contributing_e1_passages(instant_file=evaluation / 'native/instant-e1.xml', periodic_file=evaluation / 'native/field-counts.xml', detector_ids=native['instant_to_periodic_ids'], step_length=.1)
        assert passages['reconciled']
        (evaluation / 'contributing-passages.json.gz').write_bytes(gzip.compress(json.dumps(passages).encode(), mtime=0))
        verdict = audit_result()
        verdict['elapsed_s'] = time.perf_counter() - started
    except Exception as error:
        verdict = {'status': 'invalid', 'formal_result': False, 'error': {'type': type(error).__name__, 'message': str(error)},
            'elapsed_s': time.perf_counter() - started, 'partial_native_outputs_preserved': True}
        (ROOT / 'failure.log').write_text(traceback.format_exc(), encoding='utf-8')
    save(ROOT / 'verdict.json', verdict)
    save(ROOT / 'runtime.json', {'status': 'terminal', 'elapsed_s': verdict['elapsed_s'], 'verdict_status': verdict['status'], 'native_runs': 1})
    print(json.dumps(verdict, ensure_ascii=False), flush=True)
    if verdict['status'] == 'invalid':
        raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare-only', action='store_true')
    mode.add_argument('--run', action='store_true')
    args = parser.parse_args()
    run() if args.run else prepare()
