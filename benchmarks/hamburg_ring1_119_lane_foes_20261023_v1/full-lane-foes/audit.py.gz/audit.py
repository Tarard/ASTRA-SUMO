"""Audit the one-node native lane-foe precision factor with the sealed readers."""
import argparse
from copy import deepcopy
from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from astra_sumo.core.junction_split_fanout import _canonical
from astra_sumo.core.local_network_conversion import _index, _owner

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = ROOT.parent / 'full-priority'
CANDIDATE = ROOT.parent / 'candidate-lane-foes-v1'
sys.path.insert(0, str(REPO / 'outputs/hamburg-multifield-substitution-20261023-v1/response-audit'))
import audit_response as evidence  # noqa: E402
from audit_scope import digest  # noqa: E402


EXPECTED_REQUESTS = [
    {"index": "0", "response": "000000", "foes": "000100", "cont": "0"},
    {"index": "1", "response": "000000", "foes": "001100", "cont": "0"},
    {"index": "2", "response": "000011", "foes": "000011", "cont": "0"},
    {"index": "3", "response": "000010", "foes": "000010", "cont": "0"},
    {"index": "4", "response": "000000", "foes": "000000", "cont": "0"},
    {"index": "5", "response": "000000", "foes": "000000", "cont": "0"},
]
EXPECTED_PAIRS = {(0, 2), (1, 2), (1, 3)}
EXPECTED_LANE_CHECKS = {"three_shared_or_crossing_pairs_retained", "mutual_foes", "790_yields_only_to_remaining_conflicts",
    "603_major_responses_still_empty", "external_control_bytes_identical_to_v3"}
EXPECTED_SCOPE_CHECKS = {"native_priority_node", "inferred_program_removed", "native_request_table_unchanged_after_scope_restore",
    "all_loaded_turn_permissions_identical", "all_ordinary_geometry_identical", "outside_scope_order_and_semantics_identical",
    "all_six_internal_curves_lengths_speeds_widths_retained", "all_other_network_programs_identical", "exactly_one_external_program_removed", "source_inputs_immutable"}


def network_scope(before, after):
    node_id = "266199063"
    old = next(j for j in before.findall("junction") if j.get("id") == node_id)
    new = next(j for j in after.findall("junction") if j.get("id") == node_id)
    assert old.attrib == new.attrib and old.get("type") == new.get("type") == "priority"
    requests = [dict(r.attrib) for r in new.findall("request")]
    assert requests == EXPECTED_REQUESTS
    assert [dict(r.attrib) for r in old.findall("request")] != requests
    lanes = new.get("intLanes").split()
    assert lanes == [":266199063_0_0", ":266199063_0_1", ":266199063_2_0", ":266199063_2_1", ":266199063_2_2", ":266199063_2_3"]
    expected_bindings = [("603103445#2", "0", "186713429", "0"), ("603103445#2", "0", "186713429", "1"),
        ("79014037#1", "0", "186713429", "0"), ("79014037#1", "0", "186713429", "1"),
        ("79014037#1", "1", "186713429", "2"), ("79014037#1", "1", "186713429", "3")]
    for tree in [before, after]:
        bindings = {c.get("via"): tuple(c.get(k) for k in ["from", "fromLane", "to", "toLane"])
            for c in tree.findall("connection") if c.get("via") in lanes}
        assert [bindings[lane] for lane in lanes] == expected_bindings
    def bit(row, name, index):
        return row[name][-(index + 1)] == "1"
    actual_pairs = {(i, j) for i in range(6) for j in range(i + 1, 6) if bit(requests[i], "foes", j)}
    assert actual_pairs == EXPECTED_PAIRS
    assert all(bit(requests[i], "foes", j) == bit(requests[j], "foes", i) for i in range(6) for j in range(6))
    assert all(not bit(requests[i], "response", j) for i in [0, 1] for j in range(6))
    assert {i: {j for j in range(6) if bit(requests[i], "response", j)} for i in range(2, 6)} == {2: {0, 1}, 3: {1}, 4: set(), 5: set()}
    def connection_states(tree):
        index = _index(tree)
        return {tuple(c.get(k) for k in ["from", "fromLane", "to", "toLane", "via"]): c.get("state")
            for c in tree.findall("connection") if _owner(c, index) == node_id}
    old_states, new_states = [connection_states(tree) for tree in [before, after]]
    assert old_states.keys() == new_states.keys()
    changed_states = {key: [old_states[key], new_states[key]] for key in old_states if old_states[key] != new_states[key]}
    assert changed_states == {
        ("79014037#1", "1", "186713429", "2", ":266199063_2_2"): ["m", "M"],
        ("79014037#1", "1", "186713429", "3", ":266199063_2_3"): ["m", "M"]}
    def masked(tree):
        tree = deepcopy(tree)
        index = _index(tree)
        for row in tree:
            if row.tag == "junction" and row.get("id") == node_id:
                for request in list(row.findall("request")):
                    row.remove(request)
            if row.tag == "connection" and _owner(row, index) == node_id:
                row.attrib.pop("state", None)
        return [_canonical(row) for row in tree]
    assert masked(before) == masked(after), "Change outside exact target requests/connection ROW, geometry or element order"
    return {"exact_six_request_rows": requests, "retained_foe_pairs": sorted(map(list, actual_pairs)),
        "excluded_other_major_minor_pairs": [[i, j] for i in [0, 1] for j in range(2, 6) if (i, j) not in actual_pairs],
        "exactly_two_790_lane1_states_m_to_M": True, "all_other_geometry_order_and_semantics_identical": True,
        "movement_to_request_binding_explicit": True}


def check_inputs():
    preflight = json.loads((ROOT / "preflight.json").read_bytes())
    assert all(digest(Path(path)) == value for path, value in preflight["source_hashes"].items())
    prepared = ROOT / "prepared"
    assert all(digest(prepared / path) == value for path, value in preflight["prepared_hashes"].items())
    proof = json.loads((CANDIDATE / "manifest.json").read_bytes())
    assert proof["status"] == "review_required"
    assert set(proof["checks"]) == EXPECTED_SCOPE_CHECKS and all(proof["checks"].values())
    assert set(proof["lane_foe_checks"]) == EXPECTED_LANE_CHECKS and all(proof["lane_foe_checks"].values())
    command = proof["execution"]["command"]
    assert command[command.index("--check-lane-foes.all") + 1] == "true"
    for name, field in [("network.net.xml", "candidate_sha256"), ("control.add.xml", "control_sha256")]:
        assert digest(prepared / name) == digest(CANDIDATE / name) == proof[field]
    assert (prepared / "control.add.xml").read_bytes() == (SOURCE / "prepared/control.add.xml").read_bytes()
    fixed = ["demand.rou.xml", "lane-intentions.json", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"]
    assert all((prepared / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes() for name in fixed)
    assert all((ROOT / "evaluation" / name).read_bytes() == (SOURCE / "evaluation" / name).read_bytes() for name in fixed[:2])
    vehicles = ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")
    intentions = json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]
    assert len(vehicles) == len(intentions) == 8640
    assert {v.get("id") for v in vehicles} == {r["vehicle_id"] for r in intentions}
    before, after = [ET.parse(path).getroot() for path in [SOURCE / "prepared/network.net.xml", prepared / "network.net.xml"]]
    network = network_scope(before, after)
    native_node = next(j for j in ET.parse(CANDIDATE / "priority.native-local-output.net.xml").getroot().findall("junction") if j.get("id") == "266199063")
    assert [dict(r.attrib) for r in native_node.findall("request")] == EXPECTED_REQUESTS == proof["requests"]
    def lengths(tree):
        return {lane.get("id"): float(lane.get("length")) for edge in tree.findall("edge") for lane in edge.findall("lane")}
    assert lengths(before) == lengths(after)
    assert lengths(after)["79014037#1_0"] == lengths(after)["79014037#1_1"] == 3.46
    assert preflight["run_parameters"]["junction_body_hold_nodes"] == ["14398547", "205069138", "18653534", "LSA104_part0"]
    return {"status": "pass", "native_runs_by_check": 0, "N": 8640, "candidate_scope_checks": proof["checks"],
        "exact_five_lane_foe_checks": proof["lane_foe_checks"], "network_scope_relative_to_full_priority": network,
        "control_bytes_identical_to_full_priority": True, "all_lane_lengths_exact": True, "790_lane_lengths_m": [3.46, 3.46],
        "demand_intentions_and_real_observation_bytes_identical": True,
        "candidate_network_sha256": proof["candidate_sha256"], "candidate_control_sha256": proof["control_sha256"]}


def audit_result():
    scope = check_inputs()
    data = []
    for case in (SOURCE, ROOT):
        data.append(evidence.evidence(case / 'prepared', case / 'evaluation', case / 'evaluation/contributing-passages.json.gz', 8640))
    reference, current = data
    assert reference['periodic'].keys() == current['periodic'].keys()
    intentions = {r['vehicle_id']: r['field_id'] for r in json.loads((ROOT / 'prepared/lane-intentions.json').read_bytes())['vehicles']}
    assert set(current['by_vehicle']) <= intentions.keys()
    repeated = [{'vehicle_id': identity, 'field': f, 'count': n} for identity, events in current['by_vehicle'].items() for f, n in Counter(e['detector_id'] for e in events).items() if n > 1]
    extra = [{'vehicle_id': identity, 'actual_field': e['detector_id'], 'intended_field': intentions[identity]} for identity, events in current['by_vehicle'].items() for e in events if e['detector_id'] != intentions[identity]]
    output = ROOT / 'independent-audit'
    output.mkdir(exist_ok=True)
    for name in ['main', 'initial', 'stations']:
        evidence.table(output / f'{name}-comparison.csv', current[name])
    evidence.table(ROOT / 'evaluation/all182-comparison.csv', current['initial'] + current['main'])
    field_rows = []
    for field in sorted({k[0] for k in current['periodic']}):
        row = {'field': field}
        for label, d in [('reference', reference), ('candidate', current)]:
            row.update({f'{label}_{k}': v for k, v in evidence.metrics([r for r in d['main'] if r['detector_id'] == field]).items()})
        field_rows.append(row)
    evidence.table(output / 'field13-main.csv', field_rows)
    fields535 = {'hh_0535_Z_5_30894', 'hh_0535_Z_6_33855', 'hh_0535_Z_7_29316', 'hh_0535_Z_8_34287'}
    checks535 = {}
    for label, d in [('reference', reference), ('candidate', current)]:
        rows = [r for r in d['initial'] + d['main'] if r['detector_id'] in fields535]
        assert len(rows) == 56
        checks535[label] = evidence.metrics(rows)
        evidence.table(output / f'{label}-535-all56.csv', rows)
    assert checks535['reference']['TAE'] == 0
    valid = current['safe'] and not repeated and not extra
    formal = valid and current['healthy'] and current['metrics130']['TAE'] == 0 and checks535['candidate']['TAE'] == 0
    report = {'status': 'diagnostic_candidate' if valid else 'invalid', 'formal_result': formal,
        'scope': scope, 'before': reference['recorded'], 'after': current['recorded'],
        'reference': {k: reference[k] for k in ['metrics130', 'metrics52', 'metrics182', 'station40_MAE', 'completion', 'safe', 'healthy']},
        'candidate': {k: current[k] for k in ['metrics130', 'metrics52', 'metrics182', 'station40_MAE', 'completion', 'safe', 'healthy', 'event_count']},
        'all182_TAE': current['metrics182']['TAE'], 'native208_rows': len(current['periodic']), '535_all56': checks535,
        '535_zero56_retained': checks535['candidate']['TAE'] == 0, 'repeated_vehicle_fields': repeated,
        'contributions_outside_prior_primary_intention': extra,
        'unfinished': {label: d['completion']['waiting'] + d['completion']['running'] for label, d in [('reference', reference), ('candidate', current)]},
        'source_hashes': {label: d['source_hashes'] for label, d in [('reference', reference), ('candidate', current)]},
        'diagnostic_selection_authority': False,
        'claim_boundary': 'Lane-level foe precision check within the same conditional native priority model. Same-output and crossing pairs(0,2),(1,2),(1,3) remain. GS field ownership and603-major priority remain uncertain. All130/40/52/182 and all53556 rows are retained; no score or unfinished gate is silently dropped. Diagnostic status is not field control validation or promotion. Formal130zero and healthy completion remain separate from unknown field control ownership.'}
    evidence.save(output / 'audit.json', report)
    evidence.save(output / 'manifest.json', {'native_runs': 0, 'files': [{'path': p.name, 'size_bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(output.iterdir()) if p.is_file() and p.name != 'manifest.json']})
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope-only', action='store_true')
    args = parser.parse_args()
    result = check_inputs() if args.scope_only else audit_result()
    evidence.save(ROOT / ('input-proof.json' if args.scope_only else 'independent-audit-result.json'), result)
    print(json.dumps(result, ensure_ascii=False))
