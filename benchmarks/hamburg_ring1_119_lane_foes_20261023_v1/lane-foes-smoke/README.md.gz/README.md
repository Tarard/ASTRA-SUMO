# GS266 lane-foes：三个两车小样本

候选 SHA256 `92e524c94c61ae301795887c8762c430884b88cbfbb909a9f7cdd2c034b4bddc`。三个独立 Libsumo 1.27.1 进程各运行一次，六辆车全部到原出口 `199500676`，各次原 Z4/Z5 检测字段完整通过一次，零碰撞、传送、discard。全部 13 字段原生 E1 保留，未删非指定贡献。原始文件与实际覆盖见 [audit.json](audit.json)。每次保留 23 条运行警告，不能称日志无警告。

| 小样本 | 实际 GS via / 原生进入时刻 | 实际观察 |
|---|---|---|
| cross-1-2 | main `0_1` 82.3；minor `2_0` 84.0 | API82.2 main M/open，minor m/closed/hasFoe，交叉仍让行 |
| parallel-0-3 | main `0_0` 82.3；minor `2_1` 84.0 | 同时接近时两个 link 均 open，minor 无 foe；本次未同时占据 GS 内部车身范围 |
| z5-0-4 | main `0_0` 82.3；minor `2_2` 82.9 | 两 link 均 M/open，无 foe；主车车尾仍在 GS 时 Z5 已进入另一内部车道，随后均清空 |

表内 via 省略 `:266199063_`。FCD 原生时刻比 post-step API 记录早 0.1 秒。旧共享记录中的 phase/state 是 197 的信号，GS 的实际状态来自 `next_links`，不能混用。

这是普通发车的 toy 合流检查。603 车从 `603103445#2` 开始，已跳过真实 Z15 点；119 车保留原 Z4/Z5 moving stop 及原后缀，另加明确的接收车道 moving waypoint。沿用已封存的共享原生 driver、speedMode31、keepClear 和 LaneSectionHold，没有速度、位置、信号强制或提前消车。覆盖 REQ0–4；REQ5、反向先到、多车饱和及行人/自行车未覆盖。603 优先方向及现场独立控制仍是条件假设。小样本通过不证明大流量或现场安全，也不证明计数拟合。

`executed-run-pairs.py` 是运行前快照。`audit_pairs.py` 只读原生结果并复用原 197 审核函数；它不启动仿真。结果已封口，不覆盖旧文件，不自动追加场景。
