"""Reconcile three completed pairs and report actual encounter boundaries."""

import hashlib
import json
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]


def inside(c):
    return c["lane"].startswith(":266199063_") or (
        c["lane"].startswith("186713429_") and c["pos_m"] < 5)


def main():
    source = REPO / "outputs/hamburg-197-through-support-20261023-v1/smoke/audit_smokes.py"
    audit = runpy.run_path(str(source))["audit"]
    reports = {}
    for name in ("cross-1-2", "parallel-0-3", "z5-0-4"):
        checked = audit(ROOT / name)
        assert checked["status"] == "pass" and checked["all_full_routes_arrived"]
        rows = json.loads((ROOT / name / "samples.json").read_bytes())
        yield_rows, both_open_rows, body_overlap = [], [], []
        for row in rows:
            cars = row["vehicles"]
            if len(cars) != 2:
                continue
            major, minor = cars[f"{name}_major"], cars[f"{name}_minor"]
            links = [next((x for x in car["next_links"] if x[4].startswith(":266199063_")), None)
                     for car in (major, minor)]
            event = dict(poststep_API_time_s=row["time_s"], native_FCD_time_s=round(row["time_s"] - .1, 1),
                         vehicles=cars)
            if all(links):
                if links[0][1] and links[0][2] and not links[1][1] and not links[1][2] and links[1][3]:
                    yield_rows.append(event)
                if all(link[2] for link in links) and not links[1][3]:
                    both_open_rows.append(event)
            # Explicit source length5: front on receiving edge at pos<5 leaves
            # rear in the GS connection; no extrapolation from absent vehicles.
            if inside(major) and inside(minor):
                body_overlap.append(event)
        reports[name] = dict(native_audit=checked, actual_yield_rows=yield_rows,
                             simultaneous_open_approach_rows=both_open_rows,
                             GS_body_presence_overlap_rows=body_overlap)
    assert reports["cross-1-2"]["actual_yield_rows"]
    assert reports["parallel-0-3"]["simultaneous_open_approach_rows"]
    assert reports["z5-0-4"]["GS_body_presence_overlap_rows"]
    output = dict(status="pass", formal_result=False, native_runs=3, toy_vehicles=6,
                  candidate_sha256="92e524c94c61ae301795887c8762c430884b88cbfbb909a9f7cdd2c034b4bddc",
                  reused_auditor_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), cases=reports,
                  covered_requests=[0, 1, 2, 3, 4], not_covered_requests=[5],
                  coverage_boundary="REQ0/3 simultaneous-open approaches measured, but no simultaneous GS body occupancy in that case. REQ0/4 overlapping body presence measured; crossingREQ1/2 yield measured. No reverse-arrival, saturation, bicycle/pedestrian or field-priority validation. Legacy phase/state columns refer to197; actual GS properties are in next_links.")
    (ROOT / "audit.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status="pass", native_runs=3, toy_vehicles=6,
                         yield_samples=len(reports["cross-1-2"]["actual_yield_rows"]),
                         parallel_open_samples=len(reports["parallel-0-3"]["simultaneous_open_approach_rows"]),
                         z5_overlap_samples=len(reports["z5-0-4"]["GS_body_presence_overlap_rows"])), indent=2))


if __name__ == "__main__":
    main()
