"""Explicit three bounded ordinary-entry pairs; reuse the sealed native driver."""

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CANDIDATE = ROOT.parent / "candidate-lane-foes-v1"
SOURCE = REPO / "outputs/hamburg-197-through-support-20261023-v1/full/evaluation"
FROZEN_DRIVER = ROOT.parent / "merge-smoke/shared-driver.py"
EXPECTED_HASH = "92e524c94c61ae301795887c8762c430884b88cbfbb909a9f7cdd2c034b4bddc"
CASES = {"cross-1-2": (1, 0, 4), "parallel-0-3": (0, 1, 4), "z5-0-4": (0, 2, 5)}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_driver():
    spec = importlib.util.spec_from_file_location("shared_native_driver", ROOT / "shared-driver.py")
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.REPO = REPO
    return driver


def gate():
    assert sha(CANDIDATE / "network.net.xml") == EXPECTED_HASH
    manifest = json.loads((CANDIDATE / "manifest.json").read_bytes())
    assert len(manifest["checks"]) == 10 and all(manifest["checks"].values())
    assert all(manifest["lane_foe_checks"].values())
    net = ET.parse(CANDIDATE / "network.net.xml").getroot()
    junction = net.find("junction[@id='266199063']")
    assert junction.get("type") == "priority"
    requests = junction.findall("request")
    retained = {(0, 2), (1, 2), (1, 3)}
    assert len(requests) == 6
    for main in (0, 1):
        assert int(requests[main].get("response"), 2) == 0
        for minor in range(2, 6):
            expected = (main, minor) in retained
            assert bool(int(requests[minor].get("response"), 2) & (1 << main)) == expected
            assert bool(int(requests[minor].get("foes"), 2) & (1 << main)) == expected
            assert bool(int(requests[main].get("foes"), 2) & (1 << minor)) == expected
    assert sha(CANDIDATE / "control.add.xml") == sha(ROOT.parent / "candidate-priority-v3/control.add.xml")
    return net


def prepare():
    gate()
    assert not (ROOT / "inputs").exists() and not (ROOT / "shared-driver.py").exists()
    (ROOT / "shared-driver.py").write_bytes(FROZEN_DRIVER.read_bytes())
    driver = load_driver()
    inputs = ROOT / "inputs"
    inputs.mkdir()
    source = ET.parse(SOURCE / "demand.rou.xml").getroot()
    fields = {r["vehicle_id"]: r["field_id"] for r in json.loads((SOURCE / "lane-intentions.json").read_bytes())["vehicles"]}
    routes = ET.Element("routes")
    for row in source:
        if row.tag != "vehicle":
            routes.append(copy.deepcopy(row))
    jobs = []
    for case, (major_lane, minor_lane, z) in CASES.items():
        for label, field_z, start, depart, receiver, req in (
            ("minor", z, "24483344#1", 0, minor_lane, minor_lane + 2),
            ("major", 15, "603103445#2", 82, major_lane, major_lane),
        ):
            identity = f"{case}_{label}"
            original = next(v for v in source.findall("vehicle") if fields[v.get("id")].startswith(f"hh_0119_Z_{field_z}_"))
            edges = original.find("route").get("edges").split()
            suffix = edges[edges.index(start):]
            assert suffix[-1] == "199500676"
            route = ET.SubElement(routes, "route", id="r_" + identity, edges=" ".join(suffix))
            if label == "minor":
                for stop in original.findall("stop"):
                    route.append(copy.deepcopy(stop))
            ET.SubElement(route, "stop", lane=f"186713429_{receiver}", endPos="5.287260", speed="13.888889")
            driver.route_support(gate(), suffix)
            jobs.append(dict(id=identity, case=case, field=fields[original.get("id")] if label == "minor" else None,
                             source_id=original.get("id"), vehicle_attributes=dict(original.attrib),
                             route_id=route.get("id"), trigger=dict(time_s=depart), movement=100 + req,
                             expected_stop_count=len(route.findall("stop"))))
    ET.ElementTree(routes).write(inputs / "routes.rou.xml", encoding="utf-8", xml_declaration=True)
    (inputs / "field-loops.add.xml").write_bytes((SOURCE / "native/source-e1.add.xml").read_bytes())
    save(inputs / "jobs.json", dict(end_s=600, jobs=jobs))
    save(ROOT / "plan.json", dict(status="prepared", new_native_runs=0, cases=CASES,
         candidate_sha256=EXPECTED_HASH, reused_driver_sha256=sha(FROZEN_DRIVER),
         sources={str(p): sha(p) for p in (SOURCE / "demand.rou.xml", SOURCE / "lane-intentions.json", CANDIDATE / "manifest.json")},
         boundary="Toy normal entries; cropped603 route skips realZ15 detector. Original119 field stops plus explicit receiving-lane moving waypoints. No speed/position/phase forcing; unchanged speedMode31, keepClear and shared LaneSectionHold. Conditional603 priority; reverse-arrival/saturation/pedestrian/bicycle cases not tested."))


def execute(case):
    net = gate()
    driver = load_driver()
    major_lane, minor_lane, _ = CASES[case]

    def support(network, control):
        assert sha(network) == EXPECTED_HASH and sha(control) == sha(CANDIDATE / "control.add.xml")
        paths = {}
        for before, lane, receiver, req in (("603103445#2", 0, major_lane, major_lane),
                                            ("79014037#1", int(minor_lane == 2), minor_lane, minor_lane + 2)):
            matches = [c for c in net.findall("connection") if c.get("from") == before and c.get("fromLane") == str(lane)
                       and c.get("to") == "186713429" and c.get("toLane") == str(receiver)]
            assert len(matches) == 1 and "tl" not in matches[0].attrib
            paths[100 + req] = [matches[0].get("via")]
        return net, paths

    driver.support = support
    driver.run(case, case, (CANDIDATE / "network.net.xml").resolve(), (CANDIDATE / "control.add.xml").resolve())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument("--prepare-only", action="store_true")
    actions.add_argument("--execute", choices=CASES)
    args = parser.parse_args()
    prepare() if args.prepare_only else execute(args.execute)
