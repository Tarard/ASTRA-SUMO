"""Audit one sealed joint OD measurement without changing or running its inputs."""

from collections import Counter
import gzip
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import numpy as np

OUT = Path(__file__).resolve().parent
STUDY = OUT.parent
REPO = STUDY.parents[1]
CASE = STUDY / "joint-128"
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
PROPOSAL = REPO / "outputs/hamburg-healthy-joint-od-audit-20261024-v1/bounded-128"
MODEL = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json"
HELPERS = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit"
sys.path.insert(0, str(HELPERS))
import audit_response as audit  # noqa: E402
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages  # noqa: E402

FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def vehicles(folder):
    root = ET.parse(folder / "demand.rou.xml").getroot()
    rows = {v.get("id"): v for v in root.findall("vehicle")}
    assert len(rows) == len(root.findall("vehicle")) == 8640
    return root, rows


def canon(row):
    return ET.canonicalize(ET.tostring(row, encoding="unicode"), strip_text=True)


def cell(row):
    edges = row.find("route").get("edges").split()
    return edges[0], edges[-1], int(float(row.get("depart")) // 900)


def main():
    verdict = json.loads((CASE / "verdict.json").read_bytes())
    assert verdict["native_response_measured"] and verdict["status"] != "invalid"
    preflight = json.loads((CASE / "preflight.json").read_bytes())
    proof = json.loads((CASE / "scope-proof.json").read_bytes())
    assert preflight["source_proof_sha256"] == audit.digest(CASE / "scope-proof.json")
    assert proof["status"] == "pass" and proof["N"] == 8640
    assert set(preflight["versions"].values()) == {"1.27.1"} and preflight["backend"] == "libsumo"
    bindings = []
    for original, expected in proof["source_hashes"].items():
        declared = Path(original)
        resolved = (STUDY / "source-code/od_assignment_feedback.py"
                    if declared.name == "od_assignment_feedback.py" else declared)
        assert audit.digest(resolved) == expected, original
        bindings.append({"declared_path": original, "audited_path": str(resolved), "sha256": expected})
    for name, expected in proof["prepared_hashes"].items():
        assert audit.digest(CASE / "prepared" / name) == expected
    for name, expected in preflight["implementation_sha256"].items():
        assert audit.digest(CASE / "implementation" / name) == expected
        assert (CASE / "implementation" / name).read_bytes() == (SOURCE / "implementation" / name).read_bytes()
    for path, expected in preflight["binaries"].items():
        assert audit.digest(Path(path)) == expected
    assert audit.digest(CASE / "executed-driver.py") == preflight["executed_driver_sha256"]
    assert audit.digest(HELPERS / "audit_response.py") == preflight["helper_sha256"]
    assert audit.digest(HELPERS / "audit_scope.py") == preflight["helper_scope_sha256"]
    for name in ["network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "scenario.json"]:
        assert (SOURCE / "prepared" / name).read_bytes() == (CASE / "prepared" / name).read_bytes()
    for name in ["demand.rou.xml", "lane-intentions.json"]:
        assert (PROPOSAL / "generated" / name).read_bytes() == (CASE / "prepared" / name).read_bytes()
    assert (PROPOSAL / "generated/od-vector.json").read_bytes() == (CASE / "od-vector.json").read_bytes()
    roots, rows = zip(*[vehicles(folder) for folder in [SOURCE / "prepared", CASE / "prepared"]])
    assert [canon(v) for v in roots[0] if v.tag != "vehicle"] == [canon(v) for v in roots[1] if v.tag != "vehicle"]
    initial = [[canon(v) for v in r.values() if float(v.get("depart")) < 3600] for r in rows]
    assert initial[0] == initial[1]
    inventory = [Counter(cell(v) for v in r.values()) for r in rows]
    model = json.loads(MODEL.read_bytes())
    keys = [(r["origin"], r["destination"], int(r["begin_s"] // 900)) for r in model["cells"]]
    assert len(keys) == len(set(keys)) == 294 and set(keys) == inventory[0].keys() == inventory[1].keys()
    vectors = [np.array([d[k] for k in keys], dtype=np.int64) for d in inventory]
    saved = json.loads((CASE / "od-vector.json").read_bytes())
    proposed = json.loads((PROPOSAL / "proposal.json").read_bytes())
    inputs = np.load(PROPOSAL / "solver-inputs.npz")
    assert np.array_equal(vectors[0], inputs["q"])
    assert np.array_equal(vectors[1], saved["integer_counts"])
    assert np.array_equal(vectors[1], saved["values"]) and np.array_equal(vectors[1], proposed["solution"])
    assert saved["source_model_sha256"] == audit.digest(MODEL)
    delta = vectors[1] - vectors[0]
    assert int(abs(delta).sum()) == 128 and np.count_nonzero(delta) == 22
    assert np.all(vectors[1] >= inputs["lower"]) and np.all(vectors[1] <= inputs["upper"])
    assert np.all(abs(delta) <= np.floor(vectors[0] * .25)) and np.all(delta[:84] == 0)
    od_totals = []
    for od in sorted({k[:2] for k in keys}):
        before, after = [sum(int(d[k]) for k in d if k[:2] == od) for d in inventory]
        assert before == after
        od_totals.append({"origin": od[0], "destination": od[1], "before": before, "after": after})
    audit.table(OUT / "all21-od-totals.csv", od_totals)
    audit.table(OUT / "all294-cell-inventory.csv", [dict(index=i, origin=k[0], destination=k[1], departure_bin=k[2], before=int(vectors[0][i]), after=int(vectors[1][i]), delta=int(delta[i])) for i, k in enumerate(keys)])
    metadata = [{v["vehicle_id"]: v for v in json.loads((folder / "lane-intentions.json").read_bytes())["vehicles"]}
                for folder in [SOURCE / "prepared", CASE / "prepared"]]
    for demand, intentions in zip(rows, metadata):
        assert demand.keys() == intentions.keys()
        assert all(keys[intentions[i]["od_cell"]] == cell(v) for i, v in demand.items())
    common = rows[0].keys() & rows[1].keys()
    added, removed = sorted(rows[1].keys() - rows[0].keys()), sorted(rows[0].keys() - rows[1].keys())
    changes = {"departure": [], "route": [], "stop": [], "field": [], "non_departure_attributes": []}
    changed_xml = set()
    for identity in sorted(common):
        a, b = [r[identity] for r in rows]
        if a.get("depart") != b.get("depart"):
            changes["departure"].append(identity)
        if canon(a.find("route")) != canon(b.find("route")):
            changes["route"].append(identity)
        if [canon(s) for s in a.findall("stop")] != [canon(s) for s in b.findall("stop")]:
            changes["stop"].append(identity)
        if metadata[0][identity]["field_id"] != metadata[1][identity]["field_id"]:
            changes["field"].append(identity)
        if {k: v for k, v in a.attrib.items() if k != "depart"} != {k: v for k, v in b.attrib.items() if k != "depart"}:
            changes["non_departure_attributes"].append(identity)
        if canon(a) != canon(b):
            changed_xml.add(identity)
        if not delta[metadata[0][identity]["od_cell"]]:
            assert canon(a) == canon(b) and metadata[0][identity] == metadata[1][identity]
    assert len(added) == len(removed) == 64
    assert {k: len(v) for k, v in changes.items()} == dict(departure=1102, route=179, stop=284, field=284, non_departure_attributes=0)
    source = audit.evidence(SOURCE / "prepared", SOURCE / "evaluation", SOURCE / "evaluation/contributing-passages.json.gz", 8640)
    candidate = audit.evidence(CASE / "prepared", CASE / "evaluation", CASE / "evaluation/contributing-passages.json.gz", 8640)
    native = CASE / "evaluation/native"
    run = json.loads((native / "run.json").read_bytes())
    requests = [json.loads((folder / "evaluation/native/native-request.json").read_bytes()) for folder in [SOURCE, CASE]]
    normalized = [json.dumps(request, sort_keys=True).replace(str(folder).replace("\\", "\\\\"), "{case}") for request, folder in zip(requests, [SOURCE, CASE])]
    assert normalized[0] == normalized[1]
    monitor = json.loads((native / "stall-monitor.json").read_bytes())
    assert monitor["library_completed"] and monitor["native_returncode"] is None
    assert monitor["native_version"] == [22, "SUMO 1.27.1"]
    assert monitor["native_library"]["sha256"] == audit.digest(Path(monitor["native_library"]["path"]))
    raw_trip_rows = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
    assert len(raw_trip_rows) == len(candidate["tripinfo"]) == 8640 and candidate["tripinfo"].keys() == rows[1].keys()
    arrived_routes = ET.parse(native / "vehicle-routes.xml").getroot().findall("vehicle")
    assert len(arrived_routes) == len({r.get("id") for r in arrived_routes}) == 8606
    for route in arrived_routes:
        assert route.find("route").get("edges") == rows[1][route.get("id")].find("route").get("edges")
    raw_events = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml",
        detector_ids=run["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(CASE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        compact = json.load(handle)
    assert raw_events == compact and raw_events["reconciled"]
    source_run = json.loads((SOURCE / "evaluation/native/run.json").read_bytes())
    source_events = read_contributing_e1_passages(instant_file=SOURCE / "evaluation/native/instant-e1.xml",
        periodic_file=SOURCE / "evaluation/native/field-counts.xml", detector_ids=source_run["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(SOURCE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        assert source_events == json.load(handle)
    target_by_key = {(r["detector_id"], float(r["begin"]), float(r["end"])): int(r["expected_total"]) for r in source["initial"] + source["main"]}
    # NPZ row order is declared in the earlier assignment audit, rather than inferred from sorted CSV rows.
    declaration = json.loads((PROPOSAL.parent / "audit-inputs.json").read_bytes())
    declared_rows = declaration["target_rows"]
    declared_keys = [(r["detector_id"], float(r["begin"]), float(r["end"])) for r in declared_rows]
    assert set(declared_keys) == set(target_by_key) and len(declared_keys) == 182
    assert np.array_equal(inputs["y"], [target_by_key[k] for k in declared_keys])
    assert np.array_equal(inputs["C"].sum(axis=1), [int(source["periodic"][k]["nVehContrib"]) for k in declared_keys])
    actual_c = np.zeros((182, 294), dtype=np.int64)
    row_index = {k: i for i, k in enumerate(declared_keys)}
    for event in source_events["passages"]:
        k = event["detector_id"], event["interval_begin_s"], event["interval_end_s"]
        if k in row_index:
            actual_c[row_index[k], metadata[0][event["vehicle_id"]]["od_cell"]] += 1
    assert np.array_equal(actual_c, inputs["C"])
    prediction = inputs["C"] / inputs["q"] @ vectors[1]
    assert np.allclose(prediction, proposed["predicted_counts"], rtol=0, atol=1e-10)
    assert np.all(abs((prediction - inputs["y"])[inputs["exact_rows"]]) < 1e-6)
    for label, data in [("before", source), ("after", candidate)]:
        for name in ["metrics130", "metrics52", "metrics182", "completion", "safe", "healthy", "event_count", "station40_MAE"]:
            assert data[name] == verdict[label][name]
        for name, values in [("130", data["main"]), ("52", data["initial"]), ("182", data["initial"] + data["main"]), ("40", data["stations"])]:
            audit.table(OUT / f"{label}-{name}.csv", values)
    repeated = [(i, f, n) for i, es in candidate["by_vehicle"].items() for f, n in Counter(e["detector_id"] for e in es).items() if n > 1]
    outside = [(i, e["detector_id"]) for i, es in candidate["by_vehicle"].items() for e in es if e["detector_id"] != metadata[1][i]["field_id"]]
    assert not repeated and not outside
    rows535 = [r for r in candidate["initial"] + candidate["main"] if r["detector_id"] in FIELDS535]
    assert len(rows535) == 56 and audit.metrics(rows535)["TAE"] == 0
    fields = []
    for field in sorted({k[0] for k in source["periodic"]}):
        before, after = [audit.metrics([r for r in d["main"] if r["detector_id"] == field]) for d in [source, candidate]]
        fields.append(dict(field=field, before_TAE=before["TAE"], after_TAE=after["TAE"], delta_TAE=after["TAE"]-before["TAE"], before_SSE=before["SSE"], after_SSE=after["SSE"], delta_SSE=after["SSE"]-before["SSE"]))
    audit.table(OUT / "field13-response.csv", fields)
    cohort_sets = {"unmodified_common": common - changed_xml, "changed_common": changed_xml, "added_or_removed": set(added + removed)}
    cohort_counts = {name: [audit.counts(d["by_vehicle"], identities) for d in [source, candidate]] for name, identities in cohort_sets.items()}
    cohort_response = {}
    for name, identities in cohort_sets.items():
        def signature(data, identity):
            return [(e["detector_id"], e["interval_begin_s"], e["interval_end_s"]) for e in data["by_vehicle"].get(identity, [])]
        cohort_response[name] = dict(IDs=len(identities),
            before_complete_events=sum(len(source["by_vehicle"].get(i, [])) for i in identities),
            after_complete_events=sum(len(candidate["by_vehicle"].get(i, [])) for i in identities),
            field_or_bin_or_event_presence_changed=sum(signature(source, i) != signature(candidate, i) for i in identities),
            before_and_after_complete=sum(bool(source["by_vehicle"].get(i)) and bool(candidate["by_vehicle"].get(i)) for i in identities))
    response = []
    for k in sorted(source["periodic"]):
        change = int(candidate["periodic"][k]["nVehContrib"]) - int(source["periodic"][k]["nVehContrib"])
        row = dict(field=k[0], begin_s=k[1], end_s=k[2], before=int(source["periodic"][k]["nVehContrib"]), after=int(candidate["periodic"][k]["nVehContrib"]), delta=change)
        row.update({name+"_delta": counts[1][k]-counts[0][k] for name, counts in cohort_counts.items()})
        assert sum(row[name+"_delta"] for name in cohort_sets) == change
        response.append(row)
    audit.table(OUT / "native208-cohort-accounting.csv", response)
    terminal = []
    for identity, vehicle in rows[1].items():
        trip = candidate["tripinfo"].get(identity)
        if trip is not None and float(trip["arrival"]) >= 0:
            continue
        k = cell(vehicle)
        terminal.append(dict(vehicle_id=identity, origin=k[0], destination=k[1], departure_bin=k[2], requested_depart_s=vehicle.get("depart"), field=metadata[1][identity]["field_id"], state="not_inserted" if trip is None else "inserted_unfinished", source_actual_events=audit.event_view(source["by_vehicle"].get(identity, [])), candidate_actual_events=audit.event_view(candidate["by_vehicle"].get(identity, []))))
    assert len(terminal) == candidate["completion"]["waiting"] + candidate["completion"]["running"]
    audit.table(OUT / "terminal-unfinished-inputs-and-events.csv", terminal)
    gate = dict(safe=candidate["safe"], healthy=candidate["healthy"], all53556_zero=audit.metrics(rows535)["TAE"] == 0,
        no_repeated_vehicle_fields=not repeated, no_contributions_outside_primary_intention=not outside,
        main130_MAE_improves=candidate["metrics130"]["MAE"] < source["metrics130"]["MAE"],
        main130_SSE_not_worse=candidate["metrics130"]["SSE"] <= source["metrics130"]["SSE"],
        all182_TAE_not_worse=candidate["metrics182"]["TAE"] <= source["metrics182"]["TAE"])
    assert gate == verdict["gates"] and verdict["status"] == ("diagnostic_candidate" if all(gate.values()) else "rejected")
    result = dict(schema="astra.hamburg.healthy-joint-od-independent/v1", audit_status="pass", native_runs_by_audit=0,
        selection=verdict["status"], gates=gate, before={k:source[k] for k in verdict["before"]}, after={k:candidate[k] for k in verdict["after"]},
        station40_max=max(abs(r["residual"]) for r in candidate["stations"]), all53556=audit.metrics(rows535),
        source_bindings=bindings, source_raw_hashes=source["source_hashes"], candidate_raw_hashes=candidate["source_hashes"],
        scope=dict(N=8640, changed_cells=22, cell_L1=128, added_IDs=64, removed_IDs=64, common_IDs=len(common), common_changes={k:len(v) for k,v in changes.items()}, initial_requests_exact=True, all21_OD_totals_exact=True, controls_network_targets_driver_fixed=True),
        cohorts={k:len(v) for k,v in cohort_sets.items()}, cohort_response=cohort_response, field_rows=fields, terminal_count=len(terminal),
        terminal_by_origin=dict(Counter(r["origin"] for r in terminal)), terminal_by_field=dict(Counter(r["field"] for r in terminal)),
        unique_complete_contributing_vehicles=len(candidate["by_vehicle"]), repeats=repeated, outside_intentions=outside,
        commands_and_all_request_parameters_identical_after_case_path_normalization=True,
        source_C182x294_exactly_rebuilt_from_actual_complete_native_events=True,
        predicted182_TAE=float(abs(prediction-inputs["y"]).sum()), predicted130_TAE=float(abs(prediction-inputs["y"]).sum())-105,
        source_algorithm_snapshot=str(STUDY / "source-code/od_assignment_feedback.py"), live_core_may_have_later_large_integer_boundary_fix=True,
        audit_source_hashes={str(p): audit.digest(p) for p in [CASE / "preflight.json", CASE / "scope-proof.json", CASE / "verdict.json", CASE / "executed-driver.py", CASE / "evaluation/native/vehicle-routes.xml", MODEL, PROPOSAL / "solver-inputs.npz", PROPOSAL / "proposal.json", PROPOSAL.parent / "audit-inputs.json"]},
        claim_boundary="Observed assignment fractions describe this measured prior, not a Jacobian or exact changed-demand response. Cohort arithmetic is not causal separation. Quantile regeneration changes 1102 common departures, 179 routes and284 stop/field assignments. Fit and health are remeasured, not inherited. The rejected result does not identify true OD, field control or zero-fit feasibility.")
    audit.save(OUT / "summary.json", result)
    print(json.dumps({k:result[k] for k in ["audit_status", "selection", "before", "after", "scope", "terminal_by_origin", "terminal_by_field"]}))


if __name__ == "__main__":
    main()
