"""Audit saved assignment and the one saved integer proposal; no solver or SUMO."""

from collections import Counter, defaultdict
import csv
import gzip
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from astra_sumo.core.candidate_contracts import file_sha256 as sha

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"
MODEL = REPO / "outputs/hamburg-classical-od-calibration-20261023-v1/prepared/od-model.json"


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                         for k, v in row.items()} for row in rows)


def main():
    data = json.loads((ROOT / "audit-inputs.json").read_bytes())
    matrix = np.load(ROOT / "assignment182.npz")
    C, q, A, main_rows, initial = (matrix[k] for k in ("C", "q", "A", "main_mask", "initial_mask"))
    cells = json.loads(MODEL.read_bytes())["cells"]
    intents = {r["vehicle_id"]: r for r in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    compact_path = SOURCE / "evaluation/contributing-passages.json.gz"
    compact = json.loads(gzip.decompress(compact_path.read_bytes()))
    assert compact["reconciled"] and len(compact["passages"]) == len(intents) == 8640
    assert all(sha(Path(r["path"])) == r["sha256"] for r in compact["inputs"])
    target = np.array([int(r["expected_total"]) for r in data["target_rows"]])
    target_keys = [(r["detector_id"], float(r["begin"]), float(r["end"])) for r in data["target_rows"]]
    periodic = {(r.get("id"), float(r.get("begin")), float(r.get("end"))): int(r.get("nVehContrib"))
                for r in ET.parse(SOURCE / "evaluation/native/field-counts.xml").getroot()}
    all_keys = sorted(periodic, key=lambda r: (r[1], r[0]))
    all_index = {key: i for i, key in enumerate(all_keys)}
    C208 = np.zeros((208, 294), dtype=np.int64)
    observed_fields, fields_per_cell = defaultdict(set), defaultdict(Counter)
    for e in compact["passages"]:
        identity = e["vehicle_id"]
        column = intents[identity]["od_cell"]
        C208[all_index[e["detector_id"], e["interval_begin_s"], e["interval_end_s"]], column] += 1
        observed_fields[identity].add(e["detector_id"])
        fields_per_cell[column][e["detector_id"]] += 1
    assert np.array_equal(C208.sum(axis=1), [periodic[k] for k in all_keys])
    assert np.array_equal(C208.sum(axis=0), q)
    assert np.array_equal(C208[[all_index[k] for k in target_keys]], C)
    tail_indices = [i for i, key in enumerate(all_keys) if key not in target_keys]
    assert len(tail_indices) == 26 and C208[tail_indices].sum() == 314
    np.savez_compressed(ROOT / "assignment208-accounting.npz", contributions=C208, prior=q,
                        true_target_row_indices=[all_index[k] for k in target_keys],
                        unobserved_target_tail_indices=tail_indices)
    expected_by_key = dict(zip(target_keys, target))
    table(ROOT / "native208-accounting.csv", [dict(field=k[0], begin=k[1], end=k[2],
          native_count=periodic[k], expected_total=int(expected_by_key[k]) if k in expected_by_key else None,
          real_target_available=k in expected_by_key) for k in all_keys])
    proposal = json.loads((ROOT / "bounded-128/proposal.json").read_bytes())
    x = np.array(proposal["solution"], dtype=np.int64)
    inputs = np.load(ROOT / "bounded-128/solver-inputs.npz")
    exact, lo, hi = (inputs[k] for k in ("exact_rows", "lower", "upper"))
    E = matrix["OD_totals"]
    prediction = A @ x
    residual = prediction - target
    assert len(x) == 294 and x.sum() == 8640 and np.array_equal(E @ x, E @ q)
    assert np.array_equal(q[:84], x[:84]) and np.all(x >= lo) and np.all(x <= hi)
    assert np.abs(x-q).sum() == 128 and np.count_nonzero(x-q) == 22
    assert exact.sum() == 56 and np.max(np.abs(residual[exact])) < 1e-6
    assert not np.any(C[initial, 84:]) and np.allclose(prediction[initial], C[initial].sum(axis=1))
    table(ROOT / "bounded-128/prediction182.csv", [dict(field=key[0], begin=key[1], end=key[2],
          expected_total=int(target[i]), baseline_native=int(C[i].sum()), predicted_count=float(prediction[i]),
          predicted_residual=float(residual[i]), exact535_row=bool(exact[i])) for i, key in enumerate(target_keys)])
    table(ROOT / "cells294.csv", [dict(index=i, origin=c["origin"], destination=c["destination"],
          begin=c["begin_s"], end=c["end_s"], source_q=int(q[i]), candidate_q=int(x[i]), delta=int(x[i]-q[i]),
          observed_fields=dict(fields_per_cell[i]), main130_contributions=int(C[main_rows, i].sum()),
          real182_contributions=int(C[:, i].sum()), tail_contributions=int(C208[tail_indices, i].sum()),
          zero_main130_column=not bool(C[main_rows, i].sum()), zero_real182_column=not bool(C[:, i].sum()))
          for i, c in enumerate(cells)])
    free = np.flatnonzero(hi > lo)
    numerical_rank = int(np.linalg.matrix_rank(np.vstack([A[main_rows][:, free], E[:, free]])))
    zero = np.flatnonzero(C.sum(axis=0) == 0)
    prelim = json.loads((ROOT / "preliminary.json").read_bytes())
    assert prelim["initial_generation_equivalence"]["demand_bytes_same"] and prelim["initial_generation_equivalence"]["intent_bytes_same"]
    bound = [MODEL, compact_path, SOURCE / "evaluation/native/field-counts.xml", SOURCE / "evaluation/native/tripinfo.xml",
             SOURCE / "evaluation/evaluation.json", ROOT / "assignment182.npz", ROOT / "audit-inputs.json",
             ROOT / "bounded-128/proposal.json", ROOT / "bounded-128/solver-inputs.npz", ROOT / "bounded-128/generation-audit.json"]
    bound += list((SOURCE / "prepared").iterdir())
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core"
    bound += [core / n for n in ("native_temporal_feedback.py", "route_sensor_matrix.py", "hamburg_od_definition.py",
                                "hamburg_od_spsa.py", "hamburg_od_reuse.py", "spsa.py", "od_assignment_feedback.py")]
    bound += list((ROOT / "initial-model-replay").iterdir()) + list((ROOT / "bounded-128/generated").iterdir())
    summary = dict(status="pass", native_runs=0, new_solver_calls=0, formal_result=False,
        prior=prelim, full208_accounting=dict(rows=208, complete_events=8640, unique_vehicles=len(observed_fields),
            multi_field_vehicles=sum(len(v)>1 for v in observed_fields.values()), true_target_rows=182,
            real_target_window_events=8326, tail_events_without_real_targets=314,
            q_zero_columns=0, full208_zero_columns=int(np.sum(C208.sum(axis=0)==0))),
        zero_real182_columns=[dict(index=int(i), q=int(q[i]), observed_tail=int(C208[tail_indices, i].sum())) for i in zero],
        cells_with_multiple_observed_fields=sum(len(v)>1 for v in fields_per_cell.values()),
        bounded_proposal=dict(changed_cells=22, L1_change=128, vehicle_count=8640,
            before_main130_TAE=int(np.abs(C[main_rows].sum(axis=1)-target[main_rows]).sum()),
            predicted_main130_TAE=float(np.abs(residual[main_rows]).sum()),
            predicted_main130_MAE=float(np.abs(residual[main_rows]).mean()),
            before_all182_TAE=588, predicted_all182_TAE=float(np.abs(residual).sum()),
            initialization52_TAE_constant=105, predicted53556_max_abs_error=float(np.max(np.abs(residual[exact]))),
            OD_totals_preserved=True, first84_cells_frozen=True,
            actual_nonfixed_cells=len(free), numerical_rank_A130_plus_OD_totals_on_nonfixed=numerical_rank,
            nullity_on_nonfixed=len(free)-numerical_rank),
        reuse_boundaries=["native_temporal_feedback outputs OD-major columns; model is period-major: explicit reordering was checked.",
            "The256472 model reproduces current explicit demand and intentions byte-for-byte at current q; no model rebuild needed.",
            "Legacy exact integer route solver rejects fractional A and cannot replace bounded OD constraints.",
            "Initial52 have no contributions from later210 cells, so they remain constant at105TAE; they are retained, not set falsely exact.",
            "Source model network hash is historical b6ac; active prepared network99f208/controlf38c6c must be copied separately.",
            "The healthy replay lacks the OD-cache vector/execution layout required by reuse_hamburg_od_initial; do not fake cache metadata.",
            "SPSA component clipping alone does not conserve21 OD totals or implement the declared integer L1 trust region."],
        source_hashes={str(p.resolve()): sha(p) for p in bound},
        claim_boundary="C/q is same-replay accounting, not a Jacobian or a forecast invariant. Tail314 are measured model events without real target values. Positive prior8 columns with only tail evidence are not zero-demand unknown columns. Integer quantile generation changes1102 existing request times and463 route/stop records; only a new full native run can verify the proposal.")
    save(ROOT / "audit.json", summary)
    print(json.dumps(dict(status="pass", tail_events=314, initial_equivalence="byte exact", proposal_main_TAE=summary["bounded_proposal"]["predicted_main130_TAE"],
                         nonfixed_cells=len(free), constrained_numerical_nullity=len(free)-numerical_rank)))


if __name__ == "__main__":
    main()
