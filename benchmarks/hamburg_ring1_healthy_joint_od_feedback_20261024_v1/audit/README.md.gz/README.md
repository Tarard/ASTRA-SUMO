# 健康基准的联合分时 OD：离线审计

现有 `256472…` 294-cell model 在当前 q 上生成的 demand 与 lane-intentions 均与健康 full-priority **原字节相同**。无需重建 model。全部 8640 请求已插入、到达并各有一个完整 E1 事件；无跨字段或重复贡献。294 个 q 均为正，最小为 1。

描述分配使用 `native_temporal_feedback` 的贡献整数 C 与请求分母 q，已显式把 OD-major 列重排成 model 的 period-major。C/q × q 精确回算本次原生计数，只是对账。全 208 行另保存为 `assignment208-accounting.npz` 与 `native208-accounting.csv`：8326 事件落在真实 182 目标窗，314 在尾部 26 行；尾部没有真实目标，未填假零。182 中的 8 个零贡献列都有正 q 和尾部观测，不能称为零需求或未观测列。

唯一 `bounded-128` 提议使用现有新 helper，保持 21 OD 跨 14 时段总量与 N8640，冻结首 84 cell，其他 cell 限于 ±floor(q/4)，总 L1 预算 128；535 四字段 56 行预测 exact。22 个 cell 改变，主 130 TAE 的描述投影为 483→368.413577；初始化 52 的 TAE 恒为 105，保留报告而非宣称 exact。主目标与 all182 L1 只差该常数。`proposal.json`、`generated/` 和 `generation-audit.json` 已单独封口，未再改动。

生成仍用原 quantile 规则：64 新增/64 移除 ID，共同 ID 中 1102 个毫秒发车时刻、179 条 route、284 个 stop/field 意向变化。不能将此称为只有 64 人时移；未变 cell 的请求 XML 与意向逐项相同。新的原生响应由 root 的独立 native 研究测量，本目录无新 native。

最短路径：`native_temporal_feedback` 对账→`propose_bounded_od_assignment(C,q,…)`→原 `write_hamburg_od_demand`→保存的显式需求→`run_point_detector_demand` 与 `summarize_hamburg_od_measurement`。旧 exact integer route solver 不能接 fractional A；SPSA 的单坐标 clipping 也不保 OD 总量。旧 model 的 network hash 是历史 b6ac，活动网/控制必须另取当前 99f208/f38c6c。健康原运行缺旧 OD-cache 所需 vector/execution 布局，不能伪造 reuse 元数据。

主 130 数值秩为 120，全 182 为 168。冻结首 84 并加 OD 总量约束后，210 列仍有 75 维数值零空间；按实际整数界限只剩 176 个可变 cell，联合秩仍留 44 维。此为 float64 同次分配诊断，不是唯一真实 OD 识别结论，也不能保证 MAE0。`audit.json`、294-cell 表及预测 182 表保留数值与来源哈希；`finalize_audit.py` 仅核现有结果，不再求解或仿真。
