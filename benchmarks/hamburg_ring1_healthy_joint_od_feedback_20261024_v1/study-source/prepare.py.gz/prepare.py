"""Copy one sealed OD proposal into unchanged healthy native inputs."""

import argparse
from collections import Counter
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"


def prepare(proposal, audit):
    case = ROOT / "joint-128"
    assert not case.exists(), "Preserve earlier inputs and runs."
    prior = SOURCE / "prepared"
    names = ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv",
             "initialization-counts.csv", "scenario.json")
    old = ET.parse(prior / "demand.rou.xml").getroot().findall("vehicle")
    new = ET.parse(proposal / "demand.rou.xml").getroot().findall("vehicle")
    assert len(old) == len(new) == 8640 and len({v.get("id") for v in new}) == 8640
    def cells(vehicles):
        return Counter((v.find("route").get("edges").split()[0],
                        v.find("route").get("edges").split()[-1], int(float(v.get("depart")) // 900))
                       for v in vehicles)
    before, after = cells(old), cells(new)
    assert len(before) == len(after) == 294 and before.keys() == after.keys()
    assert sum(abs(after[k] - before[k]) for k in before) <= 128
    assert all(abs(after[k] - before[k]) <= int(before[k] * .25) for k in before)
    assert all(before[k] == after[k] for k in before if k[2] < 4)
    ods = {(o, d) for o, d, h in before}
    assert len(ods) == 21 and all(sum(before[o, d, h] for h in range(14)) ==
                                sum(after[o, d, h] for h in range(14)) for o, d in ods)
    assert {v.find("route").get("edges") for v in new} <= {v.find("route").get("edges") for v in old}
    def initial(vehicles):
        return [ET.canonicalize(ET.tostring(v, encoding="unicode"), strip_text=True)
                for v in vehicles if float(v.get("depart")) < 3600]
    assert initial(old) == initial(new)
    prepared = case / "prepared"
    prepared.mkdir(parents=True)
    for name in names:
        shutil.copyfile(prior / name, prepared / name)
    for name in ("demand.rou.xml", "lane-intentions.json"):
        shutil.copyfile(proposal / name, prepared / name)
    shutil.copyfile(proposal / "od-vector.json", case / "od-vector.json")
    scope_sources = [prior / n for n in (*names, "demand.rou.xml", "lane-intentions.json")]
    scope_sources += list(proposal.glob("*")) + [audit, Path(__file__), ROOT / "run_candidate.py",
        REPO / "plugins/astra-sumo/src/astra_sumo/core/od_assignment_feedback.py"]
    proof = {"status": "pass", "N": 8640,
             "source_hashes": {str(p.resolve()): sha(p) for p in scope_sources if p.is_file()},
             "prepared_hashes": {p.name: sha(p) for p in prepared.iterdir()},
             "original_driver_scope": _body_hold_nodes(prepared),
             "actual_changes": json.loads(audit.read_bytes()),
             "frozen_initialization_requests_exact": True,
             "all21_OD_totals_preserved": True, "all_routes_in_healthy_prior": True,
             "formal_result": False}
    (case / "scope-proof.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "prepared", "native_runs": 0, "N": 8640,
                      "l1_change": sum(abs(after[k] - before[k]) for k in before)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--proposal-dir", type=Path, required=True)
    parser.add_argument("--generation-audit", type=Path, required=True)
    args = parser.parse_args()
    prepare(args.proposal_dir.resolve(strict=True), args.generation_audit.resolve(strict=True))
