"""Evaluate one saved demand case against its complete native input parent."""
import argparse
import json
from pathlib import Path
import runpy
import shutil
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT))
ANCHOR = runpy.run_path(str(ROOT / "run_full_candidate.py"))
FULL = ANCHOR["FULL"]
load, sha, save = ANCHOR["load"], ANCHOR["sha"], ANCHOR["save"]
NAMES = ANCHOR["PREFIX"]["NAMES"]


def check(case):
    assert case.parent == ROOT / "cases" and case != ANCHOR["CASE"]
    proposal = load(case / "proposal.json")
    preparer = (ROOT / proposal["prepare_script"]).resolve()
    assert preparer.parent == ROOT and preparer.suffix == ".py"
    assert runpy.run_path(str(preparer))["check"](case.name)["status"] == "pass"
    parent = (REPO / proposal["source_case"]).resolve()
    assert parent.is_relative_to(REPO / "outputs") and parent != case
    previous = load(parent / "verdict.json")
    assert previous["healthy"] and previous["safe"] and previous["unique_intended_fields"]
    reference = ANCHOR["check"]()
    count = len(ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle"))
    assert count == len(load(case / "prepared/lane-intentions.json")["vehicles"])
    assert count == proposal["candidate_N"] == sum(load(case / "od-vector.json")["integer_counts"])
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert (case / "prepared" / name).read_bytes() == (parent / "prepared" / name).read_bytes()
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
    assert _body_hold_nodes(case / "prepared") == _body_hold_nodes(parent / "prepared")
    protected = proposal["protected_end_s"]
    assert protected in range(0, 12601, 900)
    paths = [Path(__file__), ROOT / "run_full_candidate.py", preparer,
             case / "proposal.json", case / "scope-proof.json", case / "od-vector.json",
             parent / "verdict.json", parent / "evaluation/native/field-counts.xml",
             FULL["BASE"]["AUDIT_HELPER"], FULL["BASE"]["AUDIT_HELPER"].parent / "audit_scope.py",
             REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_readme_results.py"]
    paths += [parent / "prepared" / name for name in NAMES]
    plan = {"source_case": str(parent), "source_N": previous["after"]["event_count"], "candidate_N": count,
            "source_hashes": {**reference["source_hashes"], **{str(p): sha(p) for p in paths}},
            "prepared_hashes": {name: sha(case / "prepared" / name) for name in NAMES},
            "prefix_end_s": protected, "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo",
            "comparison_role": "Complete native input parent; no partial-result substitution."}
    target = case / "measurement-plan.json"
    if target.exists():
        assert load(target) == plan, "Preserve the bound candidate."
    else:
        save(target, plan)
    code_paths = [Path(p) for p in plan["source_hashes"] if Path(p).suffix == ".py"]
    assert len({p.name for p in code_paths}) == len(code_paths), "Snapshot names must be unique."
    return {"status": "pass", "runtime": reference["runtime"], **plan}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    case = (ROOT / "cases" / args.case).resolve()
    checked = check(case)
    if args.check_only:
        print(json.dumps({k: checked[k] for k in ("status", "candidate_N", "source_N", "source_case", "prefix_end_s")}))
    else:
        assert not (case / "evaluation").exists() and not (case / "verdict.json").exists()
        snapshots = {"executed-driver.py": Path(__file__), "executed-shared-driver.py": ANCHOR["SHARED"]}
        assert all(not (case / name).exists() for name in snapshots)
        for name, source in snapshots.items():
            shutil.copyfile(source, case / name)
        checked["executed_driver_snapshots"] = {name: sha(case / name) for name in snapshots}
        FULL["run"](case, checked)
