"""Prepare nine existing counter-route substitutions; run no simulation."""
import argparse
from collections import Counter
import copy
import gzip
from decimal import Decimal
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET

import prepare_prefix as shared

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cases/h4_counter_z11_minus5_z5"
CASE = ROOT / "cases/h4_counter_fill9"
PAIRS = {"od_0098_v00068": "od_0092_v00000", "od_0100_v00070": "od_0094_v00000",
         "od_0099_v00070": "od_0093_v00000", "od_0098_v00070": "od_0092_v00000",
         "od_0100_v00073": "od_0094_v00000", "od_0100_v00069": "od_0094_v00000",
         "od_0099_v00069": "od_0093_v00000", "od_0098_v00069": "od_0092_v00000",
         "od_0100_v00071": "od_0094_v00000"}
SUPPORT = shared.REPO / "outputs/hamburg-counter-z13-driving-support-20261024-v1/smoke"


def data():
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    vehicles = {v.get("id"): v for v in ET.fromstring(raw).findall("vehicle")}
    metadata = json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())
    old_intent = {r["vehicle_id"]: r for r in metadata["vehicles"]}
    new_intent = copy.deepcopy(metadata)
    new_rows = {r["vehicle_id"]: r for r in new_intent["vehicles"]}
    source_q = Counter(r["od_cell"] for r in metadata["vehicles"])
    source_vector = json.loads((SOURCE / "od-vector.json").read_bytes())
    assert [source_q[i] for i in range(308)] == source_vector["integer_counts"]
    events = {r["vehicle_id"]:r for r in json.loads(gzip.decompress((SOURCE / "evaluation/contributing-passages.json.gz").read_bytes()))["passages"]}
    records = []
    for identity, template in PAIRS.items():
        old = vehicles[identity].find("route").get("edges").split()
        new = vehicles[template].find("route").get("edges").split()
        assert old[0] == "44532531" and new[0] == "25866659#1"
        assert old[-1] == new[-1] and old[old.index("24483192"):] == new[new.index("24483192"):]
        assert len(set(new)) == len(new)
        assert vehicles[identity].get("type") == vehicles[template].get("type")
        assert Decimal(4150) <= Decimal(vehicles[identity].get("depart")) < Decimal(4500)
        assert events[identity]["interval_begin_s"] >= 4500
        new_rows[identity]["od_cell"] = old_intent[template]["od_cell"]
        for key in ("route", "route_edges"):
            if key in new_rows[identity]:
                new_rows[identity][key] = new if isinstance(new_rows[identity][key], list) else " ".join(new)
        records.append(dict(vehicle_id=identity, template_vehicle_id=template,
                            departure_s=vehicles[identity].get("depart"), field_id=old_intent[identity]["field_id"],
                            old_od_cell=old_intent[identity]["od_cell"], new_od_cell=new_rows[identity]["od_cell"],
                            source_actual_E1_notification_s=events[identity]["notification_time_s"],
                            old_route=old, new_route=new))
    def replace(match):
        fragment = match.group()
        identity = ET.fromstring(fragment).get("id")
        if identity not in PAIRS:
            return fragment
        route = vehicles[PAIRS[identity]].find("route").get("edges").encode()
        updated, count = re.subn(rb'(<route\b[^>]*\bedges=")[^"]*(")', lambda m: m[1] + route + m[2], fragment, count=1)
        assert count == 1
        old, new = ET.fromstring(fragment), ET.fromstring(updated)
        assert old.attrib == new.attrib
        assert [ET.tostring(e) for e in old if e.tag != "route"] == [ET.tostring(e) for e in new if e.tag != "route"]
        return updated
    payload = shared.VEHICLE.sub(replace, raw)
    after = {v.get("id"):v for v in ET.fromstring(payload).findall("vehicle")}
    assert len(after) == len(vehicles) == 8589 and list(after) == list(vehicles)
    assert all(ET.tostring(v) == ET.tostring(vehicles[i]) for i,v in after.items() if i not in PAIRS)
    actual_map = {}
    for i,v in vehicles.items():
        edges = v.find("route").get("edges").split()
        actual_map[edges[0], edges[-1], int(Decimal(v.get("depart")) // 900)] = old_intent[i]["od_cell"]
    q = [0] * 308
    for i,v in after.items():
        edges = v.find("route").get("edges").split()
        cell = actual_map[edges[0], edges[-1], int(Decimal(v.get("depart")) // 900)]
        assert cell == new_rows[i]["od_cell"] and new_rows[i]["field_id"] == old_intent[i]["field_id"]
        q[cell] += 1
    changes = [dict(cell=i, source=source_q[i], candidate=q[i], delta=q[i]-source_q[i]) for i in range(308) if q[i]!=source_q[i]]
    assert [(r["cell"],r["delta"]) for r in changes] == [(96,3),(97,2),(98,4),(102,-3),(103,-2),(104,-4)]
    return payload, new_intent, records, [source_q[i] for i in range(308)], q, changes


def prepare():
    assert not CASE.exists(), "Preserve earlier inputs."
    parent = json.loads((SOURCE / "verdict.json").read_bytes())
    assert parent["healthy"] and parent["safe"] and parent["after"]["completion"]["arrived"] == 8589
    support = [SUPPORT / name / f"native-{name}/result.json" for name in ("source", "candidate")]
    assert all(json.loads(p.read_bytes())["status"] == "pass" for p in support)
    payload, intent, records, source_q, q, changes = data()
    prepared = CASE / "prepared"
    shutil.copytree(SOURCE / "prepared", prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    shared.save(prepared / "lane-intentions.json", intent)
    scenario = json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False,
                    demand_sha256=shared.sha(prepared / "demand.rou.xml"),
                    demand_prior="Nine existing h4 requests use the existing same-destination counter-route prefixes. All8589 IDs/times/types/fields/stops and244-onward suffixes remain; no resampling or runtime removal.")
    scenario["counter4_candidate"] = dict(route_changes=9, q_changes=changes, native_response_verified=False)
    shared.save(prepared / "scenario.json", scenario)
    shared.save(CASE / "proposal.json", dict(schema="astra.hamburg.h4-counter-fill9-proposal/v1", status="prepared", formal_result=False,
        new_native_runs=0, prepare_script="prepare_counter_fill9.py", source_case=str(SOURCE.relative_to(shared.REPO)).replace("\\", "/"),
        prefix_end_s=4500, protected_end_s=3600, source_N=8589, candidate_N=8589, changed_requests=9,
        source_first13_TAE=9, request_changes=records, q_changes=changes, q_L1=18,
        selection_rule=json.loads((SOURCE / "proposal.json").read_bytes())["selection_rule"]))
    shared.save(CASE / "od-vector.json", dict(schema="astra.hamburg.explicit-request-od-vector/v1", vehicle_count=8589,
                                             source_integer_counts=source_q, integer_counts=q, changed_cells=changes, l1_change=18,
                                             pair_count=22, dimension=308, time_bins=14,
                                             od_pairs=json.loads((SOURCE / "od-vector.json").read_bytes())["od_pairs"]))
    shutil.copy2(__file__, CASE / "executed-prepare.py")
    paths = [*[SOURCE / "prepared" / n for n in shared.NAMES], SOURCE / "verdict.json", SOURCE / "proposal.json", SOURCE / "od-vector.json",
             SOURCE / "evaluation/contributing-passages.json.gz",
             Path(__file__), Path(shared.__file__), *support]
    shared.save(CASE / "scope-proof.json", dict(schema="astra.hamburg.h4-counter-fill9-scope/v1", status="pass", N=8589,
        source_hashes={str(p.resolve()):shared.sha(p) for p in paths}, prepared_hashes={n:shared.sha(prepared / n) for n in shared.NAMES},
        proposal_sha256=shared.sha(CASE / "proposal.json"), od_vector_sha256=shared.sha(CASE / "od-vector.json"),
        checks=dict(only_nine_route_prefixes_changed=True, same_N_IDs_departures_types_fields_stops=True,
                    unchanged_vehicle_XML_and_order_exact=True, common_suffix_and_exit_exact=True,
                    existing_counter_complete_routes_only=True, actual308_q_and_nine_intents_updated=True,
                    network_control_truth_raw_bytes_exact=True, counter_Z12_Z13_support_bound=True)))
    return check("h4_counter_fill9")


def check(case_name):
    assert case_name == "h4_counter_fill9"
    scope = json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(scope["checks"].values())
    assert all(shared.sha(p)==h for p,h in scope["source_hashes"].items())
    assert all(shared.sha(CASE / "prepared" / n)==h for n,h in scope["prepared_hashes"].items())
    assert shared.sha(CASE / "proposal.json")==scope["proposal_sha256"] and shared.sha(CASE / "od-vector.json")==scope["od_vector_sha256"]
    payload, intent, records, _, q, _ = data()
    assert payload == (CASE / "prepared/demand.rou.xml").read_bytes()
    assert intent == json.loads((CASE / "prepared/lane-intentions.json").read_bytes())
    assert q == json.loads((CASE / "od-vector.json").read_bytes())["integer_counts"]
    assert records == json.loads((CASE / "proposal.json").read_bytes())["request_changes"]
    for name in shared.NAMES:
        if name not in ("demand.rou.xml", "lane-intentions.json", "scenario.json"):
            assert (CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    return dict(status="pass", case=case_name, candidate_N=8589, changed_requests=9, q_L1=18,
                protected_end_s=3600, prefix_end_s=4500, new_native_runs=0, scope_sha256=shared.sha(CASE / "scope-proof.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=["h4_counter_fill9"], default="h4_counter_fill9")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare", action="store_true")
    action.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
