"""Check a completed4500s prefix, keeping future requests and measurements distinct."""

import argparse
from collections import Counter
import gzip
import math
from pathlib import Path
import runpy
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
API = runpy.run_path(str(ROOT / "measure_prefix.py"))
load, sha, save = API["load"], API["sha"], API["save"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    case = (ROOT / "cases" / parser.parse_args().case).resolve()
    assert case.parent == ROOT / "cases" and not (case / "independent.json").exists()
    record, preflight = load(case / "record-result.json"), load(case / "preflight.json")
    assert record["status"] == "pass"
    assert all(sha(path) == digest for path, digest in preflight["source_hashes"].items())
    assert all(sha(case / "prepared" / name) == digest for name, digest in preflight["prepared_hashes"].items())
    assert all(sha(case / "measurement-implementation" / name) == digest for name, digest in preflight["implementation_sha256"].items())
    assert all(sha(path) == digest for path, digest in preflight["runtime"]["binaries"].items())
    assert all(sha(path) == digest for path, digest in record["native_output_hashes"].items())
    from astra_sumo.core.detector_demand import audit_expected_to_e1_strict
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages
    native = case / "native"
    run, monitor = load(native / "run.json"), load(native / "stall-monitor.json")
    assert run["native_status"] == "pass" and run["native_returncode"] == 0 and not run["errors"] and run["inputs_unchanged"]
    assert monitor["status"] == "completed" and monitor["library_completed"] and monitor["simulation_time_s"] == 4500
    assert monitor["native_library"] == preflight["runtime"]["native_library"]
    periodic = API["intervals"](native / "field-counts.xml")
    source = API["intervals"](API["SOURCE"] / "evaluation/native/field-counts.xml")
    protected = {key: value for key, value in periodic.items() if key[2] <= 3600}
    assert len(periodic) == 65 and len(protected) == 52
    assert protected == {key: value for key, value in source.items() if key[2] <= 3600}
    comparisons = audit_expected_to_e1_strict(API["csv_rows"](ROOT / "prefix13.csv"), native / "field-counts.xml")
    errors = [row["diff_nVehContrib_minus_expected"] for row in comparisons]
    metrics = {"rows": 13, "TAE": sum(map(abs, errors)), "SSE": sum(value*value for value in errors), "MAE": sum(map(abs, errors))/13}
    assert len(comparisons) == 13 and metrics == record["prefix13_metrics"]
    coverage = audit_expected_to_e1_strict(API["csv_rows"](case / "prepared/initialization-counts.csv") + API["csv_rows"](case / "prepared/expected-counts.csv"), native / "field-counts.xml")
    assert coverage == load(case / "all182-coverage.json") and len(coverage) == 182
    assert sum(row["measured_nVehContrib"] is None for row in coverage) == 117
    assert all(row["diff_nVehContrib_minus_expected"] is None for row in coverage if row["measured_nVehContrib"] is None)
    assert record["full130_metrics"] is None and record["full130_calibration_acceptance"] is False
    events = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=run["instant_to_periodic_ids"], step_length=.1)
    with gzip.open(case / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
        assert events == __import__("json").load(handle)
    complete = events["passages"] + events["outside_periodic_intervals"]
    fields = {row["vehicle_id"]: row["field_id"] for row in load(case / "prepared/lane-intentions.json")["vehicles"]}
    assert events["reconciled"] and all(row["detector_id"] == fields.get(row["vehicle_id"]) for row in complete)
    assert all(count == 1 for count in Counter((row["vehicle_id"], row["detector_id"]) for row in complete).values())
    assert all(abs(row["notification_time_s"]-4500) < 1e-8 for row in events["outside_periodic_intervals"])
    summary = API["summaries"](native / "summary.xml")
    assert len(summary) == 45000 and summary[-1] == record["prefix_completion"]
    final = summary[-1]
    safe = not ET.parse(native / "collisions.xml").getroot().findall("collision") and all(int(final[key]) == 0 for key in ("collisions", "teleports", "discarded"))
    assert safe
    vehicles = ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle")
    assert len(vehicles) == len(fields) == run["vehicle_count"] == 8594
    ids = {row.get("id") for row in vehicles}
    trips = ET.parse(native / "tripinfo.xml").getroot().findall("tripinfo")
    assert len(trips) == len({row.get("id") for row in trips}) == int(final["inserted"])
    assert {row.get("id") for row in trips} <= ids
    inventory = {"full_requested_N": len(vehicles), "requested_before4500": sum(math.floor(float(row.get("depart"))*1000+.5) < 4500000 for row in vehicles),
        "requested_at_or_after4500": sum(math.floor(float(row.get("depart"))*1000+.5) >= 4500000 for row in vehicles),
        "summary_loaded": int(final["loaded"]), "inserted": int(final["inserted"]), "arrived": int(final["arrived"]),
        "running": int(final["running"]), "waiting": int(final["waiting"]), "full_input_not_arrived": len(vehicles)-int(final["arrived"]),
        "complete_events_in65_intervals": len(events["passages"]), "complete_boundary_events_at4500": len(events["outside_periodic_intervals"])}
    result = {"schema": "astra.hamburg.chronological-prefix-independent/v1", "audit_status": "pass", "native_runs_by_audit": 0,
        "prefix13_metrics": metrics, "prefix13_comparison": comparisons, "initial52_all_attributes_unchanged": True,
        "initial52_TAE": sum(abs(row["diff_nVehContrib_minus_expected"]) for row in coverage[:52]), "inventory": inventory,
        "safe_until4500": safe, "future117_null": True, "full130_metrics": None, "full130_calibration_acceptance": False,
        "core_status": run["status"], "core_healthy": run["healthy"], "core_errors": run["errors"],
        "source_hashes": {**preflight["source_hashes"], **record["native_output_hashes"], str(case / "record-result.json"): sha(case / "record-result.json"), str(Path(__file__)): sha(Path(__file__))},
        "claim_boundary": "Only a safe4500s prefix is audited. Future requests have no invented positions. First13 fitting is not full calibration;117 future rows remain null and final14400s130-zero health remains unmeasured. No fixed-N zero-feasibility claim."}
    save(case / "independent.json", result)
    print(__import__("json").dumps({key: value for key, value in result.items() if key not in {"source_hashes", "prefix13_comparison"}}))


if __name__ == "__main__":
    main()
