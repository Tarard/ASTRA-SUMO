"""Prepare the four declared positive h4 refinements without running SUMO."""

import argparse
from decimal import Decimal
import json
from pathlib import Path
import shutil

import prepare_prefix as shared


ROOT = Path(__file__).resolve().parent
SHIFTS = {"h4_delay15": Decimal("15"), "h4_delay45": Decimal("45"),
          "h4_delay60": Decimal("60"), "h4_delay90": Decimal("90")}
SHARED_SHA = "5fde96010af35cf3c54db6032b2d8b3ab845f96cf2451b61870dce6d3bb139ee"
assert shared.sha(Path(shared.__file__)) == SHARED_SHA
# Extend only this imported module instance. Its source and earlier cases stay exact.
shared.SHIFTS.update(SHIFTS)


def prepare(case_name):
    assert case_name in SHIFTS
    shared.prepare(case_name)
    case = ROOT / "cases" / case_name
    proposal = json.loads((case / "proposal.json").read_bytes())
    proposal.update(prepare_script="prepare_delay_refinement.py", bounded_scan_total_new_points=4,
                    shared_prepare_source_sha256=SHARED_SHA)
    shared.save(case / "proposal.json", proposal)
    shutil.copy2(shared.__file__, case / "shared-prepare_prefix.py")
    shutil.copy2(__file__, case / "executed-prepare.py")
    scope = json.loads((case / "scope-proof.json").read_bytes())
    scope["source_hashes"][str(Path(__file__).resolve())] = shared.sha(__file__)
    scope["proposal_sha256"] = shared.sha(case / "proposal.json")
    scope["checks"].update(shared_implementation_exact=True, scan_entry_bound=True)
    shared.save(case / "scope-proof.json", scope)
    return check(case_name)


def check(case_name):
    assert case_name in SHIFTS
    assert shared.sha(Path(shared.__file__)) == SHARED_SHA
    result = shared.check(case_name)
    case = ROOT / "cases" / case_name
    proposal = json.loads((case / "proposal.json").read_bytes())
    scope = json.loads((case / "scope-proof.json").read_bytes())
    assert proposal["prepare_script"] == "prepare_delay_refinement.py"
    assert proposal["shared_prepare_source_sha256"] == SHARED_SHA
    assert scope["source_hashes"][str(Path(__file__).resolve())] == shared.sha(__file__)
    assert shared.sha(case / "shared-prepare_prefix.py") == SHARED_SHA
    assert shared.sha(case / "executed-prepare.py") == shared.sha(__file__)
    result.update(prepare_script="prepare_delay_refinement.py", shared_prepare_source_sha256=SHARED_SHA)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True, choices=list(SHIFTS))
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare", action="store_true")
    action.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    print(json.dumps(prepare(args.case) if args.prepare else check(args.case)))
