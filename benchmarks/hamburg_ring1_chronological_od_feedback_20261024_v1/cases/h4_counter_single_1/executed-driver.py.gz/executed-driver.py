"""Measure one saved prefix candidate through its declared local preparer."""

import argparse
import json
from pathlib import Path
import runpy
import shutil
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
HELPER = ROOT / "run_scan.py"
SHARED = runpy.run_path(str(HELPER))
API = SHARED["API"]
load, sha, save = SHARED["load"], SHARED["sha"], SHARED["save"]
assert sha(HELPER) == "970a6a6fd32f0fc682ac20be58aa73f57fa83ddf9f50320e8672bdb83212391f"


def check(case):
    proposal = load(case / "proposal.json")
    prepare = (ROOT / proposal["prepare_script"]).resolve()
    assert prepare.parent == ROOT and prepare.suffix == ".py" and prepare.is_file()
    assert runpy.run_path(str(prepare))["check"](case.name)["status"] == "pass"
    reference = API["check"](ROOT / "cases/baseline-prefix")
    paths = [Path(__file__), HELPER, SHARED["SHARED"], prepare, ROOT / "prepare_prefix.py",
        case / "scope-proof.json", case / "proposal.json", case / "od-vector.json"]
    plan = {key: value for key, value in reference.items() if key not in {"status", "runtime"}}
    plan.update(source_hashes={**reference["source_hashes"], **{str(path): sha(path) for path in paths}},
        prepared_hashes={name: sha(case / "prepared" / name) for name in API["NAMES"]},
        case=case.name, prepare_script=prepare.name, shared_driver_sha256=SHARED["SHARED_SHA"])
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert plan["prepared_hashes"][name] == reference["prepared_hashes"][name]
    path = case / "measurement-plan.json"
    if path.exists():
        assert load(path) == plan, "Preserve the recorded inputs and code."
    else:
        save(path, plan)
    return {"status": "pass", "runtime": reference["runtime"], **plan}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    case = (ROOT / "cases" / args.case).resolve()
    assert case.parent == ROOT / "cases"
    checked = check(case)
    gate = SHARED["baseline_gate"]()
    if args.check_only:
        print(json.dumps({"status": "pass", "native_runs": 0, "case": args.case, "baseline_gate": gate}))
    else:
        assert not (case / "native").exists() and not (case / "record-result.json").exists()
        snapshots = {"executed-driver.py": Path(__file__), "executed-shared-driver.py": SHARED["SHARED"]}
        assert all(not (case / name).exists() for name in snapshots)
        for name, source in snapshots.items():
            shutil.copyfile(source, case / name)
        checked.update(executed_driver_snapshots={name: sha(case / name) for name in snapshots}, baseline_gate=gate)
        API["run"](case, checked)
