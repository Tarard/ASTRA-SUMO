"""Select exactly one sealed counter4 vehicle fragment per independent candidate."""

import argparse
from collections import Counter
import copy
from decimal import Decimal
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import prepare_prefix as shared


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cases/h4_delay30"
DONOR = ROOT / "cases/h4_delay30_counter4"
IDS = ("od_0098_v00064", "od_0100_v00065", "od_0098_v00066", "od_0100_v00068")
CASES = {f"h4_counter_single_{index}": identity for index, identity in enumerate(IDS, 1)}


def data(case_name):
    identity = CASES[case_name]
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    donor_raw = (DONOR / "prepared/demand.rou.xml").read_bytes()
    blocks = [{ET.fromstring(match.group()).get("id"): match.group() for match in shared.VEHICLE.finditer(payload)} for payload in (raw, donor_raw)]
    assert len(blocks[0]) == len(blocks[1]) == 8594 and blocks[0].keys() == blocks[1].keys()
    old, counter = [ET.fromstring(rows[identity]) for rows in blocks]
    assert old.attrib == counter.attrib
    assert [ET.tostring(row) for row in old if row.tag != "route"] == [ET.tostring(row) for row in counter if row.tag != "route"]
    old_edges, new_edges = [row.find("route").get("edges").split() for row in (old, counter)]
    assert old_edges[0] == "44532531" and new_edges[0] == "25866659#1"
    assert old_edges[old_edges.index("24483192"):] == new_edges[new_edges.index("24483192"):]
    assert Decimal(3600) <= Decimal(old.get("depart")) < Decimal(4500)
    payload = shared.VEHICLE.sub(lambda match: blocks[1][identity] if ET.fromstring(match.group()).get("id") == identity else match.group(), raw)
    after_blocks = {ET.fromstring(match.group()).get("id"): match.group() for match in shared.VEHICLE.finditer(payload)}
    assert list(after_blocks) == list(blocks[0]) and after_blocks[identity] == blocks[1][identity]
    assert all(fragment == blocks[0][key] for key, fragment in after_blocks.items() if key != identity)
    metadata = json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())
    old_intent = {row["vehicle_id"]: row for row in metadata["vehicles"]}
    donor_intent = {row["vehicle_id"]: row for row in json.loads((DONOR / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    assert {k: v for k, v in old_intent[identity].items() if k != "od_cell"} == {k: v for k, v in donor_intent[identity].items() if k != "od_cell"}
    result = copy.deepcopy(metadata)
    for row in result["vehicles"]:
        if row["vehicle_id"] == identity:
            row["od_cell"] = donor_intent[identity]["od_cell"]
    new_intent = {row["vehicle_id"]: row for row in result["vehicles"]}
    coordinates = {}
    for key, fragment in blocks[0].items():
        vehicle = ET.fromstring(fragment)
        route = vehicle.find("route").get("edges").split()
        coordinate = route[0], route[-1], int(Decimal(vehicle.get("depart")) // 900)
        assert coordinate not in coordinates or coordinates[coordinate] == old_intent[key]["od_cell"]
        coordinates[coordinate] = old_intent[key]["od_cell"]
    source_q = [Counter(row["od_cell"] for row in metadata["vehicles"])[i] for i in range(294)]
    q = [0] * 294
    for key, fragment in after_blocks.items():
        vehicle = ET.fromstring(fragment)
        route = vehicle.find("route").get("edges").split()
        cell = coordinates[route[0], route[-1], int(Decimal(vehicle.get("depart")) // 900)]
        assert cell == new_intent[key]["od_cell"]
        q[cell] += 1
    changes = [{"cell": i, "source": a, "candidate": b, "delta": b-a} for i, (a, b) in enumerate(zip(source_q, q)) if a != b]
    assert sum(q) == 8594 and len(changes) == 2 and sum(abs(row["delta"]) for row in changes) == 2
    return payload, result, source_q, q, changes


def prepare(case_name):
    case = ROOT / "cases" / case_name
    assert not case.exists(), "Preserve previously prepared inputs."
    parent = json.loads((SOURCE / "record-result.json").read_bytes())
    assert parent["status"] == "pass" and parent["prefix13_metrics"]["TAE"] == 5
    donor_proof = json.loads((DONOR / "scope-proof.json").read_bytes())
    assert all(donor_proof["checks"].values())
    assert all(shared.sha(path) == digest for path, digest in donor_proof["source_hashes"].items())
    assert all(shared.sha(DONOR / "prepared" / name) == digest for name, digest in donor_proof["prepared_hashes"].items())
    payload, intent, source_q, q, changes = data(case_name)
    prepared = case / "prepared"
    shutil.copytree(SOURCE / "prepared", prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    shared.save(prepared / "lane-intentions.json", intent)
    scenario = json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False, demand_sha256=shared.sha(prepared / "demand.rou.xml"),
        demand_prior=f"Only{IDS.index(CASES[case_name])+1}:vehicle{CASES[case_name]} uses its complete sealed counter4 fragment. All8594 IDs/departures/fields/stops/types and the other8593 original vehicle bytes/order remain. No new route construction or runtime removal.")
    shared.save(prepared / "scenario.json", scenario)
    shared.save(case / "proposal.json", {"schema": "astra.hamburg.h4-counter-single-proposal/v1", "status": "prepared", "formal_result": False, "new_native_runs": 0,
        "prepare_script": Path(__file__).name, "source_case": str(SOURCE.relative_to(shared.REPO)).replace("\\", "/"),
        "donor_case": str(DONOR.relative_to(shared.REPO)).replace("\\", "/"), "prefix_end_s": 4500, "protected_end_s": 3600,
        "source_N": 8594, "candidate_N": 8594, "changed_requests": 1, "vehicle_id": CASES[case_name], "q_changes": changes, "q_L1": 2,
        "selection_rule": json.loads((SOURCE / "proposal.json").read_bytes())["selection_rule"],
        "claim_boundary": "One predeclared singleton response from the same parent. The four-way response does not identify any singleton effect. No automatic14-subset expansion or new native result is implied."})
    shared.save(case / "od-vector.json", {"vehicle_count": 8594, "source_integer_counts": source_q, "integer_counts": q, "changed_cells": changes, "l1_change": 2})
    paths = [*[SOURCE / "prepared" / name for name in shared.NAMES], SOURCE / "record-result.json", SOURCE / "proposal.json",
        DONOR / "prepared/demand.rou.xml", DONOR / "prepared/lane-intentions.json", DONOR / "scope-proof.json", DONOR / "proposal.json", Path(__file__), Path(shared.__file__)]
    shared.save(case / "scope-proof.json", {"schema": "astra.hamburg.h4-counter-single-scope/v1", "status": "pass", "N": 8594,
        "source_hashes": {str(path.resolve()): shared.sha(path) for path in paths}, "prepared_hashes": {name: shared.sha(prepared / name) for name in shared.NAMES},
        "proposal_sha256": shared.sha(case / "proposal.json"), "od_vector_sha256": shared.sha(case / "od-vector.json"),
        "checks": {"one_complete_counter4_fragment_exact": True, "other8593_vehicle_bytes_and_order_exact": True,
            "all_ID_depart_field_stop_type_N_preserved": True, "only_one_intent_od_cell_changed": True, "actual294_q_rebuilt": True,
            "network_control_all_truth_bytes_exact": True}})
    shutil.copyfile(__file__, case / "executed-prepare.py")
    return check(case_name)


def check(case_name):
    assert case_name in CASES
    case = ROOT / "cases" / case_name
    proof = json.loads((case / "scope-proof.json").read_bytes())
    assert proof["status"] == "pass" and all(proof["checks"].values())
    assert all(shared.sha(path) == digest for path, digest in proof["source_hashes"].items())
    assert all(shared.sha(case / "prepared" / name) == digest for name, digest in proof["prepared_hashes"].items())
    assert shared.sha(case / "proposal.json") == proof["proposal_sha256"] and shared.sha(case / "od-vector.json") == proof["od_vector_sha256"]
    payload, intent, _, q, changes = data(case_name)
    assert payload == (case / "prepared/demand.rou.xml").read_bytes()
    assert intent == json.loads((case / "prepared/lane-intentions.json").read_bytes())
    assert q == json.loads((case / "od-vector.json").read_bytes())["integer_counts"]
    assert changes == json.loads((case / "proposal.json").read_bytes())["q_changes"]
    for name in shared.NAMES:
        if name not in {"demand.rou.xml", "lane-intentions.json", "scenario.json"}:
            assert (case / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    return {"status": "pass", "native_runs": 0, "case": case_name, "vehicle_id": CASES[case_name], "candidate_N": 8594, "changed_requests": 1, "q_L1": 2}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=CASES, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare", action="store_true")
    action.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    print(json.dumps(prepare(args.case) if args.prepare else check(args.case)))
