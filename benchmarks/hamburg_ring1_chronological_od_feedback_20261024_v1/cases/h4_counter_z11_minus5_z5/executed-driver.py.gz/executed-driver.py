"""Measure the single saved8589-request candidate with the existing full runner."""

import argparse
from pathlib import Path
import runpy
import shutil
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT))
PREFIX = runpy.run_path(str(ROOT / "measure_prefix.py"))
load, sha, save = PREFIX["load"], PREFIX["sha"], PREFIX["save"]
SHARED = REPO / "outputs/hamburg-chronological-count-feedback-20261024-v1/run_case.py"
FULL = runpy.run_path(str(SHARED))
CASE = ROOT / "cases/h4_counter_z11_minus5_z5"
COMPARISON = REPO / "outputs/hamburg-chronological-count-feedback-20261024-v1/cases/window0_remove3"


def check():
    assert runpy.run_path(str(ROOT / "prepare_z11_minus5.py"))["check"](CASE.name)["status"] == "pass"
    reference = PREFIX["check"](ROOT / "cases/baseline-prefix")
    count = len(ET.parse(CASE / "prepared/demand.rou.xml").getroot().findall("vehicle"))
    assert count == 8589
    parent = REPO / load(CASE / "proposal.json")["source_case"]
    parent_record = load(parent / "record-result.json")
    assert parent_record["status"] == "pass" and all(parent_record["checks"].values())
    comparison = load(COMPARISON / "verdict.json")
    assert comparison["healthy"] and comparison["safe"] and comparison["unique_intended_fields"]
    assert comparison["after"]["metrics130"]["TAE"] == 448 and comparison["after"]["event_count"] == 8594
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert (CASE / "prepared" / name).read_bytes() == (COMPARISON / "prepared" / name).read_bytes()
    paths = [Path(__file__), SHARED, FULL["SHARED"], ROOT / "measure_prefix.py", ROOT / "prepare_z11_minus5.py",
        CASE / "scope-proof.json", CASE / "proposal.json", CASE / "od-vector.json", parent / "record-result.json", COMPARISON / "verdict.json", COMPARISON / "preflight.json"]
    plan = {"source_case": str(COMPARISON), "source_N": 8594, "candidate_N": count,
        "source_hashes": {**reference["source_hashes"], **{str(path): sha(path) for path in paths}},
        "prepared_hashes": {name: sha(CASE / "prepared" / name) for name in PREFIX["NAMES"]},
        "prefix_end_s": 3600, "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo",
        "input_parent_prefix": {"path": str(parent), "record_sha256": sha(parent / "record-result.json"), "prefix13_metrics": parent_record["prefix13_metrics"], "full_measurement": False},
        "comparison_reference": {"path": str(COMPARISON), "verdict_sha256": sha(COMPARISON / "verdict.json"), "N": 8594, "main130_TAE": 448, "role": "complete_reference_not_input_parent"}}
    target = CASE / "measurement-plan.json"
    if target.exists():
        assert load(target) == plan, "Preserve the bound full run."
    else:
        save(target, plan)
    return {"status": "pass", "runtime": reference["runtime"], **plan}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    checked = check()
    if args.check_only:
        print({key: checked[key] for key in ("status", "candidate_N", "source_N", "input_parent_prefix", "comparison_reference")})
    else:
        assert not (CASE / "evaluation").exists() and not (CASE / "verdict.json").exists()
        snapshots = {"executed-driver.py": Path(__file__), "executed-shared-driver.py": SHARED}
        assert all(not (CASE / name).exists() for name in snapshots)
        for name, source in snapshots.items():
            shutil.copyfile(source, CASE / name)
        checked["executed_driver_snapshots"] = {name: sha(CASE / name) for name in snapshots}
        FULL["run"](CASE, checked)
        verdict = load(CASE / "verdict.json")
        save(CASE / "full-result.json", {"shared_verdict": {"path": str(CASE / "verdict.json"), "sha256": sha(CASE / "verdict.json")},
            "input_parent_prefix": checked["input_parent_prefix"], "comparison_reference": checked["comparison_reference"],
            "after": verdict.get("after"), "claim_boundary": "The unmodified shared verdict source_parent key refers to the complete448 reference, not the prefix input parent. This is one fresh full measurement; no fixed-N zero-feasibility claim."})
