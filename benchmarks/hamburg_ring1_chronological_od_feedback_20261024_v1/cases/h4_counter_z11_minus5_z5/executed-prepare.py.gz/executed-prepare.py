"""Delete five hypothetical h4 requests before a fresh full native evaluation."""
import argparse
import copy
from decimal import Decimal
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import prepare_prefix as shared

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cases/h4_counter_z11_one"
NAME = "h4_counter_z11_minus5_z5"
CASE = ROOT / "cases" / NAME
REMOVED = {f"od_0104_v{rank:05d}" for rank in (59,61,62,65,66)}


def data():
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    before = {v.get("id"):v for v in ET.fromstring(raw).findall("vehicle")}
    intent = json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())
    rows = {r["vehicle_id"]:r for r in intent["vehicles"]}
    vector = json.loads((SOURCE / "od-vector.json").read_bytes())
    pairs = [(r["origin_edge"],r["destination_edge"]) for r in vector["od_pairs"]]
    assert len(before)==len(rows)==8594 and len(pairs)==22 and len(vector["integer_counts"])==308
    assert REMOVED <= set(before)
    for i in REMOVED:
        assert rows[i]["field_id"]=="hh_0119_Z_5_30494"
        assert Decimal(3600)<=Decimal(before[i].get("depart"))<Decimal(4500)
    payload = shared.VEHICLE.sub(lambda m:b"" if ET.fromstring(m.group()).get("id") in REMOVED else m.group(),raw)
    after = {v.get("id"):v for v in ET.fromstring(payload).findall("vehicle")}
    assert len(after)==8589 and set(after)==set(before)-REMOVED
    assert list(after)==[i for i in before if i not in REMOVED]
    assert all(ET.tostring(v)==ET.tostring(before[i]) for i,v in after.items())
    updated = copy.deepcopy(intent)
    updated["vehicles"] = [r for r in updated["vehicles"] if r["vehicle_id"] not in REMOVED]
    assert all(r==rows[r["vehicle_id"]] for r in updated["vehicles"])
    q = [0]*308
    source_q = [0]*308
    for i,v in before.items():
        edges = v.find("route").get("edges").split()
        cell = int(Decimal(v.get("depart"))//900)*22+pairs.index((edges[0],edges[-1]))
        assert cell==rows[i]["od_cell"]
        source_q[cell]+=1
        if i in after:
            q[cell]+=1
    assert source_q==vector["integer_counts"]
    changes = [dict(cell=i,source=source_q[i],candidate=q[i],delta=q[i]-source_q[i]) for i in range(308) if q[i]!=source_q[i]]
    assert [(r["cell"],r["delta"]) for r in changes]==[(108,-5)]
    removed = [dict(vehicle_id=i,departure_s=before[i].get("depart"),field=rows[i]["field_id"],od_cell=rows[i]["od_cell"]) for i in sorted(REMOVED)]
    return payload,updated,vector,source_q,q,changes,removed


def prepare():
    assert not CASE.exists(), "Preserve all previous cases."
    parent = json.loads((SOURCE / "record-result.json").read_bytes())
    assert parent["status"]=="pass" and all(parent["checks"].values()) and parent["prefix13_metrics"]["TAE"]==14
    payload,intent,source_vector,source_q,q,changes,removed = data()
    prepared = CASE / "prepared"
    shutil.copytree(SOURCE / "prepared",prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    shared.save(prepared / "lane-intentions.json",intent)
    scenario = json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    init = sum(Decimal(v.get("depart"))<3600 for v in ET.fromstring(payload).findall("vehicle"))
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,vehicles=8589,
        initialization_vehicles=init,main_vehicles=8589-init,demand_sha256=shared.sha(prepared / "demand.rou.xml"),
        demand_prior="Delete only five declared h4 Z5 hypothetical requests before simulation from the measured Z11-counter-one prefix. All8589 survivors retain exact XML/times/routes/fields/types/stops/order;22OD pairs remain. No runtime removal or resampling.")
    scenario["minus5_z5_candidate"] = dict(source_N=8594,candidate_N=8589,removed_requests=removed,native_response_verified=False)
    shared.save(prepared / "scenario.json",scenario)
    vector = dict(schema="astra.hamburg.explicit22pair-request-vector/v1",vehicle_count=8589,pair_count=22,time_bins=14,dimension=308,
        od_pairs=source_vector["od_pairs"],legacy_21pair_order=source_vector["legacy_21pair_order"],
        source_integer_counts=source_q,integer_counts=q,changed_cells=changes,l1_change=5)
    shared.save(CASE / "od-vector.json",vector)
    shared.save(CASE / "proposal.json",dict(schema="astra.hamburg.h4-z11-minus5-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        prepare_script="prepare_z11_minus5.py",source_case=str(SOURCE.relative_to(shared.REPO)).replace("\\","/"),
        source_N=8594,candidate_N=8589,prefix_end_s=3600,protected_end_s=3600,stage_end_s=4500,
        source_observed_end_s=4500,source_first13_TAE=14,source_full_metrics=None,
        removed_vehicle_ids=sorted(REMOVED),removed_requests=removed,added_requests=0,q_changes=changes,q_dimension=308,q_L1=5,
        claim_boundary="Five pre-simulation hypothetical input deletions. Parent has only4500s measured; do not fill its future117 from old full outputs or predict the new first13 counts. Evaluate the complete new14400 native run.",
        selection_rule=json.loads((SOURCE / "proposal.json").read_bytes())["selection_rule"]))
    shutil.copy2(__file__,CASE / "executed-prepare.py")
    paths=[*[SOURCE / "prepared" / n for n in shared.NAMES],SOURCE / "record-result.json",SOURCE / "od-vector.json",SOURCE / "proposal.json",Path(__file__),Path(shared.__file__)]
    shared.save(CASE / "scope-proof.json",dict(schema="astra.hamburg.h4-z11-minus5-scope/v1",status="pass",N=8589,source_N=8594,
        source_hashes={str(p.resolve()):shared.sha(p) for p in paths},prepared_hashes={n:shared.sha(prepared/n) for n in shared.NAMES},
        proposal_sha256=shared.sha(CASE / "proposal.json"),od_vector_sha256=shared.sha(CASE / "od-vector.json"),
        checks=dict(exact_five_h4_Z5_deletions=True,no_additions_or_runtime_removal=True,remaining_vehicle_XML_and_order_exact=True,
            remaining_intent_exact_subset=True,all_departures_routes_fields_types_stops_unchanged=True,OD_pair_library22_exact=True,
            actual308q_rebuilt=True,network_control_all130_and52_truth_raw_bytes_exact=True)))
    return check(NAME)


def check(case_name=NAME):
    assert case_name==NAME
    proof=json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(proof["checks"].values()) and all(shared.sha(p)==h for p,h in proof["source_hashes"].items())
    assert all(shared.sha(CASE / "prepared" / n)==h for n,h in proof["prepared_hashes"].items())
    assert shared.sha(CASE / "proposal.json")==proof["proposal_sha256"] and shared.sha(CASE / "od-vector.json")==proof["od_vector_sha256"]
    payload,intent,_,_,q,_,_=data()
    assert payload==(CASE / "prepared/demand.rou.xml").read_bytes()
    assert intent==json.loads((CASE / "prepared/lane-intentions.json").read_bytes())
    assert q==json.loads((CASE / "od-vector.json").read_bytes())["integer_counts"] and len(q)==308 and sum(q)==8589
    for name in shared.NAMES:
        if name not in ("demand.rou.xml","lane-intentions.json","scenario.json"):
            assert (CASE / "prepared" / name).read_bytes()==(SOURCE / "prepared" / name).read_bytes()
    return dict(status="pass",case=NAME,source_N=8594,candidate_N=8589,actual_N=8589,removed_requests=5,OD_pairs=22,q_dimension=308,new_native_runs=0,
                scope_sha256=shared.sha(CASE / "scope-proof.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=[NAME],default=NAME)
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
