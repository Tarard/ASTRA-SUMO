"""Run one of four saved timing points through the unchanged prefix measurer."""

import argparse
import json
from pathlib import Path
import runpy
import shutil
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
SHARED = ROOT / "measure_prefix.py"
SHARED_SHA = "e223be23e9b1555803d264fba813b0913630af5d1ea1fd2462a550f89a87882e"
API = runpy.run_path(str(SHARED))
load, sha, save = API["load"], API["sha"], API["save"]
assert sha(SHARED) == SHARED_SHA
CASES = ("h4_advance15", "h4_advance45", "h4_advance75", "h4_delay30")


def baseline_gate():
    path = ROOT / "cases/baseline-prefix/record-result.json"
    record = load(path)
    assert record["status"] == "pass" and all(record["checks"].values())
    assert set(record["baseline_parity"]) == {"all65_E1_attributes", "all45000_summary_except_duration", "complete_events_before4500"}
    assert all(record["baseline_parity"].values())
    assert all(sha(path) == digest for path, digest in record["native_output_hashes"].items())
    return {"path": str(path), "sha256": sha(path)}


def check(case):
    assert case.name in CASES
    assert runpy.run_path(str(ROOT / "prepare_scan.py"))["check"](case.name)["status"] == "pass"
    reference = API["check"](ROOT / "cases/baseline-prefix")
    paths = dict(reference["source_hashes"])
    for path in (Path(__file__), SHARED, ROOT / "prepare_scan.py", ROOT / "prepare_prefix.py", case / "scope-proof.json", case / "proposal.json", case / "od-vector.json"):
        paths[str(path)] = sha(path)
    prepared = {name: sha(case / "prepared" / name) for name in API["NAMES"]}
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert prepared[name] == reference["prepared_hashes"][name]
    plan = {"source_hashes": paths, "prepared_hashes": prepared, "full_requested_N": 8594, "full_target_rows": 182,
        "prefix_target_rows": 13, "end_s": 4500, "step_s": .1, "seed": 104, "backend": "libsumo",
        "case": case.name, "shared_measurement_driver": {"path": str(SHARED), "sha256": SHARED_SHA},
        "wrapper": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))}}
    path = case / "measurement-plan.json"
    if path.exists():
        assert load(path) == plan, "Preserve the bound scan point."
    else:
        save(path, plan)
    return {"status": "pass", "runtime": reference["runtime"], **plan}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=CASES, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    case = ROOT / "cases" / args.case
    checked = check(case)
    if args.check_only:
        print(json.dumps({"status": "pass", "native_runs": 0, "case": args.case, "full_requested_N": 8594,
            "prefix_end_s": 4500, "baseline_gate": baseline_gate()}))
    else:
        assert not (case / "native").exists() and not (case / "record-result.json").exists(), "Preserve previous and partial native output."
        gate = baseline_gate()
        snapshots = {"executed-driver.py": Path(__file__), "executed-shared-driver.py": SHARED}
        assert all(not (case / name).exists() for name in snapshots)
        for name, source in snapshots.items():
            shutil.copyfile(source, case / name)
        checked["executed_driver_snapshots"] = {name: sha(case / name) for name in snapshots}
        checked["baseline_gate"] = gate
        API["run"](case, checked)
