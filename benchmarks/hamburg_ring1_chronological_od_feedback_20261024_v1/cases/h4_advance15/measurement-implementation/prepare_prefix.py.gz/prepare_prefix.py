"""Prepare two fixed-population h4 timing inputs. This script runs no simulation."""

import argparse
from collections import Counter, defaultdict
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE_CASE = "outputs/hamburg-chronological-count-feedback-20261024-v1/cases/window0_remove3"
SOURCE = REPO / SOURCE_CASE
SHIFTS = {"h4_advance30": Decimal("-30"), "h4_advance60": Decimal("-60")}
NAMES = (
    "network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
    "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json",
)
VEHICLE = re.compile(rb"<vehicle\b[^>]*>.*?</vehicle>", re.S)
DEPART = re.compile(rb'(?<=\s)depart="[^"]+"')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def materialize_bytes(case_name):
    """Change only selected departure tokens, then stably sort normal requests."""
    shift = SHIFTS[case_name]
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    matches = list(VEHICLE.finditer(raw))
    assert len(matches) == 8594
    assert all(raw[a.end():b.start()] == b"" for a, b in zip(matches, matches[1:]))
    records = []
    changes = []
    source_q = [0] * 294
    q = [0] * 294
    intent = {v["vehicle_id"]: v for v in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    before_order = defaultdict(list)
    after_order = defaultdict(list)
    for rank, match in enumerate(matches):
        original = match.group()
        vehicle = ET.fromstring(original)
        identity = vehicle.get("id")
        edges = vehicle.find("route").get("edges").split()
        old = Decimal(vehicle.get("depart"))
        selected = edges[0] == "44532531" and Decimal(3600) <= old < Decimal(4500)
        new = old + shift if selected else old
        assert int(old // 900) == int(new // 900)
        cell = intent[identity]["od_cell"]
        assert cell // 21 == int(old // 900)
        source_q[cell] += 1
        q[cell] += 1
        changed = DEPART.sub(b'depart="' + format(new, "f").encode("ascii") + b'"', original, count=1) if selected else original
        if selected:
            restored = DEPART.sub(b'depart="' + vehicle.get("depart").encode("ascii") + b'"', changed, count=1)
            assert restored == original and new >= Decimal(3600)
            changes.append({"vehicle_id": identity, "od_cell": cell, "field_id": intent[identity]["field_id"],
                            "source_depart_s": str(old), "candidate_depart_s": str(new), "shift_s": str(shift)})
        records.append((new, rank, identity, changed, selected, tuple((edges[0], edges[-1]))))
        before_order[edges[0], edges[-1]].append(identity)
    assert len(changes) == 269 and len(intent) == len(records) == 8594
    assert source_q == q == json.loads((SOURCE / "od-vector.json").read_bytes())["integer_counts"]
    records.sort(key=lambda r: (r[0], r[1]))
    for record in records:
        after_order[record[5]].append(record[2])
    assert before_order == after_order
    selected_before = [r["vehicle_id"] for r in changes]
    selected_after = [r[2] for r in records if r[4]]
    assert selected_before == selected_after
    by_id = {r["vehicle_id"]: r for r in changes}
    for group in before_order.values():
        chosen = [by_id[i] for i in group if i in by_id]
        for a, b in zip(chosen, chosen[1:]):
            assert Decimal(b["source_depart_s"]) - Decimal(a["source_depart_s"]) == Decimal(b["candidate_depart_s"]) - Decimal(a["candidate_depart_s"])
    untouched_before = [ET.fromstring(m.group()).get("id") for m in matches if ET.fromstring(m.group()).get("id") not in by_id]
    assert untouched_before == [r[2] for r in records if not r[4]]
    payload = raw[:matches[0].start()] + b"".join(r[3] for r in records) + raw[matches[-1].end():]
    assert len(ET.fromstring(payload).findall("vehicle")) == 8594
    return payload, changes, q


def prepare(case_name):
    case = ROOT / "cases" / case_name
    assert not case.exists(), "Preserve existing candidates."
    health = json.loads((SOURCE / "verdict.json").read_bytes())
    assert health["healthy"] and health["safe"] and health["after"]["completion"]["arrived"] == 8594
    payload, changes, q = materialize_bytes(case_name)
    prepared = case / "prepared"
    shutil.copytree(SOURCE / "prepared", prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    scenario = json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False,
                    demand_sha256=sha(prepared / "demand.rou.xml"),
                    demand_prior="Fixed8594 explicit requests. Only269 h4 requests from44532531 have a common departure advance; no resampling, additions, deletions or route/field changes.",
                    time_prior=f"Candidate h4 common shift {SHIFTS[case_name]} seconds. Decimal request tokens retain precision. Native prefix and future response remain unmeasured.")
    scenario["prefix_timing_candidate"] = dict(changed_requests=269, shift_s=str(SHIFTS[case_name]),
                                               minimum_depart_s=min(r["candidate_depart_s"] for r in changes),
                                               protected_end_s=3600, measurement_end_s=4500,
                                               native_response_verified=False)
    save(prepared / "scenario.json", scenario)
    proposal = dict(schema="astra.hamburg.chronological-prefix-timing-proposal/v1", status="prepared", formal_result=False,
                    new_native_runs=0, source_case=SOURCE_CASE, prepare_script="prepare_prefix.py", prefix_end_s=4500,
                    protected_end_s=3600, source_N=8594, candidate_N=8594, changed_requests=269,
                    shift_s=str(SHIFTS[case_name]), source_main130_TAE=health["after"]["metrics130"]["TAE"],
                    request_changes=changes, q_changes=[], q_L1=0,
                    selection_rule={"required": ["baseline4500 actual parity before candidate simulation", "all52 initialization native attributes unchanged", "complete observed65 rows and safe identity-valid execution"],
                                    "primary_objective": "Minimize first13 main-window TAE; lower bound0.",
                                    "future_treatment": "Remaining117 main rows are unmeasured in a4500 prefix. Later full regression alone does not discard an improved stage objective; report it without a global improvement claim.",
                                    "final_target": "A complete14400 native run with all130 real main counts exact and healthy completion."},
                    claim_boundary="An empirical within-bin timing response, not a lag prediction or true demand identification. Source controls and driving assumptions remain. Future rows are unmeasured until a full run.")
    save(case / "proposal.json", proposal)
    save(case / "od-vector.json", dict(schema="astra.hamburg.explicit-request-od-vector/v1", vehicle_count=8594,
                                       source_integer_counts=q, integer_counts=q, changed_cells=[], l1_change=0))
    shutil.copy2(__file__, case / "executed-prepare.py")
    save(case / "scope-proof.json", dict(schema="astra.hamburg.chronological-prefix-timing-scope/v1", status="pass", new_native_runs=0,
        N=8594, source_N=8594, changed_requests=269,
        source_hashes={str(p.resolve()):sha(p) for p in [*[SOURCE / "prepared" / name for name in NAMES], SOURCE / "verdict.json", SOURCE / "od-vector.json", Path(__file__)]},
        prepared_hashes={name:sha(prepared / name) for name in NAMES}, proposal_sha256=sha(case / "proposal.json"), od_vector_sha256=sha(case / "od-vector.json"),
        checks=dict(same_N_IDs_vTypes_routes_stops_fields=True, exactly269_depart_tokens_changed=True, decimal_exact_shift=True,
                    all_other_vehicle_XML_exact=True, unmoved_vehicle_relative_order_exact=True, full_OD_order_exact=True,
                    selected_headways_exact=True, all_requests_globally_sorted=True, earliest_changed_depart_ge3600=True,
                    actual294_q_unchanged=True, lane_intentions_raw_bytes_exact=True, all_observations_network_control_raw_bytes_exact=True)))
    return check(case_name)


def check(case_name):
    assert case_name in SHIFTS
    case = ROOT / "cases" / case_name
    proof = json.loads((case / "scope-proof.json").read_bytes())
    assert all(proof["checks"].values())
    assert all(sha(p) == h for p,h in proof["source_hashes"].items())
    assert all(sha(case / "prepared" / n) == h for n,h in proof["prepared_hashes"].items())
    assert sha(case / "proposal.json") == proof["proposal_sha256"] and sha(case / "od-vector.json") == proof["od_vector_sha256"]
    payload, changes, q = materialize_bytes(case_name)
    assert payload == (case / "prepared/demand.rou.xml").read_bytes()
    assert changes == json.loads((case / "proposal.json").read_bytes())["request_changes"]
    assert q == json.loads((case / "od-vector.json").read_bytes())["integer_counts"]
    for name in NAMES:
        if name not in ("demand.rou.xml", "scenario.json"):
            assert (case / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    assert Counter(r["shift_s"] for r in changes) == {str(SHIFTS[case_name]):269}
    return dict(status="pass", case=case_name, new_native_runs=0, source_case=SOURCE_CASE, candidate_N=8594,
                changed_requests=269, earliest_changed_depart_s=str(min(Decimal(r["candidate_depart_s"]) for r in changes)),
                latest_changed_depart_s=str(max(Decimal(r["candidate_depart_s"]) for r in changes)),
                q_L1=0, protected_end_s=3600, prefix_end_s=4500,
                scope_sha256=sha(case / "scope-proof.json"), proposal_sha256=sha(case / "proposal.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True, choices=list(SHIFTS))
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare", action="store_true")
    action.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    print(json.dumps(prepare(args.case) if args.prepare else check(args.case)))
