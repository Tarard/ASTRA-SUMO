"""Prepare one supported Z11 counter route with explicit22-pair coordinates."""
import argparse
import copy
from decimal import Decimal
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET

import prepare_prefix as shared

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cases/h4_delay30"
CASE = ROOT / "cases/h4_counter_z11_one"
ID = "od_0097_v00010"
SUPPORT = shared.REPO / "outputs/hamburg-first13-route-support-20261024-v1/counter-z11-support.json"
SMOKE = shared.REPO / "outputs/hamburg-counter-z11-driving-support-20261024-v1/smoke"


def data():
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    before = {v.get("id"):v for v in ET.fromstring(raw).findall("vehicle")}
    metadata = json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())
    old = {r["vehicle_id"]:r for r in metadata["vehicles"]}
    pairs = [None] * 21
    legacy_q = [0] * 294
    for i,v in before.items():
        edges = v.find("route").get("edges").split()
        pair, cell = (edges[0],edges[-1]), old[i]["od_cell"]
        assert cell // 21 == int(Decimal(v.get("depart")) // 900)
        assert pairs[cell % 21] in (None,pair)
        pairs[cell % 21] = pair
        legacy_q[cell] += 1
    assert all(pairs) and len(set(pairs)) == 21
    assert legacy_q == json.loads((SOURCE / "od-vector.json").read_bytes())["integer_counts"]
    route = json.loads(SUPPORT.read_bytes())["full_route"]
    original = before[ID].find("route").get("edges").split()
    assert original[original.index("24483192"):] == route[route.index("24483192"):]
    assert (route[0],route[-1]) not in pairs and len(set(route)) == len(route)
    assert Decimal(before[ID].get("depart")) == Decimal("4148.352643252")
    all_pairs = pairs + [(route[0],route[-1])]
    def replace(match):
        if ET.fromstring(match.group()).get("id") != ID:
            return match.group()
        updated,count = re.subn(rb'(<route\b[^>]*\bedges=")[^"]*(")',lambda m:m[1]+" ".join(route).encode()+m[2],match.group(),count=1)
        assert count == 1
        return updated
    payload = shared.VEHICLE.sub(replace,raw)
    after = {v.get("id"):v for v in ET.fromstring(payload).findall("vehicle")}
    assert len(after)==8594 and list(after)==list(before)
    assert all(ET.tostring(v)==ET.tostring(before[i]) for i,v in after.items() if i!=ID)
    assert after[ID].attrib == before[ID].attrib
    assert [ET.tostring(e) for e in after[ID] if e.tag!="route"] == [ET.tostring(e) for e in before[ID] if e.tag!="route"]
    updated = copy.deepcopy(metadata)
    remapped_q,q = [0]*308,[0]*308
    remapped_labels = 0
    for row in updated["vehicles"]:
        identity = row["vehicle_id"]
        v = after[identity]
        edges = v.find("route").get("edges").split()
        time_bin = int(Decimal(v.get("depart")) // 900)
        cell = time_bin*22 + all_pairs.index((edges[0],edges[-1]))
        remapped_q[time_bin*22 + old[identity]["od_cell"]%21] += 1
        q[cell] += 1
        remapped_labels += row["od_cell"] != cell
        row["od_cell"] = cell
        if identity == ID:
            for key in ("route","route_edges"):
                if key in row:
                    row[key] = route if isinstance(row[key],list) else " ".join(route)
    changes = [dict(cell=i,source=remapped_q[i],candidate=q[i],delta=q[i]-remapped_q[i]) for i in range(308) if q[i]!=remapped_q[i]]
    assert [(r["cell"],r["delta"]) for r in changes] == [(101,-1),(109,1)]
    return payload,updated,pairs,all_pairs,legacy_q,remapped_q,q,changes,remapped_labels


def prepare():
    assert not CASE.exists(), "Preserve all earlier candidates."
    record = json.loads((SOURCE / "record-result.json").read_bytes())
    assert record["status"]=="pass" and record["prefix13_metrics"]["TAE"]==5
    assert shared.sha(SMOKE / "independent.json")=="e29c27393e9491422b22345287f648a228d0f57da2051e151261b891576cd0e3"
    assert json.loads((SMOKE / "native-support/result.json").read_bytes())["status"]=="pass"
    payload,intent,pairs,all_pairs,legacy_q,remapped_q,q,changes,labels = data()
    prepared = CASE / "prepared"
    shutil.copytree(SOURCE / "prepared",prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    shared.save(prepared / "lane-intentions.json",intent)
    scenario = json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,
        demand_sha256=shared.sha(prepared / "demand.rou.xml"),
        demand_prior="Only od_0097_v00010 uses the independently supported counter-Z11 complete route. All8594 IDs/times/types/fields/stops and244-onward suffix remain. Actual OD coordinates expand21 to22 pairs,294 to308 cells; no quantile regeneration.")
    scenario["OD_coordinates"] = dict(pairs=22,time_bins=14,cells=308,legacy_pairs=21,legacy_cells=294,native_response_verified=False)
    shared.save(prepared / "scenario.json",scenario)
    pair_rows = [dict(ordinal=i,origin_edge=a,destination_edge=b,legacy_ordinal=i if i<21 else None) for i,(a,b) in enumerate(all_pairs)]
    shared.save(CASE / "od-vector.json",dict(schema="astra.hamburg.explicit22pair-request-vector/v1",vehicle_count=8594,
        pair_count=22,time_bins=14,dimension=308,od_pairs=pair_rows,legacy_21pair_order=[dict(ordinal=i,origin_edge=a,destination_edge=b) for i,(a,b) in enumerate(pairs)],
        legacy_source_integer_counts294=legacy_q,source_integer_counts=remapped_q,integer_counts=q,changed_cells=changes,l1_change_after_coordinate_embedding=2))
    shared.save(CASE / "proposal.json",dict(schema="astra.hamburg.h4-counter-z11-one-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        source_case=str(SOURCE.relative_to(shared.REPO)).replace("\\","/"),prepare_script="prepare_counter_z11_one.py",prefix_end_s=4500,protected_end_s=3600,
        source_N=8594,candidate_N=8594,changed_requests=1,changed_vehicle_id=ID,departure_s="4148.352643252000",field="hh_0119_Z_11_28853",
        old_dimension=294,new_dimension=308,new_pair_ordinal=21,new_pair=all_pairs[-1],q_changes_in_308_coordinates=changes,q_L1_after_embedding=2,
        od_cell_labels_updated=labels,selection_rule=json.loads((SOURCE / "proposal.json").read_bytes())["selection_rule"]))
    shutil.copy2(__file__,CASE / "executed-prepare.py")
    paths=[*[SOURCE / "prepared" / n for n in shared.NAMES],SOURCE / "record-result.json",SOURCE / "od-vector.json",SOURCE / "proposal.json",SUPPORT,SMOKE / "native-support/result.json",SMOKE / "independent.json",Path(__file__),Path(shared.__file__)]
    shared.save(CASE / "scope-proof.json",dict(schema="astra.hamburg.h4-counter-z11-one-scope/v1",status="pass",N=8594,
        source_hashes={str(p.resolve()):shared.sha(p) for p in paths},prepared_hashes={n:shared.sha(prepared/n) for n in shared.NAMES},
        proposal_sha256=shared.sha(CASE / "proposal.json"),od_vector_sha256=shared.sha(CASE / "od-vector.json"),
        checks=dict(one_route_prefix_only=True,all_other_vehicle_XML_and_order_exact=True,all_departures_types_fields_stops_exact=True,
            original244_suffix_and_exit_exact=True,legacy21pair_order_recovered=True,appended22nd_pair=True,actual308q_rebuilt=True,
            all_intent_cell_labels_rebuilt=True,network_control_all_truth_bytes_exact=True,three_car_native_support_bound=True)))
    return check("h4_counter_z11_one")


def check(case_name):
    assert case_name=="h4_counter_z11_one"
    proof=json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(proof["checks"].values()) and all(shared.sha(p)==h for p,h in proof["source_hashes"].items())
    assert all(shared.sha(CASE / "prepared" / n)==h for n,h in proof["prepared_hashes"].items())
    assert shared.sha(CASE / "proposal.json")==proof["proposal_sha256"] and shared.sha(CASE / "od-vector.json")==proof["od_vector_sha256"]
    payload,intent,_,_,_,_,q,_,_=data()
    assert payload==(CASE / "prepared/demand.rou.xml").read_bytes()
    assert intent==json.loads((CASE / "prepared/lane-intentions.json").read_bytes())
    assert q==json.loads((CASE / "od-vector.json").read_bytes())["integer_counts"] and len(q)==308 and sum(q)==8594
    for name in shared.NAMES:
        if name not in ("demand.rou.xml","lane-intentions.json","scenario.json"):
            assert (CASE / "prepared" / name).read_bytes()==(SOURCE / "prepared" / name).read_bytes()
    return dict(status="pass",case=case_name,candidate_N=8594,route_changes=1,OD_pairs=22,q_dimension=308,new_native_runs=0,
                scope_sha256=shared.sha(CASE / "scope-proof.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=["h4_counter_z11_one"],default="h4_counter_z11_one")
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
