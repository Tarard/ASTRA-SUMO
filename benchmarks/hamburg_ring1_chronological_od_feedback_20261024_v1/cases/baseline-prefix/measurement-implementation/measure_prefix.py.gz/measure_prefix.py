"""Measure one4500s diagnostic prefix, keeping all full-window requests and truth."""

import argparse
from collections import Counter
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import time
import traceback
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-chronological-count-feedback-20261024-v1/cases/window0_remove3"
END = 4500
NAMES = ("network.net.xml", "control.add.xml", "demand.rou.xml", "lane-intentions.json", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv", "scenario.json")
sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
BASE = runpy.run_path(str(REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/run_full.py"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def csv_rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def intervals(path):
    rows = {}
    for row in ET.parse(path).getroot().findall("interval"):
        key = row.get("id"), float(row.get("begin")), float(row.get("end"))
        if key[2] <= END:
            assert key not in rows
            rows[key] = dict(row.attrib)
    return rows


def summaries(path):
    rows = []
    for _, row in ET.iterparse(path, events=("end",)):
        if row.tag == "step" and float(row.get("time")) < END:
            rows.append({key: value for key, value in row.attrib.items() if key != "duration"})
        row.clear()
    return rows


def prepare():
    case = ROOT / "cases/baseline-prefix"
    assert not case.exists(), "Preserve the existing baseline prefix."
    shutil.copytree(SOURCE / "prepared", case / "prepared")
    rows = [row for row in csv_rows(SOURCE / "prepared/expected-counts.csv") if float(row["begin"]) == 3600 and float(row["end"]) == END]
    assert len(rows) == len({row["detector_id"] for row in rows}) == 13
    target = ROOT / "prefix13.csv"
    if target.exists():
        assert csv_rows(target) == rows
    else:
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    save(case / "scope-proof.json", {"status": "pass", "N": 8594, "prefix_end_s": END,
        "prepared_hashes": {name: sha(case / "prepared" / name) for name in NAMES},
        "diagnostic_targets": {"path": str(target), "sha256": sha(target), "rows": 13,
            "source": str(SOURCE / "prepared/expected-counts.csv"), "source_sha256": sha(SOURCE / "prepared/expected-counts.csv")},
        "claim_boundary": "Only a shorter native horizon and separately derived diagnostic target subset. All8594 full requests and all130+52 real targets remain unchanged."})


def selfcheck():
    from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, compare_expected_to_e1_strict
    truth = csv_rows(SOURCE / "prepared/expected-counts.csv")
    actual = audit_expected_to_e1_strict(truth, SOURCE / "evaluation/native/field-counts.xml")
    counts = {(row["detector_id"], row["begin"], row["end"]): row["measured_nVehContrib"] for row in actual if float(row["end"]) <= END}
    partial = compare_expected_to_e1_strict(truth, counts)
    assert len(partial) == 130 and sum(row["measured_nVehContrib"] is None for row in partial) == 117
    assert all(row["diff_nVehContrib_minus_expected"] is None for row in partial if row["measured_nVehContrib"] is None)
    assert len(intervals(SOURCE / "evaluation/native/field-counts.xml")) == 65
    return {"status": "pass", "native_runs": 0, "source_only65_intervals": True, "future117_remain_null": True}


def check(case):
    if case.name == "baseline-prefix":
        assert all((case / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes() for name in NAMES)
    else:
        sys.path.insert(0, str(ROOT))
        assert runpy.run_path(str(ROOT / "prepare_prefix.py"))["check"](case.name)["status"] == "pass"
    assert csv_rows(ROOT / "prefix13.csv") == [row for row in csv_rows(SOURCE / "prepared/expected-counts.csv") if float(row["begin"]) == 3600 and float(row["end"]) == END]
    assert len(csv_rows(case / "prepared/expected-counts.csv")) == 130 and len(csv_rows(case / "prepared/initialization-counts.csv")) == 52
    assert len(ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle")) == 8594
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert (case / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    parent = load(SOURCE / "verdict.json")
    assert parent["healthy"] and parent["safe"] and parent["unique_intended_fields"] and parent["after"]["metrics130"]["TAE"] == 448
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    original = load(SOURCE / "preflight.json")["runtime"]
    assert runtime["modules"] == original["modules"] and runtime["native_library"] == original["native_library"]
    assert all(sha(path) == digest for path, digest in original["binaries"].items())
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime.update(binaries=original["binaries"], child_pythonpath=os.environ["PYTHONPATH"])
    request = load(SOURCE / "evaluation/native/native-request.json")
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
    assert request["backend"] == "libsumo" and request["junction_body_hold"] and request["monitor_interval_s"] is None and request["all_stopped_timeout_s"] == 300
    assert tuple(request["junction_body_hold_nodes"]) == _body_hold_nodes(case / "prepared")
    paths = [Path(__file__), BASE["RUNTIME_HELPER"], ROOT / "prefix13.csv", case / "scope-proof.json", SOURCE / "verdict.json", SOURCE / "preflight.json", SOURCE / "evaluation/native/native-request.json"]
    paths += list((SOURCE / "prepared").iterdir())
    paths += [SOURCE / "evaluation" / name for name in ("native/field-counts.xml", "native/summary.xml", "contributing-passages.json.gz")]
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in ("detector_demand_replay.py", "detector_demand.py", "hamburg_od_spsa.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    if case.name != "baseline-prefix":
        paths += [ROOT / "prepare_prefix.py", case / "proposal.json"]
    plan = {"source_hashes": {str(path): sha(path) for path in paths}, "prepared_hashes": {name: sha(case / "prepared" / name) for name in NAMES},
        "full_requested_N": 8594, "full_target_rows": 182, "prefix_target_rows": 13, "end_s": END, "step_s": .1, "seed": 104, "backend": "libsumo"}
    if (case / "measurement-plan.json").exists():
        assert load(case / "measurement-plan.json") == plan
    else:
        save(case / "measurement-plan.json", plan)
    return {"status": "pass", "runtime": runtime, **plan}


def run(case, checked):
    from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, write_csv
    from astra_sumo.core.detector_demand_replay import run_point_detector_demand
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages
    assert not (case / "native").exists() and not (case / "record-result.json").exists(), "Preserve previous and partial native evidence."
    baseline = None
    if case.name != "baseline-prefix":
        baseline = load(ROOT / "cases/baseline-prefix/record-result.json")
        assert baseline["status"] == "pass" and all(baseline["baseline_parity"].values())
        assert all(sha(path) == digest for path, digest in baseline["native_output_hashes"].items())
    implementation = case / "measurement-implementation"
    implementation.mkdir()
    for path in checked["source_hashes"]:
        path = Path(path)
        if path.suffix == ".py":
            assert not (implementation / path.name).exists()
            shutil.copyfile(path, implementation / path.name)
    save(case / "preflight.json", {**checked, "implementation_sha256": {path.name: sha(path) for path in implementation.iterdir()},
        "baseline_gate_sha256": sha(ROOT / "cases/baseline-prefix/record-result.json") if baseline else None})
    started = time.perf_counter()
    try:
        prepared, native = case / "prepared", case / "native"
        result = run_point_detector_demand(net_file=prepared / "network.net.xml", route_file=prepared / "demand.rou.xml", e1_additional_file=prepared / "field-loops.add.xml",
            expected_counts_csv=ROOT / "prefix13.csv", output_dir=native, end_s=END, step_length=.1, seed=104, backend="libsumo", timeout_seconds=4800,
            sumo_binary=str(REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe"), signal_program_file=prepared / "control.add.xml", lane_intentions_file=prepared / "lane-intentions.json",
            junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared), all_stopped_timeout_s=300)
        monitor = load(native / "stall-monitor.json")
        rows = summaries(native / "summary.xml")
        periodic, source_periodic = intervals(native / "field-counts.xml"), intervals(SOURCE / "evaluation/native/field-counts.xml")
        events = read_contributing_e1_passages(instant_file=native / "instant-e1.xml", periodic_file=native / "field-counts.xml", detector_ids=result["instant_to_periodic_ids"], step_length=.1)
        (case / "contributing-passages.json.gz").write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        complete = events["passages"] + events["outside_periodic_intervals"]
        fields = {row["vehicle_id"]: row["field_id"] for row in load(prepared / "lane-intentions.json")["vehicles"]}
        repeats = [list(key) + [count] for key, count in Counter((row["vehicle_id"], row["detector_id"]) for row in complete).items() if count > 1]
        outside = [row for row in complete if row["detector_id"] != fields.get(row["vehicle_id"])]
        comparisons = audit_expected_to_e1_strict(csv_rows(ROOT / "prefix13.csv"), native / "field-counts.xml")
        errors = [row["diff_nVehContrib_minus_expected"] for row in comparisons]
        coverage = audit_expected_to_e1_strict(csv_rows(prepared / "initialization-counts.csv") + csv_rows(prepared / "expected-counts.csv"), native / "field-counts.xml")
        assert len(coverage) == 182 and sum(row["measured_nVehContrib"] is None for row in coverage) == 117
        save(case / "all182-coverage.json", coverage)
        write_csv(case / "all182-coverage.csv", coverage, list(coverage[0]))
        protected = {key: value for key, value in periodic.items() if key[2] <= 3600}
        final = rows[-1]
        checks = {"no_unexpected_core_errors": not result["errors"], "native_subprocess_pass": result["native_status"] == "pass" and result["native_returncode"] == 0,
            "library_completed_at4500": monitor["status"] == "completed" and monitor["library_completed"] and monitor["simulation_time_s"] == END,
            "project_library_exact": monitor["native_library"] == checked["runtime"]["native_library"] and Path(monitor["traci_module"]).resolve().is_relative_to(REPO / ".venv"),
            "all45000_steps": len(rows) == 45000 and float(final["time"]) == 4499.9,
            "all65_raw_intervals": len(periodic) == 65 and len(protected) == 52,
            "all13_real_counts_measured": len(comparisons) == 13 and result["observer_complete"] and result["missing_field_bins"] == 0,
            "events_reconciled": events["reconciled"], "only_boundary_outside_events": all(abs(row["notification_time_s"]-END) < 1e-8 for row in events["outside_periodic_intervals"]),
            "known_correct_unique_observed_fields": not repeats and not outside,
            "safe_until4500": not ET.parse(native / "collisions.xml").getroot().findall("collision") and all(int(final[key]) == 0 for key in ("collisions", "teleports", "discarded")),
            "all_full_inputs_unchanged": result["inputs_unchanged"] and all(sha(prepared / name) == digest for name, digest in checked["prepared_hashes"].items()),
            "initial52_attributes_protected": protected == {key: value for key, value in source_periodic.items() if key[2] <= 3600}}
        parity = {}
        if case.name == "baseline-prefix":
            with gzip.open(SOURCE / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
                source_events = json.load(handle)["passages"]
            def order(values):
                return sorted(values, key=lambda row: (row["notification_time_s"], row["detector_id"], row["vehicle_id"]))
            parity = {"all65_E1_attributes": periodic == source_periodic, "all45000_summary_except_duration": rows == summaries(SOURCE / "evaluation/native/summary.xml"),
                "complete_events_before4500": order(events["passages"]) == order([row for row in source_events if row["notification_time_s"] < END])}
        record = {"schema": "astra.hamburg.chronological-prefix-measurement/v1", "status": "pass" if all(checks.values()) and all(parity.values()) else "blocked",
            "formal_result": False, "checks": checks, "baseline_parity": parity, "prefix13_metrics": {"rows": 13, "TAE": sum(map(abs, errors)), "SSE": sum(value*value for value in errors), "MAE": sum(map(abs, errors))/13},
            "prefix_completion": final, "full_requested_N": 8594, "future117_unmeasured": True, "full130_metrics": None, "full130_calibration_acceptance": False,
            "core_status": result["status"], "core_healthy": result["healthy"], "core_errors": result["errors"], "repeated_fields": repeats, "outside_intentions": outside,
            "native_output_hashes": {str(native / name): sha(native / name) for name in ("field-counts.xml", "instant-e1.xml", "summary.xml", "tripinfo.xml", "vehicle-routes.xml", "collisions.xml", "stall-monitor.json")},
            "elapsed_s": time.perf_counter()-started,
            "claim_boundary": "Only the4500s prefix is measured. All8594 requests and all130+52 true targets remain. Future117 rows are null, never zero. Prefix safety/equality or a first13 fit does not establish full completion or calibration; final14400s healthy130-zero remeasurement remains required. Fixed-N feasibility is not claimed."}
        save(case / "record-result.json", record)
        print(json.dumps(record, ensure_ascii=False))
        if record["status"] != "pass":
            raise SystemExit(1)
    except Exception as error:
        save(case / "failure.json", {"status": "blocked", "error": f"{type(error).__name__}: {error}", "partial_outputs_preserved": True, "full130_calibration_acceptance": False})
        (case / "failure.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("baseline-prefix", "h4_advance30", "h4_advance60"), default="baseline-prefix")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare", action="store_true")
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.prepare:
        assert args.case == "baseline-prefix"
        prepare()
    case = ROOT / "cases" / args.case
    checked = check(case)
    if args.run:
        run(case, checked)
    else:
        print(json.dumps({"status": "pass", "native_runs": 0, "selfcheck": selfcheck(), "case": args.case, "full_requested_N": 8594, "prefix_end_s": END}))
