"""Move only the four measured counter requests to a declared late timetable."""
import argparse
from collections import Counter
from decimal import Decimal
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import prepare_prefix as shared

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cases/h4_delay30_counter4"
CASE = ROOT / "cases/h4_delay30_counter4_late"
TIMES = {"od_0098_v00064": "4250.000000000000", "od_0100_v00065": "4255.000000000000",
         "od_0098_v00066": "4260.000000000000", "od_0100_v00068": "4265.000000000000"}


def data():
    raw = (SOURCE / "prepared/demand.rou.xml").read_bytes()
    matches = list(shared.VEHICLE.finditer(raw))
    assert len(matches) == 8594 and all(raw[a.end():b.start()] == b"" for a,b in zip(matches,matches[1:]))
    intent = {r["vehicle_id"]:r for r in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    q = [0] * 294
    records, changes = [], []
    for rank,match in enumerate(matches):
        original = match.group()
        vehicle = ET.fromstring(original)
        identity, old = vehicle.get("id"), vehicle.get("depart")
        new = TIMES.get(identity, old)
        assert int(Decimal(new) // 900) == int(Decimal(old) // 900) == intent[identity]["od_cell"] // 21
        q[intent[identity]["od_cell"]] += 1
        fragment = shared.DEPART.sub(b'depart="' + new.encode() + b'"',original,count=1) if identity in TIMES else original
        if identity in TIMES:
            assert shared.DEPART.sub(b'depart="' + old.encode() + b'"',fragment,count=1) == original
            changes.append(dict(vehicle_id=identity,source_depart_s=old,candidate_depart_s=new))
        records.append((Decimal(new),rank,identity,fragment))
    assert [r["vehicle_id"] for r in changes] == list(TIMES)
    assert q == json.loads((SOURCE / "od-vector.json").read_bytes())["integer_counts"]
    records.sort(key=lambda r:(r[0],r[1]))
    assert [r[2] for r in records if r[2] in TIMES] == list(TIMES)
    assert [ET.fromstring(m.group()).get("id") for m in matches if ET.fromstring(m.group()).get("id") not in TIMES] == [r[2] for r in records if r[2] not in TIMES]
    payload = raw[:matches[0].start()] + b"".join(r[3] for r in records) + raw[matches[-1].end():]
    assert len(ET.fromstring(payload).findall("vehicle")) == 8594
    return payload, changes, q


def prepare():
    assert not CASE.exists(), "Preserve all earlier cases."
    parent = json.loads((SOURCE / "record-result.json").read_bytes())
    assert parent["status"] == "pass" and parent["prefix13_metrics"]["TAE"] == 13 and all(parent["checks"].values())
    payload, changes, q = data()
    prepared = CASE / "prepared"
    shutil.copytree(SOURCE / "prepared",prepared)
    (prepared / "demand.rou.xml").write_bytes(payload)
    scenario = json.loads((SOURCE / "prepared/scenario.json").read_bytes())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,
                    demand_sha256=shared.sha(prepared / "demand.rou.xml"),
                    demand_prior="Inherited8594 explicit requests and four counter-route substitutions. Only those four counter request times change to4250/4255/4260/4265; all routes, OD quantities, fields, stops, types and other request times remain exact.",
                    time_prior="One declared four-request timing contrast. Other request interleavings can change; no native passage prediction or future fit claim.")
    scenario["counter4_late_candidate"] = dict(request_changes=changes,native_response_verified=False)
    shared.save(prepared / "scenario.json",scenario)
    shared.save(CASE / "proposal.json",dict(schema="astra.hamburg.h4-counter4-late-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        source_case=str(SOURCE.relative_to(shared.REPO)).replace("\\","/"),prepare_script="prepare_counter_late.py",
        source_N=8594,candidate_N=8594,prefix_end_s=4500,protected_end_s=3600,changed_requests=4,
        request_changes=changes,q_changes=[],q_L1=0,source_first13_TAE=13,
        selection_rule=json.loads((SOURCE / "proposal.json").read_bytes())["selection_rule"]))
    shared.save(CASE / "od-vector.json",dict(schema="astra.hamburg.explicit-request-od-vector/v1",vehicle_count=8594,
                                             source_integer_counts=q,integer_counts=q,changed_cells=[],l1_change=0))
    shutil.copy2(__file__,CASE / "executed-prepare.py")
    paths = [*[SOURCE / "prepared" / n for n in shared.NAMES],SOURCE / "record-result.json",SOURCE / "od-vector.json",SOURCE / "proposal.json",Path(__file__),Path(shared.__file__)]
    shared.save(CASE / "scope-proof.json",dict(schema="astra.hamburg.h4-counter4-late-scope/v1",status="pass",N=8594,
        source_hashes={str(p.resolve()):shared.sha(p) for p in paths},prepared_hashes={n:shared.sha(prepared / n) for n in shared.NAMES},
        proposal_sha256=shared.sha(CASE / "proposal.json"),od_vector_sha256=shared.sha(CASE / "od-vector.json"),
        checks=dict(exact_four_departure_tokens_only=True,same_N_IDs_routes_types_fields_stops=True,four_relative_order_exact=True,
                    unmoved_XML_and_relative_order_exact=True,global_departure_sort=True,actual294_q_exact=True,
                    intentions_network_control_all_truth_raw_bytes_exact=True)))
    return check("h4_delay30_counter4_late")


def check(case_name):
    assert case_name == "h4_delay30_counter4_late"
    scope = json.loads((CASE / "scope-proof.json").read_bytes())
    assert all(scope["checks"].values())
    assert all(shared.sha(p)==h for p,h in scope["source_hashes"].items())
    assert all(shared.sha(CASE / "prepared" / n)==h for n,h in scope["prepared_hashes"].items())
    assert shared.sha(CASE / "proposal.json")==scope["proposal_sha256"] and shared.sha(CASE / "od-vector.json")==scope["od_vector_sha256"]
    payload, changes, q = data()
    assert payload == (CASE / "prepared/demand.rou.xml").read_bytes()
    assert changes == json.loads((CASE / "proposal.json").read_bytes())["request_changes"]
    assert q == json.loads((CASE / "od-vector.json").read_bytes())["integer_counts"]
    assert Counter(TIMES.keys()) == Counter(r["vehicle_id"] for r in changes)
    for name in shared.NAMES:
        if name not in ("demand.rou.xml","scenario.json"):
            assert (CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    return dict(status="pass",case=case_name,candidate_N=8594,changed_requests=4,q_L1=0,new_native_runs=0,
                scope_sha256=shared.sha(CASE / "scope-proof.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=["h4_delay30_counter4_late"],default="h4_delay30_counter4_late")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args = parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
