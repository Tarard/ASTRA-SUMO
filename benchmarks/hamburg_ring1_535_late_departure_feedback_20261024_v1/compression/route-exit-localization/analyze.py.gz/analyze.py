"""Compare only the two completed same-route runs; never read other probes."""

from collections import defaultdict
import gzip
import json
from pathlib import Path
import runpy
import statistics
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
AFTER = ROOT / "compress29"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"
sys.path.insert(0, str(HELPER.parent))
tools = runpy.run_path(str(HELPER))
sha, table, save = tools["digest"], tools["table"], tools["save"]


def main():
    assert not (OUT / "manifest.json").exists()
    assert all((p / "verdict.json").is_file() for p in (SOURCE, AFTER))
    selected = {r["vehicle_id"]: r for r in json.loads((AFTER / "proposal.json").read_bytes())["proposals"]}
    assert len(selected) == 29
    routes, events, holds, prepared = [], [], [], []
    for case in (SOURCE, AFTER):
        routes.append({r.get("id"): r for r in ET.parse(case / "evaluation/native/vehicle-routes.xml").getroot().findall("vehicle") if r.get("id") in selected})
        with gzip.open(case / "evaluation/contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
            values = [r for r in json.load(handle)["passages"] if r["vehicle_id"] in selected]
        events.append({r["vehicle_id"]: r for r in values})
        assert len(values) == len(events[-1]) == 29
        holds.append(json.loads((case / "evaluation/native/stall-monitor.json").read_bytes())["lane_section_hold"])
        prepared.append({r.get("id"): r for r in ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle") if r.get("id") in selected})
    assert (SOURCE / "prepared/network.net.xml").read_bytes() == (AFTER / "prepared/network.net.xml").read_bytes()
    assert (SOURCE / "prepared/control.add.xml").read_bytes() == (AFTER / "prepared/control.add.xml").read_bytes()
    network = ET.parse(SOURCE / "prepared/network.net.xml").getroot()
    roads = {e.get("id"): e for e in network.findall("edge") if not e.get("function")}
    nodes = {j.get("id"): j for j in network.findall("junction")}
    programs = {p.get("id"): p for p in ET.parse(SOURCE / "prepared/control.add.xml").getroot().findall("tlLogic")}
    detector = next(r for r in ET.parse(SOURCE / "prepared/field-loops.add.xml").getroot() if r.get("id") == "hh_0535_Z_4_33055")
    detector_road = detector.get("lane").rsplit("_", 1)[0]
    segments, closures = [], []
    for identity, proposal in selected.items():
        first, last = [rows[identity] for rows in routes]
        path = first.find("route").get("edges").split()
        assert path == last.find("route").get("edges").split() == prepared[0][identity].find("route").get("edges").split() == prepared[1][identity].find("route").get("edges").split()
        exits = [list(map(float, r.find("route").get("exitTimes").split())) for r in (first, last)]
        assert len(path) == len(exits[0]) == len(exits[1]) and path.count(detector_road) == 1
        target_index = path.index(detector_road)
        added = []
        for index, edge in enumerate(path):
            starts = [float(r.get("depart")) if index == 0 else exits[n][index - 1] for n, r in enumerate((first, last))]
            duration = [exits[n][index] - starts[n] for n in range(2)]
            row = dict(vehicle_id=identity, route_index=index, from_road="INSERT" if index == 0 else path[index - 1], to_road=edge,
                source_start_s=starts[0], source_end_s=exits[0][index], candidate_start_s=starts[1], candidate_end_s=exits[1][index],
                source_interval_s=duration[0], candidate_interval_s=duration[1], extra_interval_s=duration[1] - duration[0],
                through_detector_front=index <= target_index)
            segments.append(row)
            if index <= target_index:
                added.append(row["extra_interval_s"])
        notification = [e[identity]["notification_time_s"] for e in events]
        departure_delta = float(last.get("depart")) - float(first.get("depart"))
        residual = [notification[n] - exits[n][target_index] for n in range(2)]
        assert abs(sum(r["extra_interval_s"] for r in segments if r["vehicle_id"] == identity) - ((float(last.get("arrival")) - float(last.get("depart"))) - (float(first.get("arrival")) - float(first.get("depart"))))) < 1e-7
        assert abs(departure_delta + sum(added) + residual[1] - residual[0] - (notification[1] - notification[0])) < 1e-7
        closures.append(dict(vehicle_id=identity, source_requested_depart_s=proposal["source_depart_s"], candidate_requested_depart_s=proposal["proposed_depart_s"],
            actual_insert_shift_s=departure_delta, E1_notification_shift_s=notification[1] - notification[0], extra_insert_to_detector_front_s=sum(added),
            source_front_exit_to_E1_notification_s=residual[0], candidate_front_exit_to_E1_notification_s=residual[1],
            source_actual_insert_lane=first.get("departLane"), candidate_actual_insert_lane=last.get("departLane")))
    groups = defaultdict(list)
    for row in segments:
        groups[row["from_road"], row["to_road"]].append(row)
    aggregated = []
    for (start, end), rows in groups.items():
        edge = roads[end]
        transition = [r for r in network.findall("connection") if r.get("from") == start and r.get("to") == end]
        end_tls = sorted({r.get("tl") for r in network.findall("connection") if r.get("from") == end and r.get("tl")})
        deltas = [r["extra_interval_s"] for r in rows]
        aggregated.append(dict(from_road=start, to_road=end, through_detector_front=rows[0]["through_detector_front"], vehicles=len(rows),
            extra_sum_s=sum(deltas), extra_median_s=statistics.median(deltas), extra_max_s=max(deltas), longer_vehicles=sum(d > 1e-7 for d in deltas),
            transition_node=edge.get("from"), transition_node_type=nodes[edge.get("from")].get("type"), transition_TLS=sorted({r.get("tl") for r in transition if r.get("tl")}),
            legal_transition_lane_pairs=[f"{r.get('fromLane')}->{r.get('toLane')}" for r in transition],
            road_end_node=edge.get("to"), road_end_node_type=nodes[edge.get("to")].get("type"), end_TLS=[dict(id=i, type=programs[i].get("type")) for i in end_tls]))
    aggregated.sort(key=lambda r: r["extra_sum_s"], reverse=True)
    top = [r for r in aggregated if r["through_detector_front"]][:2]
    representatives = []
    for group in top:
        representatives.append(max(groups[group["from_road"], group["to_road"]], key=lambda r: r["extra_interval_s"]))
    global_max = max((r for r in segments if r["through_detector_front"]), key=lambda r: r["extra_interval_s"])
    if global_max not in representatives:
        representatives.append(global_max)
    def body205_events(events, identity):
        result, active = [], False
        for event in events:
            if event.get("vehicle_id") != identity:
                continue
            if event.get("event") == "held":
                active = event.get("lane", "").startswith(":205069138_")
            if active:
                result.append(event)
            if event.get("event") == "released":
                active = False
        return result

    detailed = []
    for row in representatives:
        identity = row["vehicle_id"]
        extra = {**row, **next(r for r in closures if r["vehicle_id"] == identity)}
        extra["known_moving_stop"] = [r.attrib for r in prepared[0][identity].findall("stop")]
        extra["source_body205_events"] = body205_events(holds[0]["junction_body_hold"]["events"], identity)
        extra["candidate_body205_events"] = body205_events(holds[1]["junction_body_hold"]["events"], identity)
        detailed.append(extra)
    table(OUT / "segment-summary.csv", aggregated)
    table(OUT / "representative-exits.csv", detailed)
    table(OUT / "cohort29-closure.csv", closures)
    save(OUT / "summary.json", dict(schema="astra.hamburg.535-compression-route-exit-localization/v1", status="pass", new_native_runs=0,
        same_29_ids_and_complete_routes=True, full_trip_and_E1_time_arithmetic_closed=True, aggregate_largest_two=top, largest_single_vehicle_segment=global_max,
        known_lane_prior=dict(field=detector.get("id"), detector_lane=detector.get("lane"), detector_pos_m=detector.get("pos"), moving_stop_lane="186821034#0_5", moving_stop_endPos_m=15.12, upstream_actual_lanes="Not recorded by ordinary vehroute exitTimes; legal lane choices are not actual lane traces."),
        interpretation="The added elapsed intervals are concentrated in different parts for different vehicles. Each exit-to-exit interval includes the intervening junction/internal travel and receiving ordinary road, and can include queue or lane-choice delay. It is not pure edge stopped time. TLS names identify model ownership, not the unique cause. Source/new actual actuated histories are not reconstructed here. Only these two completed runs were read; no plus/minus30 output was read."))
    paths = [Path(__file__), AFTER / "proposal.json"]
    for case in (SOURCE, AFTER):
        paths += [case / "verdict.json", case / "evaluation/native/vehicle-routes.xml", case / "evaluation/contributing-passages.json.gz", case / "evaluation/native/stall-monitor.json", case / "prepared/demand.rou.xml", case / "prepared/network.net.xml", case / "prepared/control.add.xml", case / "prepared/field-loops.add.xml"]
    save(OUT / "source-hashes.json", {p.relative_to(REPO).as_posix(): sha(p) for p in paths})
    save(OUT / "manifest.json", dict(new_native_runs=0, files=[dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(status="pass", vehicles=29, segment_rows=len(aggregated), representatives=len(detailed), manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
