"""Prepare one29-request anchored compression; never start SUMO."""
import argparse
from bisect import bisect_left
from collections import Counter
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
CASE = ROOT / "compress29"
FIELD = "hh_0535_Z_4_33055"
ANCHOR, DEADLINE = 10800, 11670
NAMES = ["network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
         "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def native_ms(time):
    return math.floor(time * 1000 + .5)


def prepare():
    assert not CASE.exists(), "Preserve existing prepared candidates."
    source = SOURCE / "prepared"
    before = ET.parse(source / "demand.rou.xml").getroot()
    old = {v.get("id"): v for v in before.findall("vehicle")}
    metadata = json.loads((source / "lane-intentions.json").read_bytes())
    old_intent = {r["vehicle_id"]: r for r in metadata["vehicles"]}
    events = {r["vehicle_id"]: r for r in json.loads(gzip.decompress((SOURCE / "evaluation/contributing-passages.json.gz").read_bytes()))["passages"]}
    health = json.loads((SOURCE / "verdict.json").read_bytes())
    assert health["healthy"] and health["safe"] and health["after"]["metrics130"]["TAE"] == 395
    selected = sorted((i for i in old if old_intent[i]["od_cell"] == 256), key=lambda i: float(old[i].get("depart")))
    assert len(selected) == 29 and set(selected) == {f"od_0256_v{i:05d}" for i in range(29)}
    assert all(old_intent[i]["field_id"] == FIELD and events[i]["detector_id"] == FIELD for i in selected)
    routes = {i: old[i].find("route").get("edges").split() for i in old}
    assert all(routes[i][0] == "-983227468#1" and routes[i][-1] == "28665128#0" and ANCHOR <= float(old[i].get("depart")) < 11700 for i in selected)
    assert {i for i in old if routes[i][0] == "-983227468#1" and routes[i][-1] == "28665128#0" and native_ms(float(old[i].get("depart"))) // 900000 == 12} == set(selected)
    carry = [i for i in selected if events[i]["interval_begin_s"] == 11700]
    assert len(carry) == 15 and all(events[i]["interval_begin_s"] == 10800 for i in set(selected) - set(carry))
    limits = [dict(vehicle_id=i, beta_upper=1 - (events[i]["notification_time_s"] - DEADLINE) / (float(old[i].get("depart")) - ANCHOR)) for i in carry]
    limiting = min(limits, key=lambda r: r["beta_upper"])
    beta = limiting["beta_upper"]
    assert 0 < beta < 1
    proposals = []
    for identity in selected:
        departure = float(old[identity].get("depart"))
        proposed = round(ANCHOR + beta * (departure - ANCHOR), 9)
        native_shift = native_ms(proposed) - native_ms(departure)
        projected_ms = -(-(round(events[identity]["notification_time_s"] * 1000) + native_shift) // 100) * 100
        projected = projected_ms / 1000
        assert ANCHOR <= proposed < 11700 and 10800 <= projected < 11700
        if identity in carry:
            assert projected <= DEADLINE
        proposals.append(dict(vehicle_id=identity, detector_id=FIELD, od_cell=256, source_depart_s=departure,
            proposed_depart_s=proposed, source_native_depart_s=native_ms(departure)/1000,
            proposed_native_depart_s=native_ms(proposed)/1000, native_shift_s=native_shift/1000,
            source_notification_s=events[identity]["notification_time_s"], projected_notification_s=projected,
            source_interval_begin_s=events[identity]["interval_begin_s"], projected_interval_begin_s=10800,
            source_route=routes[identity], source_stops=[dict(r.attrib) for r in old[identity].findall("stop")]))
    after = apply_native_count_retiming(before, proposals)
    new = {v.get("id"): v for v in after.findall("vehicle")}
    assert set(new) == set(old) and len(new) == 8640
    for identity in old:
        restored = copy.deepcopy(new[identity])
        if identity not in selected:
            assert ET.tostring(restored) == ET.tostring(old[identity])
        restored.set("depart", old[identity].get("depart"))
        assert ET.tostring(restored) == ET.tostring(old[identity])
    assert [ET.tostring(v) for v in before if v.tag != "vehicle"] == [ET.tostring(v) for v in after if v.tag != "vehicle"]
    remaining = set(old) - set(selected)
    assert [v.get("id") for v in before.findall("vehicle") if v.get("id") in remaining] == [v.get("id") for v in after.findall("vehicle") if v.get("id") in remaining]

    def od_key(identity, vehicle):
        return routes[identity][0], routes[identity][-1], native_ms(float(vehicle.get("depart"))) // 900000

    assert Counter(od_key(i,v) for i,v in old.items()) == Counter(od_key(i,v) for i,v in new.items())
    all_od = [i for i in old if routes[i][0] == "-983227468#1" and routes[i][-1] == "28665128#0"]
    assert sorted(all_od,key=lambda i:(float(old[i].get("depart")),i)) == sorted(all_od,key=lambda i:(float(new[i].get("depart")),i))
    intent_departure_keys = []
    for row in metadata["vehicles"]:
        if row["vehicle_id"] in selected:
            for key in ("depart_s", "requested_depart_s", "requested_departure_s"):
                if key in row:
                    row[key] = float(new[row["vehicle_id"]].get("depart"))
                    intent_departure_keys.append(key)
    unselected_times = sorted(float(old[i].get("depart")) for i in remaining)
    interleaving_changes = sum(bisect_left(unselected_times,p["source_depart_s"]) - bisect_left(unselected_times,p["proposed_depart_s"]) for p in proposals)
    prepared = CASE / "prepared"
    shutil.copytree(source, prepared)
    ET.ElementTree(after).write(prepared / "demand.rou.xml", encoding="utf-8", xml_declaration=True)
    if intent_departure_keys:
        save(prepared / "lane-intentions.json", metadata)
    scenario = json.loads((source / "scenario.json").read_bytes())
    scenario.update(status="review_required", formal_result=False, exact_count_fit=False,
        demand_sha256=sha(prepared / "demand.rou.xml"),
        demand_prior="All8640 explicit IDs/routes/stops/vTypes/field intentions retained. Only the29 requests of535Z4 ODcell256/h12 are compressed toward10800;294 OD-period counts unchanged. No quantile regeneration.",
        time_prior="Single beta: t_new=10800+beta*(t_old-10800). Beta is the largest source-lag bound meeting11670 for the15 observed carry vehicles. Native-ms/notification-step projection checked, but changed native response is unmeasured. Earlier requests remain exact.",
        timing_compression=dict(anchor_s=ANCHOR,beta=beta,source_field=FIELD,source_od_cell=256,changed_requests=29,deadline_s=DEADLINE,
            same_OD_request_order_preserved=True,other_OD_interleavings_changed=True,native_response_verified=False))
    save(prepared / "scenario.json", scenario)
    proposal = dict(schema="astra.hamburg.535z4-tail-compression-proposal/v1", status="prepared", formal_result=False,
        new_native_runs=0, source_healthy_main130_TAE=395, anchor_s=ANCHOR, beta=beta, beta_formula="min_i[1-(source_notification_i-11670)/(source_depart_i-10800)] over the15 observed carry vehicles",
        limiting_vehicle=limiting["vehicle_id"], beta_limits=limits, deadline_s=DEADLINE, proposals=proposals,
        changed_vehicles=29, source_carry_vehicles=15, other_14_projected_same_bin=True,
        earliest_new_request_s=min(p["proposed_depart_s"] for p in proposals),earliest_source_request_s=min(p["source_depart_s"] for p in proposals),
        max_native_advance_s=max(-p["native_shift_s"] for p in proposals),same_OD_request_order_preserved=True,
        changed294_q_cells=0,q_L1=0,other8611_relative_order_preserved=True,other_OD_interleaving_pair_changes=interleaving_changes,
        intent_departure_keys_updated=sorted(set(intent_departure_keys)),
        unverified_projection=dict(main130_TAE_before=395,main130_TAE_after=365,main130_SSE_before=5039,main130_SSE_after=4589,
            all182_TAE_before=492,all182_TAE_after=462,other_fields_projected_unchanged=True,native_response_verified=False),
        required_native_checks="Full14400 native; all156 E1 intervals ending<=10800 exact native attributes against healthy source; report all130/52/182/40/208, all8640 completion, safety, unique expected fields. Do not accept the translated projection as measured or relax a failed prefix.")
    save(CASE / "proposal.json", proposal)
    implementation = CASE / "preparation-implementation"
    implementation.mkdir()
    core = REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_departure_probe.py"
    shutil.copy2(core,implementation/core.name)
    shutil.copy2(__file__,CASE/"executed-prepare.py")
    source_paths = [source/n for n in NAMES] + [SOURCE/"verdict.json",SOURCE/"evaluation/contributing-passages.json.gz",core,Path(__file__)]
    save(CASE / "scope-proof.json", dict(schema="astra.hamburg.535z4-tail-compression-scope/v1",status="pass",formal_result=False,new_native_runs=0,
        N=8640,actual_changes=29,source_hashes={str(p.resolve()):sha(p) for p in source_paths},
        prepared_hashes={n:sha(prepared/n) for n in NAMES},proposal_sha256=sha(CASE/"proposal.json"),
        source_snapshot_mapping=[dict(original_path=str(core),snapshot_path=str(implementation/core.name),sha256=sha(core))],
        checks=dict(all_IDs_retained=True,depart_only_for29=True,other8611_XML_exact=True,other8611_relative_order_exact=True,
                    same_OD_all_request_order_exact=True,all_route_stop_field_unchanged=True,N_and294_q_exact=True,
                    all_new_requests_after10800=True,all15_proxy_before11670=True,other14_proxy_same_bin=True,
                    network_control_targets_exact=True),
        assumption="Late-cohort timing sensitivity. Source notification translation is not a causal derivative; newnative can move other cars/bins. This is not a measured improvement."))
    return check()


def check():
    proof = json.loads((CASE/"scope-proof.json").read_bytes())
    proposal = json.loads((CASE/"proposal.json").read_bytes())
    assert all(proof["checks"].values()) and proof["N"]==8640 and proof["actual_changes"]==29
    assert all(sha(Path(path))==digest for path,digest in proof["source_hashes"].items())
    assert all(sha(CASE/"prepared"/name)==digest for name,digest in proof["prepared_hashes"].items())
    assert sha(CASE/"proposal.json")==proof["proposal_sha256"]
    for name in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
        assert (CASE/"prepared"/name).read_bytes()==(SOURCE/"prepared"/name).read_bytes()
    assert proof["prepared_hashes"]["network.net.xml"]=="6c52382e7664eca33fceff6fd02ae700d93139a316a3f9f5139d0e139d7a18ce"
    assert proof["prepared_hashes"]["control.add.xml"]=="27220b430aa68c24f0ad360c57ee3bd0f4b8dcdc88aead5344bcff00e4f43e3b"
    return dict(status="pass",new_native_runs=0,case=str(CASE),beta=proposal["beta"],changed_vehicles=29,
                earliest_new_request_s=proposal["earliest_new_request_s"],max_native_advance_s=proposal["max_native_advance_s"],
                source_proxy_only=True,scope_sha256=sha(CASE/"scope-proof.json"),proposal_sha256=sha(CASE/"proposal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare",action="store_true")
    mode.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check()))
