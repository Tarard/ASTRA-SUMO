"""Measure one saved29-car compression; never regenerate demand or start another round."""

import argparse
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASE = ROOT / "compress29"
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
SHARED = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/run_full.py"
SHARED_SHA = "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"
COHORT = {f"od_0256_v{index:05d}" for index in range(29)}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert sha(SHARED) == SHARED_SHA
BASE = runpy.run_path(str(SHARED))
SHARED_RUN = BASE["run"]


def prefix_comparison():
    paths = [folder / "evaluation/native/field-counts.xml" for folder in (SOURCE, CASE)]
    tables = []
    for path in paths:
        rows = {}
        for row in ET.parse(path).getroot().findall("interval"):
            begin, end = Decimal(row.get("begin")), Decimal(row.get("end"))
            if 0 <= begin < end <= 10800:
                key = row.get("id"), begin, end
                assert key not in rows
                rows[key] = dict(row.attrib)
        tables.append(rows)
    before, after = tables
    assert len(before) == len(after) == 156
    differences = [{"detector_id": key[0], "begin": str(key[1]), "end": str(key[2]), "source": before.get(key), "candidate": after.get(key)}
        for key in sorted(before.keys() | after.keys()) if before.get(key) != after.get(key)]
    initial = {key for key in before if key[2] <= 3600}
    first8 = {key for key in before if 3600 <= key[1] < key[2] <= 10800}
    assert len(initial) == 52 and len(first8) == 104
    return {"native_runs": 0, "cutoff_s": 10800, "all156_native_e1_attributes_identical": before == after,
        "initial52_native_attributes_identical": all(before[key] == after.get(key) for key in initial),
        "main_first8_104_native_attributes_identical": all(before[key] == after.get(key) for key in first8),
        "differences": differences, "input_hashes": {str(path): sha(path) for path in paths},
        "claim": "Actual native interval attributes, not integer-OD or fixed-lag predictions. Full-window counts and safety remain separate."}


def save(path, value):
    if path == CASE / "preflight.json":
        value["source_full_health_gate"] = value.pop("smoke")
        value["measurement_plan_sha256"] = sha(ROOT / "measurement-plan.json")
        value["shared_measurement_driver"] = {"path": str(CASE / "executed-shared-driver.py"),
            "sha256": sha(CASE / "executed-shared-driver.py"), "source_sha256": SHARED_SHA}
    if path == CASE / "verdict.json":
        if "source_plus15" in value:
            value["source_525_parent"] = value.pop("source_plus15")
        if "plus15_parent" in value.get("comparison", {}):
            value["comparison"]["parent_525_full"] = value["comparison"].pop("plus15_parent")
        if "after" in value:
            prefix = prefix_comparison()
            (CASE / "evaluation/prefix156-comparison.json").write_text(json.dumps(prefix, indent=2) + "\n", encoding="utf-8")
            value["causal_prefix_diagnostics"] = {key: prefix[key] for key in (
                "all156_native_e1_attributes_identical", "initial52_native_attributes_identical", "main_first8_104_native_attributes_identical")}
        value.update(study_role="single_h12_od0256_departure_compression", new_geometry_smoke_required=False,
            claim_boundary="Only the saved29 h12 requests use10800-anchored compression. All routes,stops,fields,N and actual294 request inventory remain fixed. The fixed-lag proposal is not a native prediction. All130/52/182/40/208 and53556,unique events,safety/backlog remain reported. Actual pre10800 interval parity is a diagnostic check for this bounded probe, not a universal user constraint. No automatic second round or field-certified zero claim.")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def source_health():
    verdict = json.loads((SOURCE / "verdict.json").read_bytes())
    stats = verdict["after"]
    assert stats["healthy"] is True and stats["safe"] is True and verdict["unique_intended_fields"] is True
    assert stats["metrics130"]["TAE"] == 395 and stats["event_count"] == 8640
    return {"status": "pass", "role": "same_network_control_parent_full_native", "new_geometry_smoke_required": False,
        "path": str(SOURCE / "verdict.json"), "sha256": sha(SOURCE / "verdict.json"),
        "parent_main130_MAE": stats["metrics130"]["MAE"], "parent_healthy": True, "parent_safe": True}


def check():
    prepare_module = runpy.run_path(str(ROOT / "prepare_compression.py"))
    assert prepare_module["check"]()["status"] == "pass"
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    parent_runtime = json.loads((SOURCE / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent_runtime["modules"] and runtime["native_library"] == parent_runtime["native_library"]
    assert all(sha(path) == value for path, value in parent_runtime["binaries"].items())
    runtime["binaries"] = parent_runtime["binaries"]
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert (CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    before, after = [{v.get("id"): v for v in ET.parse(folder / "prepared/demand.rou.xml").getroot().findall("vehicle")} for folder in (SOURCE, CASE)]
    assert before.keys() == after.keys() and len(after) == 8640
    for identity in before:
        first, last = dict(before[identity].attrib), dict(after[identity].attrib)
        if identity in COHORT:
            first.pop("depart")
            last.pop("depart")
            assert Decimal(after[identity].get("depart")) >= 10800
        assert first == last
        assert [ET.tostring(row) for row in before[identity]] == [ET.tostring(row) for row in after[identity]]
    source_health()
    paths = [Path(__file__), SHARED, ROOT / "prepare_compression.py", CASE / "scope-proof.json", SOURCE / "verdict.json", SOURCE / "preflight.json"]
    paths += list((SOURCE / "prepared").iterdir())
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "hamburg_od_spsa.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    paths += [BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"], BASE["AUDIT_HELPER"].parent / "audit_scope.py"]
    plan_path = ROOT / "measurement-plan.json"
    if not plan_path.exists():
        save(plan_path, {"formal_result": False, "source_hashes": {str(path): sha(path) for path in paths}, "source_health": source_health(),
            "native_runs": 0, "prepared_hashes": {path.name: sha(path) for path in (CASE / "prepared").iterdir()},
            "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo", "prefix_native_diagnostic_cutoff_s": 10800})
    plan = json.loads(plan_path.read_bytes())
    assert all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in plan["prepared_hashes"].items())
    return {"status": "pass", "native_runs": 0, "runtime": runtime, "source_health": source_health()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    checked = check()
    if args.check_only:
        print(json.dumps({key: value for key, value in checked.items() if key != "runtime"}))
    else:
        assert not (CASE / "evaluation").exists() and not (CASE / "verdict.json").exists(), "Preserve existing and partial results."
        assert not (CASE / "implementation").exists(), "Keep preparation snapshots separate from new measurement output."
        snapshots = CASE / "measurement-implementation"
        snapshots.mkdir(exist_ok=False)
        shutil.copyfile(SHARED, CASE / "executed-shared-driver.py")
        for path in json.loads((ROOT / "measurement-plan.json").read_bytes())["source_hashes"]:
            path = Path(path)
            if path.suffix == ".py":
                shutil.copyfile(path, snapshots / path.name)
        SHARED_RUN.__globals__.update(ROOT=ROOT, CASE=CASE, SOURCE=SOURCE, check=check, require_smoke=source_health,
            save=save, __file__=str(Path(__file__)))
        SHARED_RUN()
