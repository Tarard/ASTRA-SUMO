"""Offline own29 versus unchanged8611 accounting for the completed compression."""
from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import statistics
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full/evaluation"
AFTER = ROOT / "compress29/evaluation"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def csv_read(path):
    return list(csv.DictReader(path.open(encoding="utf-8")))


def csv_write(name, rows):
    with (OUT/name).open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    assert not (OUT/"manifest.json").exists(), "Preserve sealed response evidence."
    proposal=json.loads((ROOT/"compress29/proposal.json").read_bytes())
    selected={r["vehicle_id"]:r for r in proposal["proposals"]}
    def events(folder):
        payload=json.loads(gzip.decompress((folder/"contributing-passages.json.gz").read_bytes()))
        result={r["vehicle_id"]:r for r in payload["passages"]}
        assert payload["reconciled"] and len(result)==len(payload["passages"])==8640
        native={(r.get("id"),int(float(r.get("begin")))):int(r.get("nVehContrib")) for r in ET.parse(folder/"native/field-counts.xml").getroot().findall("interval")}
        counts=Counter((r["detector_id"],int(r["interval_begin_s"])) for r in result.values())
        assert len(native)==208 and all(counts[k]==v for k,v in native.items())
        return result,native
    before,source_counts=events(SOURCE)
    after,after_counts=events(AFTER)
    intentions={r["vehicle_id"]:r for r in json.loads((AFTER/"lane-intentions.json").read_bytes())["vehicles"]}
    old_trips={r.get("id"):r for r in ET.parse(SOURCE/"native/tripinfo.xml").getroot().findall("tripinfo")}
    new_trips={r.get("id"):r for r in ET.parse(AFTER/"native/tripinfo.xml").getroot().findall("tripinfo")}
    assert set(before)==set(after)==set(intentions)==set(old_trips)==set(new_trips)
    assert all(before[i]["detector_id"]==after[i]["detector_id"]==intentions[i]["field_id"] for i in before)
    own_rows,other_rows=[],[]
    for identity in before:
        a,b=before[identity],after[identity]
        row=dict(vehicle_id=identity,detector_id=a["detector_id"],od_cell=intentions[identity]["od_cell"],
            source_actual_depart_s=float(old_trips[identity].get("depart")),new_actual_depart_s=float(new_trips[identity].get("depart")),
            source_notification_s=a["notification_time_s"],new_notification_s=b["notification_time_s"],
            actual_notification_change_s=b["notification_time_s"]-a["notification_time_s"],
            source_interval_begin=int(a["interval_begin_s"]),new_interval_begin=int(b["interval_begin_s"]))
        if identity in selected:
            p=selected[identity]
            row.update(source_requested_depart_s=p["source_depart_s"],new_requested_depart_s=p["proposed_depart_s"],
                       unverified_proxy_notification_s=p["projected_notification_s"],proxy_interval_begin=p["projected_interval_begin_s"],
                       new_minus_proxy_s=b["notification_time_s"]-p["projected_notification_s"])
            own_rows.append(row)
        elif abs(row["actual_notification_change_s"])>1e-7:
            other_rows.append(row)
    own_rows.sort(key=lambda r:r["source_requested_depart_s"])
    other_rows.sort(key=lambda r:(r["detector_id"],r["source_notification_s"],r["vehicle_id"]))
    other_bin=[r for r in other_rows if r["source_interval_begin"]!=r["new_interval_begin"]]
    real=csv_read(AFTER/"all182-comparison.csv")
    truth={(r["detector_id"],int(float(r["begin"]))):int(r["expected_total"]) for r in real}
    field_rows=[]
    for field in sorted({r["detector_id"] for r in real}):
        main=[k for k in truth if k[0]==field and k[1]>=3600]
        def tae(values):
            return sum(abs(values[k]-truth[k]) for k in main)

        def sse(values):
            return sum((values[k]-truth[k])**2 for k in main)

        field_rows.append(dict(detector_id=field,source_main_TAE=tae(source_counts),new_main_TAE=tae(after_counts),
            TAE_change=tae(after_counts)-tae(source_counts),source_main_SSE=sse(source_counts),new_main_SSE=sse(after_counts),
            SSE_change=sse(after_counts)-sse(source_counts),unmodified_time_changed=sum(r["detector_id"]==field for r in other_rows),
            unmodified_bin_changed=sum(r["detector_id"]==field for r in other_bin)))
    own_source=Counter((before[i]["detector_id"],int(before[i]["interval_begin_s"])) for i in selected)
    own_after=Counter((after[i]["detector_id"],int(after[i]["interval_begin_s"])) for i in selected)
    changed=[]
    for key in source_counts:
        own_delta=own_after[key]-own_source[key]
        other_delta=after_counts[key]-source_counts[key]-own_delta
        if after_counts[key]!=source_counts[key] or own_delta:
            changed.append(dict(detector_id=key[0],begin=key[1],end=key[1]+900,
                expected=truth.get(key),source_nVehContrib=source_counts[key],new_nVehContrib=after_counts[key],
                own29_delta=own_delta,unmodified8611_delta=other_delta,total_delta=after_counts[key]-source_counts[key]))
    assert sum(r["TAE_change"] for r in field_rows)==5 and sum(r["SSE_change"] for r in field_rows)==95
    assert len(own_rows)==29 and len(other_bin)==52
    old_carry=[r for r in own_rows if r["source_interval_begin"]==11700]
    assert len(old_carry)==15 and all(r["new_interval_begin"]==11700 for r in old_carry)
    for name,rows in [("own29-source-proxy-actual.csv",own_rows),("unmodified545-time-response.csv",other_rows),
                      ("unmodified52-bin-transitions.csv",other_bin),("field13-response.csv",field_rows),("changed208-decomposition.csv",changed)]:
        csv_write(name,rows)
    shifts=[r["actual_notification_change_s"] for r in own_rows]
    field="hh_0535_Z_4_33055"
    summary=dict(schema="astra.hamburg.535z4-compression-response-decomposition/v1",status="pass",candidate_selection="not_adopted",new_native_runs=0,
        complete_native_events_each=8640,main_TAE=[395,400],main_SSE=[5039,5134],prefix156_native_attributes_identical=json.loads((AFTER/"prefix156-comparison.json").read_bytes()),
        own29=dict(source_bins=dict(Counter(r["source_interval_begin"] for r in own_rows)),proxy_bins=dict(Counter(r["proxy_interval_begin"] for r in own_rows)),actual_bins=dict(Counter(r["new_interval_begin"] for r in own_rows)),
            original15_carry_still_late=15,previously_on_time14_now_on_time=5,previously_on_time14_moved_late=9,
            actual_notification_shift_s=dict(min=min(shifts),median=statistics.median(shifts),max=max(shifts)),
            actual_earlier=sum(x < -1e-7 for x in shifts),actual_equal=sum(abs(x)<=1e-7 for x in shifts),actual_later=sum(x>1e-7 for x in shifts)),
        unmodified8611=dict(time_changed=len(other_rows),bin_changed=len(other_bin),
            transition_counts=[dict(detector_id=k[0],source_begin=k[1],new_begin=k[2],vehicles=v) for k,v in sorted(Counter((r["detector_id"],r["source_interval_begin"],r["new_interval_begin"]) for r in other_bin).items())]),
        target_field_late_pair=dict(target=[57,44],source=[source_counts[field,b] for b in [10800,11700]],new=[after_counts[field,b] for b in [10800,11700]],
            source_tail=source_counts[field,12600]+source_counts[field,13500],new_tail=after_counts[field,12600]+after_counts[field,13500]),
        interpretation="The edited29 did not gain penultimate service while merely displacing another group. They lost9 own on-time contributions; unchanged same-field vehicles lost1 penultimate and12 latest-main contributions, and other119fields also shifted late. This single sensitivity rejects this compression as an improvement; it neither proves a hard capacity bound nor identifies the cause of every timing change.",
        next_choice_basis="Retain the healthy395 source. Any subsequent same-cohort timing comparison must start from that source and measure actual response; do not extrapolate the failed fixed-lag projection or infer monotonicity from this one beta.")
    (OUT/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    paths=[ROOT/"compress29/proposal.json",ROOT/"compress29/scope-proof.json",ROOT/"compress29/verdict.json"]
    for folder in [SOURCE,AFTER]:
        paths += [folder/"contributing-passages.json.gz",folder/"native/field-counts.xml",folder/"native/tripinfo.xml",folder/"all182-comparison.csv",folder/"lane-intentions.json"]
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in paths],indent=2)+"\n",encoding="utf-8")
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=files),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="pass",selected_not_adopted=True,own_actual_bins=summary["own29"]["actual_bins"],others_time_changed=len(other_rows),others_bin_changed=len(other_bin),manifest_sha256=sha(OUT/"manifest.json"))))


if __name__=="__main__":
    main()
