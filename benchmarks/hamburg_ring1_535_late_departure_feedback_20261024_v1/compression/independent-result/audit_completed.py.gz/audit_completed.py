"""Audit the one completed compression using existing native E1 evidence helpers."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import runpy
import sys


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
CASE = ROOT / "compress29"
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def static_checks():
    assert runpy.run_path(str(ROOT / "prepare_compression.py"))["check"]()["status"] == "pass"
    plan = load(ROOT / "measurement-plan.json")
    assert all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in plan["prepared_hashes"].items())
    preflight = load(CASE / "preflight.json")
    assert preflight["measurement_plan_sha256"] == sha(ROOT / "measurement-plan.json")
    assert preflight["scope_sha256"] == sha(CASE / "scope-proof.json")
    assert sha(CASE / "executed-driver.py") == sha(CASE / "measurement-implementation/run_compression.py") == sha(ROOT / "run_compression.py")
    shared = preflight["shared_measurement_driver"]
    assert sha(Path(shared["path"])) == shared["sha256"] == shared["source_sha256"] == "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"
    assert all(sha(CASE / "implementation" / name) == value for name, value in preflight["implementation_sha256"].items())
    runtime = preflight["runtime"]
    assert all(sha(path) == value for path, value in runtime["binaries"].items())
    for row in runtime["modules"].values():
        assert row["version"] == "1.27.1" and Path(row["path"]).resolve().is_relative_to(REPO / ".venv")
        assert sha(row["path"]) == row["sha256"]
    assert sha(runtime["native_library"]["path"]) == runtime["native_library"]["sha256"]
    assert (preflight["end_s"], preflight["step_length_s"], preflight["seed"]) == (14400, .1, 104)
    return preflight


def stats(data):
    return {key: data[key] for key in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    preflight = static_checks()
    if args.check_only:
        print(json.dumps({"status": "pass", "native_runs": 0, "scope_runtime_and_two_driver_snapshots": True, "candidate_native_XML_read": False}))
        return
    assert (CASE / "verdict.json").is_file(), "Wait for a terminal verdict before reading native output."
    assert not (OUT / "summary.json").exists(), "Keep the sealed audit."
    verdict = load(CASE / "verdict.json")
    assert verdict["status"] == "diagnostic_measurement_complete"
    sys.path.insert(0, str(HELPER.parent))
    tools = runpy.run_path(str(HELPER))
    measured = {}
    for label, folder in (("parent525", SOURCE), ("candidate", CASE)):
        evaluation = folder / "evaluation"
        measured[label] = tools["evidence"](folder / "prepared", evaluation, evaluation / "contributing-passages.json.gz", 8640)
    before, after = measured["parent525"], measured["candidate"]
    assert verdict["after"] == stats(after) and verdict["source_525_parent"] == stats(before)
    monitor, native = load(CASE / "evaluation/native/stall-monitor.json"), load(CASE / "evaluation/native/run.json")
    assert native["native_status"] == "pass" and native["errors"] == [] and native["inputs_unchanged"]
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400 and monitor["library_completed"]
    assert monitor["native_returncode"] is None and monitor["native_library"] == preflight["runtime"]["native_library"]
    assert Path(monitor["traci_module"]).resolve().is_relative_to(REPO / ".venv")
    prefix = [{key: value for key, value in data["periodic"].items() if 0 <= key[1] < key[2] <= 10800} for data in (before, after)]
    assert all(len(rows) == 156 for rows in prefix)
    first, last = prefix
    initial = {key for key in first if key[2] <= 3600}
    main8 = {key for key in first if 3600 <= key[1] < key[2] <= 10800}
    assert len(initial) == 52 and len(main8) == 104
    parity = {"all156_native_e1_attributes_identical": first == last,
        "initial52_native_attributes_identical": all(first[key] == last.get(key) for key in initial),
        "main_first8_104_native_attributes_identical": all(first[key] == last.get(key) for key in main8)}
    assert verdict["causal_prefix_diagnostics"] == parity
    assert all(load(CASE / "evaluation/prefix156-comparison.json")[key] == value for key, value in parity.items())
    differences = [{"detector_id": key[0], "begin": key[1], "end": key[2], "parent": first.get(key), "candidate": last.get(key)}
        for key in sorted(first.keys() | last.keys()) if first.get(key) != last.get(key)]
    fields = {row["vehicle_id"]: row["field_id"] for row in load(CASE / "prepared/lane-intentions.json")["vehicles"]}
    assert after["by_vehicle"].keys() <= fields.keys()
    repeats = [{"vehicle_id": identity, "field": field, "count": count} for identity, rows in after["by_vehicle"].items()
        for field, count in Counter(row["detector_id"] for row in rows).items() if count > 1]
    outside = [{"vehicle_id": identity, "actual_field": row["detector_id"], "intended_field": fields.get(identity)}
        for identity, rows in after["by_vehicle"].items() for row in rows if row["detector_id"] != fields.get(identity)]
    once = all(len(after["by_vehicle"].get(identity, [])) == 1 and after["by_vehicle"][identity][0]["detector_id"] == field for identity, field in fields.items())
    assert verdict["repeated_vehicle_fields"] == repeats and verdict["contributions_outside_prior_primary_intention"] == outside
    assert verdict["unique_intended_fields"] == (once and not repeats and not outside)
    protected = [row for row in after["initial"] + after["main"] if row["detector_id"] in FIELDS535]
    assert len(protected) == 56 and verdict["all53556"] == tools["metrics"](protected)
    cohort = []
    for row in load(CASE / "proposal.json")["proposals"]:
        identity = row["vehicle_id"]
        events = after["by_vehicle"].get(identity, [])
        actual = events[0]["notification_time_s"] if len(events) == 1 else None
        cohort.append({"vehicle_id": identity, "source_depart_s": row["source_depart_s"], "candidate_depart_s": row["proposed_depart_s"],
            "source_notification_s": row["source_notification_s"], "fixed_lag_projection_s": row["projected_notification_s"],
            "actual_notification_s": actual, "actual_before_11700": actual < 11700 if actual is not None else None,
            "actual_minus_projection_s": actual - row["projected_notification_s"] if actual is not None else None})
    assert len(cohort) == 29
    rows535 = [row for row in after["main"] if row["detector_id"] == "hh_0535_Z_4_33055" and float(row["begin"]) >= 10800]
    assert len(rows535) == 2
    for name, rows in (("main130", after["main"]), ("initialization52", after["initial"]), ("all182", after["initial"] + after["main"]),
        ("station40", after["stations"]), ("native208", list(after["periodic"].values())), ("535-all56", protected),
        ("535Z4-last2", rows535), ("cohort29-actual", cohort)):
        tools["table"](OUT / (name + ".csv"), rows)
    tools["save"](OUT / "prefix156-differences.json", differences)
    result = {"audit_status": "pass", "native_runs_by_audit": 0, "formal_result": False, "after": stats(after), "parent525": stats(before),
        "main130_TAE_delta": after["metrics130"]["TAE"] - before["metrics130"]["TAE"],
        "maximum_error_before_after": [before["metrics130"]["max_abs_error"], after["metrics130"]["max_abs_error"]],
        "actual_prefix_parity": parity, "prefix_mismatch_count": len(differences), "one_expected_event_per_request": once,
        "repeated_fields": repeats, "outside_intentions": outside, "all53556": tools["metrics"](protected),
        "cohort29_actual_before11700": sum(row["actual_before_11700"] is True for row in cohort),
        "535Z4_last2_actual": rows535, "healthy": after["healthy"], "exact_main130": after["metrics130"]["TAE"] == 0,
        "claim_boundary": "Actual periodic/instant counts and native completion only. Fixed-lag projection is independently compared with actual29 events. Prefix equality is reported from156 raw intervals, not inferred from fixed OD counts. This audit does not start traffic, modify inputs or establish field timing/capacity."}
    tools["save"](OUT / "summary.json", result)
    hashes = {str(path): sha(path) for path in (Path(__file__), HELPER, HELPER.parent / "audit_scope.py", CASE / "verdict.json", CASE / "scope-proof.json", CASE / "preflight.json", ROOT / "measurement-plan.json")}
    for data in measured.values():
        hashes.update(data["source_hashes"])
    tools["save"](OUT / "source-hashes.json", hashes)
    tools["save"](OUT / "manifest.json", {"native_runs": 0, "files": [{"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)}
        for path in sorted(OUT.iterdir()) if path.is_file() and path.name != "manifest.json"]})
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
