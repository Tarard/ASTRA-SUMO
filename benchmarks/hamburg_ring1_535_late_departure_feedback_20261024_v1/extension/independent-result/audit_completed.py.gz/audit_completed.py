"""Audit the two completed offset extensions against the fixed healthy525 native reference."""

from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path
import runpy
import sys
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
HELPER = REPO / "outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py"
FIELDS535 = {"hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stats(data):
    return {key: data[key] for key in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}


def execution_checks(case):
    assert runpy.run_path(str(ROOT / "prepare_extensions.py"))["check"](case.name)["status"] == "pass"
    plan, preflight = load(case / "measurement-plan.json"), load(case / "preflight.json")
    assert all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert all(sha(case / "prepared" / name) == value for name, value in plan["prepared_hashes"].items())
    assert preflight["measurement_plan_sha256"] == sha(case / "measurement-plan.json")
    assert preflight["scope_sha256"] == sha(case / "scope-proof.json")
    assert sha(case / "executed-driver.py") == sha(case / "measurement-implementation/run_extension.py") == sha(ROOT / "run_extension.py")
    shared = preflight["shared_measurement_driver"]
    assert sha(Path(shared["path"])) == shared["sha256"] == shared["source_sha256"] == "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"
    assert all(sha(case / "implementation" / name) == value for name, value in preflight["implementation_sha256"].items())
    for path, digest in plan["source_hashes"].items():
        if Path(path).suffix == ".py":
            assert sha(case / "measurement-implementation" / Path(path).name) == digest
    runtime = preflight["runtime"]
    assert all(sha(path) == value for path, value in runtime["binaries"].items())
    assert Path(runtime["python"]).resolve() == (REPO / ".venv/Scripts/python.exe").resolve()
    for row in runtime["modules"].values():
        assert row["version"] == "1.27.1" and Path(row["path"]).resolve().is_relative_to(REPO / ".venv")
        assert sha(row["path"]) == row["sha256"]
    assert sha(runtime["native_library"]["path"]) == runtime["native_library"]["sha256"]
    assert (preflight["end_s"], preflight["step_length_s"], preflight["seed"]) == (14400, .1, 104)
    native, monitor = load(case / "evaluation/native/run.json"), load(case / "evaluation/native/stall-monitor.json")
    assert native["native_status"] == "pass" and native["errors"] == [] and native["inputs_unchanged"]
    assert monitor["status"] == "completed" and monitor["simulation_time_s"] == 14400 and monitor["library_completed"]
    assert monitor["native_returncode"] is None and monitor["native_library"] == runtime["native_library"]
    assert Path(monitor["traci_module"]).resolve().is_relative_to(REPO / ".venv")
    for item in native["inputs"] + native["snapshots"]:
        assert sha(item["path"]) == item["sha256"]
    return preflight


def inventory_checks(case):
    source = ET.parse(SOURCE / "prepared/demand.rou.xml").getroot().findall("vehicle")
    candidate = ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle")
    pairs = sorted({(row.find("route").get("edges").split()[0], row.find("route").get("edges").split()[-1]) for row in source})
    assert len(pairs) == 21 and len(source) == len(candidate) == 8640
    metadata = {row["vehicle_id"]: row for row in load(case / "prepared/lane-intentions.json")["vehicles"]}
    vectors = []
    for rows in (source, candidate):
        vector = [0] * 294
        for row in rows:
            route = row.find("route").get("edges").split()
            index = (math.floor(float(row.get("depart")) * 1000 + .5) // 900000) * 21 + pairs.index((route[0], route[-1]))
            vector[index] += 1
            if rows is candidate:
                assert metadata[row.get("id")]["od_cell"] == index
        vectors.append(vector)
    recorded = load(case / "od-vector.json")
    assert vectors == [recorded["source_integer_counts"], recorded["integer_counts"]]
    changes = [{"index": i, "source": a, "candidate": b} for i, (a, b) in enumerate(zip(*vectors)) if a != b]
    assert changes == [{"index": 235, "source": vectors[0][235], "candidate": vectors[0][235] + 1},
        {"index": 256, "source": vectors[0][256], "candidate": vectors[0][256] - 1}]
    return {"actual294_inventory_rebuilt": True, "q_L1": 2, "changed_cells": changes,
        "od_metadata_rebuilt_from_route_and_native_ms": True, "od_vector_sha256": sha(case / "od-vector.json")}


def main():
    assert not (OUT / "summary.json").exists(), "Keep a completed audit immutable."
    assert all((ROOT / "cases" / name / "verdict.json").exists() for name in ("minus60", "minus90")), "Wait for both terminal verdicts."
    sys.path.insert(0, str(HELPER.parent))
    tools = runpy.run_path(str(HELPER))
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

    measured, hashes, summary = {}, {}, {"audit_status": "pass", "native_runs_by_audit": 0, "formal_result": False, "points": {}}
    for label, case in (("source395", SOURCE), ("minus60", ROOT / "cases/minus60"), ("minus90", ROOT / "cases/minus90")):
        if label != "source395":
            execution_checks(case)
        evaluation = case / "evaluation"
        data = tools["evidence"](case / "prepared", evaluation, evaluation / "contributing-passages.json.gz", 8640)
        native = load(evaluation / "native/run.json")
        raw = read_contributing_e1_passages(instant_file=evaluation / "native/instant-e1.xml", periodic_file=evaluation / "native/field-counts.xml",
            detector_ids=native["instant_to_periodic_ids"], step_length=.1)
        with gzip.open(evaluation / "contributing-passages.json.gz", "rt", encoding="utf-8") as handle:
            assert raw == json.load(handle)
        fields = {row["vehicle_id"]: row["field_id"] for row in load(case / "prepared/lane-intentions.json")["vehicles"]}
        repeats = [{"vehicle_id": identity, "field": field, "count": count} for identity, events in data["by_vehicle"].items()
            for field, count in Counter(row["detector_id"] for row in events).items() if count > 1]
        outside = [{"vehicle_id": identity, "actual": event["detector_id"], "intended": fields.get(identity)}
            for identity, events in data["by_vehicle"].items() for event in events if event["detector_id"] != fields.get(identity)]
        once = set(fields) == set(data["by_vehicle"]) and all(len(data["by_vehicle"][identity]) == 1 for identity in fields) and not outside
        assert len(fields) == 8640 and once and not repeats
        requested = {row.get("id"): row.find("route").get("edges") for row in ET.parse(case / "prepared/demand.rou.xml").getroot().findall("vehicle")}
        routes = ET.parse(evaluation / "native/vehicle-routes.xml").getroot().findall("vehicle")
        assert len(routes) == 8640 and {row.get("id") for row in routes} == set(fields)
        assert all(float(row.get("arrival", "-1")) >= 0 and row.find("route").get("edges") == requested[row.get("id")] for row in routes)
        protected = [row for row in data["initial"] + data["main"] if row["detector_id"] in FIELDS535]
        assert len(protected) == 56
        result = {**stats(data), "all53556": tools["metrics"](protected), "one_intended_complete_event_per_request": once,
            "repeated_vehicle_fields": repeats, "contributions_outside_intention": outside, "raw_instant_equals_saved_compact": True,
            "all8640_arrived_routes_match_requested_edges": True}
        destination = OUT / label
        destination.mkdir()
        for name, rows in (("main130", data["main"]), ("initialization52", data["initial"]), ("all182", data["initial"] + data["main"]),
            ("station40", data["stations"]), ("native208", list(data["periodic"].values())), ("535-all56", protected)):
            tools["table"](destination / (name + ".csv"), rows)
        if label != "source395":
            result["actual_request_inventory"] = inventory_checks(case)
            verdict, before = load(case / "verdict.json"), measured["source395"]
            assert verdict["after"] == stats(data) and verdict["source_525_parent"] == stats(before)
            assert verdict["unique_intended_fields"] and verdict["repeated_vehicle_fields"] == repeats
            assert verdict["contributions_outside_prior_primary_intention"] == outside and verdict["all53556"] == result["all53556"]
            prefixes = [{key: value for key, value in item["periodic"].items() if 0 <= key[1] < key[2] <= 10800} for item in (before, data)]
            first, last = prefixes
            assert len(first) == len(last) == 156
            parity = {"all156_native_e1_attributes_identical": first == last,
                "initial52_native_attributes_identical": all(value == last[key] for key, value in first.items() if key[2] <= 3600),
                "main_first8_104_native_attributes_identical": all(value == last[key] for key, value in first.items() if key[1] >= 3600)}
            assert verdict["causal_prefix_diagnostics"] == parity
            assert all(load(evaluation / "prefix156-comparison.json")[key] == value for key, value in parity.items())
            differences = [{"detector_id": key[0], "begin": key[1], "end": key[2], "source": first.get(key), "candidate": last.get(key)}
                for key in sorted(first.keys() | last.keys()) if first.get(key) != last.get(key)]
            tools["save"](destination / "prefix156-differences.json", differences)
            result.update(prefix156=parity, prefix156_changed_intervals=len(differences),
                main130_TAE_delta_from_source=data["metrics130"]["TAE"] - before["metrics130"]["TAE"])
        tools["save"](destination / "audit.json", result)
        summary["points"][label], measured[label] = result, data
        hashes.update(data["source_hashes"])
        for path in (case / "prepared").iterdir():
            hashes[str(path)] = sha(path)
        for name in ("verdict.json", "preflight.json", "evaluation/native/vehicle-routes.xml", "evaluation/native/sumo-errors.log"):
            hashes[str(case / name)] = sha(case / name)
        if label != "source395":
            for name in ("measurement-plan.json", "scope-proof.json", "proposal.json", "od-vector.json", "executed-driver.py", "executed-shared-driver.py"):
                hashes[str(case / name)] = sha(case / name)
    summary["claim_boundary"] = "Three actual native points with independent raw208/130/52/182/40 and complete instant-event checks. The two shifts are bounded response measurements; no monotonic improvement is assumed. Prefix156 equality is diagnostic only because one request crosses10800. No new native run, phase change, automatic next parameter or field-OD identification follows from this audit."
    tools["save"](OUT / "summary.json", summary)
    for path in (Path(__file__), HELPER, HELPER.parent / "audit_scope.py", ROOT / "run_extension.py", ROOT / "prepare_extensions.py"):
        hashes[str(path)] = sha(path)
    tools["save"](OUT / "source-hashes.json", hashes)
    tools["save"](OUT / "manifest.json", {"native_runs": 0, "files": [{"path": path.relative_to(OUT).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}
        for path in sorted(OUT.rglob("*")) if path.is_file() and path.name != "manifest.json" and "__pycache__" not in path.parts]})
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
