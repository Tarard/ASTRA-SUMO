"""Prepare two late-cohort offsets with explicit cross-bin OD metadata."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

from astra_sumo.core.hamburg_departure_probe import apply_native_count_retiming

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
SHIFTS = {"minus60": -60, "minus90": -90}
NAMES = ["network.net.xml", "control.add.xml", "demand.rou.xml", "field-loops.add.xml",
         "expected-counts.csv", "initialization-counts.csv", "lane-intentions.json", "scenario.json"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def ms(time):
    return math.floor(time*1000+.5)


def prepare(case_name):
    case, shift = ROOT / "cases" / case_name, SHIFTS[case_name]
    assert not case.exists(), "Preserve each prepared case."
    source = SOURCE / "prepared"
    before = ET.parse(source / "demand.rou.xml").getroot()
    old = {v.get("id"):v for v in before.findall("vehicle")}
    intentions = json.loads((source / "lane-intentions.json").read_bytes())
    intent = {r["vehicle_id"]:r for r in intentions["vehicles"]}
    selected = sorted(i for i in old if intent[i]["od_cell"]==256)
    assert selected==[f"od_0256_v{i:05d}" for i in range(29)]
    assert all(intent[i]["field_id"]=="hh_0535_Z_4_33055" for i in selected)
    health = json.loads((SOURCE/"verdict.json").read_bytes())
    assert health["healthy"] and health["safe"] and health["after"]["metrics130"]["TAE"]==395
    proposals = [dict(vehicle_id=i,source_depart_s=float(old[i].get("depart")),proposed_depart_s=float(old[i].get("depart"))+shift,
                      shift_s=shift,od_cell=256,detector_id=intent[i]["field_id"]) for i in selected]
    after = apply_native_count_retiming(before,proposals)
    new = {v.get("id"):v for v in after.findall("vehicle")}
    assert len(old)==len(new)==8640 and old.keys()==new.keys()
    for identity,v in old.items():
        restored = copy.deepcopy(new[identity])
        if identity not in selected:
            assert ET.tostring(restored)==ET.tostring(v)
        else:
            assert ms(float(restored.get("depart")))-ms(float(v.get("depart")))==shift*1000
            assert 9900<=float(restored.get("depart"))<11700
        restored.set("depart",v.get("depart"))
        assert ET.tostring(restored)==ET.tostring(v)
    def order(rows):
        return [v.get("id") for v in rows.findall("vehicle") if v.get("id") not in selected]

    assert order(before)==order(after)
    edges = {i:v.find("route").get("edges").split() for i,v in old.items()}
    def key(identity, vehicle):
        return edges[identity][0], edges[identity][-1], ms(float(vehicle.get("depart")))//900000

    source_cells = {}
    for identity, vehicle in old.items():
        cell_key = key(identity, vehicle)
        if cell_key in source_cells:
            assert source_cells[cell_key] == intent[identity]["od_cell"]
        source_cells[cell_key] = intent[identity]["od_cell"]
    old_q = [0] * 294
    new_q = [0] * 294
    metadata_updates = []
    for row in intentions["vehicles"]:
        identity = row["vehicle_id"]
        old_cell = row["od_cell"]
        actual_cell = source_cells[key(identity, new[identity])]
        old_q[old_cell] += 1
        new_q[actual_cell] += 1
        if actual_cell != old_cell:
            row["od_cell"] = actual_cell
            metadata_updates.append(dict(vehicle_id=identity,source_od_cell=old_cell,target_od_cell=actual_cell,
                source_request_begin_s=key(identity,old[identity])[2]*900,new_request_begin_s=key(identity,new[identity])[2]*900))
    assert metadata_updates == [dict(vehicle_id="od_0256_v00000",source_od_cell=256,target_od_cell=235,
        source_request_begin_s=10800,new_request_begin_s=9900)]
    q_changes = [dict(cell=i,source=old_q[i],candidate=new_q[i],delta=new_q[i]-old_q[i]) for i in range(294) if old_q[i]!=new_q[i]]
    assert [(r["cell"],r["delta"]) for r in q_changes]==[(235,1),(256,-1)]
    od = [i for i in old if edges[i][0]=="-983227468#1" and edges[i][-1]=="28665128#0"]
    assert all(edges[i][0]=="-983227468#1" and edges[i][-1]=="28665128#0" for i in selected)
    assert sorted(od,key=lambda i:(float(old[i].get("depart")),i))==sorted(od,key=lambda i:(float(new[i].get("depart")),i))
    before_headways = [ms(float(old[b].get("depart")))-ms(float(old[a].get("depart"))) for a,b in zip(selected,selected[1:])]
    after_headways = [ms(float(new[b].get("depart")))-ms(float(new[a].get("depart"))) for a,b in zip(selected,selected[1:])]
    assert before_headways==after_headways
    assert [ET.tostring(v) for v in before if v.tag!="vehicle"]==[ET.tostring(v) for v in after if v.tag!="vehicle"]
    departure_keys = []
    for row in intentions["vehicles"]:
        if row["vehicle_id"] in selected:
            for name in ["depart_s","requested_depart_s","requested_departure_s"]:
                if name in row:
                    row[name]=float(new[row["vehicle_id"]].get("depart"))
                    departure_keys.append(name)
    prepared = case/"prepared"
    shutil.copytree(source,prepared)
    ET.ElementTree(after).write(prepared/"demand.rou.xml",encoding="utf-8",xml_declaration=True)
    save(prepared/"lane-intentions.json",intentions)
    scenario=json.loads((source/"scenario.json").read_bytes())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,demand_sha256=sha(prepared/"demand.rou.xml"),
        demand_prior=f"Only29 explicit535Z4 source-ODcell256/h12 requests shift by{shift:+d}s from healthy525 source. All8640 historical IDs/routes/stops/vTypes/field intentions remain. One request crosses10800:actual294 q changes235+1/256-1 and its od_cell is synchronized; no quantile regeneration.",
        time_prior="Whole-cohort time offset preserves native-millisecond headways and complete same-OD order. One new request is before10800. Native response and actual156-prefix differences are unmeasured and must be reported, not assumed identical; no monotonicity claim.",
        timing_offset=dict(source_od_cell=256,changed_requests=29,shift_s=shift,new_requests_before10800=1,changed_q_cells=q_changes,
            native_response_verified=False,other_OD_interleavings_can_change=True))
    save(prepared/"scenario.json",scenario)
    proposal=dict(schema="astra.hamburg.535z4-tail-offset-extension-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        case=case_name,source_main130_TAE=395,shift_s=shift,changed_vehicles=29,proposals=proposals,
        earliest_new_request_s=min(float(new[i].get("depart")) for i in selected),latest_new_request_s=max(float(new[i].get("depart")) for i in selected),
        headways_preserved_native_ms=True,original_headways_ms=before_headways,same_OD_request_order_preserved=True,
        changed294_q_cells=q_changes,q_L1=2,actual_od_cell_updates=metadata_updates,
        other_OD_interleavings_can_change=True,intent_departure_keys_updated=sorted(set(departure_keys)),
        claim_boundary="One bounded timing response from source395, not the failed compression. No measured improvement, fixed-lag response, monotonicity or capacity claim. Two cases have isolated prepared/measurement artifacts.")
    save(case/"proposal.json",proposal)
    save(case/"od-vector.json",dict(schema="astra.hamburg.explicit-request-od-vector/v1",vehicle_count=8640,
        generation="Existing explicit requests retimed; actual native-millisecond OD-period bins rebuilt, not quantile generated.",
        source_integer_counts=old_q,integer_counts=new_q,changed_cells=q_changes,l1_change=2))
    implementation=case/"preparation-implementation"
    implementation.mkdir()
    core=REPO/"plugins/astra-sumo/src/astra_sumo/core/hamburg_departure_probe.py"
    shutil.copy2(core,implementation/core.name)
    shutil.copy2(__file__,case/"executed-prepare.py")
    sources=[source/n for n in NAMES]+[SOURCE/"verdict.json",core,Path(__file__)]
    save(case/"scope-proof.json",dict(schema="astra.hamburg.535z4-tail-offset-extension-scope/v1",status="pass",formal_result=False,new_native_runs=0,
        N=8640,case=case_name,actual_changes=29,shift_s=shift,source_hashes={str(p.resolve()):sha(p) for p in sources},
        prepared_hashes={n:sha(prepared/n) for n in NAMES},proposal_sha256=sha(case/"proposal.json"),
        od_vector_sha256=sha(case/"od-vector.json"),q_L1=2,actual_od_cell_updates=metadata_updates,
        checks=dict(only29_departures_changed=True,other8611_XML_exact=True,other8611_relative_order_exact=True,
            complete_same_OD_request_order_preserved=True,all_native_ms_headways_preserved=True,all_ID_route_stop_field_N_preserved=True,
            actual_q_and_metadata_rebuilt=True,only_v0_crosses10800=True,other8611_requests_exact=True,network_control_targets_exact=True),
        required_native_prefix="Report actual156 nativeE1 intervals ending<=10800 and every attribute difference from source; equality is not required because one request now crosses10800. Full130/52/182/40/208 and completion/safety/uniquefields remain required."))
    return check(case_name)


def check(case_name):
    case=ROOT/"cases"/case_name
    proof=json.loads((case/"scope-proof.json").read_bytes())
    proposal=json.loads((case/"proposal.json").read_bytes())
    assert proof["status"]=="pass" and all(proof["checks"].values()) and proof["actual_changes"]==29
    assert all(sha(Path(p))==h for p,h in proof["source_hashes"].items())
    assert all(sha(case/"prepared"/n)==h for n,h in proof["prepared_hashes"].items())
    assert sha(case/"proposal.json")==proof["proposal_sha256"]
    assert sha(case/"od-vector.json")==proof["od_vector_sha256"]
    vector=json.loads((case/"od-vector.json").read_bytes())
    assert len(vector["integer_counts"])==294 and sum(vector["integer_counts"])==8640 and vector["l1_change"]==2
    for n in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
        assert (case/"prepared"/n).read_bytes()==(SOURCE/"prepared"/n).read_bytes()
    assert proof["prepared_hashes"]["network.net.xml"]=="6c52382e7664eca33fceff6fd02ae700d93139a316a3f9f5139d0e139d7a18ce"
    assert proof["prepared_hashes"]["control.add.xml"]=="27220b430aa68c24f0ad360c57ee3bd0f4b8dcdc88aead5344bcff00e4f43e3b"
    return dict(status="pass",new_native_runs=0,case=str(case),shift_s=SHIFTS[case_name],changed_vehicles=29,
                earliest_new_request_s=proposal["earliest_new_request_s"],latest_new_request_s=proposal["latest_new_request_s"],
                scope_sha256=sha(case/"scope-proof.json"),proposal_sha256=sha(case/"proposal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=SHIFTS,required=True)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare",action="store_true")
    mode.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare(args.case) if args.prepare else check(args.case)))
