"""Account for the two completed offset extensions and the closed five-candidate study."""
from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
REPO=ROOT.parents[1]
SOURCE=REPO/"outputs/hamburg-266197525-partial-control-20261024-v1/full/evaluation"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def events(folder):
    payload=json.loads(gzip.decompress((folder/"contributing-passages.json.gz").read_bytes()))
    by_id={r["vehicle_id"]:r for r in payload["passages"]}
    raw={(r.get("id"),int(float(r.get("begin")))):int(r.get("nVehContrib")) for r in ET.parse(folder/"native/field-counts.xml").getroot().findall("interval")}
    counted=Counter((r["detector_id"],int(r["interval_begin_s"])) for r in by_id.values())
    assert payload["reconciled"] and len(by_id)==len(payload["passages"])==8640 and len(raw)==208
    assert all(counted[k]==v for k,v in raw.items())
    return by_id,raw


def write_csv(name,rows):
    with (OUT/name).open("w",encoding="utf-8",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    assert not (OUT/"manifest.json").exists(),"Preserve sealed analysis."
    before,source_counts=events(SOURCE)
    truth={(r["detector_id"],int(float(r["begin"]))):int(r["expected_total"]) for r in csv.DictReader((SOURCE/"all182-comparison.csv").open(encoding="utf-8"))}
    intents={r["vehicle_id"]:r for r in json.loads((SOURCE/"lane-intentions.json").read_bytes())["vehicles"]}
    all_fields,all_intervals,summary=[],[],{}
    source_paths=[SOURCE/"contributing-passages.json.gz",SOURCE/"native/field-counts.xml",SOURCE/"all182-comparison.csv",SOURCE/"lane-intentions.json"]
    for name in ["minus60","minus90"]:
        case=ROOT/"cases"/name
        folder=case/"evaluation"
        after,counts=events(folder)
        proposals={r["vehicle_id"]:r for r in json.loads((case/"proposal.json").read_bytes())["proposals"]}
        actual_intents={r["vehicle_id"]:r for r in json.loads((folder/"lane-intentions.json").read_bytes())["vehicles"]}
        assert set(after)==set(before) and len(proposals)==29
        own,other=[],[]
        for identity,a in before.items():
            b=after[identity]
            assert a["detector_id"]==b["detector_id"]==intents[identity]["field_id"]
            row=dict(vehicle_id=identity,detector_id=a["detector_id"],source_od_cell=intents[identity]["od_cell"],
                source_notification_s=a["notification_time_s"],actual_notification_s=b["notification_time_s"],
                actual_shift_s=b["notification_time_s"]-a["notification_time_s"],
                source_begin=int(a["interval_begin_s"]),actual_begin=int(b["interval_begin_s"]))
            if identity in proposals:
                p=proposals[identity]
                row.update(source_depart_s=p["source_depart_s"],actual_requested_depart_s=p["proposed_depart_s"],actual_od_cell=actual_intents[identity]["od_cell"])
                own.append(row)
            elif abs(row["actual_shift_s"])>1e-7:
                other.append(row)
        own.sort(key=lambda r:r["vehicle_id"])
        other.sort(key=lambda r:(r["detector_id"],r["source_notification_s"]))
        moved=[r for r in other if r["source_begin"]!=r["actual_begin"]]
        write_csv(name+"-own29.csv",own)
        write_csv(name+"-unmodified-time-response.csv",other)
        write_csv(name+"-unmodified-bin-response.csv",moved)
        own_before=Counter((before[i]["detector_id"],int(before[i]["interval_begin_s"])) for i in proposals)
        own_after=Counter((after[i]["detector_id"],int(after[i]["interval_begin_s"])) for i in proposals)
        for field in sorted({k[0] for k in truth}):
            keys=[k for k in truth if k[0]==field and k[1]>=3600]
            old_tae=sum(abs(source_counts[k]-truth[k]) for k in keys)
            new_tae=sum(abs(counts[k]-truth[k]) for k in keys)
            all_fields.append(dict(case=name,detector_id=field,source_TAE=old_tae,actual_TAE=new_tae,TAE_change=new_tae-old_tae,
                source_SSE=sum((source_counts[k]-truth[k])**2 for k in keys),actual_SSE=sum((counts[k]-truth[k])**2 for k in keys),
                unmodified_time_changed=sum(r["detector_id"]==field for r in other),unmodified_bin_changed=sum(r["detector_id"]==field for r in moved)))
        for key in source_counts:
            own_delta=own_after[key]-own_before[key]
            if counts[key]!=source_counts[key] or own_delta:
                all_intervals.append(dict(case=name,detector_id=key[0],begin=key[1],end=key[1]+900,expected=truth.get(key),
                    source=source_counts[key],actual=counts[key],own29_delta=own_delta,unmodified8611_delta=counts[key]-source_counts[key]-own_delta))
        late=[k for k in truth if k[1]>=10800]
        selected_carry=[r for r in own if r["source_begin"]==11700]
        summary[name]=dict(own_source_bins=dict(Counter(r["source_begin"] for r in own)),own_actual_bins=dict(Counter(r["actual_begin"] for r in own)),
            original15_carry_recovered=sum(r["actual_begin"]==10800 for r in selected_carry),original15_carry_remaining=sum(r["actual_begin"]==11700 for r in selected_carry),
            other_time_changed=len(other),other_bin_changed=len(moved),
            other_transitions=[dict(field=k[0],source_begin=k[1],actual_begin=k[2],vehicles=v) for k,v in sorted(Counter((r["detector_id"],r["source_begin"],r["actual_begin"]) for r in moved).items())],
            all_last26_TAE_source=sum(abs(source_counts[k]-truth[k]) for k in late),all_last26_TAE_actual=sum(abs(counts[k]-truth[k]) for k in late),
            prefix156=json.loads((folder/"prefix156-comparison.json").read_bytes()),
            all_before10800_counts_identical=all(source_counts[k]==counts[k] for k in source_counts if k[1]<10800))
        source_paths += [case/"proposal.json",case/"scope-proof.json",case/"verdict.json",case/"od-vector.json",folder/"lane-intentions.json",folder/"contributing-passages.json.gz",folder/"native/field-counts.xml",folder/"prefix156-comparison.json"]
    write_csv("field13-paired-response.csv",all_fields)
    write_csv("changed208-paired-decomposition.csv",all_intervals)
    points=[]
    studies=[("source",SOURCE,None),
        ("compression_beta",REPO/"outputs/hamburg-535z4-tail-compression-20261024-v1/compress29/evaluation",None),
        ("minus30",REPO/"outputs/hamburg-535z4-tail-offset-20261024-v1/cases/minus30/evaluation",-30),
        ("plus30",REPO/"outputs/hamburg-535z4-tail-offset-20261024-v1/cases/plus30/evaluation",30),
        ("minus60",ROOT/"cases/minus60/evaluation",-60),("minus90",ROOT/"cases/minus90/evaluation",-90)]
    selected_ids={f"od_0256_v{i:05d}" for i in range(29)}
    for label,folder,shift in studies:
        actual,counts=events(folder)
        main=[k for k in truth if k[1]>=3600]
        late=[k for k in truth if k[1]>=10800]
        own_bins=Counter(int(actual[i]["interval_begin_s"]) for i in selected_ids)
        field_keys=[k for k in main if k[0]=="hh_0535_Z_4_33055"]
        points.append(dict(case=label,whole_cohort_offset_s=shift,main130_TAE=sum(abs(counts[k]-truth[k]) for k in main),
            main130_SSE=sum((counts[k]-truth[k])**2 for k in main),last26_TAE=sum(abs(counts[k]-truth[k]) for k in late),
            field535Z4_TAE=sum(abs(counts[k]-truth[k]) for k in field_keys),
            field535Z4_penultimate=counts["hh_0535_Z_4_33055",10800],field535Z4_last=counts["hh_0535_Z_4_33055",11700],
            field535Z4_tail=counts["hh_0535_Z_4_33055",12600]+counts["hh_0535_Z_4_33055",13500],
            own29_penultimate=own_bins[10800],own29_last=own_bins[11700],original15_carry_recovered=sum(before[i]["interval_begin_s"]==11700 and actual[i]["interval_begin_s"]==10800 for i in selected_ids)))
        source_paths += [folder/"contributing-passages.json.gz",folder/"native/field-counts.xml"]
    write_csv("closed-study-six-points.csv",points)
    report=dict(schema="astra.hamburg.535z4-tail-offset-extension-response/v1",status="pass",new_native_runs=0,source_main_TAE=395,
        cases=summary,
        all_measured_points=points,closed_cohort_search=True,best_measured_main_point="minus30",
        interpretation="Minus60 recovers2 own carry vehicles and improves535Z4 TAE by4;minus90 recovers3 and improves it by6. Each also improves unchanged119 fields by a net20TAE. Minus30 remains best at365 because it improves own535Z4 by8 and other fields by22. Same-field unchanged vehicles do not cross bins in either extension. No further cohort parameter search is implied.",
        boundaries="Both extensions change actual294 q by235+1/256-1;v0 metadata is235 while its historical ID staysod0256.156prefix equality is a measured result, not a preparation assumption. All late-tail rows without real observations retain expected=null. These responses do not establish monotonicity, a hard capacity bound, or field control validity.")
    (OUT/"summary.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in dict.fromkeys(source_paths)],indent=2)+"\n",encoding="utf-8")
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=files),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="pass",manifest_sha256=sha(OUT/"manifest.json"),cases={n:dict(own_actual_bins=r["own_actual_bins"],others_bin_changed=r["other_bin_changed"],late26_TAE=r["all_last26_TAE_actual"]) for n,r in summary.items()})))


if __name__=="__main__":
    main()
