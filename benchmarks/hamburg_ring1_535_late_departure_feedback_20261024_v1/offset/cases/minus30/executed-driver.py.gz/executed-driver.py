"""Measure one saved29-car uniform timing shift in a separate case directory."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-266197525-partial-control-20261024-v1/full"
REUSED_PATH = REPO / "outputs/hamburg-535z4-tail-compression-20261024-v1/run_compression.py"
REUSED_SHA = "074a01b1ac033db8de2424eb39f0c323a3bbe962ea7970d1d6a6e9a5278d0d8b"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert sha(REUSED_PATH) == REUSED_SHA
REUSED = runpy.run_path(str(REUSED_PATH))
BASE = REUSED["BASE"]
SHARED, SHARED_SHA, SHARED_RUN = REUSED["SHARED"], REUSED["SHARED_SHA"], REUSED["SHARED_RUN"]
source_health = REUSED["source_health"]
prefix_comparison = REUSED["prefix_comparison"]
CASE = None


def save(path, value):
    if path == CASE / "preflight.json":
        value["source_full_health_gate"] = value.pop("smoke")
        value["measurement_plan_sha256"] = sha(CASE / "measurement-plan.json")
        value["shared_measurement_driver"] = {"path": str(CASE / "executed-shared-driver.py"),
            "sha256": sha(CASE / "executed-shared-driver.py"), "source_sha256": SHARED_SHA}
    if path == CASE / "verdict.json":
        if "source_plus15" in value:
            value["source_525_parent"] = value.pop("source_plus15")
        if "plus15_parent" in value.get("comparison", {}):
            value["comparison"]["parent_525_full"] = value["comparison"].pop("plus15_parent")
        if "after" in value:
            prefix = prefix_comparison()
            (CASE / "evaluation/prefix156-comparison.json").write_text(json.dumps(prefix, indent=2) + "\n", encoding="utf-8")
            value["causal_prefix_diagnostics"] = {key: prefix[key] for key in (
                "all156_native_e1_attributes_identical", "initial52_native_attributes_identical", "main_first8_104_native_attributes_identical")}
        value.update(study_role="single_h12_od0256_uniform_departure_shift", timing_case=CASE.name,
            new_geometry_smoke_required=False,
            claim_boundary="Only29 saved h12 requests shift uniformly by30 seconds. Routes,stops,fields,N and294 inventory stay fixed. Actual130/52/182/40/208,53556,unique events,safety and backlog are reported. Prefix parity and count response require native measurement. No automatic next round or field-certified zero claim.")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def verify_plan(plan):
    assert all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in plan["prepared_hashes"].items())


def check():
    assert runpy.run_path(str(ROOT / "prepare_offsets.py"))["check"](CASE.name)["status"] == "pass"
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    parent = json.loads((SOURCE / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent["modules"] and runtime["native_library"] == parent["native_library"]
    assert all(sha(path) == value for path, value in parent["binaries"].items())
    runtime["binaries"] = parent["binaries"]
    paths = [Path(__file__), REUSED_PATH, SHARED, ROOT / "prepare_offsets.py", CASE / "scope-proof.json", CASE / "proposal.json",
        SOURCE / "verdict.json", SOURCE / "preflight.json", BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"], BASE["AUDIT_HELPER"].parent / "audit_scope.py"]
    paths += list((SOURCE / "prepared").iterdir())
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "hamburg_od_spsa.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    plan_path = CASE / "measurement-plan.json"
    if not plan_path.exists():
        save(plan_path, {"formal_result": False, "case": CASE.name, "source_hashes": {str(path): sha(path) for path in paths},
            "source_health": source_health(), "native_runs": 0,
            "prepared_hashes": {path.name: sha(path) for path in (CASE / "prepared").iterdir()},
            "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo", "prefix_native_diagnostic_cutoff_s": 10800})
    verify_plan(json.loads(plan_path.read_bytes()))
    return {"status": "pass", "case": CASE.name, "native_runs": 0, "runtime": runtime, "source_health": source_health()}


def select_case(name):
    global CASE
    assert name in {"minus30", "plus30"}
    CASE = ROOT / "cases" / name
    prefix_comparison.__globals__.update(CASE=CASE, SOURCE=SOURCE)
    SHARED_RUN.__globals__.update(ROOT=CASE, CASE=CASE, SOURCE=SOURCE, check=check,
        require_smoke=source_health, save=save, __file__=str(Path(__file__)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("minus30", "plus30"), required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    select_case(args.case)
    checked = check()
    if args.check_only:
        print(json.dumps({key: value for key, value in checked.items() if key != "runtime"}))
    else:
        assert not (CASE / "evaluation").exists() and not (CASE / "verdict.json").exists(), "Preserve existing and partial results."
        assert not (CASE / "implementation").exists(), "Keep preparation snapshots separate."
        snapshots = CASE / "measurement-implementation"
        snapshots.mkdir(exist_ok=False)
        shutil.copyfile(SHARED, CASE / "executed-shared-driver.py")
        for path in json.loads((CASE / "measurement-plan.json").read_bytes())["source_hashes"]:
            path = Path(path)
            if path.suffix == ".py":
                shutil.copyfile(path, snapshots / path.name)
        SHARED_RUN()
