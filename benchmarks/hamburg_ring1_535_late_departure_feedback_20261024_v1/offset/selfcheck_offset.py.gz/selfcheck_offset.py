"""Check separate case writes and reject a changed saved input without SUMO."""

import json
from pathlib import Path
import runpy
import tempfile


SCRIPT = Path(__file__).with_name("run_offset.py")
api = runpy.run_path(str(SCRIPT))
state = api["select_case"].__globals__
with tempfile.TemporaryDirectory() as temporary:
    state["ROOT"] = Path(temporary)
    outputs = []
    for name in ("minus30", "plus30"):
        api["select_case"](name)
        case = state["CASE"]
        (case / "prepared").mkdir(parents=True)
        marker = case / "prepared/input.txt"
        marker.write_text(name, encoding="utf-8")
        plan = {"source_hashes": {str(SCRIPT): api["sha"](SCRIPT)}, "prepared_hashes": {marker.name: api["sha"](marker)}}
        api["verify_plan"](plan)
        api["save"](case / "measurement-plan.json", plan)
        api["save"](case / "case-marker.json", {"case": name})
        run_state = api["SHARED_RUN"].__globals__
        assert run_state["ROOT"] == run_state["CASE"] == case
        assert api["prefix_comparison"].__globals__["CASE"] == case
        outputs.append(case / "measurement-plan.json")
        marker.write_text("tampered", encoding="utf-8")
        try:
            api["verify_plan"](plan)
        except AssertionError:
            pass
        else:
            raise AssertionError("Changed input was accepted.")
    assert outputs[0] != outputs[1] and all(path.is_file() for path in outputs)
    assert [json.loads((path.parent / "case-marker.json").read_bytes())["case"] for path in outputs] == ["minus30", "plus30"]
print(json.dumps({"status": "pass", "native_runs": 0, "case_writes_isolated": True, "two_tampered_inputs_rejected": True,
    "claim_boundary": "Offline test-after checks only. No native result or capacity claim."}))
