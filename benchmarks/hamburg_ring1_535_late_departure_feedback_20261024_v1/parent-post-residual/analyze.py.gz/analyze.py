"""Reconcile completed525 counts and inspect one late535Z4 request cohort offline."""
from collections import Counter
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics
import xml.etree.ElementTree as ET

from astra_sumo.core.native_temporal_feedback import native_departure_windows, native_temporal_feedback

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
CURRENT = OUT.parent / "full/evaluation"
PARENT = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/full/evaluation"
FIELD = "hh_0535_Z_4_33055"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(name, rows):
    with (OUT / name).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()} for row in rows)


def read_csv(path):
    return list(csv.DictReader(path.open(encoding="utf-8")))


def stats(values):
    return dict(min=min(values), median=statistics.median(values), max=max(values))


def main():
    assert not (OUT / "manifest.json").exists(), "Keep sealed source analyses."
    vehicles = {v.get("id"): v for v in ET.parse(CURRENT / "demand.rou.xml").getroot().findall("vehicle")}
    intentions = {r["vehicle_id"]: r for r in json.loads((CURRENT / "lane-intentions.json").read_bytes())["vehicles"]}
    trips = {r.get("id"): r for r in ET.parse(CURRENT / "native/tripinfo.xml").getroot().findall("tripinfo")}
    passages = json.loads(gzip.decompress((CURRENT / "contributing-passages.json.gz").read_bytes()))
    events = {r["vehicle_id"]: r for r in passages["passages"]}
    parent_events = {r["vehicle_id"]: r for r in json.loads(gzip.decompress((PARENT / "contributing-passages.json.gz").read_bytes()))["passages"]}
    assert passages["reconciled"] and len(vehicles) == len(trips) == len(intentions) == len(events) == 8640
    assert set(vehicles) == set(trips) == set(intentions) == set(events) == set(parent_events)
    assert all(float(v.get("arrival")) >= 0 for v in trips.values())
    raw = {(r.get("id"), int(float(r.get("begin")))): int(r.get("nVehContrib"))
           for r in ET.parse(CURRENT / "native/field-counts.xml").getroot().findall("interval")}
    assert len(raw) == 208
    counts = Counter((r["detector_id"], int(r["interval_begin_s"])) for r in events.values())
    assert all(counts[key] == value for key, value in raw.items())
    assert all(e["detector_id"] == intentions[i]["field_id"] for i, e in events.items())
    true_rows = read_csv(CURRENT / "all182-comparison.csv")
    parent_rows = {(r["detector_id"], int(float(r["begin"]))): r for r in read_csv(PARENT / "all182-comparison.csv")}
    fields = sorted({r["detector_id"] for r in true_rows})
    main_rows = []
    for row in true_rows:
        field, begin = row["detector_id"], int(float(row["begin"]))
        expected, actual = int(row["expected_total"]), raw[field, begin]
        old = parent_rows[field, begin]
        assert expected == int(old["expected_total"]) and actual == int(row["measured_nVehContrib"])
        if begin >= 3600:
            main_rows.append(dict(detector_id=field, begin=begin, end=begin + 900, expected=expected,
                measured=actual, residual=actual - expected, parent_measured=int(old["measured_nVehContrib"]),
                parent_residual=int(old["diff_nVehContrib_minus_expected"]), measured_change=actual - int(old["measured_nVehContrib"])))
    assert len(main_rows) == 130 and sum(abs(r["residual"]) for r in main_rows) == 395
    matrix = [dict(detector_id=field, **{str(r["begin"]): r["residual"] for r in main_rows if r["detector_id"] == field}) for field in fields]
    regions = []
    stock = Counter(r["field_id"] for r in intentions.values())
    for field in fields:
        real = [r for r in true_rows if r["detector_id"] == field]
        main = [r for r in main_rows if r["detector_id"] == field]
        init_target = sum(int(r["expected_total"]) for r in real if float(r["begin"]) < 3600)
        main_target = sum(r["expected"] for r in main)
        init = sum(value for (f, b), value in raw.items() if f == field and b < 3600)
        measured_main = sum(r["measured"] for r in main)
        tail = sum(value for (f, b), value in raw.items() if f == field and b >= 12600)
        assert init + measured_main + tail == stock[field]
        regions.append(dict(detector_id=field, intended_population=stock[field], init_target=init_target, init_events=init,
            main_target=main_target, main_events=measured_main, tail_events=tail, main_signed=measured_main-main_target,
            main_TAE=sum(abs(r["residual"]) for r in main), parent_main_TAE=sum(abs(r["parent_residual"]) for r in main),
            population_minus_real14_target=stock[field]-init_target-main_target))
    requests, event_rows = [], []
    for identity, v in vehicles.items():
        edges = v.find("route").get("edges").split()
        departure = math.floor(float(v.get("depart")) * 1000 + .5) / 1000
        inserted, event = float(trips[identity].get("depart")), events[identity]
        requests.append(dict(vehicle_id=identity, requested_depart_s=departure, detector_id=event["detector_id"],
                             plan_id=f"{edges[0]}|{edges[-1]}|{event['detector_id']}"))
        event_rows.append(dict(vehicle_id=identity, detector_id=event["detector_id"], od_cell=intentions[identity]["od_cell"],
            origin=edges[0], destination=edges[-1], source_departure_s=float(v.get("depart")), native_requested_depart_s=departure,
            requested_bin_begin=int(departure // 900)*900, actual_depart_s=inserted, actual_depart_bin_begin=int(inserted // 900)*900,
            insertion_delay_s=inserted-departure, native_notification_s=event["notification_time_s"],
            actual_bin_begin=int(event["interval_begin_s"]), entry_interpolation_s=event["time_s"],
            inserted_to_notification_s=event["notification_time_s"]-inserted,
            parent_notification_s=parent_events[identity]["notification_time_s"], parent_bin_begin=int(parent_events[identity]["interval_begin_s"]),
            route_edges=edges, stops=[dict(r.attrib) for r in v.findall("stop")]))
    temporal = native_temporal_feedback(requests=requests,
        trips=[dict(vehicle_id=i, actual_depart_s=float(v.get("depart"))) for i, v in trips.items()], passages=list(events.values()),
        measurements=[dict(detector_id=f, begin=b, end=b+900, measured_nVehContrib=n) for (f, b), n in raw.items()])
    assert temporal["totals"]["observed_window_passages"] == 8640
    cohorts = Counter((r["detector_id"],r["requested_bin_begin"],r["actual_bin_begin"],r["od_cell"],r["origin"],r["destination"]) for r in event_rows)
    cohort_rows = [dict(zip(["detector_id","request_bin_begin","actual_bin_begin","od_cell","origin","destination"], key, strict=True), vehicles=value) for key,value in sorted(cohorts.items())]
    z5 = [r for r in event_rows if r["detector_id"] == "hh_0119_Z_5_30494" and r["actual_bin_begin"] >= 10800]
    z4 = [r for r in event_rows if r["detector_id"] == FIELD and r["actual_bin_begin"] >= 10800]
    selected = sorted([r for r in z4 if r["actual_bin_begin"] == 11700 and r["requested_bin_begin"] == 10800],key=lambda r:r["source_departure_s"])
    assert [r["vehicle_id"] for r in selected] == [f"od_0256_v{i:05d}" for i in range(14,29)]
    assert len(selected) == 15 and {r["od_cell"] for r in selected} == {256}
    window_checks = {}
    for guard in [30,60]:
        desired = [dict(vehicle_id=r["vehicle_id"],requested_depart_s=r["source_departure_s"],
                        targets=[dict(detector_id=FIELD,begin_s=10800,end_s=11700)]) for r in selected]
        windows = native_departure_windows(requests=desired,passages=[events[r["vehicle_id"]] for r in selected],max_shift_s=900,guard_s=guard,step_s=.1)
        assert all(r["status"] == "feasible_frozen_lags" for r in windows["rows"])
        proposed = {r["vehicle_id"]:r for r in windows["rows"]}
        check_rows = []
        for r in selected:
            move = proposed[r["vehicle_id"]]
            prediction = r["native_notification_s"] + move["proposed_shift_s"]
            check_rows.append(dict(vehicle_id=r["vehicle_id"],proposed_depart_s=move["proposed_depart_s"],unverified_shift_s=move["proposed_shift_s"],unverified_notification_s=prediction))
            assert move["proposed_depart_s"] >= 10800 and int(move["proposed_depart_s"]//900) == 12
        order = [r["proposed_depart_s"] for r in check_rows]
        preceding = next(r for r in event_rows if r["vehicle_id"] == "od_0256_v00013")
        window_checks[str(guard)] = dict(rows=check_rows,earliest_changed_request_s=min(order),max_advance_s=max(-r["unverified_shift_s"] for r in check_rows),
            changed294_q_cells=0,q_L1=0,all_new_requests_at_or_after10800=True,
            selected_request_order_preserved=order==sorted(order),
            full_original_OD_order_preserved=order==sorted(order) and order[0]>preceding["native_requested_depart_s"],
            unmodified_previous_vehicle=preceding["vehicle_id"],unmodified_previous_request_s=preceding["native_requested_depart_s"],
            all_prediction_values_unverified=True)
    for name,rows in [("main130-parent-comparison.csv",main_rows),("main13x10-residuals.csv",matrix),
                      ("field-init-main-tail.csv",regions),("request-to-event-cohorts.csv",cohort_rows),
                      ("late119Z5-events.csv",sorted(z5,key=lambda r:r["native_notification_s"])),
                      ("late535Z4-events.csv",sorted(z4,key=lambda r:r["native_notification_s"])),("selected535Z4-carry15.csv",selected)]:
        write_csv(name,rows)
    summary = dict(schema="astra.hamburg.525-late-demand-residuals/v1",status="review_required",new_native_runs=0,inputs_changed=0,
        main130_TAE=395,main130_SSE=sum(r["residual"]**2 for r in main_rows),native208_reconciled=True,unique_expected_events=8640,
        network_sha256=sha(OUT.parent/"full/prepared/network.net.xml"),control_sha256=sha(OUT.parent/"full/prepared/control.add.xml"),
        native_feedback_totals=temporal["totals"],native_feedback_columns=len(temporal["columns"]),
        selected_carry15=dict(field=FIELD,od_cell=256,origin=selected[0]["origin"],destination=selected[0]["destination"],
            departure=stats([r["native_requested_depart_s"] for r in selected]),actual_depart=stats([r["actual_depart_s"] for r in selected]),
            notification=stats([r["native_notification_s"] for r in selected]),insertion_delay=stats([r["insertion_delay_s"] for r in selected]),
            inserted_to_notification=stats([r["inserted_to_notification_s"] for r in selected]),
            late_pair_actual=[42,59],late_pair_target=[57,44],late_pair_population_actual=101,late_pair_population_target=101),
        frozen_window_checks=window_checks,
        recommendation="One535Z4 late boundary only; keep all network/control/lane/route/field/vehicle identities and every other direction fixed.15 observed carry vehicles are identifiable, but unchanged original request order plus the proposed frozen-lag deadline are incompatible. Do not materialize without declaring which order condition is retained. Native lag translation is not a marginal response or causal effect.",
        prefix_boundary="Only vehicles requested>=10800 and new requests>=10800 may change for this late-only question. Preserve/recheck all previous8main bins and earlier native physical-prefix evidence. Future measurements remain separately reported; changed loaded/pre-read values are not vehicle motion.",
        constraints=["Targets are detector contributions, not requested departure counts. The planned-stock versus target term is accounting, not proof of quantity error.",
            "Z5+23/-26 has23 carry-ins from9900 plus52 current10800 requests. Those52 late requests offer freedom, not a unique true vehicle assignment;Z5 is not selected here.",
            "535Z4 late totals101 match the two true-window totals;15 carry-ins explain the signed pair residual algebraically. Changing their departures can change other vehicles and does not guarantee these15 switch bins.",
            "All native vehicles completed their one expected field; no missing event has been filled with zero.",
            "Keeping IDs/stops/routes/population/q does not imply keeping relative departure/arrival order. Helper outputs explicitly show the order conflict."])
    (OUT/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    paths=[CURRENT/"demand.rou.xml",CURRENT/"lane-intentions.json",CURRENT/"contributing-passages.json.gz",CURRENT/"native/field-counts.xml",CURRENT/"native/tripinfo.xml",CURRENT/"all182-comparison.csv",
           PARENT/"contributing-passages.json.gz",PARENT/"all182-comparison.csv",OUT.parent/"full/prepared/network.net.xml",OUT.parent/"full/prepared/control.add.xml",
           REPO/"plugins/astra-sumo/src/astra_sumo/core/native_temporal_feedback.py",REPO/"plugins/astra-sumo/src/astra_sumo/core/hamburg_departure_probe.py"]
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in paths],indent=2)+"\n",encoding="utf-8")
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="review_required",main_TAE=395,selected15=True,orders_preserved={k:v["full_original_OD_order_preserved"] for k,v in window_checks.items()},manifest_sha256=sha(OUT/"manifest.json"))))


if __name__=="__main__":
    main()
