"""Inspect saved LSA119 control provenance without changing or running inputs."""

import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.ocit_c_programs import read_ocit_fixed_program

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
PREPARED = REPO / "outputs/hamburg-cohort-timing-extension-20261024-v1/extension/prepared"
M2 = REPO / "benchmarks/hamburg_ring1_m2_control_20261021_v1"
OFFICIAL = REPO / "benchmarks/hamburg_ring1_official_sources_20261020_v1"
FAMILY = {"LSA119_part0", "6390683126"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def local(row):
    return row.tag.rsplit("}", 1)[-1]


def child(row, name):
    return next((c for c in row if local(c) == name), None)


def text(row, name):
    item = child(row, name)
    return None if item is None else item.text


def main():
    source_manifest = load(OFFICIAL / "manifest.json")
    source = next(r for r in source_manifest["files"] if r["node_id"] == "119" and r["kind"] == "ocit_xml")
    compressed = OFFICIAL / source["path"]
    raw = gzip.decompress(compressed.read_bytes())
    ocit = M2 / "inputs/ocit_119.xml"
    assert sha(compressed) == source["compressed_sha256"] and hashlib.sha256(raw).hexdigest() == source["sha256"]
    assert raw == ocit.read_bytes() and len(raw) == source["bytes"]
    fresh = read_ocit_fixed_program(ocit, "1")
    frozen = load(M2 / "source-program-119.json")
    assert fresh["cycle_s"] == frozen["cycle_s"] == 90 and fresh["signal_times_offset_native"] == frozen["signal_times_offset_native"] == "0"
    assert fresh["groups"] == frozen["groups"] and fresh["safety_intergreens"] == frozen["safety_intergreens"]
    controls = {t.get("id"): t for t in ET.parse(PREPARED / "control.add.xml").getroot().findall("tlLogic")}
    originals = {t.get("id"): t for t in ET.parse(M2 / "control-A.add.xml").getroot().findall("tlLogic")}
    net = ET.parse(PREPARED / "network.net.xml").getroot()
    assert {k for k in controls if k.startswith("LSA119")} == {"LSA119_part0"}
    with gzip.open(M2 / "link-bindings.json.gz", "rt", encoding="utf-8") as handle:
        bindings = json.load(handle)["rows"]
    by_key = {tuple(r["physical_key"]): r for r in bindings}
    family = []
    movement_rows = []
    for identity in sorted(FAMILY):
        logic = controls[identity]
        phases = [dict(p.attrib) for p in logic.findall("phase")]
        assert logic.get("type") == "static" and logic.get("programID") == "readme_fixed_A" and logic.get("offset") == "0"
        assert sum(float(p["duration"]) for p in phases) == 90
        original = originals[identity]
        assert phases == [dict(p.attrib) for p in original.findall("phase")] and original.get("offset") == "0"
        connections = [c for c in net.findall("connection") if c.get("tl") == identity]
        assert sorted(int(c.get("linkIndex")) for c in connections) == list(range(len(phases[0]["state"])))
        family.append(dict(controller_id=identity, program_id=logic.get("programID"), type=logic.get("type"), cycle_s=90, offset_s=0, source_program_reference="119/SP1", controlled_indices=len(connections), role="main official-group projection" if identity.startswith("LSA") else "declared Z15 alternative A mapped to119/K9", original_M2_A_phase_attributes_and_offset_identical=True, phases=phases))
        for c in sorted(connections, key=lambda row: int(row.get("linkIndex"))):
            key = (c.get("from"), int(c.get("fromLane")), c.get("to"), int(c.get("toLane")))
            binding = by_key[key]
            movement_rows.append(dict(controller_id=identity, link_index=int(c.get("linkIndex")), from_edge=key[0], from_lane=key[1], to_edge=key[2], to_lane=key[3], source_group_expression=binding["groups"] if identity.startswith("LSA") else [["119", "K9"]], binding_origin=binding["origin"]))
    root = ET.fromstring(raw)
    program = next(x for x in root.iter() if local(x) == "Signalprogramm" and text(x, "BezeichnungKurz") == "1")
    header = child(program, "SPKopfzeile")
    monday = next(x for x in root.iter() if local(x) == "StandardTagesplan" and text(x, "BezeichnungKurz") == "Montag")
    monday_commands = [{k: text(c, k) for k in ["Uhrzeit", "Programm", "VA", "OePNV", "IVVA"]} for c in monday if local(c) == "Befehl"]
    net_programs = [dict(**t.attrib, cycle_s=sum(float(p.get("duration")) for p in t.findall("phase"))) for t in net.findall("tlLogic") if t.get("id") in FAMILY]
    k9_intergreens = [r for r in fresh["safety_intergreens"]["rows"] if "K9" in [r.get("clearing_group"), r.get("entering_group")]]
    report = dict(schema="astra.hamburg.lsa119-offset-provenance/v1", status="review_required", native_runs=0, candidate_created=False,
        absolute_field_phase_anchor=dict(status="unknown", current_SUMO_offset_zero_is_measured_SPAT=False, source_native_config_offset_zero=True, basis="M2 explicitly declares local-midnight cycle zero and no field signal observation confirms it. OCIT program-relative times/native offset do not independently establish the observed absolute state at2026-10-19T04:30Z."),
        official_source=dict(**source, retrieved_at_utc=source_manifest["retrieved_at_utc"], raw_equals_M2_input=True),
        source_SP1_header_xml=ET.tostring(header, encoding="unicode"), source_cycle_s=90, source_native_signal_times_offset="0", source_Monday_schedule=monday_commands,
        source_header_limits="EP/AP/UP=25 and SY(Vor24,Haupt25,Max_Dauer90) are retained facts. The current parser/installer does not bind their controller startup/resynchronization semantics to a dated absolute SUMO clock. This audit does not invent that binding.",
        current_external_family=family, network_embedded_programs=net_programs,
        common_phase_origin_group=sorted(FAMILY), common_phase_origin_basis="These two model controllers are projections of the same119/SP1 repeating cycle under the retained declared K9 alternative. Any common-origin sensitivity must translate both together to retain their current relative phase/clearance relations.",
        K9_related_source_intergreens=k9_intergreens,
        outside_group=dict(LSA119_part1_or_part2_present=False, GS266_node_type=next(j.get("type") for j in net.findall("junction") if j.get("id") == "266199063"), other_official_controllers="No evidence here requires moving104/118/200/535 merely because they also have90s cycles or zero offsets."),
        source_clock_assumption=load(M2 / "report.json")["clock_assumption"], source_claim_boundary=fresh["claim_boundary"],
        code_citations=[dict(path="plugins/astra-sumo/src/astra_sumo/core/hamburg_readme_control.py", line=159, role="Select119/SP1"), dict(path="plugins/astra-sumo/src/astra_sumo/core/hamburg_readme_control.py", line=248, role="Declared Z15 alternative A uses119/K9"), dict(path="plugins/astra-sumo/src/astra_sumo/core/hamburg_readme_control.py", line=260, role="Write static programs with explicit offset0"), dict(path="plugins/astra-sumo/src/astra_sumo/core/hamburg_readme_control.py", line=301, role="Declare local-midnight absolute clock assumption"), dict(path="plugins/astra-sumo/src/astra_sumo/core/ocit_c_programs.py", line=173, role="Parser does not assign an absolute clock"), dict(path="plugins/astra-sumo/src/astra_sumo/core/ocit_c_programs.py", line=222, role="Raw cycle-relative timing before clock alignment")],
        current_native_program_selection_boundary="The full run declares external additional programs and loads the exact saved control file. This audit inventories that configured program; it does not add an unrecorded current getProgram/getPhase trace.",
        chosen_offset_s=None, recommendation="No offset is selected and no phase, duration, state, input or controller is changed.",
        unknowns=["Actual absolute phase anchor during the count date", "Actual program overrides, synchronization and clock corrections on that date", "Field validity of the retained Z15/K9 alternative", "Measured inter-junction corridor coordination"],
        claim_boundary="Configuration provenance and preservation requirements only. Unknown absolute phase is not proof that a new offset is physically correct, safe or improves count fit. A common translation preserves current within-family relative timing; traffic interactions still require a separate authorized native measurement.")
    save(OUT / "evidence.json", report)
    for name, rows in [("controller-inventory.csv", [{k: v for k, v in r.items() if k != "phases"} for r in family]), ("movement-bindings.csv", movement_rows)]:
        with (OUT / name).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()} for row in rows)
    paths = [compressed, OFFICIAL / "manifest.json", ocit, M2 / "README.md", M2 / "report.json", M2 / "source-program-119.json", M2 / "control-A.add.xml", M2 / "link-bindings.json.gz", PREPARED / "control.add.xml", PREPARED / "network.net.xml", PREPARED / "scenario.json", REPO / "plugins/astra-sumo/src/astra_sumo/core/hamburg_readme_control.py", REPO / "plugins/astra-sumo/src/astra_sumo/core/ocit_c_programs.py", Path(__file__)]
    save(OUT / "source-hashes.json", {str(p.relative_to(REPO)): sha(p) for p in paths})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(status="review_required", absolute_anchor="unknown", current_family=sorted(FAMILY), source_config_offset=0, common_cycle_s=90, chosen_offset=None, native_runs=0, manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
