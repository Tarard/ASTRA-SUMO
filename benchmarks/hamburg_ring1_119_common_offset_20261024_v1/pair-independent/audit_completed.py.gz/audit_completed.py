"""Read the two terminal offset responses once; never run or poll SUMO."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import runpy
import sys
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority'
HELPER = REPO / 'outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py'
PROVENANCE = REPO / 'outputs/hamburg-lsa119-offset-provenance-20261024-v1'
CASES = {'plus15': 15, 'minus15': 75}
GROUP = {'LSA119_part0', '6390683126'}
FILES = ('network.net.xml', 'control.add.xml', 'demand.rou.xml', 'lane-intentions.json',
         'field-loops.add.xml', 'expected-counts.csv', 'initialization-counts.csv', 'scenario.json')
FIELDS535 = {'hh_0535_Z_5_30894', 'hh_0535_Z_6_33855', 'hh_0535_Z_7_29316', 'hh_0535_Z_8_34287'}
BOUNDARY = ('Only the common phase origin of the declared119/K9 family is varied. '
            'TU90 and source-relative offset0 are configuration facts; the dated absolute phase '
            'anchor and retained K9 mapping are unmeasured. Shared offsets preserve the current '
            'within-family intervals, not field coordination or universal traffic safety. '
            'No actual getProgram/getPhase history is added by this audit. Audit pass is not candidate acceptance.')


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def signed(rows):
    return sum(int(r['diff_nVehContrib_minus_expected']) for r in rows)


def scope(case):
    prepared = case / 'prepared'
    old, new = [ET.parse(p / 'control.add.xml').getroot() for p in (SOURCE / 'prepared', prepared)]
    assert len(old) == len(new) == 50
    changed = []
    for a, b in zip(old, new, strict=True):
        if a.get('id') in GROUP:
            assert a.get('type') == b.get('type') == 'static'
            assert a.get('programID') == b.get('programID') == 'readme_fixed_A'
            assert float(a.get('offset')) == 0 and int(b.get('offset')) == CASES[case.name]
            assert sum(float(p.get('duration')) for p in a.findall('phase')) == 90
            changed.append(a.get('id'))
            b.set('offset', a.get('offset'))
        assert ET.tostring(a) == ET.tostring(b)
    assert set(changed) == GROUP
    for name in FILES:
        if name not in {'control.add.xml', 'scenario.json'}:
            assert (SOURCE / 'prepared' / name).read_bytes() == (prepared / name).read_bytes()
    old_scenario, new_scenario = [load(p / 'scenario.json') for p in (SOURCE / 'prepared', prepared)]
    assert {k for k in old_scenario.keys() | new_scenario.keys() if old_scenario.get(k) != new_scenario.get(k)} == {'control_sha256', 'control_variant', 'control_assumptions'}
    assert new_scenario['control_assumptions'].startswith(old_scenario['control_assumptions'])
    assert new_scenario['control_sha256'] == sha(prepared / 'control.add.xml')
    checked = load(case / 'scope.json')
    hashes = {n: sha(prepared / n) for n in FILES}
    assert checked['status'] == 'pass' and checked['prepared_hashes'] == hashes
    return dict(status='pass', offset_s=CASES[case.name], common_controllers=sorted(changed),
                six_other_input_files_byte_identical=True, old_phase_states_parameters_and_relative_timing_preserved=True,
                prepared_hashes=hashes)


def terminal(case, helper, baseline, baseline_main):
    checked = scope(case)
    verdict = load(case / 'verdict.json')
    before_hashes = {str(p): sha(p) for p in [case / 'verdict.json', case / 'scope.json'] + [case / 'prepared' / n for n in FILES]}
    if verdict['status'] == 'invalid':
        return dict(case=case.name, audit_status='pass', raw_verdict='invalid', measured=None,
                    scope=checked, source_hashes=before_hashes, partial_native_not_interpreted=True), []
    preflight = load(case / 'preflight.json')
    for name, expected in preflight['implementation_sha256'].items():
        assert sha(SOURCE / 'implementation' / name) == expected
    assert preflight['prepared_hashes'] == checked['prepared_hashes']
    assert preflight['runner_sha256'] == sha(case / 'executed-measure.py')
    assert preflight['helper_sha256'] == sha(HELPER) and preflight['helper_scope_sha256'] == sha(HELPER.parent / 'audit_scope.py')
    assert preflight['provenance_sha256'] == sha(PROVENANCE / 'manifest.json') == '6fac62d0d9597b1ae91af70c0c1a854166cf787d87fb2bee6b86609e67fc2e3b'
    assert preflight['source_verdict_sha256'] == sha(SOURCE / 'verdict.json')
    assert set(preflight['versions'].values()) == {'1.27.1'}
    assert all(sha(Path(p)) == h for p, h in preflight['binaries'].items())
    evaluation = case / 'evaluation'
    assert load(evaluation / 'core-result.json')['errors'] == []
    data = helper['evidence'](case / 'prepared', evaluation, evaluation / 'contributing-passages.json.gz', 8640)
    fields = {r['vehicle_id']: r['field_id'] for r in load(case / 'prepared/lane-intentions.json')['vehicles']}
    repeat = sum(n - 1 for es in data['by_vehicle'].values() for n in Counter(e['detector_id'] for e in es).values() if n > 1)
    outside = sum(e['detector_id'] != fields.get(identity) for identity, es in data['by_vehicle'].items() for e in es)
    rows535 = [r for r in data['initial'] + data['main'] if r['detector_id'] in FIELDS535]
    assert len(rows535) == 56
    metrics535 = helper['metrics'](rows535)
    after = {k: data[k] for k in ('metrics130', 'metrics52', 'metrics182', 'station40_MAE', 'completion', 'safe', 'healthy', 'event_count')}
    gates = dict(safe=data['safe'], healthy=data['healthy'], no_repeated_fields=not repeat, no_extra_fields=not outside,
                 all53556_zero=metrics535['TAE'] == 0, MAE_improves=data['metrics130']['MAE'] < baseline['metrics130']['MAE'],
                 SSE_not_worse=data['metrics130']['SSE'] <= baseline['metrics130']['SSE'],
                 all182_TAE_not_worse=data['metrics182']['TAE'] <= baseline['metrics182']['TAE'])
    assert verdict['before'] == baseline and verdict['after'] == after and verdict['gates'] == gates
    assert verdict['status'] == ('improved_conditional_candidate' if all(gates.values()) else 'rejected')
    assert len({r['detector_id'] for r in data['main']}) == 13
    per_field = []
    for field in sorted({r['detector_id'] for r in data['main']}):
        old_rows = [r for r in baseline_main if r['detector_id'] == field]
        new_rows = [r for r in data['main'] if r['detector_id'] == field]
        assert len(old_rows) == len(new_rows) == 10
        per_field.append(dict(case=case.name, field_id=field, before_TAE=helper['metrics'](old_rows)['TAE'],
                              after_TAE=helper['metrics'](new_rows)['TAE'], before_signed=signed(old_rows), after_signed=signed(new_rows)))
    paths = [case / 'preflight.json', case / 'executed-measure.py', evaluation / 'native/vehicle-routes.xml']
    paths += [SOURCE / 'implementation' / n for n in preflight['implementation_sha256']]
    paths += [evaluation / n for n in ('initialization52-comparison.csv', 'all182-comparison.csv', 'native208-comparison.csv', '535-all56.csv')]
    assert before_hashes == {p: sha(Path(p)) for p in before_hashes}
    return dict(case=case.name, audit_status='pass', raw_verdict=verdict['status'], measured=after, gates=gates,
                all53556=metrics535, repeated_fields=repeat, outside_primary_fields=outside, scope=checked,
                runtime=preflight['parameters'], binaries_sha256=preflight['binaries'], implementation_sha256=preflight['implementation_sha256'],
                actual_native_version=load(evaluation / 'native/stall-monitor.json')['native_version'],
                source_hashes={**before_hashes, **data['source_hashes'], **{str(p): sha(p) for p in paths}}), per_field


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope-only', action='store_true', help='Read prepared inputs only and print; write no results.')
    args = parser.parse_args()
    if args.scope_only:
        print(json.dumps({n: scope(ROOT / n) for n in CASES}, ensure_ascii=False))
        return
    assert all((ROOT / n / 'verdict.json').is_file() for n in CASES), 'Both terminal verdicts are required; no active native output was read.'
    assert not (OUT / 'summary.json').exists(), 'Preserve the sealed independent result.'
    sys.path.insert(0, str(HELPER.parent))
    helper = runpy.run_path(str(HELPER))
    baseline_csv = SOURCE.parent / 'full-priority-independent/main130-before-after.csv'
    baseline_manifest = SOURCE.parent / 'full-priority-independent/manifest.json'
    assert sha(baseline_manifest) == '96cda279d299bba132c6eddadd10a4d9f83c8bf9a55cb2f5d1167d584ba62986'
    row = next(r for r in load(baseline_manifest)['files'] if r['path'] == baseline_csv.name)
    assert sha(baseline_csv) == row['sha256']
    baseline_main = [dict(detector_id=r['field'], begin=r['begin_s'], end=r['end_s'],
                         expected_total=r['real_target'], measured_nVehContrib=r['after_count'],
                         diff_nVehContrib_minus_expected=r['after_residual']) for r in helper['read_csv_rows'](baseline_csv)]
    baseline = load(SOURCE / 'verdict.json')['candidate']
    assert helper['metrics'](baseline_main) == baseline['metrics130']
    reports, fields = {}, []
    for name in CASES:
        reports[name], rows = terminal(ROOT / name, helper, baseline, baseline_main)
        fields.extend(rows)
    helper['table'](OUT / 'field13-main.csv', fields)
    helper['save'](OUT / 'summary.json', dict(schema='astra.hamburg.119-common-offset-independent/v1', audit_status='pass',
        native_runs_by_audit=0, baseline=baseline, cases=reports, claim_boundary=BOUNDARY,
        common_source_hashes={str(p): sha(p) for p in (Path(__file__), HELPER, HELPER.parent / 'audit_scope.py',
                                                     PROVENANCE / 'manifest.json', baseline_manifest, baseline_csv, SOURCE / 'verdict.json')}))
    helper['save'](OUT / 'manifest.json', dict(native_runs=0, files=[dict(path=p.relative_to(OUT).as_posix(), bytes=p.stat().st_size, sha256=sha(p))
        for p in sorted(OUT.rglob('*')) if p.is_file() and p != OUT / 'manifest.json' and '__pycache__' not in p.parts]))
    print(json.dumps({n: dict(raw_verdict=r['raw_verdict'], measured=r['measured']) for n, r in reports.items()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
