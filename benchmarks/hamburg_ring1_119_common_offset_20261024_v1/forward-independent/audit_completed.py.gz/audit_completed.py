"""Reuse the sealed offset-pair reader for the single terminal+30s response."""
import argparse
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
READER = REPO / 'outputs/hamburg-119-common-offset-20261024-v1/independent/audit_completed.py'
READER_SHA = '3bc11816306a3b275c1151f96b61fddda550a09124e6967e2c746d0a3e284c47'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true', help='Check only prepared inputs; read no native output.')
    args = parser.parse_args()
    assert hashlib.sha256(READER.read_bytes()).hexdigest() == READER_SHA
    spec = spec_from_file_location('sealed_common_offset_reader', READER)
    reader = module_from_spec(spec)
    spec.loader.exec_module(reader)
    reader.OUT, reader.ROOT, reader.CASES = OUT, ROOT, {'plus30': 30}
    if args.check_only:
        print(json.dumps(reader.scope(ROOT / 'plus30'), ensure_ascii=False))
        return
    assert (ROOT / 'plus30/verdict.json').is_file(), 'Require the terminal verdict before reading native output.'
    assert not (OUT / 'summary.json').exists(), 'Preserve a sealed independent result.'
    (OUT / 'reader-reuse.json').write_text(json.dumps(dict(reader_path=str(READER), reader_sha256=READER_SHA,
        wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), overrides=dict(output=str(OUT),
        input_family=str(ROOT), cases={'plus30': 30}), native_runs=0), indent=2) + '\n', encoding='utf-8')
    sys.argv = [sys.argv[0]]
    reader.main()


if __name__ == '__main__':
    main()
