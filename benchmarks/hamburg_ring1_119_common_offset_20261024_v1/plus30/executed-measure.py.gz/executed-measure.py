"""One additional +30s common-clock sensitivity after the completed +/-15s pair."""
import argparse
from collections import Counter
import gzip
import importlib
from importlib.metadata import version
import json
from pathlib import Path
import re
import runpy
import shutil
import sys
import time
import traceback
import xml.etree.ElementTree as ET

from astra_sumo.core.candidate_contracts import file_sha256 as sha
from astra_sumo.core.detector_demand_replay import run_point_detector_demand
from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / 'outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority'
PROVENANCE = REPO / 'outputs/hamburg-lsa119-offset-provenance-20261024-v1/manifest.json'
HELPER = REPO / 'outputs/hamburg-multifield-substitution-20261023-v1/response-audit/audit_response.py'
FILES = ('network.net.xml', 'control.add.xml', 'demand.rou.xml', 'lane-intentions.json',
         'field-loops.add.xml', 'expected-counts.csv', 'initialization-counts.csv', 'scenario.json')
FAMILY = ('LSA119_part0', '6390683126')
OFFSETS = {'plus30': 30}
BOUNDARY = ('Only the common phase origin of the two declared119 controllers changes. '
            'Official absolute clock alignment is unmeasured; these are sensitivity candidates, '
            'not field SPaT or an established correction. All real130/52 rows remain unchanged.')


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def change_offset(raw, offset):
    for identity in FAMILY:
        pattern = rb'(<tlLogic\b[^>]*\bid="' + identity.encode() + rb'"[^>]*\boffset=")0(")'
        raw, count = re.subn(pattern, lambda m: m[1] + str(offset).encode() + m[2], raw)
        assert count == 1
    return raw


def scenario(offset):
    data = json.loads((SOURCE / 'prepared/scenario.json').read_bytes())
    import hashlib
    data.update(control_sha256=hashlib.sha256(change_offset((SOURCE / 'prepared/control.add.xml').read_bytes(), offset)).hexdigest(),
                control_variant=f'conditional_119_common_offset_{offset}',
                control_assumptions=data['control_assumptions'] + ' ' + BOUNDARY)
    return data


def check(case):
    prepared = case / 'prepared'
    offset = OFFSETS[case.name]
    for name in FILES:
        old, new = (SOURCE / 'prepared' / name).read_bytes(), (prepared / name).read_bytes()
        if name == 'scenario.json':
            assert json.loads(new) == scenario(offset)
        else:
            assert new == (change_offset(old, offset) if name == 'control.add.xml' else old), name
    old, new = [ET.parse(p / 'control.add.xml').getroot() for p in (SOURCE / 'prepared', prepared)]
    assert len(old) == len(new) == 50
    changed = []
    for a, b in zip(old, new, strict=True):
        if a.get('id') in FAMILY:
            assert a.get('type') == b.get('type') == 'static'
            assert a.get('offset') == '0' and int(b.get('offset')) == offset
            assert sum(float(p.get('duration')) for p in a.findall('phase')) == 90
            changed.append(a.get('id'))
            b.set('offset', '0')
        assert ET.tostring(a) == ET.tostring(b)
    assert set(changed) == set(FAMILY)
    assert tuple(_body_hold_nodes(prepared)) == ('14398547', '205069138', '18653534', 'LSA104_part0')
    assert len(ET.parse(prepared / 'demand.rou.xml').getroot().findall('vehicle')) == 8640
    return {'status': 'pass', 'changed_controller_ids': changed, 'offset_s': offset,
            'prepared_hashes': {n: sha(prepared / n) for n in FILES}, 'claim_boundary': BOUNDARY,
            'scenario_metadata_changes': ['control_sha256', 'control_variant', 'control_assumptions']}


def prepare(case):
    assert not case.exists(), 'Preserve an existing candidate or failure.'
    (case / 'prepared').mkdir(parents=True)
    for name in FILES:
        shutil.copyfile(SOURCE / 'prepared' / name, case / 'prepared' / name)
    control = case / 'prepared/control.add.xml'
    control.write_bytes(change_offset(control.read_bytes(), OFFSETS[case.name]))
    save(case / 'prepared/scenario.json', scenario(OFFSETS[case.name]))
    save(case / 'scope.json', check(case))


def run(case):
    checked = check(case)
    evaluation = case / 'evaluation'
    assert not evaluation.exists(), 'Preserve the original run.'
    evaluation.mkdir()
    prepared = case / 'prepared'
    started = time.perf_counter()
    attempted = False
    try:
        assert Path(sys.executable).resolve() == (REPO / '.venv/Scripts/python.exe').resolve()
        versions = {n: version(n) for n in ('eclipse-sumo', 'libsumo', 'traci', 'sumolib')}
        assert set(versions.values()) == {'1.27.1'}
        modules = {n: Path(importlib.import_module(n).__file__).resolve() for n in ('libsumo', 'traci', 'sumolib')}
        assert all(p.is_relative_to((REPO / '.venv').resolve()) for p in modules.values()), 'Use project SUMO modules, not system SUMO_HOME/PYTHONPATH.'
        assert importlib.import_module('traci').__version__ == '1.27.1'
        assert sha(PROVENANCE) == '6fac62d0d9597b1ae91af70c0c1a854166cf787d87fb2bee6b86609e67fc2e3b'
        for name in ('demand.rou.xml', 'lane-intentions.json'):
            shutil.copyfile(prepared / name, evaluation / name)
        shutil.copyfile(__file__, case / 'executed-measure.py')
        binaries = [REPO / '.venv/Scripts/python.exe', REPO / '.venv/Lib/site-packages/sumo/bin/sumo.exe']
        binaries += list((REPO / '.venv/Lib/site-packages/libsumo').glob('*.pyd'))
        assert len(binaries) >= 3
        implementation = {p.name: sha(REPO / 'plugins/astra-sumo/src/astra_sumo/core' / p.name)
                          for p in (SOURCE / 'implementation').glob('*.py')}
        assert all(sha(SOURCE / 'implementation' / n) == h for n, h in implementation.items())
        save(case / 'preflight.json', dict(checked, versions=versions, python=sys.executable,
            module_paths={n: str(p) for n, p in modules.items()},
            binaries={str(p): sha(p) for p in binaries}, implementation_sha256=implementation,
            runner_sha256=sha(case / 'executed-measure.py'), provenance_sha256=sha(PROVENANCE),
            source_verdict_sha256=sha(SOURCE / 'verdict.json'), helper_sha256=sha(HELPER),
            helper_scope_sha256=sha(HELPER.parent / 'audit_scope.py'),
            parameters=dict(end_s=14400, step_length=.1, seed=104, backend='libsumo',
                            body_hold_nodes=list(_body_hold_nodes(prepared)))))
        attempted = True
        native = run_point_detector_demand(net_file=prepared / 'network.net.xml', route_file=prepared / 'demand.rou.xml',
            e1_additional_file=prepared / 'field-loops.add.xml', expected_counts_csv=prepared / 'expected-counts.csv',
            output_dir=evaluation / 'native', end_s=14400, timeout_seconds=4800, step_length=.1, seed=104,
            backend='libsumo', sumo_binary=str(binaries[1]), signal_program_file=prepared / 'control.add.xml',
            lane_intentions_file=prepared / 'lane-intentions.json', junction_body_hold=True,
            junction_body_hold_nodes=_body_hold_nodes(prepared))
        save(evaluation / 'core-result.json', native)
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        events = read_contributing_e1_passages(instant_file=evaluation / 'native/instant-e1.xml',
            periodic_file=evaluation / 'native/field-counts.xml', detector_ids=native['instant_to_periodic_ids'], step_length=.1)
        assert events['reconciled']
        compact = evaluation / 'contributing-passages.json.gz'
        compact.write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        sys.path.insert(0, str(HELPER.parent))
        audit = runpy.run_path(str(HELPER))
        measured = audit['evidence'](prepared, evaluation, compact, 8640)
        for name, rows in [('initialization52', measured['initial']), ('all182', measured['initial'] + measured['main']),
                           ('native208', list(measured['periodic'].values()))]:
            audit['table'](evaluation / (name + '-comparison.csv'), rows)
        fields = {r['vehicle_id']: r['field_id'] for r in json.loads((prepared / 'lane-intentions.json').read_bytes())['vehicles']}
        repeated = [dict(vehicle_id=i, field=f, count=n) for i, es in measured['by_vehicle'].items()
                    for f, n in Counter(e['detector_id'] for e in es).items() if n > 1]
        outside = [dict(vehicle_id=i, actual_field=e['detector_id'], expected_field=fields.get(i))
                   for i, es in measured['by_vehicle'].items() for e in es if e['detector_id'] != fields.get(i)]
        rows535 = [r for r in measured['initial'] + measured['main'] if r['detector_id'] in
                   {'hh_0535_Z_5_30894', 'hh_0535_Z_6_33855', 'hh_0535_Z_7_29316', 'hh_0535_Z_8_34287'}]
        assert len(rows535) == 56
        audit['table'](evaluation / '535-all56.csv', rows535)
        after = {k: measured[k] for k in ('metrics130', 'metrics52', 'metrics182', 'station40_MAE', 'completion', 'safe', 'healthy', 'event_count')}
        before = json.loads((SOURCE / 'verdict.json').read_bytes())['candidate']
        gates = dict(safe=after['safe'], healthy=after['healthy'], no_repeated_fields=not repeated,
                     no_extra_fields=not outside, all53556_zero=audit['metrics'](rows535)['TAE'] == 0,
                     MAE_improves=after['metrics130']['MAE'] < before['metrics130']['MAE'],
                     SSE_not_worse=after['metrics130']['SSE'] <= before['metrics130']['SSE'],
                     all182_TAE_not_worse=after['metrics182']['TAE'] <= before['metrics182']['TAE'])
        assert check(case) == checked
        verdict = dict(status='improved_conditional_candidate' if all(gates.values()) else 'rejected',
            formal_result=False, before=before, after=after, gates=gates, offset_s=OFFSETS[case.name],
            repeated_vehicle_fields=repeated, outside_primary_intention=outside,
            exact130=after['metrics130']['TAE'] == 0, claim_boundary=BOUNDARY)
    except Exception as error:
        verdict = dict(status='invalid', formal_result=False, error=f'{type(error).__name__}: {error}',
                       native_call_attempted=attempted, partial_outputs_preserved=True)
        (case / 'failure.log').write_text(traceback.format_exc(), encoding='utf-8')
    verdict['elapsed_s'] = time.perf_counter() - started
    save(case / 'verdict.json', verdict)
    print(json.dumps(verdict, ensure_ascii=False), flush=True)
    if verdict['status'] == 'invalid':
        raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', choices=tuple(OFFSETS), required=True)
    parser.add_argument('--mode', choices=('prepare', 'check', 'run'), required=True)
    args = parser.parse_args()
    case = ROOT / args.case
    if args.mode == 'prepare':
        prepare(case)
    elif args.mode == 'check':
        print(json.dumps(check(case), ensure_ascii=False))
    else:
        run(case)
