"""Describe only the completed0,+15,-15 responses; never read forward results."""

from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from astra_sumo.core.detector_demand import audit_expected_to_e1_strict, read_csv_rows

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT.parents[1]
BASE = REPO / "outputs/hamburg-119-receiving-diagnosis-20261023-v1/full-priority"


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def table(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def metrics(rows):
    errors = [int(r["diff_nVehContrib_minus_expected"]) for r in rows]
    return dict(rows=len(rows), TAE=sum(abs(v) for v in errors), SSE=sum(v*v for v in errors), MAE=sum(abs(v) for v in errors)/len(rows), max_abs_error=max(abs(v) for v in errors), signed=sum(errors), actual=sum(int(r["measured_nVehContrib"]) for r in rows))


def key(row):
    return row["detector_id"], float(row["begin"]), float(row["end"])


def main():
    data, paths = {}, []
    for name, folder in [("zero", BASE), ("plus15", ROOT / "plus15"), ("minus15", ROOT / "minus15")]:
        native = folder / "evaluation/native/field-counts.xml"
        main_rows = audit_expected_to_e1_strict(read_csv_rows(BASE / "prepared/expected-counts.csv"), native)
        initial = audit_expected_to_e1_strict(read_csv_rows(BASE / "prepared/initialization-counts.csv"), native)
        periodic = {(r.get("id"), float(r.get("begin")), float(r.get("end"))): int(r.get("nVehContrib")) for r in ET.parse(native).getroot().findall("interval")}
        assert len(main_rows) == 130 and len(initial) == 52 and len(periodic) == 208
        recorded = load(folder / "verdict.json")
        measured = recorded["candidate" if name == "zero" else "after"]
        for rows, label in [(main_rows, "metrics130"), (initial, "metrics52"), (initial+main_rows, "metrics182")]:
            actual = metrics(rows)
            assert all(actual[k] == v for k, v in measured[label].items())
        main_keys, initial_keys = set(map(key, main_rows)), set(map(key, initial))
        regions = dict(initial=sum(periodic[k] for k in initial_keys), main=sum(periodic[k] for k in main_keys), tail=sum(v for k, v in periodic.items() if k not in initial_keys | main_keys))
        totals = defaultdict(int)
        for (field, _, _), value in periodic.items():
            totals[field] += value
        data[name] = dict(main=main_rows, initial=initial, periodic=periodic, regions=regions, field_totals=dict(totals), measured=measured, raw_status=recorded["status"], gates=recorded.get("gates"))
        paths += [native, folder / "verdict.json"]
    assert data["zero"]["field_totals"] == data["plus15"]["field_totals"]
    assert sum(data["zero"]["regions"].values()) == sum(data["plus15"]["regions"].values()) == 8640
    field_outputs, period_outputs, row_changes = {}, {}, []
    for region in ["main", "initial"]:
        field_rows, period_rows = [], []
        for name in ["plus15", "minus15"]:
            before, after = data["zero"][region], data[name][region]
            assert list(map(key, before)) == list(map(key, after))
            for field in sorted({r["detector_id"] for r in before}):
                a, b = [metrics([r for r in rows if r["detector_id"] == field]) for rows in [before, after]]
                field_rows.append(dict(case=name, field_id=field, before_TAE=a["TAE"], after_TAE=b["TAE"], delta_TAE=b["TAE"]-a["TAE"], before_SSE=a["SSE"], after_SSE=b["SSE"], delta_SSE=b["SSE"]-a["SSE"], before_signed=a["signed"], after_signed=b["signed"]))
            for begin in sorted({float(r["begin"]) for r in before}):
                a, b = [metrics([r for r in rows if float(r["begin"]) == begin]) for rows in [before, after]]
                period_rows.append(dict(case=name, begin_s=begin, end_s=begin+900, before_TAE=a["TAE"], after_TAE=b["TAE"], delta_TAE=b["TAE"]-a["TAE"], before_SSE=a["SSE"], after_SSE=b["SSE"], delta_SSE=b["SSE"]-a["SSE"]))
            for a, b in zip(before, after):
                x, y = [int(r["diff_nVehContrib_minus_expected"]) for r in [a, b]]
                row_changes.append(dict(case=name, region=region, field_id=a["detector_id"], begin_s=float(a["begin"]), end_s=float(a["end"]), before_count=a["measured_nVehContrib"], after_count=b["measured_nVehContrib"], before_residual=x, after_residual=y, delta_absolute_error=abs(y)-abs(x), delta_SSE=y*y-x*x))
        field_outputs[region], period_outputs[region] = field_rows, period_rows
        table(OUT / f"field13-{region}.csv", field_rows)
        table(OUT / f"period-{region}.csv", period_rows)
    table(OUT / "row-response182.csv", row_changes)
    table(OUT / "region-counts.csv", [dict(case=name, **value["regions"], complete_events=sum(value["regions"].values())) for name, value in data.items()])
    main_changes = [r["delta_absolute_error"] for r in row_changes if r["case"] == "plus15" and r["region"] == "main"]
    plus = data["plus15"]
    assert plus["raw_status"] == "rejected" and plus["gates"]["all182_TAE_not_worse"] is False and sum(not v for v in plus["gates"].values()) == 1
    report = dict(schema="astra.hamburg.119-offset-three-point-response/v1", status="analysis_complete", native_runs=0, evidence_points_s=[-15, 0, 15], forward30_results_read=False,
        measured={name: dict(metrics130=value["measured"]["metrics130"], metrics52=value["measured"]["metrics52"], metrics182=value["measured"]["metrics182"], healthy=value["measured"]["healthy"], completion=value["measured"]["completion"], raw_status=value["raw_status"], native_counts_by_region=value["regions"]) for name, value in data.items()},
        plus15_main_row_response=dict(improved=sum(v < 0 for v in main_changes), worsened=sum(v > 0 for v in main_changes), unchanged=sum(v == 0 for v in main_changes), gross_TAE_reduction=-sum(v for v in main_changes if v < 0), gross_TAE_increase=sum(v for v in main_changes if v > 0), net_TAE_change=sum(main_changes)),
        plus15_field_main=[r for r in field_outputs["main"] if r["case"] == "plus15"], plus15_field_initial=[r for r in field_outputs["initial"] if r["case"] == "plus15"], plus15_initial_periods=[r for r in period_outputs["initial"] if r["case"] == "plus15"],
        plus15_count_balance={region: data["plus15"]["regions"][region]-data["zero"]["regions"][region] for region in ["initial", "main", "tail"]},
        plus15_interpretation="A conditional Pareto point: lower measured main130 MAE/SSE/max with full health, but worse initialization and all182TAE. Raw rejected remains unchanged; this is not acceptance under the original8 gates.",
        one_forward_probe_basis="The positive15s point improves both main objectives and stays healthy while negative15s worsens main fit and leaves89unfinished. Four field-level main gains outweigh three losses, providing an empirical reason for one separately authorized +30s measurement from the same zero source.25 rows improve and30 worsen, initialization loses63TAE, and interactions are asymmetric; no smoothness, optimum, significance, or numerical +30 forecast follows from these three single-seed points.",
        unchanged_gate_policy=True, source_manifest_sha256=sha(ROOT / "independent/manifest.json"),
        claim_boundary="Only the completed -15/0/+15 runs are analyzed. Counts by region conserve the healthy plus15 population; they do not identify individual vehicle transfers. An absolute-error increase is not a vehicle count. Initialization remains real evidence and must be reported even when the user's strict target is main130.")
    save(OUT / "summary.json", report)
    paths += [BASE / "prepared/expected-counts.csv", BASE / "prepared/initialization-counts.csv", ROOT / "independent/manifest.json", ROOT / "independent/field13-main.csv", Path(__file__)]
    save(OUT / "source-hashes.json", {str(p.relative_to(REPO)): sha(p) for p in paths})
    save(OUT / "manifest.json", dict(schema="astra.evidence-manifest/v1", files=[dict(path=p.name, sha256=sha(p), size_bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "manifest.json"]))
    print(json.dumps(dict(plus15_main=report["plus15_main_row_response"], count_balance=report["plus15_count_balance"], manifest_sha256=sha(OUT / "manifest.json"))))


if __name__ == "__main__":
    main()
