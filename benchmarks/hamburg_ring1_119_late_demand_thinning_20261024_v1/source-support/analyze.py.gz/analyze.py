"""Inspect existing h13 Z12/Z13 requests; write support tables, never change demand."""
from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[1]
CASE=REPO/"outputs/hamburg-535z4-tail-offset-20261024-v1/cases/minus30"
FIELDS={"hh_0119_Z_12_31546":"43866090#0_0","hh_0119_Z_13_34018":"43866090#0_1"}
QUOTAS={"hh_0119_Z_12_31546":{287:5,288:4,289:4},"hh_0119_Z_13_34018":{287:5,288:5,289:5}}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump_csv(name,rows):
    with (OUT/name).open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    assert not (OUT/"manifest.json").exists(),"Preserve sealed support."
    prepared,evaluation=CASE/"prepared",CASE/"evaluation"
    vehicles={v.get("id"):v for v in ET.parse(prepared/"demand.rou.xml").getroot().findall("vehicle")}
    intent={r["vehicle_id"]:r for r in json.loads((prepared/"lane-intentions.json").read_bytes())["vehicles"]}
    raw=json.loads(gzip.decompress((evaluation/"contributing-passages.json.gz").read_bytes()))
    events={r["vehicle_id"]:r for r in raw["passages"]}
    assert raw["reconciled"] and len(events)==len(vehicles)==8640
    loops={r.get("id"):r.get("lane") for r in ET.parse(prepared/"field-loops.add.xml").getroot()}
    truth={(r["detector_id"],int(float(r["begin"]))):int(r["expected_total"]) for r in csv.DictReader((evaluation/"all182-comparison.csv").open(encoding="utf-8"))}
    groups=defaultdict(list)
    pools,carry,templates=[],[],{}
    by_field={}
    for field,lane in FIELDS.items():
        assert loops[field]==lane
        all_ids=[i for i in vehicles if intent[i]["field_id"]==field]
        last=[i for i in all_ids if events[i]["interval_begin_s"]==11700]
        h13=[]
        for identity in all_ids:
            v=vehicles[identity]
            native_depart=math.floor(float(v.get("depart"))*1000+.5)/1000
            period=math.floor(native_depart/900)*900
            if period!=11700 and identity not in last:
                continue
            edges=v.find("route").get("edges").split()
            stops=[dict(s.attrib) for s in v.findall("stop")]
            assert len(stops)==1 and stops[0]["lane"]==lane and events[identity]["detector_id"]==field
            row=dict(vehicle_id=identity,field_id=field,od_cell=intent[identity]["od_cell"],origin=edges[0],destination=edges[-1],
                requested_depart_s=float(v.get("depart")),native_requested_begin_s=period,
                native_notification_s=events[identity]["notification_time_s"],actual_event_begin_s=int(events[identity]["interval_begin_s"]),
                planned_stop_lane=lane,native_detector_lane=loops[field],type_id=v.get("type"),
                eligible_major_origin=edges[0]=="44532531",route_template_id=str(intent[identity]["od_cell"]))
            if period==11700:
                h13.append(identity)
                pools.append(row)
                groups[field,intent[identity]["od_cell"]].append(row)
                template=dict(origin=edges[0],destination=edges[-1],full_edges=edges,
                    common_vehicle_attributes={k:value for k,value in v.attrib.items() if k not in ["id","depart"]})
                key=str(intent[identity]["od_cell"])
                if key in templates:
                    assert templates[key]==template
                templates[key]=template
            else:
                carry.append(row)
        by_field[field]=dict(real_last_target=truth[field,11700],native_last_contributions=len(last),planned_h13=len(h13),
            h13_contribution_bins=dict(Counter(int(events[i]["interval_begin_s"]) for i in h13)),
            last_contribution_request_bins=dict(Counter(math.floor((math.floor(float(vehicles[i].get("depart"))*1000+.5)/1000)/900)*900 for i in last)),
            h13_by_OD=dict(Counter(intent[i]["od_cell"] for i in h13)))
    samples=[]
    for (field,cell),rows in sorted(groups.items()):
        rows.sort(key=lambda r:(r["requested_depart_s"],r["vehicle_id"]))
        quota=QUOTAS.get(field,{}).get(cell,0)
        if not quota:
            continue
        ranks=[math.floor((j+.5)*len(rows)/quota) for j in range(quota)]
        assert len(set(ranks))==quota
        for rank in ranks:
            samples.append(dict(rows[rank],source_field_OD_pool=len(rows),uniform_midpoint_rank=rank,illustrative_quota=quota))
    assert len(pools)==217 and len(carry)==30 and len(samples)==28
    assert Counter(r["field_id"] for r in samples)==Counter({"hh_0119_Z_12_31546":13,"hh_0119_Z_13_34018":15})
    assert all(r["actual_event_begin_s"]==11700 for r in samples)
    q=Counter(r["od_cell"] for r in intent.values())
    sample_q=Counter(r["od_cell"] for r in samples)
    dump_csv("h13-planned-pool217.csv",sorted(pools,key=lambda r:(r["field_id"],r["od_cell"],r["requested_depart_s"])))
    dump_csv("actual-last-window-carry30.csv",sorted(carry,key=lambda r:(r["field_id"],r["native_notification_s"])))
    dump_csv("illustrative-unmaterialized-28-IDs.csv",samples)
    (OUT/"route-templates.json").write_text(json.dumps(templates,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    report=dict(schema="astra.hamburg.119-h13-count-freedom/v1",status="review_required",native_runs=0,inputs_changed=0,
        source="healthy minus30 mainTAE365",fields=by_field,
        key_finding="Z12 planned h13 equals99 true observations but97 pass in thatwindow and15 earlier requests carry in. Z13 planned118 all pass plus15 carry in. The observed surplus does not uniquely identify excessive h13 demand.",
        route_lane_relation="Within each OD, vehicle type/ordinary edges/non-ID non-time attributes are identical. Z12 andZ13 use the same OD routes but different existing moving-stop lanes438#0_0/1. These are declared lane intentions; actual contributions are tied to their native E1 lane, not an inferred natural lane-choice observation.",
        illustrative_thinning=dict(materialized=False,requests_removed=0,N_if_later_materialized=8612,
            quotas={field:{str(cell):count for cell,count in values.items()} for field,values in QUOTAS.items()},
            method="Within each(field,OD), sort original requests by(depart,id); use zero-based floor((j+.5)*pool/quota) midpoint ranks. Tiny counter-origin groups281–283 remain. Selection uses planned request ranks; observed contributions are reported after selection, not used to redefine eligibility.",
            q_if_materialized=[dict(cell=cell,source=q[cell],candidate=q[cell]-sample_q[cell],delta=-sample_q[cell]) for cell in sorted(sample_q)],
            earliest_illustrative_request_s=min(r["requested_depart_s"] for r in samples),
            unverified_same_event_subtraction=dict(last_Z12=99,last_Z13=118,main_TAE=337,main_SSE=3723),
            actual_changed_response_verified=False),
        boundaries=["No requests were deleted/added, no candidate demand was materialized, and no simulation was started.",
            "A later deletion would only thin hypothetical input instances before simulation; no runtime vehicle removal is involved.",
            "N8640 is the source population, not an immutable user requirement. All real130+52 observations remain unchanged.",
            "Field-stratified surviving instances are a declared OD realization; changing the same294 q with quantile regeneration is a different experiment.",
            "The arithmetic subtraction of current selected contributions is not a native prediction. Remaining vehicles, queues and actuated realization can respond.",
            "All illustrative requests are after11700; an eventual run should report/recheck169 source E1 intervals ending<=11700, then all130/52/182/40/208 and remaining-ID completion/safety/unique fields."])
    (OUT/"summary.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    paths=[prepared/"demand.rou.xml",prepared/"lane-intentions.json",prepared/"field-loops.add.xml",prepared/"network.net.xml",prepared/"control.add.xml",
           evaluation/"contributing-passages.json.gz",evaluation/"all182-comparison.csv",CASE/"verdict.json"]
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in paths],indent=2)+"\n",encoding="utf-8")
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=files),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="review_required",pool217=True,carry30=True,illustrative28_not_materialized=True,manifest_sha256=sha(OUT/"manifest.json"))))


if __name__=="__main__":
    main()
