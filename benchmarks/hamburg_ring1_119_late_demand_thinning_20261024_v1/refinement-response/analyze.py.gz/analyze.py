"""Read-only remove43 response relative to measured remove30."""
from collections import Counter
import csv
from importlib.util import module_from_spec,spec_from_file_location
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
REPO=ROOT.parents[1]


def main():
    assert not (OUT/"manifest.json").exists()
    helper=ROOT/"response-decomposition/analyze.py"
    spec=spec_from_file_location("existing_thinning_response_reader",helper)
    module=module_from_spec(spec)
    spec.loader.exec_module(module)
    module.OUT=OUT
    source,old_counts=module.read_events(ROOT/"cases/remove30/evaluation",8610)
    after,new_counts=module.read_events(ROOT/"cases/remove43/evaluation",8597)
    case=ROOT/"cases/remove43"
    proposal=json.loads((case/"proposal.json").read_bytes())
    extra={r["vehicle_id"] for r in proposal["additional13"]}
    assert set(after)==set(source)-extra and len(extra)==13
    removed=Counter((source[i]["detector_id"],int(source[i]["interval_begin_s"])) for i in extra)
    assert all(new_counts[key]==value-removed[key] for key,value in old_counts.items())
    changed=[dict(vehicle_id=i,field_id=after[i]["detector_id"],source_notification_s=source[i]["notification_time_s"],
                  actual_notification_s=after[i]["notification_time_s"],source_begin=int(source[i]["interval_begin_s"]),actual_begin=int(after[i]["interval_begin_s"]))
             for i in after if abs(after[i]["notification_time_s"]-source[i]["notification_time_s"])>1e-7]
    assert not any(r["source_begin"]!=r["actual_begin"] for r in changed)
    true_rows=list(csv.DictReader((case/"evaluation/all182-comparison.csv").open(encoding="utf-8")))
    final=[dict(field_id=r["detector_id"],begin=11700,end=12600,expected=int(r["expected_total"]),actual=new_counts[r["detector_id"],11700],
                residual=new_counts[r["detector_id"],11700]-int(r["expected_total"])) for r in true_rows if float(r["begin"])==11700]
    vehicles={v.get("id"):v for v in ET.parse(case/"prepared/demand.rou.xml").getroot().findall("vehicle")}
    intents={r["vehicle_id"]:r for r in json.loads((case/"prepared/lane-intentions.json").read_bytes())["vehicles"]}
    tail=[]
    for identity,event in after.items():
        if event["interval_begin_s"]<12600:
            continue
        vehicle=vehicles[identity]
        edges=vehicle.find("route").get("edges").split()
        tail.append(dict(vehicle_id=identity,field_id=event["detector_id"],od_cell=intents[identity]["od_cell"],origin=edges[0],destination=edges[-1],
            source_depart_s=float(vehicle.get("depart")),request_cohort_begin=__import__("math").floor(float(vehicle.get("depart"))/900)*900,
            actual_notification_s=event["notification_time_s"],actual_event_begin=int(event["interval_begin_s"])))
    tail.sort(key=lambda r:(r["field_id"],r["actual_notification_s"]))
    historical=[dict(vehicle_id=i,field_id=source[i]["detector_id"],remove30_notification_s=source[i]["notification_time_s"],begin=int(source[i]["interval_begin_s"])) for i in sorted(extra)]
    module.write_csv("additional13-historical-contributions.csv",historical)
    module.write_csv("survivor-time-response.csv",sorted(changed,key=lambda r:(r["field_id"],r["source_notification_s"])))
    module.write_csv("final13-vector.csv",final)
    module.write_csv("tail24-by-ID.csv",tail)
    groups=Counter((r["field_id"],r["od_cell"],r["origin"],r["destination"],r["request_cohort_begin"]) for r in tail)
    summary=dict(schema="astra.hamburg.119-remove43-response/v1",status="pass",new_native_runs=0,source_N=8610,candidate_N=8597,
        historical13_removed=dict(Counter(r["field_id"] for r in historical)),survivor_time_changes=len(changed),survivor_bin_changes=0,
        main_TAE=[337,324],main_SSE=[3723,3598],final13_TAE=sum(abs(r["residual"]) for r in final),
        final13=final,tail_groups=[dict(field=k[0],od_cell=k[1],origin=k[2],destination=k[3],request_cohort_begin=k[4],vehicles=v) for k,v in sorted(groups.items())],
        final_future_stock=[dict(field=r["field_id"],last_main=r["actual"],tail=sum(t["field_id"]==r["field_id"] for t in tail),
                               last_main_plus_tail=r["actual"]+sum(t["field_id"]==r["field_id"] for t in tail),target=r["expected"]) for r in final],
        interpretation="Additional13 input deletions explain every per-bin count change from remove30. Surviving vehicles change times but do not cross bins. Z4 retains63main+9tail=72 versus70,whileZ5 retains51+15=66 versus66. Bringing every tail vehicle before12600 would not zero the full last vector.",
        boundaries="No native run/input change. Deleted requests are not SUMO noninsertions/discards. Future stock is this declared input population,not trueOD or a hard capacity claim.")
    (OUT/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    paths=[helper,ROOT/"cases/remove30/evaluation/contributing-passages.json.gz",ROOT/"cases/remove30/evaluation/native/field-counts.xml",case/"proposal.json",case/"prepared/demand.rou.xml",case/"prepared/lane-intentions.json",case/"evaluation/contributing-passages.json.gz",case/"evaluation/native/field-counts.xml",case/"evaluation/all182-comparison.csv",case/"verdict.json"]
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),sha256=module.sha(p)) for p in paths],indent=2)+"\n",encoding="utf-8")
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=module.sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=files),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="pass",manifest_sha256=module.sha(OUT/"manifest.json"),survivor_time_changes=len(changed),tail_groups=summary["tail_groups"])))


if __name__=="__main__":
    main()
