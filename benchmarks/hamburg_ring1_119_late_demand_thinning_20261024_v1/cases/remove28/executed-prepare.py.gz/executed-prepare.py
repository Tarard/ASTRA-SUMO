"""Prepare nested hypothetical-request thinnings; never remove native vehicles."""
import argparse
from collections import Counter
import copy
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
SOURCE=REPO/"outputs/hamburg-535z4-tail-offset-20261024-v1/cases/minus30"
SUPPORT=REPO/"outputs/hamburg-119-h13-count-support-20261024-v1"
NAMES=["network.net.xml","control.add.xml","demand.rou.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv","lane-intentions.json","scenario.json"]
Z12="hh_0119_Z_12_31546"
Z13="hh_0119_Z_13_34018"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


def native_begin(vehicle):
    return (math.floor(float(vehicle.get("depart"))*1000+.5)//900000)*900


def prepare(case_name):
    case=ROOT/"cases"/case_name
    assert not case.exists(),"Preserve all existing candidates."
    source=SOURCE/"prepared"
    health=json.loads((SOURCE/"verdict.json").read_bytes())
    assert health["healthy"] and health["safe"] and health["after"]["metrics130"]["TAE"]==365
    manifest=json.loads((SUPPORT/"manifest.json").read_bytes())
    for row in manifest["files"]:
        path=SUPPORT/row["path"]
        assert path.stat().st_size==row["bytes"] and sha(path)==row["sha256"]
    sampled=list(csv.DictReader((SUPPORT/"illustrative-unmaterialized-28-IDs.csv").open(encoding="utf-8")))
    base28={r["vehicle_id"] for r in sampled}
    assert len(base28)==28
    before=ET.parse(source/"demand.rou.xml").getroot()
    vehicles={v.get("id"):v for v in before.findall("vehicle")}
    metadata=json.loads((source/"lane-intentions.json").read_bytes())
    intent={r["vehicle_id"]:r for r in metadata["vehicles"]}
    assert len(vehicles)==len(intent)==8640 and set(vehicles)==set(intent)
    selected=set(base28)
    extra=[]
    for cell in [288,289]:
        pool=sorted([i for i in vehicles if intent[i]["od_cell"]==cell and intent[i]["field_id"]==Z12],key=lambda i:(float(vehicles[i].get("depart")),i))
        used=sorted(j for j,i in enumerate(pool) if i in base28)
        assert len(pool)==31 and used==[3,11,19,27]
        bounds=[-1]+used+[len(pool)]
        gaps=[list(range(a+1,b)) for a,b in zip(bounds,bounds[1:]) if b-a>1]
        gap=min(gaps,key=lambda values:(-len(values),abs((values[0]+values[-1])/2-(len(pool)-1)/2),values[0]))
        rank=(gap[0]+gap[-1])//2
        extra.append(dict(vehicle_id=pool[rank],field_id=Z12,od_cell=cell,rank=rank,unselected_gap=gap,
            rule="Largest unused rank gap; ties choose midpoint nearest the pool center, then earlier gap."))
    if case_name=="remove30":
        selected.update(r["vehicle_id"] for r in extra)
    count=28 if case_name=="remove28" else 30
    assert len(selected)==count and base28<=selected
    assert Counter(intent[i]["field_id"] for i in selected)==Counter({Z12:13 if count==28 else 15,Z13:15})
    assert all(native_begin(vehicles[i])==11700 and intent[i]["od_cell"] in [287,288,289] for i in selected)
    after=copy.deepcopy(before)
    for vehicle in list(after.findall("vehicle")):
        if vehicle.get("id") in selected:
            after.remove(vehicle)
    remaining={v.get("id"):v for v in after.findall("vehicle")}
    expected_ids=set(vehicles)-selected
    assert set(remaining)==expected_ids and len(remaining)==8640-count
    assert all(ET.tostring(v)==ET.tostring(vehicles[i]) for i,v in remaining.items())
    assert [v.get("id") for v in after.findall("vehicle")]==[v.get("id") for v in before.findall("vehicle") if v.get("id") in expected_ids]
    assert [ET.tostring(v) for v in before if v.tag!="vehicle"]==[ET.tostring(v) for v in after if v.tag!="vehicle"]
    source_q=[0]*294
    new_q=[0]*294
    cell_keys={}
    for identity,vehicle in vehicles.items():
        edges=vehicle.find("route").get("edges").split()
        key=edges[0],edges[-1],native_begin(vehicle)
        cell=intent[identity]["od_cell"]
        if key in cell_keys:
            assert cell_keys[key]==cell
        cell_keys[key]=cell
        source_q[cell]+=1
    for identity,vehicle in remaining.items():
        edges=vehicle.find("route").get("edges").split()
        cell=cell_keys[edges[0],edges[-1],native_begin(vehicle)]
        assert cell==intent[identity]["od_cell"]
        new_q[cell]+=1
    changes=[dict(cell=i,source=source_q[i],candidate=new_q[i],delta=new_q[i]-source_q[i]) for i in range(294) if source_q[i]!=new_q[i]]
    assert [(r["cell"],r["delta"]) for r in changes]==[(287,-10),(288,-9 if count==28 else -10),(289,-9 if count==28 else -10)]
    metadata["vehicles"]=[r for r in metadata["vehicles"] if r["vehicle_id"] in expected_ids]
    assert {r["vehicle_id"] for r in metadata["vehicles"]}==expected_ids
    assert all(r==intent[r["vehicle_id"]] for r in metadata["vehicles"])
    assert all(i in remaining for i in vehicles if intent[i]["od_cell"] in [281,282,283])
    prepared=case/"prepared"
    shutil.copytree(source,prepared)
    ET.ElementTree(after).write(prepared/"demand.rou.xml",encoding="utf-8",xml_declaration=True)
    save(prepared/"lane-intentions.json",metadata)
    scenario=json.loads((source/"scenario.json").read_bytes())
    init_count=sum(float(v.get("depart"))<3600 for v in remaining.values())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,vehicles=len(remaining),
        main_vehicles=len(remaining)-init_count,initialization_vehicles=init_count,demand_sha256=sha(prepared/"demand.rou.xml"),
        demand_prior=f"Source is measured healthy minus30/TAE365. Before simulation, hypothetically thin{count} h13 requests from existing field/OD strata. Remaining{len(remaining)} IDs, XML attributes, times, routes, stops, fields and relative order are exact; no quantile regeneration or runtime removal.",
        time_prior="All surviving source departures including the previous535 cohort minus30 remain exact. Thinning follows source request ranks; actual changed response is unmeasured.",
        demand_thinning=dict(source_N=8640,candidate_N=len(remaining),removed_requests=count,
            field_counts={Z12:13 if count==28 else 15,Z13:15},actual_q_changes=changes,native_response_verified=False))
    save(prepared/"scenario.json",scenario)
    removals=[dict(vehicle_id=i,field_id=intent[i]["field_id"],source_od_cell=intent[i]["od_cell"],source_depart_s=float(vehicles[i].get("depart")),
        source_route=vehicles[i].find("route").get("edges").split(),source_stops=[dict(s.attrib) for s in vehicles[i].findall("stop")]) for i in sorted(selected,key=lambda i:(float(vehicles[i].get("depart")),i))]
    proposal=dict(schema="astra.hamburg.119-late-demand-thinning-proposal/v1",status="prepared",formal_result=False,new_native_runs=0,
        case=case_name,source_N=8640,candidate_N=len(remaining),source_main130_TAE=365,removed_vehicle_ids=sorted(selected),removals=removals,
        base28_removed_ids=sorted(base28),remove30_additional_two=extra if count==30 else [],nested_remove28_preserved=True,
        q_changes=changes,q_L1=count,earliest_removed_request_s=min(r["source_depart_s"] for r in removals),
        initialization_requests_unchanged=True,source_535_minus30_survivors_exact=True,
        claim_boundary="13/15 uses current observed surplus;15/15 instead initially compensates the observed carry count. Both are hypotheses, not trueOD or native predictions. N8640 is a source value, not a fixed user target. All real130+52 observations remain.")
    save(case/"proposal.json",proposal)
    save(case/"od-vector.json",dict(schema="astra.hamburg.explicit-request-od-vector/v1",vehicle_count=len(remaining),
        source_integer_counts=source_q,integer_counts=new_q,changed_cells=changes,l1_change=count,
        generation="Stable field-stratified thinning of existing requests; no quantile resampling."))
    with (case/"removed-requests.csv").open("w",encoding="utf-8",newline="") as handle:
        fields=["vehicle_id","field_id","source_od_cell","source_depart_s"]
        writer=csv.DictWriter(handle,fieldnames=fields,extrasaction="ignore")
        writer.writeheader()
        writer.writerows(removals)
    shutil.copy2(__file__,case/"executed-prepare.py")
    paths=[source/name for name in NAMES]+[SOURCE/"verdict.json",SUPPORT/"manifest.json",SUPPORT/"illustrative-unmaterialized-28-IDs.csv",Path(__file__)]
    save(case/"scope-proof.json",dict(schema="astra.hamburg.119-late-demand-thinning-scope/v1",status="pass",formal_result=False,new_native_runs=0,
        source_N=8640,N=len(remaining),actual_changes=count,source_hashes={str(p.resolve()):sha(p) for p in paths},
        prepared_hashes={name:sha(prepared/name) for name in NAMES},proposal_sha256=sha(case/"proposal.json"),od_vector_sha256=sha(case/"od-vector.json"),
        checks=dict(surviving_XML_exact=True,surviving_relative_order_exact=True,surviving_times_routes_stops_fields_types_exact=True,
            metadata_ID_set_exact=True,actual294_q_rebuilt=True,source_counter281_283_exact=True,nested_sample_exact=True,
            network_control_all_observations_exact=True,no_runtime_removal=True),
        required_native_checks="Report169 E1 intervals ending<=11700 against source on every attribute, then all130/52/182/40/208. Completion/unique expected contributions must use actual candidateN, not8640. Reject unsafe/missing records before comparing fit."))
    return check(case_name)


def check(case_name):
    case=ROOT/"cases"/case_name
    proof=json.loads((case/"scope-proof.json").read_bytes())
    assert all(proof["checks"].values())
    assert all(sha(Path(path))==value for path,value in proof["source_hashes"].items())
    assert all(sha(case/"prepared"/name)==value for name,value in proof["prepared_hashes"].items())
    assert sha(case/"proposal.json")==proof["proposal_sha256"] and sha(case/"od-vector.json")==proof["od_vector_sha256"]
    vehicles=ET.parse(case/"prepared/demand.rou.xml").getroot().findall("vehicle")
    intent=json.loads((case/"prepared/lane-intentions.json").read_bytes())["vehicles"]
    vector=json.loads((case/"od-vector.json").read_bytes())
    assert len(vehicles)==len(intent)==sum(vector["integer_counts"])==proof["N"]
    assert {v.get("id") for v in vehicles}=={r["vehicle_id"] for r in intent}
    for name in ["network.net.xml","control.add.xml","field-loops.add.xml","expected-counts.csv","initialization-counts.csv"]:
        assert (case/"prepared"/name).read_bytes()==(SOURCE/"prepared"/name).read_bytes()
    return dict(status="pass",new_native_runs=0,case=str(case),source_N=8640,candidate_N=proof["N"],removed_requests=proof["actual_changes"],
        scope_sha256=sha(case/"scope-proof.json"),proposal_sha256=sha(case/"proposal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=["remove28","remove30"],required=True)
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare(args.case) if args.prepare else check(args.case)))
