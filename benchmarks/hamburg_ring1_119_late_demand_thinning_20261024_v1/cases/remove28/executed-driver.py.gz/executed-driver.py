"""Measure one saved variable-N demand; never remove vehicles during simulation."""

import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import time
import traceback
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "outputs/hamburg-535z4-tail-offset-20261024-v1/cases/minus30"
SHARED = REPO / "outputs/hamburg-209-ordinal-full-evaluation-20261024-v1/run_full.py"
SHARED_SHA = "7226de8dd9159ca45fcbcc72e712048d4654553f9fc9232304c3fb69de6719e0"
COUNTS = {"remove28": 8612, "remove30": 8610}
CASE = None


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


assert sha(SHARED) == SHARED_SHA
BASE = runpy.run_path(str(SHARED))


def source_health():
    verdict = json.loads((SOURCE / "verdict.json").read_bytes())
    after = verdict["after"]
    assert after["healthy"] and after["safe"] and verdict["unique_intended_fields"]
    assert after["metrics130"]["TAE"] == 365 and after["event_count"] == 8640
    return {"status": "pass", "source_N": 8640, "source_main130_TAE": 365,
        "path": str(SOURCE / "verdict.json"), "sha256": sha(SOURCE / "verdict.json")}


def check():
    assert runpy.run_path(str(ROOT / "prepare_thinning.py"))["check"](CASE.name)["status"] == "pass"
    runtime, _ = BASE["REUSED"]["check_runtime"]()
    sys.path.insert(0, str(REPO / "plugins/astra-sumo/src"))
    os.environ["PYTHONPATH"] = os.pathsep.join(map(str, [REPO / ".venv/Lib/site-packages", REPO / "plugins/astra-sumo/src"]))
    runtime["child_pythonpath"] = os.environ["PYTHONPATH"]
    parent = json.loads((SOURCE / "preflight.json").read_bytes())["runtime"]
    assert runtime["modules"] == parent["modules"] and runtime["native_library"] == parent["native_library"]
    assert all(sha(path) == value for path, value in parent["binaries"].items())
    runtime["binaries"] = parent["binaries"]
    original, candidate = [ET.parse(folder / "prepared/demand.rou.xml").getroot() for folder in (SOURCE, CASE)]
    before, after = [{row.get("id"): ET.tostring(row) for row in xml.findall("vehicle")} for xml in (original, candidate)]
    ids, count = set(after), len(candidate.findall("vehicle"))
    assert count == len(ids) == COUNTS[CASE.name] and len(before) == 8640 and ids < before.keys()
    assert all(after[identity] == before[identity] for identity in ids)
    assert [row.get("id") for row in original.findall("vehicle") if row.get("id") in ids] == [row.get("id") for row in candidate.findall("vehicle")]
    assert [ET.tostring(row) for row in original if row.tag != "vehicle"] == [ET.tostring(row) for row in candidate if row.tag != "vehicle"]
    fields = json.loads((CASE / "prepared/lane-intentions.json").read_bytes())["vehicles"]
    assert len(fields) == count and {row["vehicle_id"] for row in fields} == ids
    original_intents = {row["vehicle_id"]: row for row in json.loads((SOURCE / "prepared/lane-intentions.json").read_bytes())["vehicles"]}
    assert all(row == original_intents[row["vehicle_id"]] for row in fields)
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes
    assert _body_hold_nodes(CASE / "prepared") == _body_hold_nodes(SOURCE / "prepared")
    request = json.loads((SOURCE / "evaluation/native/native-request.json").read_bytes())
    driver = {key: request[key] for key in ("backend", "junction_body_hold", "junction_body_hold_nodes", "all_stopped_timeout_s", "monitor_interval_s")}
    assert driver["backend"] == "libsumo" and driver["junction_body_hold"] and driver["monitor_interval_s"] is None
    assert tuple(driver["junction_body_hold_nodes"]) == _body_hold_nodes(CASE / "prepared")
    for name in ("network.net.xml", "control.add.xml", "field-loops.add.xml", "expected-counts.csv", "initialization-counts.csv"):
        assert (CASE / "prepared" / name).read_bytes() == (SOURCE / "prepared" / name).read_bytes()
    paths = [Path(__file__), SHARED, ROOT / "prepare_thinning.py", CASE / "scope-proof.json", CASE / "proposal.json",
        SOURCE / "verdict.json", SOURCE / "preflight.json", SOURCE / "evaluation/native/native-request.json",
        BASE["RUNTIME_HELPER"], BASE["AUDIT_HELPER"], BASE["AUDIT_HELPER"].parent / "audit_scope.py"]
    paths += list((SOURCE / "prepared").iterdir())
    if (CASE / "od-vector.json").exists():
        paths.append(CASE / "od-vector.json")
    paths += [REPO / "plugins/astra-sumo/src/astra_sumo/core" / name for name in
        ("detector_demand_replay.py", "detector_demand.py", "hamburg_od_spsa.py", "hamburg_readme_results.py", "simulation_stall.py", "lane_section_hold.py", "route_sensor_matrix.py")]
    plan_path = CASE / "measurement-plan.json"
    if not plan_path.exists():
        save(plan_path, {"formal_result": False, "native_runs": 0, "source_hashes": {str(path): sha(path) for path in paths},
            "prepared_hashes": {path.name: sha(path) for path in (CASE / "prepared").iterdir()},
            "source_health": source_health(), "source_N": 8640, "candidate_N": count,
            "end_s": 14400, "step_s": .1, "seed": 104, "backend": "libsumo", "prefix_cutoff_s": 11700})
    plan = json.loads(plan_path.read_bytes())
    assert plan["candidate_N"] == count and all(sha(path) == value for path, value in plan["source_hashes"].items())
    assert all(sha(CASE / "prepared" / name) == value for name, value in plan["prepared_hashes"].items())
    return {"status": "pass", "native_runs": 0, "source_N": 8640, "candidate_N": count, "runtime": runtime,
        "original_driver_scope": driver, "source_health": source_health()}


def prefix_comparison(measured):
    source = {tuple((row.get("id"), float(row.get("begin")), float(row.get("end")))): dict(row.attrib)
        for row in ET.parse(SOURCE / "evaluation/native/field-counts.xml").getroot().findall("interval") if float(row.get("end")) <= 11700}
    after = {key: row for key, row in measured["periodic"].items() if key[2] <= 11700}
    assert len(source) == len(after) == 169
    differences = [{"detector_id": key[0], "begin": key[1], "end": key[2], "source": source.get(key), "candidate": after.get(key)}
        for key in sorted(source.keys() | after.keys()) if source.get(key) != after.get(key)]
    return {"native_runs": 0, "cutoff_s": 11700, "intervals": 169, "all169_native_e1_attributes_identical": source == after, "differences": differences}


def run(checked):
    from astra_sumo.core.detector_demand_replay import run_point_detector_demand
    from astra_sumo.core.hamburg_od_spsa import _body_hold_nodes, summarize_hamburg_od_measurement
    from astra_sumo.core.route_sensor_matrix import read_contributing_e1_passages
    prepared, evaluation, count = CASE / "prepared", CASE / "evaluation", checked["candidate_N"]
    assert not evaluation.exists() and not (CASE / "verdict.json").exists(), "Preserve existing and partial results."
    evaluation.mkdir()
    for name in ("demand.rou.xml", "lane-intentions.json"):
        shutil.copyfile(prepared / name, evaluation / name)
    shutil.copyfile(__file__, CASE / "executed-driver.py")
    implementation = CASE / "measurement-implementation"
    implementation.mkdir(exist_ok=False)
    for path in json.loads((CASE / "measurement-plan.json").read_bytes())["source_hashes"]:
        path = Path(path)
        if path.suffix == ".py":
            shutil.copyfile(path, implementation / path.name)
    save(CASE / "preflight.json", {**checked, "scope_sha256": sha(CASE / "scope-proof.json"),
        "measurement_plan_sha256": sha(CASE / "measurement-plan.json"), "end_s": 14400, "step_length_s": .1, "seed": 104,
        "implementation_sha256": {path.name: sha(path) for path in implementation.iterdir()}})
    started = time.perf_counter()
    try:
        native = run_point_detector_demand(net_file=prepared / "network.net.xml", route_file=prepared / "demand.rou.xml",
            e1_additional_file=prepared / "field-loops.add.xml", expected_counts_csv=prepared / "expected-counts.csv",
            output_dir=evaluation / "native", end_s=14400, timeout_seconds=4800, step_length=.1, seed=104, backend="libsumo",
            all_stopped_timeout_s=checked["original_driver_scope"]["all_stopped_timeout_s"],
            sumo_binary=str(REPO / ".venv/Lib/site-packages/sumo/bin/sumo.exe"), signal_program_file=prepared / "control.add.xml",
            lane_intentions_file=prepared / "lane-intentions.json", junction_body_hold=True, junction_body_hold_nodes=_body_hold_nodes(prepared))
        assert native["vehicle_count"] == count and Path(native["stall_monitor"]["traci_module"]).resolve().is_relative_to(REPO / ".venv")
        assert native["stall_monitor"]["native_library"] == checked["runtime"]["native_library"]
        summarize_hamburg_od_measurement(prepared_dir=prepared, proposal_dir=evaluation, native=native)
        events = read_contributing_e1_passages(instant_file=evaluation / "native/instant-e1.xml", periodic_file=evaluation / "native/field-counts.xml",
            detector_ids=native["instant_to_periodic_ids"], step_length=.1)
        assert events["reconciled"]
        compact = evaluation / "contributing-passages.json.gz"
        compact.write_bytes(gzip.compress(json.dumps(events).encode(), mtime=0))
        tools = BASE["audit_tools"]()
        measured = tools["evidence"](prepared, evaluation, compact, count)
        fields = {row["vehicle_id"]: row["field_id"] for row in json.loads((prepared / "lane-intentions.json").read_bytes())["vehicles"]}
        requested = {row.get("id"): row.find("route").get("edges") for row in ET.parse(prepared / "demand.rou.xml").getroot().findall("vehicle")}
        ids = set(requested)
        routes = ET.parse(evaluation / "native/vehicle-routes.xml").getroot().findall("vehicle")
        route_ids = {row.get("id") for row in routes}
        repeated = [{"vehicle_id": identity, "field": field, "count": n} for identity, rows in measured["by_vehicle"].items()
            for field, n in Counter(row["detector_id"] for row in rows).items() if n > 1]
        outside = [{"vehicle_id": identity, "actual_field": row["detector_id"], "intended_field": fields.get(identity)}
            for identity, rows in measured["by_vehicle"].items() for row in rows if row["detector_id"] != fields.get(identity)]
        one_each = ids == fields.keys() == measured["by_vehicle"].keys() and all(len(measured["by_vehicle"][i]) == 1 for i in ids) and not outside
        identity_checks = {"demand_intent_trip_route_event_ID_sets_equal": ids == fields.keys() == measured["tripinfo"].keys() == route_ids == measured["by_vehicle"].keys(),
            "one_intended_complete_event_per_request": one_each,
            "all_routes_arrived": len(routes) == count and all(float(row.get("arrival", "-1")) >= 0 for row in routes),
            "actual_route_edges_match_remaining_requests": all(row.find("route").get("edges") == requested.get(row.get("id")) for row in routes),
            "no_repeated_or_outside_fields": not repeated and not outside}
        for name, rows in (("main130", measured["main"]), ("initialization52", measured["initial"]), ("all182", measured["initial"] + measured["main"]),
            ("native208", list(measured["periodic"].values())), ("station40", measured["stations"])):
            tools["table"](evaluation / (name + "-comparison.csv"), rows)
        protected = [row for row in measured["initial"] + measured["main"] if row["detector_id"] in {
            "hh_0535_Z_5_30894", "hh_0535_Z_6_33855", "hh_0535_Z_7_29316", "hh_0535_Z_8_34287"}]
        assert len(protected) == 56
        tools["table"](evaluation / "535-all56.csv", protected)
        prefix = prefix_comparison(measured)
        save(evaluation / "prefix169-comparison.json", prefix)
        after = {key: measured[key] for key in ("metrics130", "metrics52", "metrics182", "station40_MAE", "completion", "safe", "healthy", "event_count")}
        parent = json.loads((SOURCE / "verdict.json").read_bytes())["after"]
        verdict = {"status": "diagnostic_measurement_complete", "formal_result": False, "source_N": 8640, "candidate_N": count,
            "source_minus30_parent": parent, "after": after, "identity_checks": identity_checks, "repeated_vehicle_fields": repeated,
            "contributions_outside_prior_primary_intention": outside, "unique_intended_fields": all(identity_checks.values()),
            "all53556": tools["metrics"](protected), "healthy": measured["healthy"], "safe": measured["safe"],
            "prefix169_all_native_attributes_identical": prefix["all169_native_e1_attributes_identical"],
            "exact_count_fit_main130": after["metrics130"]["TAE"] == 0,
            "main130_zero_and_healthy": after["metrics130"]["TAE"] == 0 and measured["healthy"] and measured["safe"] and all(identity_checks.values()),
            "main130_TAE_delta_from_source": after["metrics130"]["TAE"] - parent["metrics130"]["TAE"],
            "claim_boundary": "Sparse requests were removed before simulation, with all remaining requests and all130/52 real targets retained. Actual XML N governs completion. No runtime vehicle removal or count intervention occurs. All130/52/182/208/40,53556,prefix169,identity,safety and backlog are reported. These hypothetical OD changes do not establish true demand or field-certified zero."}
    except Exception as error:
        verdict = {"status": "invalid", "formal_result": False, "source_N": 8640, "candidate_N": count,
            "error": f"{type(error).__name__}: {error}", "partial_outputs_preserved": True}
        (CASE / "failure.log").write_text(traceback.format_exc(), encoding="utf-8")
    verdict["elapsed_s"] = time.perf_counter() - started
    save(CASE / "verdict.json", verdict)
    print(json.dumps(verdict, ensure_ascii=False))
    if verdict["status"] == "invalid":
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=COUNTS, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    CASE = ROOT / "cases" / args.case
    checked = check()
    if args.check_only:
        print(json.dumps({key: value for key, value in checked.items() if key != "runtime"}))
    else:
        run(checked)
