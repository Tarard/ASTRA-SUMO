"""Prepare one nested43-request refinement from the fixed minus30 source."""
import argparse
from collections import Counter
import copy
import csv
import gzip
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import prepare_thinning as base

ROOT=Path(__file__).resolve().parent
CASE=ROOT/"cases/remove43"
BEST=ROOT/"cases/remove30"
SOURCE=base.SOURCE
QUOTAS={"hh_0119_Z_11_28853":{286:2},"hh_0535_Z_4_33055":{277:6,292:5}}


def prepare():
    assert not CASE.exists(),"Preserve existing refinements."
    base.check("remove30")
    source=SOURCE/"prepared"
    before=ET.parse(source/"demand.rou.xml").getroot()
    old={v.get("id"):v for v in before.findall("vehicle")}
    best_vehicles={v.get("id"):v for v in ET.parse(BEST/"prepared/demand.rou.xml").getroot().findall("vehicle")}
    metadata=json.loads((source/"lane-intentions.json").read_bytes())
    intent={r["vehicle_id"]:r for r in metadata["vehicles"]}
    parent=json.loads((BEST/"proposal.json").read_bytes())
    old_removed=set(parent["removed_vehicle_ids"])
    assert len(old_removed)==30 and set(best_vehicles)==set(old)-old_removed
    best_health=json.loads((BEST/"verdict.json").read_bytes())
    assert best_health["healthy"] and best_health["safe"] and best_health["after"]["metrics130"]["TAE"]==337
    source_health=json.loads((SOURCE/"verdict.json").read_bytes())
    assert source_health["healthy"] and source_health["after"]["metrics130"]["TAE"]==365
    payload=json.loads(gzip.decompress((BEST/"evaluation/contributing-passages.json.gz").read_bytes()))
    events={r["vehicle_id"]:r for r in payload["passages"]}
    assert payload["reconciled"] and set(events)==set(best_vehicles)
    facts={}
    extra=[]
    for field,quotas in QUOTAS.items():
        all_ids=[i for i in best_vehicles if intent[i]["field_id"]==field]
        h13=[i for i in all_ids if base.native_begin(old[i])==11700]
        last=[i for i in all_ids if events[i]["interval_begin_s"]==11700]
        expected_h13=14 if field=="hh_0119_Z_11_28853" else 44
        expected_carry=2 if expected_h13==14 else 11
        assert len(h13)==expected_h13 and all(events[i]["interval_begin_s"]==11700 for i in h13)
        assert len(last)==expected_h13+expected_carry and not any(events[i]["interval_begin_s"]>=12600 for i in all_ids)
        facts[field]=dict(planned_h13=len(h13),native_last=len(last),h12_carry=expected_carry,tail=0)
        for cell,quota in sorted(quotas.items()):
            pool=sorted([i for i in h13 if intent[i]["od_cell"]==cell],key=lambda i:(float(old[i].get("depart")),i))
            assert len(pool)==(14 if cell==286 else 22)
            ranks=[math.floor((j+.5)*len(pool)/quota) for j in range(quota)]
            for rank in ranks:
                identity=pool[rank]
                assert identity not in old_removed
                extra.append(dict(vehicle_id=identity,field_id=field,source_od_cell=cell,source_depart_s=float(old[identity].get("depart")),
                    pool_size=len(pool),quota=quota,uniform_midpoint_rank=rank,current_best_notification_s=events[identity]["notification_time_s"]))
    assert len(extra)==13
    assert Counter(r["source_od_cell"] for r in extra)==Counter({286:2,277:6,292:5})
    selected=old_removed|{r["vehicle_id"] for r in extra}
    assert len(selected)==43
    after=copy.deepcopy(before)
    for vehicle in list(after.findall("vehicle")):
        if vehicle.get("id") in selected:
            after.remove(vehicle)
    remaining={v.get("id"):v for v in after.findall("vehicle")}
    assert len(remaining)==8597 and set(remaining)==set(best_vehicles)-{r["vehicle_id"] for r in extra}
    assert all(ET.tostring(v)==ET.tostring(old[i])==ET.tostring(best_vehicles[i]) for i,v in remaining.items())
    assert [v.get("id") for v in after.findall("vehicle")]==[v.get("id") for v in before.findall("vehicle") if v.get("id") not in selected]
    assert [ET.tostring(v) for v in after if v.tag!="vehicle"]==[ET.tostring(v) for v in before if v.tag!="vehicle"]
    assert all(i in remaining for i in old if intent[i]["od_cell"] in [281,282,283])
    source_q=[0]*294
    new_q=[0]*294
    actual_cells={}
    for identity,v in old.items():
        edges=v.find("route").get("edges").split()
        key=edges[0],edges[-1],base.native_begin(v)
        cell=intent[identity]["od_cell"]
        if key in actual_cells:
            assert actual_cells[key]==cell
        actual_cells[key]=cell
        source_q[cell]+=1
    for identity,v in remaining.items():
        edges=v.find("route").get("edges").split()
        cell=actual_cells[edges[0],edges[-1],base.native_begin(v)]
        assert cell==intent[identity]["od_cell"]
        new_q[cell]+=1
    q_changes=[dict(cell=i,source=source_q[i],candidate=new_q[i],delta=new_q[i]-source_q[i]) for i in range(294) if source_q[i]!=new_q[i]]
    assert sum(abs(r["delta"]) for r in q_changes)==43
    metadata["vehicles"]=[r for r in metadata["vehicles"] if r["vehicle_id"] in remaining]
    assert all(r==intent[r["vehicle_id"]] for r in metadata["vehicles"])
    prepared=CASE/"prepared"
    shutil.copytree(source,prepared)
    ET.ElementTree(after).write(prepared/"demand.rou.xml",encoding="utf-8",xml_declaration=True)
    base.save(prepared/"lane-intentions.json",metadata)
    scenario=json.loads((source/"scenario.json").read_bytes())
    init=sum(float(v.get("depart"))<3600 for v in remaining.values())
    scenario.update(status="review_required",formal_result=False,exact_count_fit=False,vehicles=8597,main_vehicles=8597-init,
        initialization_vehicles=init,demand_sha256=base.sha(prepared/"demand.rou.xml"),
        demand_prior="Nested hypothetical thinning from original minus30/TAE365. Preserve the30 removals of measured current-best remove30/TAE337, then thin2 h13 Z11 and11 h13 535Z4 requests. All8597 survivor XML/time/route/stop/field/ID/order values remain exact. No runtime removal or quantile regeneration.",
        time_prior="All survivor request times, including source535 minus30 timing, remain exact. Native response to the reduced hypothetical requests is unmeasured.",
        demand_thinning=dict(source_N=8640,current_best_N=8610,candidate_N=8597,removed_requests=43,new_relative_to_best=13,actual_q_changes=q_changes,native_response_verified=False))
    base.save(prepared/"scenario.json",scenario)
    removals=[dict(vehicle_id=i,field_id=intent[i]["field_id"],source_od_cell=intent[i]["od_cell"],source_depart_s=float(old[i].get("depart"))) for i in sorted(selected)]
    proposal=dict(schema="astra.hamburg.119-late-demand-refinement/v1",status="prepared",formal_result=False,new_native_runs=0,case="remove43",
        source_N=8640,current_best_N=8610,candidate_N=8597,source_main130_TAE=365,current_best_main130_TAE=337,
        removed_vehicle_ids=sorted(selected),removals=removals,nested_base_remove30_ids=sorted(old_removed),additional13=extra,
        current_best_pool_facts=facts,quotas=QUOTAS,source_remove30_proposal_sha256=base.sha(BEST/"proposal.json"),
        q_changes=q_changes,q_L1=43,earliest_removed_request_s=min(float(old[i].get("depart")) for i in selected),
        claim_boundary="Hypothetical h13 quantity compensation for observed surplus/carry. No trueOD identification or native count prediction. Keep all real130+52 rows; candidate population is an input estimate, not noninsertion/discard.")
    base.save(CASE/"proposal.json",proposal)
    base.save(CASE/"od-vector.json",dict(schema="astra.hamburg.explicit-request-od-vector/v1",vehicle_count=8597,
        source_integer_counts=source_q,integer_counts=new_q,changed_cells=q_changes,l1_change=43,generation="Nested stable instance thinning; no quantile generation."))
    with (CASE/"additional13.csv").open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(extra[0]))
        writer.writeheader()
        writer.writerows(extra)
    shutil.copy2(__file__,CASE/"executed-prepare-refinement.py")
    paths=[source/name for name in base.NAMES]+[BEST/"prepared"/name for name in base.NAMES]
    paths += [SOURCE/"verdict.json",BEST/"verdict.json",BEST/"proposal.json",BEST/"evaluation/contributing-passages.json.gz",Path(base.__file__),Path(__file__)]
    base.save(CASE/"scope-proof.json",dict(schema="astra.hamburg.119-late-demand-refinement-scope/v1",status="pass",formal_result=False,new_native_runs=0,
        source_N=8640,current_best_N=8610,N=8597,actual_changes=43,additional_changes_from_best=13,
        source_hashes={str(p.resolve()):base.sha(p) for p in paths},prepared_hashes={name:base.sha(prepared/name) for name in base.NAMES},
        proposal_sha256=base.sha(CASE/"proposal.json"),od_vector_sha256=base.sha(CASE/"od-vector.json"),
        checks=dict(nested_remove30_exact=True,only13_additional_h13_requests=True,surviving_XML_from_both_sources_exact=True,
            surviving_relative_order_exact=True,all_survivor_times_routes_stops_fields_IDs_exact=True,intent_exact_subset=True,
            actual294_q_rebuilt=True,counter281_283_preserved=True,network_control_real_observations_exact=True,no_runtime_remove=True),
        required_native_checks="All169 E1 intervals ending<=11700 must be compared on every native attribute. Report all130/52/182/40/208; health/completion/one expected event per request use actualN8597. No prediction replaces native measurement."))
    return check()


def check(case_name="remove43"):
    assert case_name=="remove43"
    checked=base.check(case_name)
    proof=json.loads((CASE/"scope-proof.json").read_bytes())
    proposal=json.loads((CASE/"proposal.json").read_bytes())
    current=json.loads((BEST/"proposal.json").read_bytes())
    assert set(current["removed_vehicle_ids"])<set(proposal["removed_vehicle_ids"])
    assert len(set(proposal["removed_vehicle_ids"])-set(current["removed_vehicle_ids"]))==13
    assert Counter(r["source_od_cell"] for r in proposal["additional13"])==Counter({286:2,277:6,292:5})
    assert proof["current_best_N"]==8610 and proof["N"]==8597
    return dict(checked,current_best_N=8610,current_best_main130_TAE=337)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=["remove43"],default="remove43")
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--prepare",action="store_true")
    action.add_argument("--check-only",action="store_true")
    args=parser.parse_args()
    print(json.dumps(prepare() if args.prepare else check(args.case)))
