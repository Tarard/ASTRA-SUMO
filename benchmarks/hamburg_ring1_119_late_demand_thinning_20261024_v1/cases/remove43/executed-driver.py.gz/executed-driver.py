"""Measure the saved nested43-request thinning with the unchanged variable-N driver."""

import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil


ROOT = Path(__file__).resolve().parent
CASE = ROOT / "cases/remove43"
SHARED = ROOT / "run_thinning.py"
SHARED_SHA = "17a4debb6f631564cd23ae6cd17b9173d05d65c3d0829cf96992bf03ae4a0eb9"
COMPARISON = ROOT / "cases/remove30/verdict.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert sha(SHARED) == SHARED_SHA
API = runpy.run_path(str(SHARED))
STATE = API["check"].__globals__
STATE.update(CASE=CASE, COUNTS={**API["COUNTS"], "remove43": 8597}, __file__=str(Path(__file__)))
BASE_SAVE = API["save"]


def comparison():
    verdict = json.loads(COMPARISON.read_bytes())
    assert verdict["healthy"] and verdict["safe"] and verdict["unique_intended_fields"]
    assert verdict["candidate_N"] == 8610 and verdict["after"]["metrics130"]["TAE"] == 337
    return {"path": str(COMPARISON), "sha256": sha(COMPARISON), "N": 8610, "after": verdict["after"]}


def save(path, value):
    if path == CASE / "preflight.json":
        value["shared_measurement_driver"] = {"path": str(CASE / "executed-shared-driver.py"),
            "sha256": sha(CASE / "executed-shared-driver.py"), "source_sha256": SHARED_SHA}
        value["measured_remove30_reference"] = comparison()
    if path == CASE / "verdict.json":
        value["measured_remove30_reference"] = comparison()
        value["study_role"] = "nested43_request_thinning_from_source_minus30"
        if "after" in value:
            value["main130_TAE_delta_from_remove30"] = value["after"]["metrics130"]["TAE"] - 337
    BASE_SAVE(path, value)


STATE["save"] = save


def check():
    assert runpy.run_path(str(ROOT / "prepare_refinement.py"))["check"]("remove43")["status"] == "pass"
    plan_path = CASE / "measurement-plan.json"
    fresh = not plan_path.exists()
    checked = API["check"]()
    plan = json.loads(plan_path.read_bytes())
    bindings = {str(SHARED): SHARED_SHA, str(ROOT / "prepare_refinement.py"): sha(ROOT / "prepare_refinement.py"), str(COMPARISON): sha(COMPARISON)}
    if fresh:
        plan["source_hashes"].update(bindings)
        save(plan_path, plan)
    assert all(plan["source_hashes"].get(path) == digest == sha(path) for path, digest in bindings.items())
    checked["measured_remove30_reference"] = comparison()
    return checked


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("remove43",), default="remove43")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check-only", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    checked = check()
    if args.check_only:
        print(json.dumps({key: value for key, value in checked.items() if key != "runtime"}))
    else:
        assert not (CASE / "evaluation").exists() and not (CASE / "verdict.json").exists(), "Preserve previous and partial outputs."
        assert not (CASE / "executed-shared-driver.py").exists(), "Preserve the bound shared-driver snapshot."
        shutil.copyfile(SHARED, CASE / "executed-shared-driver.py")
        API["run"](checked)
