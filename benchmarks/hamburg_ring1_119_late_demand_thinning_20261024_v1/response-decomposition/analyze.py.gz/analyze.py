"""Separate historical input subtraction from the actual surviving-ID response."""
from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
REPO=ROOT.parents[1]
SOURCE=REPO/"outputs/hamburg-535z4-tail-offset-20261024-v1/cases/minus30/evaluation"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(name,rows):
    with (OUT/name).open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def read_events(folder,expected_n):
    payload=json.loads(gzip.decompress((folder/"contributing-passages.json.gz").read_bytes()))
    events={r["vehicle_id"]:r for r in payload["passages"]}
    raw={(r.get("id"),int(float(r.get("begin")))):int(r.get("nVehContrib")) for r in ET.parse(folder/"native/field-counts.xml").getroot().findall("interval")}
    counted=Counter((r["detector_id"],int(r["interval_begin_s"])) for r in events.values())
    assert payload["reconciled"] and len(events)==len(payload["passages"])==expected_n and len(raw)==208
    assert all(counted[key]==value for key,value in raw.items())
    return events,raw


def main():
    assert not (OUT/"manifest.json").exists(),"Preserve sealed decomposition."
    source,source_counts=read_events(SOURCE,8640)
    truth={(r["detector_id"],int(float(r["begin"]))):int(r["expected_total"]) for r in csv.DictReader((SOURCE/"all182-comparison.csv").open(encoding="utf-8"))}
    intent={r["vehicle_id"]:r for r in json.loads((SOURCE/"lane-intentions.json").read_bytes())["vehicles"]}
    main_keys=[key for key in truth if key[1]>=3600]

    def metrics(values,keys=main_keys):
        return dict(TAE=sum(abs(values[k]-truth[k]) for k in keys),SSE=sum((values[k]-truth[k])**2 for k in keys))

    cases,case_events,case_removed={}, {}, {}
    field_rows,changed_rows=[],[]
    bound=[SOURCE/"contributing-passages.json.gz",SOURCE/"native/field-counts.xml",SOURCE/"all182-comparison.csv",SOURCE/"lane-intentions.json"]
    for name in ["remove28","remove30"]:
        case=ROOT/"cases"/name
        folder=case/"evaluation"
        proposal=json.loads((case/"proposal.json").read_bytes())
        removed=set(proposal["removed_vehicle_ids"])
        after,counts=read_events(folder,proposal["candidate_N"])
        assert set(after)==set(source)-removed
        assert all(after[i]["detector_id"]==source[i]["detector_id"]==intent[i]["field_id"] for i in after)
        removed_counts=Counter((source[i]["detector_id"],int(source[i]["interval_begin_s"])) for i in removed)
        direct={key:value-removed_counts[key] for key,value in source_counts.items()}
        historical=[dict(vehicle_id=i,field_id=source[i]["detector_id"],source_od_cell=intent[i]["od_cell"],source_notification_s=source[i]["notification_time_s"],
            source_begin=int(source[i]["interval_begin_s"]),candidate_input_status="not_in_candidate_input") for i in sorted(removed)]
        survivors=[]
        for identity,b in after.items():
            a=source[identity]
            delta=b["notification_time_s"]-a["notification_time_s"]
            if abs(delta)>1e-7:
                survivors.append(dict(vehicle_id=identity,field_id=a["detector_id"],source_od_cell=intent[identity]["od_cell"],
                    source_notification_s=a["notification_time_s"],actual_notification_s=b["notification_time_s"],actual_shift_s=delta,
                    source_begin=int(a["interval_begin_s"]),actual_begin=int(b["interval_begin_s"])))
        survivors.sort(key=lambda r:(r["field_id"],r["source_notification_s"]))
        moves=[r for r in survivors if r["source_begin"]!=r["actual_begin"]]
        assert {r["vehicle_id"] for r in moves}=={"od_0288_v00069","od_0289_v00069"}
        assert all(r["source_begin"]==12600 and r["actual_begin"]==11700 for r in moves)
        for key in source_counts:
            survivor_delta=counts[key]-direct[key]
            if removed_counts[key] or survivor_delta:
                changed_rows.append(dict(case=name,detector_id=key[0],begin=key[1],end=key[1]+900,expected=truth.get(key),
                    source=source_counts[key],historical_removed=removed_counts[key],source_survivor_only_count=direct[key],
                    actual_survivor_redistribution=survivor_delta,actual_candidate=counts[key]))
        for field in sorted({k[0] for k in truth}):
            keys=[k for k in main_keys if k[0]==field]
            old,virtual,new=metrics(source_counts,keys),metrics(direct,keys),metrics(counts,keys)
            field_rows.append(dict(case=name,detector_id=field,source_TAE=old["TAE"],historical_subtraction_TAE=virtual["TAE"],actual_TAE=new["TAE"],
                source_SSE=old["SSE"],historical_subtraction_SSE=virtual["SSE"],actual_SSE=new["SSE"],
                historical_removed_last=removed_counts[field,11700],actual_last=counts[field,11700],
                actual_survivor_last_delta=counts[field,11700]-direct[field,11700]))
        write_csv(name+"-historical-removed.csv",historical)
        write_csv(name+"-survivor-time-response.csv",survivors)
        write_csv(name+"-survivor-bin-response.csv",moves)
        cases[name]=dict(source_N=8640,actual_N=len(after),historical_input_removals=len(removed),
            source_main=metrics(source_counts),historical_subtraction_only=metrics(direct),actual_main=metrics(counts),
            survivor_time_changes=len(survivors),survivor_bin_changes=moves,
            actual_last_fields={f:counts[f,11700] for f in ["hh_0119_Z_12_31546","hh_0119_Z_13_34018"]},
            prefix169=json.loads((folder/"prefix169-comparison.json").read_bytes()))
        case_events[name],case_removed[name]=after,removed
        bound += [case/"proposal.json",case/"scope-proof.json",case/"od-vector.json",case/"verdict.json",folder/"contributing-passages.json.gz",folder/"native/field-counts.xml",folder/"prefix169-comparison.json"]
    extra=case_removed["remove30"]-case_removed["remove28"]
    common=set(case_events["remove30"])
    assert extra=={"od_0288_v00035","od_0289_v00035"}
    assert set(case_events["remove28"])-extra==common
    common_bin_changes=[i for i in common if case_events["remove28"][i]["interval_begin_s"]!=case_events["remove30"][i]["interval_begin_s"]]
    assert not common_bin_changes
    pair_extra=[dict(vehicle_id=i,field_id=case_events["remove28"][i]["detector_id"],remove28_actual_notification_s=case_events["remove28"][i]["notification_time_s"],
                    remove28_actual_begin=int(case_events["remove28"][i]["interval_begin_s"]),remove30_status="not_in_candidate_input") for i in sorted(extra)]
    write_csv("remove28-to-remove30-extra-two.csv",pair_extra)
    write_csv("field13-direct-and-survivor.csv",field_rows)
    write_csv("changed208-direct-and-survivor.csv",changed_rows)
    report=dict(schema="astra.hamburg.119-h13-thinning-response/v1",status="pass",new_native_runs=0,cases=cases,
        nested_pair=dict(extra_input_removals=pair_extra,common_survivors=8610,common_survivor_bin_changes=0,
            common_survivor_time_changes=sum(abs(case_events["remove28"][i]["notification_time_s"]-case_events["remove30"][i]["notification_time_s"])>1e-7 for i in common)),
        interpretation="Removed input requests are not noninserted/discarded native vehicles. Historical subtraction is separated from actual surviving-ID redistribution:the same two Z12 tail vehicles refill the last main interval in both cases. All other fields keep their per-bin counts. Betweenremove28 andremove30,the two additional current Z12 input deletions explain the entire2-count last-window difference;common survivors may change times but none change bins.",
        boundaries="All real130+52 observations remain. This is count-fit evidence for hypothetical demand, not trueOD identification. No absent deleted-ID event is inserted as a zero measurement. No new simulation, input mutation or runtime vehicle removal occurs in this audit.")
    (OUT/"summary.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (OUT/"source-hashes.json").write_text(json.dumps([dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in bound],indent=2)+"\n",encoding="utf-8")
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="manifest.json"]
    (OUT/"manifest.json").write_text(json.dumps(dict(schema="astra.evidence.manifest/v1",new_native_runs=0,files=files),indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status="pass",manifest_sha256=sha(OUT/"manifest.json"),actual_main={k:r["actual_main"] for k,r in cases.items()},nested_common_bin_changes=0)))


if __name__=="__main__":
    main()
